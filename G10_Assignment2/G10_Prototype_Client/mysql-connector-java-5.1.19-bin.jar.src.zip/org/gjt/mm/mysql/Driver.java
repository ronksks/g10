package org.gjt.mm.mysql;

import java.sql.SQLException;

public class Driver
  extends com.mysql.jdbc.Driver
{
  public Driver()
    throws SQLException
  {}
}


/* Location:              C:\Users\Static\Desktop\G10_Prototype_Client.jar!\mysql-connector-java-5.1.19-bin.jar!\org\gjt\mm\mysql\Driver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */