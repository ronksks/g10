/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.ParameterMetaData;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CallableStatement
/*      */   extends PreparedStatement
/*      */   implements java.sql.CallableStatement
/*      */ {
/*      */   protected static final Constructor<?> JDBC_4_CSTMT_2_ARGS_CTOR;
/*      */   protected static final Constructor<?> JDBC_4_CSTMT_4_ARGS_CTOR;
/*      */   private static final int NOT_OUTPUT_PARAMETER_INDICATOR = Integer.MIN_VALUE;
/*      */   private static final String PARAMETER_NAMESPACE_PREFIX = "@com_mysql_jdbc_outparam_";
/*      */   
/*      */   static
/*      */   {
/*   63 */     if (Util.isJdbc4()) {
/*      */       try {
/*   65 */         JDBC_4_CSTMT_2_ARGS_CTOR = Class.forName("com.mysql.jdbc.JDBC4CallableStatement").getConstructor(new Class[] { MySQLConnection.class, CallableStatementParamInfo.class });
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*   70 */         JDBC_4_CSTMT_4_ARGS_CTOR = Class.forName("com.mysql.jdbc.JDBC4CallableStatement").getConstructor(new Class[] { MySQLConnection.class, String.class, String.class, Boolean.TYPE });
/*      */ 
/*      */ 
/*      */       }
/*      */       catch (SecurityException e)
/*      */       {
/*      */ 
/*   77 */         throw new RuntimeException(e);
/*      */       } catch (NoSuchMethodException e) {
/*   79 */         throw new RuntimeException(e);
/*      */       } catch (ClassNotFoundException e) {
/*   81 */         throw new RuntimeException(e);
/*      */       }
/*      */     } else {
/*   84 */       JDBC_4_CSTMT_4_ARGS_CTOR = null;
/*   85 */       JDBC_4_CSTMT_2_ARGS_CTOR = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected static class CallableStatementParam
/*      */   {
/*      */     int desiredJdbcType;
/*      */     
/*      */     int index;
/*      */     
/*      */     int inOutModifier;
/*      */     
/*      */     boolean isIn;
/*      */     
/*      */     boolean isOut;
/*      */     
/*      */     int jdbcType;
/*      */     
/*      */     short nullability;
/*      */     
/*      */     String paramName;
/*      */     
/*      */     int precision;
/*      */     
/*      */     int scale;
/*      */     String typeName;
/*      */     
/*      */     CallableStatementParam(String name, int idx, boolean in, boolean out, int jdbcType, String typeName, int precision, int scale, short nullability, int inOutModifier)
/*      */     {
/*  115 */       this.paramName = name;
/*  116 */       this.isIn = in;
/*  117 */       this.isOut = out;
/*  118 */       this.index = idx;
/*      */       
/*  120 */       this.jdbcType = jdbcType;
/*  121 */       this.typeName = typeName;
/*  122 */       this.precision = precision;
/*  123 */       this.scale = scale;
/*  124 */       this.nullability = nullability;
/*  125 */       this.inOutModifier = inOutModifier;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     protected Object clone()
/*      */       throws CloneNotSupportedException
/*      */     {
/*  134 */       return super.clone();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected class CallableStatementParamInfo
/*      */   {
/*      */     String catalogInUse;
/*      */     
/*      */ 
/*      */     boolean isFunctionCall;
/*      */     
/*      */     String nativeSql;
/*      */     
/*      */     int numParameters;
/*      */     
/*      */     List<CallableStatement.CallableStatementParam> parameterList;
/*      */     
/*      */     Map<String, CallableStatement.CallableStatementParam> parameterMap;
/*      */     
/*  155 */     boolean isReadOnlySafeProcedure = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  160 */     boolean isReadOnlySafeChecked = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     CallableStatementParamInfo(CallableStatementParamInfo fullParamInfo)
/*      */     {
/*  170 */       this.nativeSql = CallableStatement.this.originalSql;
/*  171 */       this.catalogInUse = CallableStatement.this.currentCatalog;
/*  172 */       this.isFunctionCall = fullParamInfo.isFunctionCall;
/*      */       
/*  174 */       int[] localParameterMap = CallableStatement.this.placeholderToParameterIndexMap;
/*  175 */       int parameterMapLength = localParameterMap.length;
/*      */       
/*  177 */       this.isReadOnlySafeProcedure = fullParamInfo.isReadOnlySafeProcedure;
/*  178 */       this.isReadOnlySafeChecked = fullParamInfo.isReadOnlySafeChecked;
/*  179 */       this.parameterList = new ArrayList(fullParamInfo.numParameters);
/*  180 */       this.parameterMap = new HashMap(fullParamInfo.numParameters);
/*      */       
/*  182 */       if (this.isFunctionCall)
/*      */       {
/*  184 */         this.parameterList.add(fullParamInfo.parameterList.get(0));
/*      */       }
/*      */       
/*  187 */       int offset = this.isFunctionCall ? 1 : 0;
/*      */       
/*  189 */       for (int i = 0; i < parameterMapLength; i++) {
/*  190 */         if (localParameterMap[i] != 0) {
/*  191 */           CallableStatement.CallableStatementParam param = (CallableStatement.CallableStatementParam)fullParamInfo.parameterList.get(localParameterMap[i] + offset);
/*      */           
/*  193 */           this.parameterList.add(param);
/*  194 */           this.parameterMap.put(param.paramName, param);
/*      */         }
/*      */       }
/*      */       
/*  198 */       this.numParameters = this.parameterList.size();
/*      */     }
/*      */     
/*      */     CallableStatementParamInfo(ResultSet paramTypesRs)
/*      */       throws SQLException
/*      */     {
/*  204 */       boolean hadRows = paramTypesRs.last();
/*      */       
/*  206 */       this.nativeSql = CallableStatement.this.originalSql;
/*  207 */       this.catalogInUse = CallableStatement.this.currentCatalog;
/*  208 */       this.isFunctionCall = CallableStatement.this.callingStoredFunction;
/*      */       
/*  210 */       if (hadRows) {
/*  211 */         this.numParameters = paramTypesRs.getRow();
/*      */         
/*  213 */         this.parameterList = new ArrayList(this.numParameters);
/*  214 */         this.parameterMap = new HashMap(this.numParameters);
/*      */         
/*  216 */         paramTypesRs.beforeFirst();
/*      */         
/*  218 */         addParametersFromDBMD(paramTypesRs);
/*      */       } else {
/*  220 */         this.numParameters = 0;
/*      */       }
/*      */       
/*  223 */       if (this.isFunctionCall) {
/*  224 */         this.numParameters += 1;
/*      */       }
/*      */     }
/*      */     
/*      */     private void addParametersFromDBMD(ResultSet paramTypesRs) throws SQLException
/*      */     {
/*  230 */       int i = 0;
/*      */       
/*  232 */       while (paramTypesRs.next()) {
/*  233 */         String paramName = paramTypesRs.getString(4);
/*  234 */         int inOutModifier = paramTypesRs.getInt(5);
/*      */         
/*  236 */         boolean isOutParameter = false;
/*  237 */         boolean isInParameter = false;
/*      */         
/*  239 */         if ((i == 0) && (this.isFunctionCall)) {
/*  240 */           isOutParameter = true;
/*  241 */           isInParameter = false;
/*  242 */         } else if (inOutModifier == 2) {
/*  243 */           isOutParameter = true;
/*  244 */           isInParameter = true;
/*  245 */         } else if (inOutModifier == 1) {
/*  246 */           isOutParameter = false;
/*  247 */           isInParameter = true;
/*  248 */         } else if (inOutModifier == 4) {
/*  249 */           isOutParameter = true;
/*  250 */           isInParameter = false;
/*      */         }
/*      */         
/*  253 */         int jdbcType = paramTypesRs.getInt(6);
/*  254 */         String typeName = paramTypesRs.getString(7);
/*  255 */         int precision = paramTypesRs.getInt(8);
/*  256 */         int scale = paramTypesRs.getInt(10);
/*  257 */         short nullability = paramTypesRs.getShort(12);
/*      */         
/*  259 */         CallableStatement.CallableStatementParam paramInfoToAdd = new CallableStatement.CallableStatementParam(paramName, i++, isInParameter, isOutParameter, jdbcType, typeName, precision, scale, nullability, inOutModifier);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  264 */         this.parameterList.add(paramInfoToAdd);
/*  265 */         this.parameterMap.put(paramName, paramInfoToAdd);
/*      */       }
/*      */     }
/*      */     
/*      */     protected void checkBounds(int paramIndex) throws SQLException {
/*  270 */       int localParamIndex = paramIndex - 1;
/*      */       
/*  272 */       if ((paramIndex < 0) || (localParamIndex >= this.numParameters)) {
/*  273 */         throw SQLError.createSQLException(Messages.getString("CallableStatement.11") + paramIndex + Messages.getString("CallableStatement.12") + this.numParameters + Messages.getString("CallableStatement.13"), "S1009", CallableStatement.this.getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected Object clone()
/*      */       throws CloneNotSupportedException
/*      */     {
/*  286 */       return super.clone();
/*      */     }
/*      */     
/*      */     CallableStatement.CallableStatementParam getParameter(int index) {
/*  290 */       return (CallableStatement.CallableStatementParam)this.parameterList.get(index);
/*      */     }
/*      */     
/*      */     CallableStatement.CallableStatementParam getParameter(String name) {
/*  294 */       return (CallableStatement.CallableStatementParam)this.parameterMap.get(name);
/*      */     }
/*      */     
/*      */     public String getParameterClassName(int arg0) throws SQLException {
/*  298 */       String mysqlTypeName = getParameterTypeName(arg0);
/*      */       
/*  300 */       boolean isBinaryOrBlob = (StringUtils.indexOfIgnoreCase(mysqlTypeName, "BLOB") != -1) || (StringUtils.indexOfIgnoreCase(mysqlTypeName, "BINARY") != -1);
/*      */       
/*      */ 
/*  303 */       boolean isUnsigned = StringUtils.indexOfIgnoreCase(mysqlTypeName, "UNSIGNED") != -1;
/*      */       
/*  305 */       int mysqlTypeIfKnown = 0;
/*      */       
/*  307 */       if (StringUtils.startsWithIgnoreCase(mysqlTypeName, "MEDIUMINT")) {
/*  308 */         mysqlTypeIfKnown = 9;
/*      */       }
/*      */       
/*  311 */       return ResultSetMetaData.getClassNameForJavaType(getParameterType(arg0), isUnsigned, mysqlTypeIfKnown, isBinaryOrBlob, false);
/*      */     }
/*      */     
/*      */     public int getParameterCount() throws SQLException
/*      */     {
/*  316 */       if (this.parameterList == null) {
/*  317 */         return 0;
/*      */       }
/*      */       
/*  320 */       return this.parameterList.size();
/*      */     }
/*      */     
/*      */     public int getParameterMode(int arg0) throws SQLException {
/*  324 */       checkBounds(arg0);
/*      */       
/*  326 */       return getParameter(arg0 - 1).inOutModifier;
/*      */     }
/*      */     
/*      */     public int getParameterType(int arg0) throws SQLException {
/*  330 */       checkBounds(arg0);
/*      */       
/*  332 */       return getParameter(arg0 - 1).jdbcType;
/*      */     }
/*      */     
/*      */     public String getParameterTypeName(int arg0) throws SQLException {
/*  336 */       checkBounds(arg0);
/*      */       
/*  338 */       return getParameter(arg0 - 1).typeName;
/*      */     }
/*      */     
/*      */     public int getPrecision(int arg0) throws SQLException {
/*  342 */       checkBounds(arg0);
/*      */       
/*  344 */       return getParameter(arg0 - 1).precision;
/*      */     }
/*      */     
/*      */     public int getScale(int arg0) throws SQLException {
/*  348 */       checkBounds(arg0);
/*      */       
/*  350 */       return getParameter(arg0 - 1).scale;
/*      */     }
/*      */     
/*      */     public int isNullable(int arg0) throws SQLException {
/*  354 */       checkBounds(arg0);
/*      */       
/*  356 */       return getParameter(arg0 - 1).nullability;
/*      */     }
/*      */     
/*      */     public boolean isSigned(int arg0) throws SQLException {
/*  360 */       checkBounds(arg0);
/*      */       
/*  362 */       return false;
/*      */     }
/*      */     
/*      */     Iterator<CallableStatement.CallableStatementParam> iterator() {
/*  366 */       return this.parameterList.iterator();
/*      */     }
/*      */     
/*      */     int numberOfParameters() {
/*  370 */       return this.numParameters;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected class CallableStatementParamInfoJDBC3
/*      */     extends CallableStatement.CallableStatementParamInfo
/*      */     implements ParameterMetaData
/*      */   {
/*      */     CallableStatementParamInfoJDBC3(ResultSet paramTypesRs)
/*      */       throws SQLException
/*      */     {
/*  385 */       super(paramTypesRs);
/*      */     }
/*      */     
/*      */     public CallableStatementParamInfoJDBC3(CallableStatement.CallableStatementParamInfo paramInfo) {
/*  389 */       super(paramInfo);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean isWrapperFor(Class<?> iface)
/*      */       throws SQLException
/*      */     {
/*  408 */       CallableStatement.this.checkClosed();
/*      */       
/*      */ 
/*      */ 
/*  412 */       return iface.isInstance(this);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public Object unwrap(Class<?> iface)
/*      */       throws SQLException
/*      */     {
/*      */       try
/*      */       {
/*  433 */         return Util.cast(iface, this);
/*      */       } catch (ClassCastException cce) {
/*  435 */         throw SQLError.createSQLException("Unable to unwrap to " + iface.toString(), "S1009", CallableStatement.this.getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static String mangleParameterName(String origParameterName)
/*      */   {
/*  447 */     if (origParameterName == null) {
/*  448 */       return null;
/*      */     }
/*      */     
/*  451 */     int offset = 0;
/*      */     
/*  453 */     if ((origParameterName.length() > 0) && (origParameterName.charAt(0) == '@'))
/*      */     {
/*  455 */       offset = 1;
/*      */     }
/*      */     
/*  458 */     StringBuffer paramNameBuf = new StringBuffer("@com_mysql_jdbc_outparam_".length() + origParameterName.length());
/*      */     
/*      */ 
/*  461 */     paramNameBuf.append("@com_mysql_jdbc_outparam_");
/*  462 */     paramNameBuf.append(origParameterName.substring(offset));
/*      */     
/*  464 */     return paramNameBuf.toString();
/*      */   }
/*      */   
/*  467 */   private boolean callingStoredFunction = false;
/*      */   
/*      */   private ResultSetInternalMethods functionReturnValueResults;
/*      */   
/*  471 */   private boolean hasOutputParams = false;
/*      */   
/*      */ 
/*      */   private ResultSetInternalMethods outputParameterResults;
/*      */   
/*      */ 
/*  477 */   protected boolean outputParamWasNull = false;
/*      */   
/*      */ 
/*      */ 
/*      */   private int[] parameterIndexToRsIndex;
/*      */   
/*      */ 
/*      */ 
/*      */   protected CallableStatementParamInfo paramInfo;
/*      */   
/*      */ 
/*      */   private CallableStatementParam returnValueParam;
/*      */   
/*      */ 
/*      */   private int[] placeholderToParameterIndexMap;
/*      */   
/*      */ 
/*      */ 
/*      */   public CallableStatement(MySQLConnection conn, CallableStatementParamInfo paramInfo)
/*      */     throws SQLException
/*      */   {
/*  498 */     super(conn, paramInfo.nativeSql, paramInfo.catalogInUse);
/*      */     
/*  500 */     this.paramInfo = paramInfo;
/*  501 */     this.callingStoredFunction = this.paramInfo.isFunctionCall;
/*      */     
/*  503 */     if (this.callingStoredFunction) {
/*  504 */       this.parameterCount += 1;
/*      */     }
/*      */     
/*  507 */     this.retrieveGeneratedKeys = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static CallableStatement getInstance(MySQLConnection conn, String sql, String catalog, boolean isFunctionCall)
/*      */     throws SQLException
/*      */   {
/*  519 */     if (!Util.isJdbc4()) {
/*  520 */       return new CallableStatement(conn, sql, catalog, isFunctionCall);
/*      */     }
/*      */     
/*  523 */     return (CallableStatement)Util.handleNewInstance(JDBC_4_CSTMT_4_ARGS_CTOR, new Object[] { conn, sql, catalog, Boolean.valueOf(isFunctionCall) }, conn.getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static CallableStatement getInstance(MySQLConnection conn, CallableStatementParamInfo paramInfo)
/*      */     throws SQLException
/*      */   {
/*  537 */     if (!Util.isJdbc4()) {
/*  538 */       return new CallableStatement(conn, paramInfo);
/*      */     }
/*      */     
/*  541 */     return (CallableStatement)Util.handleNewInstance(JDBC_4_CSTMT_2_ARGS_CTOR, new Object[] { conn, paramInfo }, conn.getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private synchronized void generateParameterMap()
/*      */     throws SQLException
/*      */   {
/*  549 */     if (this.paramInfo == null) {
/*  550 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  557 */     int parameterCountFromMetaData = this.paramInfo.getParameterCount();
/*      */     
/*      */ 
/*      */ 
/*  561 */     if (this.callingStoredFunction) {
/*  562 */       parameterCountFromMetaData--;
/*      */     }
/*      */     
/*  565 */     if ((this.paramInfo != null) && (this.parameterCount != parameterCountFromMetaData))
/*      */     {
/*  567 */       this.placeholderToParameterIndexMap = new int[this.parameterCount];
/*      */       
/*  569 */       int startPos = this.callingStoredFunction ? StringUtils.indexOfIgnoreCase(this.originalSql, "SELECT") : StringUtils.indexOfIgnoreCase(this.originalSql, "CALL");
/*      */       
/*      */ 
/*  572 */       if (startPos != -1) {
/*  573 */         int parenOpenPos = this.originalSql.indexOf('(', startPos + 4);
/*      */         
/*  575 */         if (parenOpenPos != -1) {
/*  576 */           int parenClosePos = StringUtils.indexOfIgnoreCaseRespectQuotes(parenOpenPos, this.originalSql, ")", '\'', true);
/*      */           
/*      */ 
/*  579 */           if (parenClosePos != -1) {
/*  580 */             List<?> parsedParameters = StringUtils.split(this.originalSql.substring(parenOpenPos + 1, parenClosePos), ",", "'\"", "'\"", true);
/*      */             
/*  582 */             int numParsedParameters = parsedParameters.size();
/*      */             
/*      */ 
/*      */ 
/*  586 */             if (numParsedParameters != this.parameterCount) {}
/*      */             
/*      */ 
/*      */ 
/*  590 */             int placeholderCount = 0;
/*      */             
/*  592 */             for (int i = 0; i < numParsedParameters; i++) {
/*  593 */               if (((String)parsedParameters.get(i)).equals("?")) {
/*  594 */                 this.placeholderToParameterIndexMap[(placeholderCount++)] = i;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CallableStatement(MySQLConnection conn, String sql, String catalog, boolean isFunctionCall)
/*      */     throws SQLException
/*      */   {
/*  618 */     super(conn, sql, catalog);
/*      */     
/*  620 */     this.callingStoredFunction = isFunctionCall;
/*      */     
/*  622 */     if (!this.callingStoredFunction) {
/*  623 */       if (!StringUtils.startsWithIgnoreCaseAndWs(sql, "CALL"))
/*      */       {
/*  625 */         fakeParameterTypes(false);
/*      */       } else {
/*  627 */         determineParameterTypes();
/*      */       }
/*      */       
/*  630 */       generateParameterMap();
/*      */     } else {
/*  632 */       determineParameterTypes();
/*  633 */       generateParameterMap();
/*      */       
/*  635 */       this.parameterCount += 1;
/*      */     }
/*      */     
/*  638 */     this.retrieveGeneratedKeys = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addBatch()
/*      */     throws SQLException
/*      */   {
/*  647 */     setOutParams();
/*      */     
/*  649 */     super.addBatch();
/*      */   }
/*      */   
/*      */   private synchronized CallableStatementParam checkIsOutputParam(int paramIndex)
/*      */     throws SQLException
/*      */   {
/*  655 */     if (this.callingStoredFunction) {
/*  656 */       if (paramIndex == 1)
/*      */       {
/*  658 */         if (this.returnValueParam == null) {
/*  659 */           this.returnValueParam = new CallableStatementParam("", 0, false, true, 12, "VARCHAR", 0, 0, (short)2, 5);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  665 */         return this.returnValueParam;
/*      */       }
/*      */       
/*      */ 
/*  669 */       paramIndex--;
/*      */     }
/*      */     
/*  672 */     checkParameterIndexBounds(paramIndex);
/*      */     
/*  674 */     int localParamIndex = paramIndex - 1;
/*      */     
/*  676 */     if (this.placeholderToParameterIndexMap != null) {
/*  677 */       localParamIndex = this.placeholderToParameterIndexMap[localParamIndex];
/*      */     }
/*      */     
/*  680 */     CallableStatementParam paramDescriptor = this.paramInfo.getParameter(localParamIndex);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  686 */     if (this.connection.getNoAccessToProcedureBodies()) {
/*  687 */       paramDescriptor.isOut = true;
/*  688 */       paramDescriptor.isIn = true;
/*  689 */       paramDescriptor.inOutModifier = 2;
/*  690 */     } else if (!paramDescriptor.isOut) {
/*  691 */       throw SQLError.createSQLException(Messages.getString("CallableStatement.9") + paramIndex + Messages.getString("CallableStatement.10"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  697 */     this.hasOutputParams = true;
/*      */     
/*  699 */     return paramDescriptor;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private synchronized void checkParameterIndexBounds(int paramIndex)
/*      */     throws SQLException
/*      */   {
/*  710 */     this.paramInfo.checkBounds(paramIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void checkStreamability()
/*      */     throws SQLException
/*      */   {
/*  722 */     if ((this.hasOutputParams) && (createStreamingResultSet())) {
/*  723 */       throw SQLError.createSQLException(Messages.getString("CallableStatement.14"), "S1C00", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */   public synchronized void clearParameters() throws SQLException
/*      */   {
/*  729 */     super.clearParameters();
/*      */     try
/*      */     {
/*  732 */       if (this.outputParameterResults != null) {
/*  733 */         this.outputParameterResults.close();
/*      */       }
/*      */     } finally {
/*  736 */       this.outputParameterResults = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private synchronized void fakeParameterTypes(boolean isReallyProcedure)
/*      */     throws SQLException
/*      */   {
/*  747 */     Field[] fields = new Field[13];
/*      */     
/*  749 */     fields[0] = new Field("", "PROCEDURE_CAT", 1, 0);
/*  750 */     fields[1] = new Field("", "PROCEDURE_SCHEM", 1, 0);
/*  751 */     fields[2] = new Field("", "PROCEDURE_NAME", 1, 0);
/*  752 */     fields[3] = new Field("", "COLUMN_NAME", 1, 0);
/*  753 */     fields[4] = new Field("", "COLUMN_TYPE", 1, 0);
/*  754 */     fields[5] = new Field("", "DATA_TYPE", 5, 0);
/*  755 */     fields[6] = new Field("", "TYPE_NAME", 1, 0);
/*  756 */     fields[7] = new Field("", "PRECISION", 4, 0);
/*  757 */     fields[8] = new Field("", "LENGTH", 4, 0);
/*  758 */     fields[9] = new Field("", "SCALE", 5, 0);
/*  759 */     fields[10] = new Field("", "RADIX", 5, 0);
/*  760 */     fields[11] = new Field("", "NULLABLE", 5, 0);
/*  761 */     fields[12] = new Field("", "REMARKS", 1, 0);
/*      */     
/*  763 */     String procName = isReallyProcedure ? extractProcedureName() : null;
/*      */     
/*  765 */     byte[] procNameAsBytes = null;
/*      */     try
/*      */     {
/*  768 */       procNameAsBytes = procName == null ? null : StringUtils.getBytes(procName, "UTF-8");
/*      */     } catch (UnsupportedEncodingException ueEx) {
/*  770 */       procNameAsBytes = StringUtils.s2b(procName, this.connection);
/*      */     }
/*      */     
/*  773 */     ArrayList<ByteArrayRow> resultRows = new ArrayList();
/*      */     
/*  775 */     for (int i = 0; i < this.parameterCount; i++) {
/*  776 */       byte[][] row = new byte[13][];
/*  777 */       row[0] = null;
/*  778 */       row[1] = null;
/*  779 */       row[2] = procNameAsBytes;
/*  780 */       row[3] = StringUtils.s2b(String.valueOf(i), this.connection);
/*      */       
/*  782 */       row[4] = StringUtils.s2b(String.valueOf(1), this.connection);
/*      */       
/*      */ 
/*      */ 
/*  786 */       row[5] = StringUtils.s2b(String.valueOf(12), this.connection);
/*      */       
/*  788 */       row[6] = StringUtils.s2b("VARCHAR", this.connection);
/*  789 */       row[7] = StringUtils.s2b(Integer.toString(65535), this.connection);
/*  790 */       row[8] = StringUtils.s2b(Integer.toString(65535), this.connection);
/*  791 */       row[9] = StringUtils.s2b(Integer.toString(0), this.connection);
/*  792 */       row[10] = StringUtils.s2b(Integer.toString(10), this.connection);
/*      */       
/*  794 */       row[11] = StringUtils.s2b(Integer.toString(2), this.connection);
/*      */       
/*      */ 
/*      */ 
/*  798 */       row[12] = null;
/*      */       
/*  800 */       resultRows.add(new ByteArrayRow(row, getExceptionInterceptor()));
/*      */     }
/*      */     
/*  803 */     ResultSet paramTypesRs = DatabaseMetaData.buildResultSet(fields, resultRows, this.connection);
/*      */     
/*      */ 
/*  806 */     convertGetProcedureColumnsToInternalDescriptors(paramTypesRs);
/*      */   }
/*      */   
/*      */   private synchronized void determineParameterTypes() throws SQLException
/*      */   {
/*  811 */     ResultSet paramTypesRs = null;
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  816 */       String procName = extractProcedureName();
/*  817 */       String quotedId = "";
/*      */       try {
/*  819 */         quotedId = this.connection.supportsQuotedIdentifiers() ? this.connection.getMetaData().getIdentifierQuoteString() : "";
/*      */ 
/*      */       }
/*      */       catch (SQLException sqlEx)
/*      */       {
/*  824 */         AssertionFailedException.shouldNotHappen(sqlEx);
/*      */       }
/*      */       
/*  827 */       List<?> parseList = StringUtils.splitDBdotName(procName, "", quotedId, this.connection.isNoBackslashEscapesSet());
/*      */       
/*  829 */       String tmpCatalog = "";
/*      */       
/*  831 */       if (parseList.size() == 2) {
/*  832 */         tmpCatalog = (String)parseList.get(0);
/*  833 */         procName = (String)parseList.get(1);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  838 */       java.sql.DatabaseMetaData dbmd = this.connection.getMetaData();
/*      */       
/*  840 */       boolean useCatalog = false;
/*      */       
/*  842 */       if (tmpCatalog.length() <= 0) {
/*  843 */         useCatalog = true;
/*      */       }
/*      */       
/*  846 */       paramTypesRs = dbmd.getProcedureColumns((this.connection.versionMeetsMinimum(5, 0, 2)) && (useCatalog) ? this.currentCatalog : tmpCatalog, null, procName, "%");
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  851 */       boolean hasResults = false;
/*      */       try {
/*  853 */         if (paramTypesRs.next()) {
/*  854 */           paramTypesRs.previous();
/*  855 */           hasResults = true;
/*      */         }
/*      */       }
/*      */       catch (Exception e) {}
/*      */       
/*  860 */       if (hasResults) {
/*  861 */         convertGetProcedureColumnsToInternalDescriptors(paramTypesRs);
/*      */       } else {
/*  863 */         fakeParameterTypes(true);
/*      */       }
/*      */     } finally {
/*  866 */       SQLException sqlExRethrow = null;
/*      */       
/*  868 */       if (paramTypesRs != null) {
/*      */         try {
/*  870 */           paramTypesRs.close();
/*      */         } catch (SQLException sqlEx) {
/*  872 */           sqlExRethrow = sqlEx;
/*      */         }
/*      */         
/*  875 */         paramTypesRs = null;
/*      */       }
/*      */       
/*  878 */       if (sqlExRethrow != null) {
/*  879 */         throw sqlExRethrow;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private synchronized void convertGetProcedureColumnsToInternalDescriptors(ResultSet paramTypesRs) throws SQLException {
/*  885 */     if (!this.connection.isRunningOnJDK13()) {
/*  886 */       this.paramInfo = new CallableStatementParamInfoJDBC3(paramTypesRs);
/*      */     }
/*      */     else {
/*  889 */       this.paramInfo = new CallableStatementParamInfo(paramTypesRs);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean execute()
/*      */     throws SQLException
/*      */   {
/*  899 */     boolean returnVal = false;
/*      */     
/*  901 */     checkClosed();
/*      */     
/*  903 */     checkStreamability();
/*      */     
/*  905 */     synchronized (this.connection) {
/*  906 */       setInOutParamsOnServer();
/*  907 */       setOutParams();
/*      */       
/*  909 */       returnVal = super.execute();
/*      */       
/*  911 */       if (this.callingStoredFunction) {
/*  912 */         this.functionReturnValueResults = this.results;
/*  913 */         this.functionReturnValueResults.next();
/*  914 */         this.results = null;
/*      */       }
/*      */       
/*  917 */       retrieveOutParams();
/*      */     }
/*      */     
/*  920 */     if (!this.callingStoredFunction) {
/*  921 */       return returnVal;
/*      */     }
/*      */     
/*      */ 
/*  925 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized ResultSet executeQuery()
/*      */     throws SQLException
/*      */   {
/*  934 */     checkClosed();
/*      */     
/*  936 */     checkStreamability();
/*      */     
/*  938 */     ResultSet execResults = null;
/*      */     
/*  940 */     synchronized (this.connection) {
/*  941 */       setInOutParamsOnServer();
/*  942 */       setOutParams();
/*      */       
/*  944 */       execResults = super.executeQuery();
/*      */       
/*  946 */       retrieveOutParams();
/*      */     }
/*      */     
/*  949 */     return execResults;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int executeUpdate()
/*      */     throws SQLException
/*      */   {
/*  958 */     int returnVal = -1;
/*      */     
/*  960 */     checkClosed();
/*      */     
/*  962 */     checkStreamability();
/*      */     
/*  964 */     if (this.callingStoredFunction) {
/*  965 */       execute();
/*      */       
/*  967 */       return -1;
/*      */     }
/*      */     
/*  970 */     synchronized (this.connection) {
/*  971 */       setInOutParamsOnServer();
/*  972 */       setOutParams();
/*      */       
/*  974 */       returnVal = super.executeUpdate();
/*      */       
/*  976 */       retrieveOutParams();
/*      */     }
/*      */     
/*  979 */     return returnVal;
/*      */   }
/*      */   
/*      */   private String extractProcedureName() throws SQLException {
/*  983 */     String sanitizedSql = StringUtils.stripComments(this.originalSql, "`\"'", "`\"'", true, false, true, true);
/*      */     
/*      */ 
/*      */ 
/*  987 */     int endCallIndex = StringUtils.indexOfIgnoreCase(sanitizedSql, "CALL ");
/*      */     
/*  989 */     int offset = 5;
/*      */     
/*  991 */     if (endCallIndex == -1) {
/*  992 */       endCallIndex = StringUtils.indexOfIgnoreCase(sanitizedSql, "SELECT ");
/*      */       
/*  994 */       offset = 7;
/*      */     }
/*      */     
/*  997 */     if (endCallIndex != -1) {
/*  998 */       StringBuffer nameBuf = new StringBuffer();
/*      */       
/* 1000 */       String trimmedStatement = sanitizedSql.substring(endCallIndex + offset).trim();
/*      */       
/*      */ 
/* 1003 */       int statementLength = trimmedStatement.length();
/*      */       
/* 1005 */       for (int i = 0; i < statementLength; i++) {
/* 1006 */         char c = trimmedStatement.charAt(i);
/*      */         
/* 1008 */         if ((Character.isWhitespace(c)) || (c == '(') || (c == '?')) {
/*      */           break;
/*      */         }
/* 1011 */         nameBuf.append(c);
/*      */       }
/*      */       
/*      */ 
/* 1015 */       return nameBuf.toString();
/*      */     }
/*      */     
/* 1018 */     throw SQLError.createSQLException(Messages.getString("CallableStatement.1"), "S1000", getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized String fixParameterName(String paramNameIn)
/*      */     throws SQLException
/*      */   {
/* 1035 */     if (((paramNameIn == null) || (paramNameIn.length() == 0)) && (!hasParametersView())) {
/* 1036 */       throw SQLError.createSQLException(Messages.getString("CallableStatement.0") + paramNameIn == null ? Messages.getString("CallableStatement.15") : Messages.getString("CallableStatement.16"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1042 */     if ((paramNameIn == null) && (hasParametersView())) {
/* 1043 */       paramNameIn = "nullpn";
/*      */     }
/*      */     
/* 1046 */     if (this.connection.getNoAccessToProcedureBodies()) {
/* 1047 */       throw SQLError.createSQLException("No access to parameters by name when connection has been configured not to access procedure bodies", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 1051 */     return mangleParameterName(paramNameIn);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized Array getArray(int i)
/*      */     throws SQLException
/*      */   {
/* 1066 */     ResultSetInternalMethods rs = getOutputParameters(i);
/*      */     
/* 1068 */     Array retValue = rs.getArray(mapOutputParameterIndexToRsIndex(i));
/*      */     
/* 1070 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1072 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized Array getArray(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1080 */     ResultSetInternalMethods rs = getOutputParameters(0);
/*      */     
/*      */ 
/* 1083 */     Array retValue = rs.getArray(fixParameterName(parameterName));
/*      */     
/* 1085 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1087 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized BigDecimal getBigDecimal(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1095 */     ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */     
/* 1097 */     BigDecimal retValue = rs.getBigDecimal(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */     
/*      */ 
/* 1100 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1102 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public synchronized BigDecimal getBigDecimal(int parameterIndex, int scale)
/*      */     throws SQLException
/*      */   {
/* 1123 */     ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */     
/* 1125 */     BigDecimal retValue = rs.getBigDecimal(mapOutputParameterIndexToRsIndex(parameterIndex), scale);
/*      */     
/*      */ 
/* 1128 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1130 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized BigDecimal getBigDecimal(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1138 */     ResultSetInternalMethods rs = getOutputParameters(0);
/*      */     
/*      */ 
/* 1141 */     BigDecimal retValue = rs.getBigDecimal(fixParameterName(parameterName));
/*      */     
/* 1143 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1145 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized Blob getBlob(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1152 */     ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */     
/* 1154 */     Blob retValue = rs.getBlob(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */     
/*      */ 
/* 1157 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1159 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized Blob getBlob(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1166 */     ResultSetInternalMethods rs = getOutputParameters(0);
/*      */     
/*      */ 
/* 1169 */     Blob retValue = rs.getBlob(fixParameterName(parameterName));
/*      */     
/* 1171 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1173 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized boolean getBoolean(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1181 */     ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */     
/* 1183 */     boolean retValue = rs.getBoolean(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */     
/*      */ 
/* 1186 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1188 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized boolean getBoolean(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1196 */     ResultSetInternalMethods rs = getOutputParameters(0);
/*      */     
/*      */ 
/* 1199 */     boolean retValue = rs.getBoolean(fixParameterName(parameterName));
/*      */     
/* 1201 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1203 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized byte getByte(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1210 */     ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */     
/* 1212 */     byte retValue = rs.getByte(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */     
/*      */ 
/* 1215 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1217 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized byte getByte(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1224 */     ResultSetInternalMethods rs = getOutputParameters(0);
/*      */     
/*      */ 
/* 1227 */     byte retValue = rs.getByte(fixParameterName(parameterName));
/*      */     
/* 1229 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1231 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized byte[] getBytes(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1238 */     ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */     
/* 1240 */     byte[] retValue = rs.getBytes(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */     
/*      */ 
/* 1243 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1245 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized byte[] getBytes(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1253 */     ResultSetInternalMethods rs = getOutputParameters(0);
/*      */     
/*      */ 
/* 1256 */     byte[] retValue = rs.getBytes(fixParameterName(parameterName));
/*      */     
/* 1258 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1260 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized Clob getClob(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1267 */     ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */     
/* 1269 */     Clob retValue = rs.getClob(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */     
/*      */ 
/* 1272 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1274 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized Clob getClob(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1281 */     ResultSetInternalMethods rs = getOutputParameters(0);
/*      */     
/*      */ 
/* 1284 */     Clob retValue = rs.getClob(fixParameterName(parameterName));
/*      */     
/* 1286 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1288 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized Date getDate(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1295 */     ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */     
/* 1297 */     Date retValue = rs.getDate(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */     
/*      */ 
/* 1300 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1302 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized Date getDate(int parameterIndex, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1310 */     ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */     
/* 1312 */     Date retValue = rs.getDate(mapOutputParameterIndexToRsIndex(parameterIndex), cal);
/*      */     
/*      */ 
/* 1315 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1317 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized Date getDate(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1324 */     ResultSetInternalMethods rs = getOutputParameters(0);
/*      */     
/*      */ 
/* 1327 */     Date retValue = rs.getDate(fixParameterName(parameterName));
/*      */     
/* 1329 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1331 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized Date getDate(String parameterName, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1340 */     ResultSetInternalMethods rs = getOutputParameters(0);
/*      */     
/*      */ 
/* 1343 */     Date retValue = rs.getDate(fixParameterName(parameterName), cal);
/*      */     
/* 1345 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1347 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized double getDouble(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1355 */     ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */     
/* 1357 */     double retValue = rs.getDouble(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */     
/*      */ 
/* 1360 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1362 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized double getDouble(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1370 */     ResultSetInternalMethods rs = getOutputParameters(0);
/*      */     
/*      */ 
/* 1373 */     double retValue = rs.getDouble(fixParameterName(parameterName));
/*      */     
/* 1375 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1377 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized float getFloat(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1384 */     ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */     
/* 1386 */     float retValue = rs.getFloat(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */     
/*      */ 
/* 1389 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1391 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized float getFloat(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1399 */     ResultSetInternalMethods rs = getOutputParameters(0);
/*      */     
/*      */ 
/* 1402 */     float retValue = rs.getFloat(fixParameterName(parameterName));
/*      */     
/* 1404 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1406 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized int getInt(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1413 */     ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */     
/* 1415 */     int retValue = rs.getInt(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */     
/*      */ 
/* 1418 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1420 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized int getInt(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1427 */     ResultSetInternalMethods rs = getOutputParameters(0);
/*      */     
/*      */ 
/* 1430 */     int retValue = rs.getInt(fixParameterName(parameterName));
/*      */     
/* 1432 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1434 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized long getLong(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1441 */     ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */     
/* 1443 */     long retValue = rs.getLong(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */     
/*      */ 
/* 1446 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1448 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized long getLong(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1455 */     ResultSetInternalMethods rs = getOutputParameters(0);
/*      */     
/*      */ 
/* 1458 */     long retValue = rs.getLong(fixParameterName(parameterName));
/*      */     
/* 1460 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1462 */     return retValue;
/*      */   }
/*      */   
/*      */   protected synchronized int getNamedParamIndex(String paramName, boolean forOut) throws SQLException
/*      */   {
/* 1467 */     if (this.connection.getNoAccessToProcedureBodies()) {
/* 1468 */       throw SQLError.createSQLException("No access to parameters by name when connection has been configured not to access procedure bodies", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1473 */     if ((paramName == null) || (paramName.length() == 0)) {
/* 1474 */       throw SQLError.createSQLException(Messages.getString("CallableStatement.2"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 1478 */     if (this.paramInfo == null) {
/* 1479 */       throw SQLError.createSQLException(Messages.getString("CallableStatement.3") + paramName + Messages.getString("CallableStatement.4"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1484 */     CallableStatementParam namedParamInfo = this.paramInfo.getParameter(paramName);
/*      */     
/*      */ 
/* 1487 */     if ((forOut) && (!namedParamInfo.isOut)) {
/* 1488 */       throw SQLError.createSQLException(Messages.getString("CallableStatement.5") + paramName + Messages.getString("CallableStatement.6"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1495 */     if (this.placeholderToParameterIndexMap == null) {
/* 1496 */       return namedParamInfo.index + 1;
/*      */     }
/*      */     
/* 1499 */     for (int i = 0; i < this.placeholderToParameterIndexMap.length; i++) {
/* 1500 */       if (this.placeholderToParameterIndexMap[i] == namedParamInfo.index) {
/* 1501 */         return i + 1;
/*      */       }
/*      */     }
/*      */     
/* 1505 */     throw SQLError.createSQLException("Can't find local placeholder mapping for parameter named \"" + paramName + "\".", "S1009", getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized Object getObject(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1514 */     CallableStatementParam paramDescriptor = checkIsOutputParam(parameterIndex);
/*      */     
/* 1516 */     ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */     
/* 1518 */     Object retVal = rs.getObjectStoredProc(mapOutputParameterIndexToRsIndex(parameterIndex), paramDescriptor.desiredJdbcType);
/*      */     
/*      */ 
/*      */ 
/* 1522 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1524 */     return retVal;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized Object getObject(int parameterIndex, Map<String, Class<?>> map)
/*      */     throws SQLException
/*      */   {
/* 1532 */     ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */     
/* 1534 */     Object retVal = rs.getObject(mapOutputParameterIndexToRsIndex(parameterIndex), map);
/*      */     
/*      */ 
/* 1537 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1539 */     return retVal;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized Object getObject(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1547 */     ResultSetInternalMethods rs = getOutputParameters(0);
/*      */     
/*      */ 
/* 1550 */     Object retValue = rs.getObject(fixParameterName(parameterName));
/*      */     
/* 1552 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1554 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized Object getObject(String parameterName, Map<String, Class<?>> map)
/*      */     throws SQLException
/*      */   {
/* 1563 */     ResultSetInternalMethods rs = getOutputParameters(0);
/*      */     
/*      */ 
/* 1566 */     Object retValue = rs.getObject(fixParameterName(parameterName), map);
/*      */     
/* 1568 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1570 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized ResultSetInternalMethods getOutputParameters(int paramIndex)
/*      */     throws SQLException
/*      */   {
/* 1584 */     this.outputParamWasNull = false;
/*      */     
/* 1586 */     if ((paramIndex == 1) && (this.callingStoredFunction) && (this.returnValueParam != null))
/*      */     {
/* 1588 */       return this.functionReturnValueResults;
/*      */     }
/*      */     
/* 1591 */     if (this.outputParameterResults == null) {
/* 1592 */       if (this.paramInfo.numberOfParameters() == 0) {
/* 1593 */         throw SQLError.createSQLException(Messages.getString("CallableStatement.7"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/* 1597 */       throw SQLError.createSQLException(Messages.getString("CallableStatement.8"), "S1000", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 1601 */     return this.outputParameterResults;
/*      */   }
/*      */   
/*      */   public synchronized ParameterMetaData getParameterMetaData()
/*      */     throws SQLException
/*      */   {
/* 1607 */     if (this.placeholderToParameterIndexMap == null) {
/* 1608 */       return (CallableStatementParamInfoJDBC3)this.paramInfo;
/*      */     }
/*      */     
/* 1611 */     return new CallableStatementParamInfoJDBC3(this.paramInfo);
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized Ref getRef(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1618 */     ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */     
/* 1620 */     Ref retValue = rs.getRef(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */     
/*      */ 
/* 1623 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1625 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized Ref getRef(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1632 */     ResultSetInternalMethods rs = getOutputParameters(0);
/*      */     
/*      */ 
/* 1635 */     Ref retValue = rs.getRef(fixParameterName(parameterName));
/*      */     
/* 1637 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1639 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized short getShort(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1646 */     ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */     
/* 1648 */     short retValue = rs.getShort(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */     
/*      */ 
/* 1651 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1653 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized short getShort(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1661 */     ResultSetInternalMethods rs = getOutputParameters(0);
/*      */     
/*      */ 
/* 1664 */     short retValue = rs.getShort(fixParameterName(parameterName));
/*      */     
/* 1666 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1668 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized String getString(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1676 */     ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */     
/* 1678 */     String retValue = rs.getString(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */     
/*      */ 
/* 1681 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1683 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized String getString(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1691 */     ResultSetInternalMethods rs = getOutputParameters(0);
/*      */     
/*      */ 
/* 1694 */     String retValue = rs.getString(fixParameterName(parameterName));
/*      */     
/* 1696 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1698 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized Time getTime(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1705 */     ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */     
/* 1707 */     Time retValue = rs.getTime(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */     
/*      */ 
/* 1710 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1712 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized Time getTime(int parameterIndex, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1720 */     ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */     
/* 1722 */     Time retValue = rs.getTime(mapOutputParameterIndexToRsIndex(parameterIndex), cal);
/*      */     
/*      */ 
/* 1725 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1727 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized Time getTime(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1734 */     ResultSetInternalMethods rs = getOutputParameters(0);
/*      */     
/*      */ 
/* 1737 */     Time retValue = rs.getTime(fixParameterName(parameterName));
/*      */     
/* 1739 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1741 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized Time getTime(String parameterName, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1750 */     ResultSetInternalMethods rs = getOutputParameters(0);
/*      */     
/*      */ 
/* 1753 */     Time retValue = rs.getTime(fixParameterName(parameterName), cal);
/*      */     
/* 1755 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1757 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized Timestamp getTimestamp(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1765 */     ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */     
/* 1767 */     Timestamp retValue = rs.getTimestamp(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */     
/*      */ 
/* 1770 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1772 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized Timestamp getTimestamp(int parameterIndex, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1780 */     ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */     
/* 1782 */     Timestamp retValue = rs.getTimestamp(mapOutputParameterIndexToRsIndex(parameterIndex), cal);
/*      */     
/*      */ 
/* 1785 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1787 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized Timestamp getTimestamp(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1795 */     ResultSetInternalMethods rs = getOutputParameters(0);
/*      */     
/*      */ 
/* 1798 */     Timestamp retValue = rs.getTimestamp(fixParameterName(parameterName));
/*      */     
/* 1800 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1802 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized Timestamp getTimestamp(String parameterName, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1811 */     ResultSetInternalMethods rs = getOutputParameters(0);
/*      */     
/*      */ 
/* 1814 */     Timestamp retValue = rs.getTimestamp(fixParameterName(parameterName), cal);
/*      */     
/*      */ 
/* 1817 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1819 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized URL getURL(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1826 */     ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */     
/* 1828 */     URL retValue = rs.getURL(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */     
/*      */ 
/* 1831 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1833 */     return retValue;
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized URL getURL(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1840 */     ResultSetInternalMethods rs = getOutputParameters(0);
/*      */     
/*      */ 
/* 1843 */     URL retValue = rs.getURL(fixParameterName(parameterName));
/*      */     
/* 1845 */     this.outputParamWasNull = rs.wasNull();
/*      */     
/* 1847 */     return retValue;
/*      */   }
/*      */   
/*      */   protected synchronized int mapOutputParameterIndexToRsIndex(int paramIndex)
/*      */     throws SQLException
/*      */   {
/* 1853 */     if ((this.returnValueParam != null) && (paramIndex == 1)) {
/* 1854 */       return 1;
/*      */     }
/*      */     
/* 1857 */     checkParameterIndexBounds(paramIndex);
/*      */     
/* 1859 */     int localParamIndex = paramIndex - 1;
/*      */     
/* 1861 */     if (this.placeholderToParameterIndexMap != null) {
/* 1862 */       localParamIndex = this.placeholderToParameterIndexMap[localParamIndex];
/*      */     }
/*      */     
/* 1865 */     int rsIndex = this.parameterIndexToRsIndex[localParamIndex];
/*      */     
/* 1867 */     if (rsIndex == Integer.MIN_VALUE) {
/* 1868 */       throw SQLError.createSQLException(Messages.getString("CallableStatement.21") + paramIndex + Messages.getString("CallableStatement.22"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1874 */     return rsIndex + 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void registerOutParameter(int parameterIndex, int sqlType)
/*      */     throws SQLException
/*      */   {
/* 1882 */     CallableStatementParam paramDescriptor = checkIsOutputParam(parameterIndex);
/* 1883 */     paramDescriptor.desiredJdbcType = sqlType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void registerOutParameter(int parameterIndex, int sqlType, int scale)
/*      */     throws SQLException
/*      */   {
/* 1891 */     registerOutParameter(parameterIndex, sqlType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void registerOutParameter(int parameterIndex, int sqlType, String typeName)
/*      */     throws SQLException
/*      */   {
/* 1900 */     checkIsOutputParam(parameterIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void registerOutParameter(String parameterName, int sqlType)
/*      */     throws SQLException
/*      */   {
/* 1909 */     registerOutParameter(getNamedParamIndex(parameterName, true), sqlType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void registerOutParameter(String parameterName, int sqlType, int scale)
/*      */     throws SQLException
/*      */   {
/* 1918 */     registerOutParameter(getNamedParamIndex(parameterName, true), sqlType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void registerOutParameter(String parameterName, int sqlType, String typeName)
/*      */     throws SQLException
/*      */   {
/* 1927 */     registerOutParameter(getNamedParamIndex(parameterName, true), sqlType, typeName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private synchronized void retrieveOutParams()
/*      */     throws SQLException
/*      */   {
/* 1938 */     int numParameters = this.paramInfo.numberOfParameters();
/*      */     
/* 1940 */     this.parameterIndexToRsIndex = new int[numParameters];
/*      */     
/* 1942 */     for (int i = 0; i < numParameters; i++) {
/* 1943 */       this.parameterIndexToRsIndex[i] = Integer.MIN_VALUE;
/*      */     }
/*      */     
/* 1946 */     int localParamIndex = 0;
/*      */     
/* 1948 */     if (numParameters > 0) {
/* 1949 */       StringBuffer outParameterQuery = new StringBuffer("SELECT ");
/*      */       
/* 1951 */       boolean firstParam = true;
/* 1952 */       boolean hadOutputParams = false;
/*      */       
/* 1954 */       Iterator<CallableStatementParam> paramIter = this.paramInfo.iterator();
/* 1955 */       while (paramIter.hasNext()) {
/* 1956 */         CallableStatementParam retrParamInfo = (CallableStatementParam)paramIter.next();
/*      */         
/*      */ 
/* 1959 */         if (retrParamInfo.isOut) {
/* 1960 */           hadOutputParams = true;
/*      */           
/* 1962 */           this.parameterIndexToRsIndex[retrParamInfo.index] = (localParamIndex++);
/*      */           
/* 1964 */           if ((retrParamInfo.paramName == null) && (hasParametersView())) {
/* 1965 */             retrParamInfo.paramName = ("nullnp" + retrParamInfo.index);
/*      */           }
/*      */           
/* 1968 */           String outParameterName = mangleParameterName(retrParamInfo.paramName);
/*      */           
/* 1970 */           if (!firstParam) {
/* 1971 */             outParameterQuery.append(",");
/*      */           } else {
/* 1973 */             firstParam = false;
/*      */           }
/*      */           
/* 1976 */           if (!outParameterName.startsWith("@")) {
/* 1977 */             outParameterQuery.append('@');
/*      */           }
/*      */           
/* 1980 */           outParameterQuery.append(outParameterName);
/*      */         }
/*      */       }
/*      */       
/* 1984 */       if (hadOutputParams)
/*      */       {
/*      */ 
/* 1987 */         Statement outParameterStmt = null;
/* 1988 */         ResultSet outParamRs = null;
/*      */         try
/*      */         {
/* 1991 */           outParameterStmt = this.connection.createStatement();
/* 1992 */           outParamRs = outParameterStmt.executeQuery(outParameterQuery.toString());
/*      */           
/* 1994 */           this.outputParameterResults = ((ResultSetInternalMethods)outParamRs).copy();
/*      */           
/*      */ 
/* 1997 */           if (!this.outputParameterResults.next()) {
/* 1998 */             this.outputParameterResults.close();
/* 1999 */             this.outputParameterResults = null;
/*      */           }
/*      */         } finally {
/* 2002 */           if (outParameterStmt != null) {
/* 2003 */             outParameterStmt.close();
/*      */           }
/*      */         }
/*      */       } else {
/* 2007 */         this.outputParameterResults = null;
/*      */       }
/*      */     } else {
/* 2010 */       this.outputParameterResults = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAsciiStream(String parameterName, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 2020 */     setAsciiStream(getNamedParamIndex(parameterName, false), x, length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBigDecimal(String parameterName, BigDecimal x)
/*      */     throws SQLException
/*      */   {
/* 2029 */     setBigDecimal(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBinaryStream(String parameterName, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 2038 */     setBinaryStream(getNamedParamIndex(parameterName, false), x, length);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBoolean(String parameterName, boolean x)
/*      */     throws SQLException
/*      */   {
/* 2045 */     setBoolean(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setByte(String parameterName, byte x)
/*      */     throws SQLException
/*      */   {
/* 2052 */     setByte(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBytes(String parameterName, byte[] x)
/*      */     throws SQLException
/*      */   {
/* 2059 */     setBytes(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCharacterStream(String parameterName, Reader reader, int length)
/*      */     throws SQLException
/*      */   {
/* 2068 */     setCharacterStream(getNamedParamIndex(parameterName, false), reader, length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setDate(String parameterName, Date x)
/*      */     throws SQLException
/*      */   {
/* 2076 */     setDate(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDate(String parameterName, Date x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 2085 */     setDate(getNamedParamIndex(parameterName, false), x, cal);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setDouble(String parameterName, double x)
/*      */     throws SQLException
/*      */   {
/* 2092 */     setDouble(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setFloat(String parameterName, float x)
/*      */     throws SQLException
/*      */   {
/* 2099 */     setFloat(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */ 
/*      */   private synchronized void setInOutParamsOnServer()
/*      */     throws SQLException
/*      */   {
/* 2106 */     if (this.paramInfo.numParameters > 0) {
/* 2107 */       Iterator<CallableStatementParam> paramIter = this.paramInfo.iterator();
/* 2108 */       while (paramIter.hasNext())
/*      */       {
/* 2110 */         CallableStatementParam inParamInfo = (CallableStatementParam)paramIter.next();
/*      */         
/*      */ 
/*      */ 
/* 2114 */         if ((inParamInfo.isOut) && (inParamInfo.isIn)) {
/* 2115 */           if ((inParamInfo.paramName == null) && (hasParametersView())) {
/* 2116 */             inParamInfo.paramName = ("nullnp" + inParamInfo.index);
/*      */           }
/*      */           
/* 2119 */           String inOutParameterName = mangleParameterName(inParamInfo.paramName);
/* 2120 */           StringBuffer queryBuf = new StringBuffer(4 + inOutParameterName.length() + 1 + 1);
/*      */           
/* 2122 */           queryBuf.append("SET ");
/* 2123 */           queryBuf.append(inOutParameterName);
/* 2124 */           queryBuf.append("=?");
/*      */           
/* 2126 */           PreparedStatement setPstmt = null;
/*      */           try
/*      */           {
/* 2129 */             setPstmt = (PreparedStatement)this.connection.clientPrepareStatement(queryBuf.toString());
/*      */             
/*      */ 
/* 2132 */             byte[] parameterAsBytes = getBytesRepresentation(inParamInfo.index);
/*      */             
/*      */ 
/* 2135 */             if (parameterAsBytes != null) {
/* 2136 */               if ((parameterAsBytes.length > 8) && (parameterAsBytes[0] == 95) && (parameterAsBytes[1] == 98) && (parameterAsBytes[2] == 105) && (parameterAsBytes[3] == 110) && (parameterAsBytes[4] == 97) && (parameterAsBytes[5] == 114) && (parameterAsBytes[6] == 121) && (parameterAsBytes[7] == 39))
/*      */               {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2145 */                 setPstmt.setBytesNoEscapeNoQuotes(1, parameterAsBytes);
/*      */               }
/*      */               else {
/* 2148 */                 int sqlType = inParamInfo.desiredJdbcType;
/*      */                 
/* 2150 */                 switch (sqlType) {
/*      */                 case -7: 
/*      */                 case -4: 
/*      */                 case -3: 
/*      */                 case -2: 
/*      */                 case 2000: 
/*      */                 case 2004: 
/* 2157 */                   setPstmt.setBytes(1, parameterAsBytes);
/* 2158 */                   break;
/*      */                 
/*      */ 
/*      */                 default: 
/* 2162 */                   setPstmt.setBytesNoEscape(1, parameterAsBytes);
/*      */                 }
/*      */               }
/*      */             } else {
/* 2166 */               setPstmt.setNull(1, 0);
/*      */             }
/*      */             
/* 2169 */             setPstmt.executeUpdate();
/*      */           } finally {
/* 2171 */             if (setPstmt != null) {
/* 2172 */               setPstmt.close();
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setInt(String parameterName, int x)
/*      */     throws SQLException
/*      */   {
/* 2184 */     setInt(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setLong(String parameterName, long x)
/*      */     throws SQLException
/*      */   {
/* 2191 */     setLong(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setNull(String parameterName, int sqlType)
/*      */     throws SQLException
/*      */   {
/* 2198 */     setNull(getNamedParamIndex(parameterName, false), sqlType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNull(String parameterName, int sqlType, String typeName)
/*      */     throws SQLException
/*      */   {
/* 2207 */     setNull(getNamedParamIndex(parameterName, false), sqlType, typeName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setObject(String parameterName, Object x)
/*      */     throws SQLException
/*      */   {
/* 2215 */     setObject(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setObject(String parameterName, Object x, int targetSqlType)
/*      */     throws SQLException
/*      */   {
/* 2224 */     setObject(getNamedParamIndex(parameterName, false), x, targetSqlType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private synchronized void setOutParams()
/*      */     throws SQLException
/*      */   {
/* 2236 */     if (this.paramInfo.numParameters > 0) {
/* 2237 */       Iterator<CallableStatementParam> paramIter = this.paramInfo.iterator();
/* 2238 */       while (paramIter.hasNext()) {
/* 2239 */         CallableStatementParam outParamInfo = (CallableStatementParam)paramIter.next();
/*      */         
/*      */ 
/* 2242 */         if ((!this.callingStoredFunction) && (outParamInfo.isOut))
/*      */         {
/* 2244 */           if ((outParamInfo.paramName == null) && (hasParametersView())) {
/* 2245 */             outParamInfo.paramName = ("nullnp" + outParamInfo.index);
/*      */           }
/*      */           
/* 2248 */           String outParameterName = mangleParameterName(outParamInfo.paramName);
/*      */           
/* 2250 */           int outParamIndex = 0;
/*      */           
/* 2252 */           if (this.placeholderToParameterIndexMap == null) {
/* 2253 */             outParamIndex = outParamInfo.index + 1;
/*      */           }
/*      */           else {
/* 2256 */             boolean found = false;
/*      */             
/* 2258 */             for (int i = 0; i < this.placeholderToParameterIndexMap.length; i++) {
/* 2259 */               if (this.placeholderToParameterIndexMap[i] == outParamInfo.index) {
/* 2260 */                 outParamIndex = i + 1;
/* 2261 */                 found = true;
/* 2262 */                 break;
/*      */               }
/*      */             }
/*      */             
/* 2266 */             if (!found) {
/* 2267 */               throw SQLError.createSQLException("boo!", "S1000", this.connection.getExceptionInterceptor());
/*      */             }
/*      */           }
/*      */           
/* 2271 */           setBytesNoEscapeNoQuotes(outParamIndex, StringUtils.getBytes(outParameterName, this.charConverter, this.charEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), getExceptionInterceptor()));
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setShort(String parameterName, short x)
/*      */     throws SQLException
/*      */   {
/* 2286 */     setShort(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setString(String parameterName, String x)
/*      */     throws SQLException
/*      */   {
/* 2294 */     setString(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setTime(String parameterName, Time x)
/*      */     throws SQLException
/*      */   {
/* 2301 */     setTime(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTime(String parameterName, Time x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 2310 */     setTime(getNamedParamIndex(parameterName, false), x, cal);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTimestamp(String parameterName, Timestamp x)
/*      */     throws SQLException
/*      */   {
/* 2319 */     setTimestamp(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTimestamp(String parameterName, Timestamp x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 2328 */     setTimestamp(getNamedParamIndex(parameterName, false), x, cal);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setURL(String parameterName, URL val)
/*      */     throws SQLException
/*      */   {
/* 2335 */     setURL(getNamedParamIndex(parameterName, false), val);
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized boolean wasNull()
/*      */     throws SQLException
/*      */   {
/* 2342 */     return this.outputParamWasNull;
/*      */   }
/*      */   
/*      */   public int[] executeBatch() throws SQLException {
/* 2346 */     if (this.hasOutputParams) {
/* 2347 */       throw SQLError.createSQLException("Can't call executeBatch() on CallableStatement with OUTPUT parameters", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 2351 */     return super.executeBatch();
/*      */   }
/*      */   
/*      */   protected int getParameterIndexOffset() {
/* 2355 */     if (this.callingStoredFunction) {
/* 2356 */       return -1;
/*      */     }
/*      */     
/* 2359 */     return super.getParameterIndexOffset();
/*      */   }
/*      */   
/*      */   public void setAsciiStream(String parameterName, InputStream x) throws SQLException {
/* 2363 */     setAsciiStream(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */   public void setAsciiStream(String parameterName, InputStream x, long length) throws SQLException
/*      */   {
/* 2368 */     setAsciiStream(getNamedParamIndex(parameterName, false), x, length);
/*      */   }
/*      */   
/*      */   public void setBinaryStream(String parameterName, InputStream x) throws SQLException
/*      */   {
/* 2373 */     setBinaryStream(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */   public void setBinaryStream(String parameterName, InputStream x, long length) throws SQLException
/*      */   {
/* 2378 */     setBinaryStream(getNamedParamIndex(parameterName, false), x, length);
/*      */   }
/*      */   
/*      */   public void setBlob(String parameterName, Blob x) throws SQLException
/*      */   {
/* 2383 */     setBlob(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */   public void setBlob(String parameterName, InputStream inputStream) throws SQLException
/*      */   {
/* 2388 */     setBlob(getNamedParamIndex(parameterName, false), inputStream);
/*      */   }
/*      */   
/*      */   public void setBlob(String parameterName, InputStream inputStream, long length) throws SQLException
/*      */   {
/* 2393 */     setBlob(getNamedParamIndex(parameterName, false), inputStream, length);
/*      */   }
/*      */   
/*      */   public void setCharacterStream(String parameterName, Reader reader) throws SQLException
/*      */   {
/* 2398 */     setCharacterStream(getNamedParamIndex(parameterName, false), reader);
/*      */   }
/*      */   
/*      */   public void setCharacterStream(String parameterName, Reader reader, long length) throws SQLException
/*      */   {
/* 2403 */     setCharacterStream(getNamedParamIndex(parameterName, false), reader, length);
/*      */   }
/*      */   
/*      */   public void setClob(String parameterName, Clob x) throws SQLException
/*      */   {
/* 2408 */     setClob(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */   
/*      */   public void setClob(String parameterName, Reader reader) throws SQLException
/*      */   {
/* 2413 */     setClob(getNamedParamIndex(parameterName, false), reader);
/*      */   }
/*      */   
/*      */   public void setClob(String parameterName, Reader reader, long length) throws SQLException
/*      */   {
/* 2418 */     setClob(getNamedParamIndex(parameterName, false), reader, length);
/*      */   }
/*      */   
/*      */   public void setNCharacterStream(String parameterName, Reader value) throws SQLException
/*      */   {
/* 2423 */     setNCharacterStream(getNamedParamIndex(parameterName, false), value);
/*      */   }
/*      */   
/*      */   public void setNCharacterStream(String parameterName, Reader value, long length) throws SQLException
/*      */   {
/* 2428 */     setNCharacterStream(getNamedParamIndex(parameterName, false), value, length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private synchronized boolean checkReadOnlyProcedure()
/*      */     throws SQLException
/*      */   {
/* 2439 */     if (this.connection.getNoAccessToProcedureBodies()) {
/* 2440 */       return false;
/*      */     }
/*      */     
/* 2443 */     synchronized (this.paramInfo) {
/* 2444 */       if (this.paramInfo.isReadOnlySafeChecked) {
/* 2445 */         return this.paramInfo.isReadOnlySafeProcedure;
/*      */       }
/*      */       
/* 2448 */       ResultSet rs = null;
/* 2449 */       java.sql.PreparedStatement ps = null;
/*      */       try
/*      */       {
/* 2452 */         String procName = extractProcedureName();
/*      */         
/* 2454 */         String catalog = this.currentCatalog;
/*      */         
/* 2456 */         if (procName.indexOf(".") != -1) {
/* 2457 */           catalog = procName.substring(0, procName.indexOf("."));
/*      */           
/* 2459 */           if ((StringUtils.startsWithIgnoreCaseAndWs(catalog, "`")) && (catalog.trim().endsWith("`"))) {
/* 2460 */             catalog = catalog.substring(1, catalog.length() - 1);
/*      */           }
/*      */           
/* 2463 */           procName = procName.substring(procName.indexOf(".") + 1);
/* 2464 */           procName = StringUtils.toString(StringUtils.stripEnclosure(StringUtils.getBytes(procName), "`", "`"));
/*      */         }
/*      */         
/* 2467 */         ps = this.connection.prepareStatement("SELECT SQL_DATA_ACCESS FROM  information_schema.routines  WHERE routine_schema = ?  AND routine_name = ?");
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 2472 */         ps.setMaxRows(0);
/* 2473 */         ps.setFetchSize(0);
/*      */         
/* 2475 */         ps.setString(1, catalog);
/* 2476 */         ps.setString(2, procName);
/* 2477 */         rs = ps.executeQuery();
/* 2478 */         if (rs.next()) {
/* 2479 */           String sqlDataAccess = rs.getString(1);
/* 2480 */           if (("READS SQL DATA".equalsIgnoreCase(sqlDataAccess)) || ("NO SQL".equalsIgnoreCase(sqlDataAccess)))
/*      */           {
/* 2482 */             synchronized (this.paramInfo) {
/* 2483 */               this.paramInfo.isReadOnlySafeChecked = true;
/* 2484 */               this.paramInfo.isReadOnlySafeProcedure = true;
/*      */             }
/* 2486 */             ??? = 1;jsr 30;return ???;
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (SQLException e) {}finally
/*      */       {
/* 2492 */         jsr 6; } localObject3 = returnAddress; if (rs != null) {
/* 2493 */         rs.close();
/*      */       }
/* 2495 */       if (ps != null)
/* 2496 */         ps.close(); ret;
/*      */       
/*      */ 
/*      */ 
/* 2500 */       this.paramInfo.isReadOnlySafeChecked = false;
/* 2501 */       this.paramInfo.isReadOnlySafeProcedure = false;
/*      */     }
/* 2503 */     return false;
/*      */   }
/*      */   
/*      */   protected boolean checkReadOnlySafeStatement() throws SQLException
/*      */   {
/* 2508 */     return (super.checkReadOnlySafeStatement()) || (checkReadOnlyProcedure());
/*      */   }
/*      */   
/*      */   private synchronized boolean hasParametersView() throws SQLException {
/*      */     try {
/* 2513 */       if (this.connection.versionMeetsMinimum(5, 5, 0)) {
/* 2514 */         java.sql.DatabaseMetaData dbmd1 = new DatabaseMetaDataUsingInfoSchema(this.connection, this.connection.getCatalog());
/* 2515 */         return ((DatabaseMetaDataUsingInfoSchema)dbmd1).gethasParametersView();
/*      */       }
/*      */       
/* 2518 */       return false;
/*      */     } catch (SQLException e) {}
/* 2520 */     return false;
/*      */   }
/*      */   
/*      */   public void setObject(String parameterName, Object x, int targetSqlType, int scale)
/*      */     throws SQLException
/*      */   {}
/*      */ }


/* Location:              C:\Users\Static\Desktop\G10_Prototype_Client.jar!\mysql-connector-java-5.1.19-bin.jar!\com\mysql\jdbc\CallableStatement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */