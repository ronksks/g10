/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.exceptions.MySQLStatementCancelledException;
/*      */ import com.mysql.jdbc.exceptions.MySQLTimeoutException;
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import com.mysql.jdbc.profiler.ProfilerEventHandler;
/*      */ import java.io.InputStream;
/*      */ import java.math.BigInteger;
/*      */ import java.sql.BatchUpdateException;
/*      */ import java.sql.DriverManager;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Collections;
/*      */ import java.util.Enumeration;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import java.util.Timer;
/*      */ import java.util.TimerTask;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StatementImpl
/*      */   implements Statement
/*      */ {
/*      */   protected static final String PING_MARKER = "/* ping */";
/*      */   
/*      */   class CancelTask
/*      */     extends TimerTask
/*      */   {
/*   78 */     long connectionId = 0L;
/*   79 */     String origHost = "";
/*   80 */     SQLException caughtWhileCancelling = null;
/*      */     StatementImpl toCancel;
/*   82 */     Properties origConnProps = null;
/*   83 */     String origConnURL = "";
/*      */     
/*      */     CancelTask(StatementImpl cancellee) throws SQLException {
/*   86 */       this.connectionId = cancellee.connectionId;
/*   87 */       this.origHost = StatementImpl.this.connection.getHost();
/*   88 */       this.toCancel = cancellee;
/*   89 */       this.origConnProps = new Properties();
/*      */       
/*   91 */       Properties props = StatementImpl.this.connection.getProperties();
/*      */       
/*   93 */       Enumeration<?> keys = props.propertyNames();
/*      */       
/*   95 */       while (keys.hasMoreElements()) {
/*   96 */         String key = keys.nextElement().toString();
/*   97 */         this.origConnProps.setProperty(key, props.getProperty(key));
/*      */       }
/*      */       
/*  100 */       this.origConnURL = StatementImpl.this.connection.getURL();
/*      */     }
/*      */     
/*      */     public void run()
/*      */     {
/*  105 */       Thread cancelThread = new Thread()
/*      */       {
/*      */         public void run() {
/*  108 */           if (StatementImpl.this.connection.getQueryTimeoutKillsConnection()) {
/*      */             try {
/*  110 */               StatementImpl.CancelTask.this.toCancel.wasCancelled = true;
/*  111 */               StatementImpl.CancelTask.this.toCancel.wasCancelledByTimeout = true;
/*  112 */               StatementImpl.this.connection.realClose(false, false, true, new MySQLStatementCancelledException(Messages.getString("Statement.ConnectionKilledDueToTimeout")));
/*      */ 
/*      */             }
/*      */             catch (NullPointerException npe) {}catch (SQLException sqlEx)
/*      */             {
/*  117 */               StatementImpl.CancelTask.this.caughtWhileCancelling = sqlEx;
/*      */             }
/*      */           } else {
/*  120 */             Connection cancelConn = null;
/*  121 */             java.sql.Statement cancelStmt = null;
/*      */             try
/*      */             {
/*  124 */               synchronized (StatementImpl.this.cancelTimeoutMutex) {
/*  125 */                 if (StatementImpl.CancelTask.this.origConnURL.equals(StatementImpl.this.connection.getURL()))
/*      */                 {
/*  127 */                   cancelConn = StatementImpl.this.connection.duplicate();
/*  128 */                   cancelStmt = cancelConn.createStatement();
/*  129 */                   cancelStmt.execute("KILL QUERY " + StatementImpl.CancelTask.this.connectionId);
/*      */                 } else {
/*      */                   try {
/*  132 */                     cancelConn = (Connection)DriverManager.getConnection(StatementImpl.CancelTask.this.origConnURL, StatementImpl.CancelTask.this.origConnProps);
/*  133 */                     cancelStmt = cancelConn.createStatement();
/*  134 */                     cancelStmt.execute("KILL QUERY " + StatementImpl.CancelTask.this.connectionId);
/*      */                   }
/*      */                   catch (NullPointerException npe) {}
/*      */                 }
/*      */                 
/*  139 */                 StatementImpl.CancelTask.this.toCancel.wasCancelled = true;
/*  140 */                 StatementImpl.CancelTask.this.toCancel.wasCancelledByTimeout = true;
/*      */               }
/*      */             } catch (SQLException sqlEx) {
/*  143 */               StatementImpl.CancelTask.this.caughtWhileCancelling = sqlEx;
/*      */ 
/*      */ 
/*      */ 
/*      */             }
/*      */             catch (NullPointerException npe) {}finally
/*      */             {
/*      */ 
/*      */ 
/*  152 */               if (cancelStmt != null) {
/*      */                 try {
/*  154 */                   cancelStmt.close();
/*      */                 } catch (SQLException sqlEx) {
/*  156 */                   throw new RuntimeException(sqlEx.toString());
/*      */                 }
/*      */               }
/*      */               
/*  160 */               if (cancelConn != null) {
/*      */                 try {
/*  162 */                   cancelConn.close();
/*      */                 } catch (SQLException sqlEx) {
/*  164 */                   throw new RuntimeException(sqlEx.toString());
/*      */                 }
/*      */               }
/*      */               
/*  168 */               StatementImpl.CancelTask.this.toCancel = null;
/*  169 */               StatementImpl.CancelTask.this.origConnProps = null;
/*  170 */               StatementImpl.CancelTask.this.origConnURL = null;
/*      */             }
/*      */             
/*      */           }
/*      */         }
/*  175 */       };
/*  176 */       cancelThread.start();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  183 */   protected Object cancelTimeoutMutex = new Object();
/*      */   
/*      */ 
/*  186 */   static int statementCounter = 1;
/*      */   
/*      */   public static final byte USES_VARIABLES_FALSE = 0;
/*      */   
/*      */   public static final byte USES_VARIABLES_TRUE = 1;
/*      */   
/*      */   public static final byte USES_VARIABLES_UNKNOWN = -1;
/*      */   
/*  194 */   protected boolean wasCancelled = false;
/*  195 */   protected boolean wasCancelledByTimeout = false;
/*      */   
/*      */ 
/*      */   protected List batchedArgs;
/*      */   
/*      */ 
/*  201 */   protected SingleByteCharsetConverter charConverter = null;
/*      */   
/*      */ 
/*  204 */   protected String charEncoding = null;
/*      */   
/*      */ 
/*  207 */   protected MySQLConnection connection = null;
/*      */   
/*  209 */   protected long connectionId = 0L;
/*      */   
/*      */ 
/*  212 */   protected String currentCatalog = null;
/*      */   
/*      */ 
/*  215 */   protected boolean doEscapeProcessing = true;
/*      */   
/*      */ 
/*  218 */   protected ProfilerEventHandler eventSink = null;
/*      */   
/*      */ 
/*  221 */   private int fetchSize = 0;
/*      */   
/*      */ 
/*  224 */   protected boolean isClosed = false;
/*      */   
/*      */ 
/*  227 */   protected long lastInsertId = -1L;
/*      */   
/*      */ 
/*  230 */   protected int maxFieldSize = MysqlIO.getMaxBuf();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  236 */   protected int maxRows = -1;
/*      */   
/*      */ 
/*  239 */   protected boolean maxRowsChanged = false;
/*      */   
/*      */ 
/*  242 */   protected Set openResults = new HashSet();
/*      */   
/*      */ 
/*  245 */   protected boolean pedantic = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Throwable pointOfOrigin;
/*      */   
/*      */ 
/*      */ 
/*  254 */   protected boolean profileSQL = false;
/*      */   
/*      */ 
/*  257 */   protected ResultSetInternalMethods results = null;
/*      */   
/*      */ 
/*  260 */   protected int resultSetConcurrency = 0;
/*      */   
/*      */ 
/*  263 */   protected int resultSetType = 0;
/*      */   
/*      */ 
/*      */   protected int statementId;
/*      */   
/*      */ 
/*  269 */   protected int timeoutInMillis = 0;
/*      */   
/*      */ 
/*  272 */   protected long updateCount = -1L;
/*      */   
/*      */ 
/*  275 */   protected boolean useUsageAdvisor = false;
/*      */   
/*      */ 
/*  278 */   protected SQLWarning warningChain = null;
/*      */   
/*      */ 
/*  281 */   protected boolean clearWarningsCalled = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  287 */   protected boolean holdResultsOpenOverClose = false;
/*      */   
/*  289 */   protected ArrayList batchedGeneratedKeys = null;
/*      */   
/*  291 */   protected boolean retrieveGeneratedKeys = false;
/*      */   
/*  293 */   protected boolean continueBatchOnError = false;
/*      */   
/*  295 */   protected PingTarget pingTarget = null;
/*      */   
/*      */ 
/*      */   protected boolean useLegacyDatetimeCode;
/*      */   
/*      */   private ExceptionInterceptor exceptionInterceptor;
/*      */   
/*  302 */   protected boolean lastQueryIsOnDupKeyUpdate = false;
/*      */   
/*      */ 
/*  305 */   protected final AtomicBoolean statementExecuting = new AtomicBoolean(false);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StatementImpl(MySQLConnection c, String catalog)
/*      */     throws SQLException
/*      */   {
/*  319 */     if ((c == null) || (c.isClosed())) {
/*  320 */       throw SQLError.createSQLException(Messages.getString("Statement.0"), "08003", null);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  325 */     this.connection = c;
/*  326 */     this.connectionId = this.connection.getId();
/*  327 */     this.exceptionInterceptor = this.connection.getExceptionInterceptor();
/*      */     
/*      */ 
/*  330 */     this.currentCatalog = catalog;
/*  331 */     this.pedantic = this.connection.getPedantic();
/*  332 */     this.continueBatchOnError = this.connection.getContinueBatchOnError();
/*  333 */     this.useLegacyDatetimeCode = this.connection.getUseLegacyDatetimeCode();
/*      */     
/*  335 */     if (!this.connection.getDontTrackOpenResources()) {
/*  336 */       this.connection.registerStatement(this);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  343 */     if (this.connection != null) {
/*  344 */       this.maxFieldSize = this.connection.getMaxAllowedPacket();
/*      */       
/*  346 */       int defaultFetchSize = this.connection.getDefaultFetchSize();
/*      */       
/*  348 */       if (defaultFetchSize != 0) {
/*  349 */         setFetchSize(defaultFetchSize);
/*      */       }
/*      */       
/*  352 */       if (this.connection.getUseUnicode()) {
/*  353 */         this.charEncoding = this.connection.getEncoding();
/*      */         
/*  355 */         this.charConverter = this.connection.getCharsetConverter(this.charEncoding);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  360 */       boolean profiling = (this.connection.getProfileSql()) || (this.connection.getUseUsageAdvisor()) || (this.connection.getLogSlowQueries());
/*      */       
/*      */ 
/*  363 */       if ((this.connection.getAutoGenerateTestcaseScript()) || (profiling)) {
/*  364 */         this.statementId = (statementCounter++);
/*      */       }
/*      */       
/*  367 */       if (profiling) {
/*  368 */         this.pointOfOrigin = new Throwable();
/*  369 */         this.profileSQL = this.connection.getProfileSql();
/*  370 */         this.useUsageAdvisor = this.connection.getUseUsageAdvisor();
/*  371 */         this.eventSink = ProfilerEventHandlerFactory.getInstance(this.connection);
/*      */       }
/*      */       
/*  374 */       int maxRowsConn = this.connection.getMaxRows();
/*      */       
/*  376 */       if (maxRowsConn != -1) {
/*  377 */         setMaxRows(maxRowsConn);
/*      */       }
/*      */       
/*  380 */       this.holdResultsOpenOverClose = this.connection.getHoldResultsOpenOverStatementClose();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void addBatch(String sql)
/*      */     throws SQLException
/*      */   {
/*  394 */     if (this.batchedArgs == null) {
/*  395 */       this.batchedArgs = new ArrayList();
/*      */     }
/*      */     
/*  398 */     if (sql != null) {
/*  399 */       this.batchedArgs.add(sql);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List getBatchedArgs()
/*      */   {
/*  410 */     return this.batchedArgs == null ? null : Collections.unmodifiableList(this.batchedArgs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void cancel()
/*      */     throws SQLException
/*      */   {
/*  419 */     if (!this.statementExecuting.get()) {
/*  420 */       return;
/*      */     }
/*      */     
/*  423 */     if ((!this.isClosed) && (this.connection != null) && (this.connection.versionMeetsMinimum(5, 0, 0)))
/*      */     {
/*      */ 
/*  426 */       Connection cancelConn = null;
/*  427 */       java.sql.Statement cancelStmt = null;
/*      */       try
/*      */       {
/*  430 */         cancelConn = this.connection.duplicate();
/*  431 */         cancelStmt = cancelConn.createStatement();
/*  432 */         cancelStmt.execute("KILL QUERY " + this.connection.getIO().getThreadId());
/*      */         
/*  434 */         this.wasCancelled = true;
/*      */       } finally {
/*  436 */         if (cancelStmt != null) {
/*  437 */           cancelStmt.close();
/*      */         }
/*      */         
/*  440 */         if (cancelConn != null) {
/*  441 */           cancelConn.close();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void checkClosed()
/*      */     throws SQLException
/*      */   {
/*  457 */     if (this.isClosed) {
/*  458 */       throw SQLError.createSQLException(Messages.getString("Statement.49"), "08003", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void checkForDml(String sql, char firstStatementChar)
/*      */     throws SQLException
/*      */   {
/*  478 */     if ((firstStatementChar == 'I') || (firstStatementChar == 'U') || (firstStatementChar == 'D') || (firstStatementChar == 'A') || (firstStatementChar == 'C'))
/*      */     {
/*      */ 
/*  481 */       String noCommentSql = StringUtils.stripComments(sql, "'\"", "'\"", true, false, true, true);
/*      */       
/*      */ 
/*  484 */       if ((StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "INSERT")) || (StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "UPDATE")) || (StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "DELETE")) || (StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "DROP")) || (StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "CREATE")) || (StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "ALTER")))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  490 */         throw SQLError.createSQLException(Messages.getString("Statement.57"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void checkNullOrEmptyQuery(String sql)
/*      */     throws SQLException
/*      */   {
/*  507 */     if (sql == null) {
/*  508 */       throw SQLError.createSQLException(Messages.getString("Statement.59"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  513 */     if (sql.length() == 0) {
/*  514 */       throw SQLError.createSQLException(Messages.getString("Statement.61"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void clearBatch()
/*      */     throws SQLException
/*      */   {
/*  529 */     if (this.batchedArgs != null) {
/*  530 */       this.batchedArgs.clear();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void clearWarnings()
/*      */     throws SQLException
/*      */   {
/*  542 */     this.clearWarningsCalled = true;
/*  543 */     this.warningChain = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void close()
/*      */     throws SQLException
/*      */   {
/*  562 */     realClose(true, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected synchronized void closeAllOpenResults()
/*      */   {
/*  569 */     if (this.openResults != null) {
/*  570 */       for (Iterator iter = this.openResults.iterator(); iter.hasNext();) {
/*  571 */         ResultSetInternalMethods element = (ResultSetInternalMethods)iter.next();
/*      */         try
/*      */         {
/*  574 */           element.realClose(false);
/*      */         } catch (SQLException sqlEx) {
/*  576 */           AssertionFailedException.shouldNotHappen(sqlEx);
/*      */         }
/*      */       }
/*      */       
/*  580 */       this.openResults.clear();
/*      */     }
/*      */   }
/*      */   
/*      */   public synchronized void removeOpenResultSet(ResultSet rs) {
/*  585 */     if (this.openResults != null) {
/*  586 */       this.openResults.remove(rs);
/*      */     }
/*      */   }
/*      */   
/*      */   public synchronized int getOpenResultSetCount() {
/*  591 */     if (this.openResults != null) {
/*  592 */       return this.openResults.size();
/*      */     }
/*      */     
/*  595 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private synchronized ResultSetInternalMethods createResultSetUsingServerFetch(String sql)
/*      */     throws SQLException
/*      */   {
/*  604 */     java.sql.PreparedStatement pStmt = this.connection.prepareStatement(sql, this.resultSetType, this.resultSetConcurrency);
/*      */     
/*      */ 
/*  607 */     pStmt.setFetchSize(this.fetchSize);
/*      */     
/*  609 */     if (this.maxRows > -1) {
/*  610 */       pStmt.setMaxRows(this.maxRows);
/*      */     }
/*      */     
/*  613 */     statementBegins();
/*      */     
/*  615 */     pStmt.execute();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  621 */     ResultSetInternalMethods rs = ((StatementImpl)pStmt).getResultSetInternal();
/*      */     
/*      */ 
/*  624 */     rs.setStatementUsedForFetchingRows((PreparedStatement)pStmt);
/*      */     
/*      */ 
/*  627 */     this.results = rs;
/*      */     
/*  629 */     return rs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized boolean createStreamingResultSet()
/*      */   {
/*  640 */     return (this.resultSetType == 1003) && (this.resultSetConcurrency == 1007) && (this.fetchSize == Integer.MIN_VALUE);
/*      */   }
/*      */   
/*      */ 
/*  644 */   private int originalResultSetType = 0;
/*  645 */   private int originalFetchSize = 0;
/*      */   
/*      */ 
/*      */   public synchronized void enableStreamingResults()
/*      */     throws SQLException
/*      */   {
/*  651 */     this.originalResultSetType = this.resultSetType;
/*  652 */     this.originalFetchSize = this.fetchSize;
/*      */     
/*  654 */     setFetchSize(Integer.MIN_VALUE);
/*  655 */     setResultSetType(1003);
/*      */   }
/*      */   
/*      */   public synchronized void disableStreamingResults() throws SQLException {
/*  659 */     if ((this.fetchSize == Integer.MIN_VALUE) && (this.resultSetType == 1003))
/*      */     {
/*  661 */       setFetchSize(this.originalFetchSize);
/*  662 */       setResultSetType(this.originalResultSetType);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean execute(String sql)
/*      */     throws SQLException
/*      */   {
/*  681 */     return execute(sql, false);
/*      */   }
/*      */   
/*      */   private synchronized boolean execute(String sql, boolean returnGeneratedKeys) throws SQLException {
/*  685 */     checkClosed();
/*      */     
/*  687 */     MySQLConnection locallyScopedConn = this.connection;
/*      */     char firstNonWsChar;
/*  689 */     boolean isSelect; boolean doStreaming; synchronized (locallyScopedConn) {
/*  690 */       this.retrieveGeneratedKeys = returnGeneratedKeys;
/*  691 */       this.lastQueryIsOnDupKeyUpdate = false;
/*  692 */       if (returnGeneratedKeys) {
/*  693 */         this.lastQueryIsOnDupKeyUpdate = containsOnDuplicateKeyInString(sql);
/*      */       }
/*  695 */       resetCancelledState();
/*      */       
/*  697 */       checkNullOrEmptyQuery(sql);
/*      */       
/*  699 */       checkClosed();
/*      */       
/*  701 */       firstNonWsChar = StringUtils.firstAlphaCharUc(sql, findStartOfStatement(sql));
/*      */       
/*  703 */       isSelect = true;
/*      */       
/*  705 */       if (firstNonWsChar != 'S') {
/*  706 */         isSelect = false;
/*      */         
/*  708 */         if (locallyScopedConn.isReadOnly()) {
/*  709 */           throw SQLError.createSQLException(Messages.getString("Statement.27") + Messages.getString("Statement.28"), "S1009", getExceptionInterceptor());
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  716 */       doStreaming = createStreamingResultSet();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  727 */       if ((doStreaming) && (locallyScopedConn.getNetTimeoutForStreamingResults() > 0))
/*      */       {
/*  729 */         executeSimpleNonQuery(locallyScopedConn, "SET net_write_timeout=" + locallyScopedConn.getNetTimeoutForStreamingResults());
/*      */       }
/*      */       
/*      */       Object escapedSqlResult;
/*  733 */       if (this.doEscapeProcessing) {
/*  734 */         escapedSqlResult = EscapeProcessor.escapeSQL(sql, locallyScopedConn.serverSupportsConvertFn(), locallyScopedConn);
/*      */         
/*      */ 
/*  737 */         if ((escapedSqlResult instanceof String)) {
/*  738 */           sql = (String)escapedSqlResult;
/*      */         } else {
/*  740 */           sql = ((EscapeProcessorResult)escapedSqlResult).escapedSql;
/*      */         }
/*      */       }
/*      */       
/*  744 */       if ((this.results != null) && 
/*  745 */         (!locallyScopedConn.getHoldResultsOpenOverStatementClose())) {
/*  746 */         this.results.realClose(false);
/*      */       }
/*      */       
/*      */ 
/*  750 */       if ((sql.charAt(0) == '/') && 
/*  751 */         (sql.startsWith("/* ping */"))) {
/*  752 */         doPingInstead();
/*      */         
/*  754 */         escapedSqlResult = 1;jsr 595;return (boolean)escapedSqlResult;
/*      */       }
/*      */       
/*      */ 
/*  758 */       CachedResultSetMetaData cachedMetaData = null;
/*      */       
/*  760 */       ResultSetInternalMethods rs = null;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  769 */       this.batchedGeneratedKeys = null;
/*      */       
/*  771 */       if (useServerFetch()) {
/*  772 */         rs = createResultSetUsingServerFetch(sql);
/*      */       } else {
/*  774 */         timeoutTask = null;
/*      */         
/*  776 */         String oldCatalog = null;
/*      */         try
/*      */         {
/*  779 */           if ((locallyScopedConn.getEnableQueryTimeouts()) && (this.timeoutInMillis != 0) && (locallyScopedConn.versionMeetsMinimum(5, 0, 0)))
/*      */           {
/*      */ 
/*  782 */             timeoutTask = new CancelTask(this);
/*  783 */             locallyScopedConn.getCancelTimer().schedule(timeoutTask, this.timeoutInMillis);
/*      */           }
/*      */           
/*      */ 
/*  787 */           if (!locallyScopedConn.getCatalog().equals(this.currentCatalog))
/*      */           {
/*  789 */             oldCatalog = locallyScopedConn.getCatalog();
/*  790 */             locallyScopedConn.setCatalog(this.currentCatalog);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  797 */           Field[] cachedFields = null;
/*      */           
/*  799 */           if (locallyScopedConn.getCacheResultSetMetadata()) {
/*  800 */             cachedMetaData = locallyScopedConn.getCachedMetaData(sql);
/*      */             
/*  802 */             if (cachedMetaData != null) {
/*  803 */               cachedFields = cachedMetaData.fields;
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  810 */           if (locallyScopedConn.useMaxRows()) {
/*  811 */             int rowLimit = -1;
/*      */             
/*  813 */             if (isSelect) {
/*  814 */               if (StringUtils.indexOfIgnoreCase(sql, "LIMIT") != -1) {
/*  815 */                 rowLimit = this.maxRows;
/*      */               }
/*  817 */               else if (this.maxRows <= 0) {
/*  818 */                 executeSimpleNonQuery(locallyScopedConn, "SET OPTION SQL_SELECT_LIMIT=DEFAULT");
/*      */               }
/*      */               else {
/*  821 */                 executeSimpleNonQuery(locallyScopedConn, "SET OPTION SQL_SELECT_LIMIT=" + this.maxRows);
/*      */               }
/*      */               
/*      */ 
/*      */             }
/*      */             else {
/*  827 */               executeSimpleNonQuery(locallyScopedConn, "SET OPTION SQL_SELECT_LIMIT=DEFAULT");
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*  832 */             statementBegins();
/*      */             
/*      */ 
/*  835 */             rs = locallyScopedConn.execSQL(this, sql, rowLimit, null, this.resultSetType, this.resultSetConcurrency, doStreaming, this.currentCatalog, cachedFields);
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*  840 */             statementBegins();
/*      */             
/*  842 */             rs = locallyScopedConn.execSQL(this, sql, -1, null, this.resultSetType, this.resultSetConcurrency, doStreaming, this.currentCatalog, cachedFields);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  848 */           if (timeoutTask != null) {
/*  849 */             if (timeoutTask.caughtWhileCancelling != null) {
/*  850 */               throw timeoutTask.caughtWhileCancelling;
/*      */             }
/*      */             
/*  853 */             timeoutTask.cancel();
/*  854 */             timeoutTask = null;
/*      */           }
/*      */           
/*  857 */           synchronized (this.cancelTimeoutMutex) {
/*  858 */             if (this.wasCancelled) {
/*  859 */               SQLException cause = null;
/*      */               
/*  861 */               if (this.wasCancelledByTimeout) {
/*  862 */                 cause = new MySQLTimeoutException();
/*      */               } else {
/*  864 */                 cause = new MySQLStatementCancelledException();
/*      */               }
/*      */               
/*  867 */               resetCancelledState();
/*      */               
/*  869 */               throw cause;
/*      */             }
/*      */           }
/*      */         } finally {
/*  873 */           if (timeoutTask != null) {
/*  874 */             timeoutTask.cancel();
/*  875 */             locallyScopedConn.getCancelTimer().purge();
/*      */           }
/*      */           
/*  878 */           if (oldCatalog != null) {
/*  879 */             locallyScopedConn.setCatalog(oldCatalog);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*  884 */       if (rs != null) {
/*  885 */         this.lastInsertId = rs.getUpdateID();
/*      */         
/*  887 */         this.results = rs;
/*      */         
/*  889 */         rs.setFirstCharOfQuery(firstNonWsChar);
/*      */         
/*  891 */         if (rs.reallyResult()) {
/*  892 */           if (cachedMetaData != null) {
/*  893 */             locallyScopedConn.initializeResultsMetadataFromCache(sql, cachedMetaData, this.results);
/*      */ 
/*      */           }
/*  896 */           else if (this.connection.getCacheResultSetMetadata()) {
/*  897 */             locallyScopedConn.initializeResultsMetadataFromCache(sql, null, this.results);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  904 */       CancelTask timeoutTask = (rs != null) && (rs.reallyResult()) ? 1 : 0;jsr 17;return timeoutTask;
/*      */     } finally {
/*  906 */       jsr 6; } localObject5 = returnAddress;this.statementExecuting.set(false);ret;
/*      */     
/*  908 */     localObject6 = finally;throw ((Throwable)localObject6);
/*      */   }
/*      */   
/*      */   protected void statementBegins() {
/*  912 */     this.clearWarningsCalled = false;
/*  913 */     this.statementExecuting.set(true);
/*      */   }
/*      */   
/*      */   protected synchronized void resetCancelledState() {
/*  917 */     if (this.cancelTimeoutMutex == null) {
/*  918 */       return;
/*      */     }
/*      */     
/*  921 */     synchronized (this.cancelTimeoutMutex) {
/*  922 */       this.wasCancelled = false;
/*  923 */       this.wasCancelledByTimeout = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean execute(String sql, int returnGeneratedKeys)
/*      */     throws SQLException
/*      */   {
/*  934 */     if (returnGeneratedKeys == 1) {
/*  935 */       checkClosed();
/*      */       
/*  937 */       MySQLConnection locallyScopedConn = this.connection;
/*      */       
/*  939 */       synchronized (locallyScopedConn)
/*      */       {
/*      */ 
/*      */ 
/*  943 */         boolean readInfoMsgState = this.connection.isReadInfoMsgEnabled();
/*      */         
/*  945 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */         try
/*      */         {
/*  948 */           boolean bool1 = execute(sql, true);jsr 17;return bool1;
/*      */         } finally {
/*  950 */           jsr 6; } localObject2 = returnAddress;locallyScopedConn.setReadInfoMsgEnabled(readInfoMsgState);ret;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  955 */     return execute(sql);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized boolean execute(String sql, int[] generatedKeyIndices)
/*      */     throws SQLException
/*      */   {
/*  963 */     if ((generatedKeyIndices != null) && (generatedKeyIndices.length > 0)) {
/*  964 */       checkClosed();
/*      */       
/*  966 */       MySQLConnection locallyScopedConn = this.connection;
/*      */       
/*  968 */       synchronized (locallyScopedConn) {
/*  969 */         this.retrieveGeneratedKeys = true;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  974 */         boolean readInfoMsgState = locallyScopedConn.isReadInfoMsgEnabled();
/*      */         
/*  976 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */         try
/*      */         {
/*  979 */           boolean bool1 = execute(sql, true);jsr 17;return bool1;
/*      */         } finally {
/*  981 */           jsr 6; } localObject2 = returnAddress;locallyScopedConn.setReadInfoMsgEnabled(readInfoMsgState);ret;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  986 */     return execute(sql);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized boolean execute(String sql, String[] generatedKeyNames)
/*      */     throws SQLException
/*      */   {
/*  994 */     if ((generatedKeyNames != null) && (generatedKeyNames.length > 0)) {
/*  995 */       checkClosed();
/*      */       
/*  997 */       MySQLConnection locallyScopedConn = this.connection;
/*      */       
/*  999 */       synchronized (locallyScopedConn) {
/* 1000 */         this.retrieveGeneratedKeys = true;
/*      */         
/*      */ 
/*      */ 
/* 1004 */         boolean readInfoMsgState = this.connection.isReadInfoMsgEnabled();
/*      */         
/* 1006 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */         try
/*      */         {
/* 1009 */           boolean bool1 = execute(sql, true);jsr 17;return bool1;
/*      */         } finally {
/* 1011 */           jsr 6; } localObject2 = returnAddress;locallyScopedConn.setReadInfoMsgEnabled(readInfoMsgState);ret;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1016 */     return execute(sql);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int[] executeBatch()
/*      */     throws SQLException
/*      */   {
/* 1034 */     checkClosed();
/*      */     
/* 1036 */     MySQLConnection locallyScopedConn = this.connection;
/*      */     
/* 1038 */     if (locallyScopedConn.isReadOnly()) {
/* 1039 */       throw SQLError.createSQLException(Messages.getString("Statement.34") + Messages.getString("Statement.35"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1045 */     if ((this.results != null) && 
/* 1046 */       (!locallyScopedConn.getHoldResultsOpenOverStatementClose())) {
/* 1047 */       this.results.realClose(false);
/*      */     }
/*      */     
/*      */ 
/* 1051 */     synchronized (locallyScopedConn) {
/* 1052 */       if ((this.batchedArgs == null) || (this.batchedArgs.size() == 0)) {
/* 1053 */         return new int[0];
/*      */       }
/*      */       
/*      */ 
/* 1057 */       int individualStatementTimeout = this.timeoutInMillis;
/* 1058 */       this.timeoutInMillis = 0;
/*      */       
/* 1060 */       CancelTask timeoutTask = null;
/*      */       try
/*      */       {
/* 1063 */         resetCancelledState();
/*      */         
/* 1065 */         statementBegins();
/*      */         try
/*      */         {
/* 1068 */           this.retrieveGeneratedKeys = true;
/*      */           
/* 1070 */           int[] updateCounts = null;
/*      */           
/*      */ 
/* 1073 */           if (this.batchedArgs != null) {
/* 1074 */             nbrCommands = this.batchedArgs.size();
/*      */             
/* 1076 */             this.batchedGeneratedKeys = new ArrayList(this.batchedArgs.size());
/*      */             
/* 1078 */             boolean multiQueriesEnabled = locallyScopedConn.getAllowMultiQueries();
/*      */             
/* 1080 */             if ((locallyScopedConn.versionMeetsMinimum(4, 1, 1)) && ((multiQueriesEnabled) || ((locallyScopedConn.getRewriteBatchedStatements()) && (nbrCommands > 4))))
/*      */             {
/*      */ 
/*      */ 
/* 1084 */               int[] arrayOfInt1 = executeBatchUsingMultiQueries(multiQueriesEnabled, nbrCommands, individualStatementTimeout);return arrayOfInt1;
/*      */             }
/*      */             
/* 1087 */             if ((locallyScopedConn.getEnableQueryTimeouts()) && (individualStatementTimeout != 0) && (locallyScopedConn.versionMeetsMinimum(5, 0, 0)))
/*      */             {
/*      */ 
/* 1090 */               timeoutTask = new CancelTask(this);
/* 1091 */               locallyScopedConn.getCancelTimer().schedule(timeoutTask, individualStatementTimeout);
/*      */             }
/*      */             
/*      */ 
/* 1095 */             updateCounts = new int[nbrCommands];
/*      */             
/* 1097 */             for (int i = 0; i < nbrCommands; i++) {
/* 1098 */               updateCounts[i] = -3;
/*      */             }
/*      */             
/* 1101 */             SQLException sqlEx = null;
/*      */             
/* 1103 */             int commandIndex = 0;
/*      */             
/* 1105 */             for (commandIndex = 0; commandIndex < nbrCommands; commandIndex++) {
/*      */               try {
/* 1107 */                 String sql = (String)this.batchedArgs.get(commandIndex);
/* 1108 */                 updateCounts[commandIndex] = executeUpdate(sql, true, true);
/*      */                 
/* 1110 */                 getBatchedGeneratedKeys(containsOnDuplicateKeyInString(sql) ? 1 : 0);
/*      */               } catch (SQLException ex) {
/* 1112 */                 updateCounts[commandIndex] = -3;
/*      */                 
/* 1114 */                 if ((this.continueBatchOnError) && (!(ex instanceof MySQLTimeoutException)) && (!(ex instanceof MySQLStatementCancelledException)) && (!hasDeadlockOrTimeoutRolledBackTx(ex)))
/*      */                 {
/*      */ 
/*      */ 
/* 1118 */                   sqlEx = ex;
/*      */                 } else {
/* 1120 */                   int[] newUpdateCounts = new int[commandIndex];
/*      */                   
/* 1122 */                   if (hasDeadlockOrTimeoutRolledBackTx(ex)) {
/* 1123 */                     for (int i = 0; i < newUpdateCounts.length; i++) {
/* 1124 */                       newUpdateCounts[i] = -3;
/*      */                     }
/*      */                   } else {
/* 1127 */                     System.arraycopy(updateCounts, 0, newUpdateCounts, 0, commandIndex);
/*      */                   }
/*      */                   
/*      */ 
/* 1131 */                   throw new BatchUpdateException(ex.getMessage(), ex.getSQLState(), ex.getErrorCode(), newUpdateCounts);
/*      */                 }
/*      */               }
/*      */             }
/*      */             
/*      */ 
/*      */ 
/* 1138 */             if (sqlEx != null) {
/* 1139 */               throw new BatchUpdateException(sqlEx.getMessage(), sqlEx.getSQLState(), sqlEx.getErrorCode(), updateCounts);
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 1145 */           if (timeoutTask != null) {
/* 1146 */             if (timeoutTask.caughtWhileCancelling != null) {
/* 1147 */               throw timeoutTask.caughtWhileCancelling;
/*      */             }
/*      */             
/* 1150 */             timeoutTask.cancel();
/*      */             
/* 1152 */             locallyScopedConn.getCancelTimer().purge();
/* 1153 */             timeoutTask = null;
/*      */           }
/*      */           
/* 1156 */           int nbrCommands = updateCounts != null ? updateCounts : new int[0];return nbrCommands;
/*      */         } finally {
/* 1158 */           this.statementExecuting.set(false);
/*      */         }
/*      */         
/*      */ 
/* 1162 */         localObject4 = returnAddress; } finally { jsr 6; } if (timeoutTask != null) {
/* 1163 */         timeoutTask.cancel();
/*      */         
/* 1165 */         locallyScopedConn.getCancelTimer().purge();
/*      */       }
/*      */       
/* 1168 */       resetCancelledState();
/*      */       
/* 1170 */       this.timeoutInMillis = individualStatementTimeout;
/*      */       
/* 1172 */       clearBatch();ret;
/*      */     }
/*      */   }
/*      */   
/*      */   protected final synchronized boolean hasDeadlockOrTimeoutRolledBackTx(SQLException ex)
/*      */   {
/* 1178 */     int vendorCode = ex.getErrorCode();
/*      */     
/* 1180 */     switch (vendorCode) {
/*      */     case 1206: 
/*      */     case 1213: 
/* 1183 */       return true;
/*      */     case 1205: 
/*      */       try {
/* 1186 */         return !this.connection.versionMeetsMinimum(5, 0, 13);
/*      */       }
/*      */       catch (SQLException sqlEx) {
/* 1189 */         return false;
/*      */       }
/*      */     }
/* 1192 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private synchronized int[] executeBatchUsingMultiQueries(boolean multiQueriesEnabled, int nbrCommands, int individualStatementTimeout)
/*      */     throws SQLException
/*      */   {
/* 1207 */     MySQLConnection locallyScopedConn = this.connection;
/*      */     
/* 1209 */     if (!multiQueriesEnabled) {
/* 1210 */       locallyScopedConn.getIO().enableMultiQueries();
/*      */     }
/*      */     
/* 1213 */     java.sql.Statement batchStmt = null;
/*      */     
/* 1215 */     CancelTask timeoutTask = null;
/*      */     try
/*      */     {
/* 1218 */       int[] updateCounts = new int[nbrCommands];
/*      */       
/* 1220 */       for (int i = 0; i < nbrCommands; i++) {
/* 1221 */         updateCounts[i] = -3;
/*      */       }
/*      */       
/* 1224 */       int commandIndex = 0;
/*      */       
/* 1226 */       StringBuffer queryBuf = new StringBuffer();
/*      */       
/* 1228 */       batchStmt = locallyScopedConn.createStatement();
/*      */       
/* 1230 */       if ((locallyScopedConn.getEnableQueryTimeouts()) && (individualStatementTimeout != 0) && (locallyScopedConn.versionMeetsMinimum(5, 0, 0)))
/*      */       {
/*      */ 
/* 1233 */         timeoutTask = new CancelTask((StatementImpl)batchStmt);
/* 1234 */         locallyScopedConn.getCancelTimer().schedule(timeoutTask, individualStatementTimeout);
/*      */       }
/*      */       
/*      */ 
/* 1238 */       int counter = 0;
/*      */       
/* 1240 */       int numberOfBytesPerChar = 1;
/*      */       
/* 1242 */       String connectionEncoding = locallyScopedConn.getEncoding();
/*      */       
/* 1244 */       if (StringUtils.startsWithIgnoreCase(connectionEncoding, "utf")) {
/* 1245 */         numberOfBytesPerChar = 3;
/* 1246 */       } else if (CharsetMapping.isMultibyteCharset(connectionEncoding)) {
/* 1247 */         numberOfBytesPerChar = 2;
/*      */       }
/*      */       
/* 1250 */       int escapeAdjust = 1;
/*      */       
/* 1252 */       batchStmt.setEscapeProcessing(this.doEscapeProcessing);
/*      */       
/* 1254 */       if (this.doEscapeProcessing)
/*      */       {
/* 1256 */         escapeAdjust = 2;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1261 */       SQLException sqlEx = null;
/*      */       
/* 1263 */       int argumentSetsInBatchSoFar = 0;
/*      */       
/* 1265 */       for (commandIndex = 0; commandIndex < nbrCommands; commandIndex++) {
/* 1266 */         String nextQuery = (String)this.batchedArgs.get(commandIndex);
/*      */         
/* 1268 */         if (((queryBuf.length() + nextQuery.length()) * numberOfBytesPerChar + 1 + 4) * escapeAdjust + 32 > this.connection.getMaxAllowedPacket())
/*      */         {
/*      */ 
/*      */           try
/*      */           {
/* 1273 */             batchStmt.execute(queryBuf.toString(), 1);
/*      */           } catch (SQLException ex) {
/* 1275 */             sqlEx = handleExceptionForBatch(commandIndex, argumentSetsInBatchSoFar, updateCounts, ex);
/*      */           }
/*      */           
/*      */ 
/* 1279 */           counter = processMultiCountsAndKeys((StatementImpl)batchStmt, counter, updateCounts);
/*      */           
/*      */ 
/* 1282 */           queryBuf = new StringBuffer();
/* 1283 */           argumentSetsInBatchSoFar = 0;
/*      */         }
/*      */         
/* 1286 */         queryBuf.append(nextQuery);
/* 1287 */         queryBuf.append(";");
/* 1288 */         argumentSetsInBatchSoFar++;
/*      */       }
/*      */       
/* 1291 */       if (queryBuf.length() > 0) {
/*      */         try {
/* 1293 */           batchStmt.execute(queryBuf.toString(), 1);
/*      */         } catch (SQLException ex) {
/* 1295 */           sqlEx = handleExceptionForBatch(commandIndex - 1, argumentSetsInBatchSoFar, updateCounts, ex);
/*      */         }
/*      */         
/*      */ 
/* 1299 */         counter = processMultiCountsAndKeys((StatementImpl)batchStmt, counter, updateCounts);
/*      */       }
/*      */       
/*      */ 
/* 1303 */       if (timeoutTask != null) {
/* 1304 */         if (timeoutTask.caughtWhileCancelling != null) {
/* 1305 */           throw timeoutTask.caughtWhileCancelling;
/*      */         }
/*      */         
/* 1308 */         timeoutTask.cancel();
/*      */         
/* 1310 */         locallyScopedConn.getCancelTimer().purge();
/*      */         
/* 1312 */         timeoutTask = null;
/*      */       }
/*      */       
/* 1315 */       if (sqlEx != null) {
/* 1316 */         throw new BatchUpdateException(sqlEx.getMessage(), sqlEx.getSQLState(), sqlEx.getErrorCode(), updateCounts);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1321 */       return updateCounts != null ? updateCounts : new int[0];
/*      */     } finally {
/* 1323 */       if (timeoutTask != null) {
/* 1324 */         timeoutTask.cancel();
/*      */         
/* 1326 */         locallyScopedConn.getCancelTimer().purge();
/*      */       }
/*      */       
/* 1329 */       resetCancelledState();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1337 */     ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized int processMultiCountsAndKeys(StatementImpl batchedStatement, int updateCountCounter, int[] updateCounts)
/*      */     throws SQLException
/*      */   {
/* 1346 */     updateCounts[(updateCountCounter++)] = batchedStatement.getUpdateCount();
/*      */     
/* 1348 */     boolean doGenKeys = this.batchedGeneratedKeys != null;
/*      */     
/* 1350 */     byte[][] row = (byte[][])null;
/*      */     
/* 1352 */     if (doGenKeys) {
/* 1353 */       long generatedKey = batchedStatement.getLastInsertID();
/*      */       
/* 1355 */       row = new byte[1][];
/* 1356 */       row[0] = StringUtils.getBytes(Long.toString(generatedKey));
/* 1357 */       this.batchedGeneratedKeys.add(new ByteArrayRow(row, getExceptionInterceptor()));
/*      */     }
/*      */     
/*      */ 
/* 1361 */     while ((batchedStatement.getMoreResults()) || (batchedStatement.getUpdateCount() != -1)) {
/* 1362 */       updateCounts[(updateCountCounter++)] = batchedStatement.getUpdateCount();
/*      */       
/* 1364 */       if (doGenKeys) {
/* 1365 */         long generatedKey = batchedStatement.getLastInsertID();
/*      */         
/* 1367 */         row = new byte[1][];
/* 1368 */         row[0] = StringUtils.getBytes(Long.toString(generatedKey));
/* 1369 */         this.batchedGeneratedKeys.add(new ByteArrayRow(row, getExceptionInterceptor()));
/*      */       }
/*      */     }
/*      */     
/* 1373 */     return updateCountCounter;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected SQLException handleExceptionForBatch(int endOfBatchIndex, int numValuesPerBatch, int[] updateCounts, SQLException ex)
/*      */     throws BatchUpdateException
/*      */   {
/* 1381 */     for (int j = endOfBatchIndex; j > endOfBatchIndex - numValuesPerBatch; j--) {
/* 1382 */       updateCounts[j] = -3;
/*      */     }
/*      */     SQLException sqlEx;
/* 1385 */     if ((this.continueBatchOnError) && (!(ex instanceof MySQLTimeoutException)) && (!(ex instanceof MySQLStatementCancelledException)) && (!hasDeadlockOrTimeoutRolledBackTx(ex)))
/*      */     {
/*      */ 
/*      */ 
/* 1389 */       sqlEx = ex;
/*      */     } else {
/* 1391 */       int[] newUpdateCounts = new int[endOfBatchIndex];
/* 1392 */       System.arraycopy(updateCounts, 0, newUpdateCounts, 0, endOfBatchIndex);
/*      */       
/*      */ 
/* 1395 */       BatchUpdateException batchException = new BatchUpdateException(ex.getMessage(), ex.getSQLState(), ex.getErrorCode(), newUpdateCounts);
/*      */       
/*      */ 
/* 1398 */       batchException.initCause(ex);
/* 1399 */       throw batchException;
/*      */     }
/*      */     SQLException sqlEx;
/* 1402 */     return sqlEx;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized ResultSet executeQuery(String sql)
/*      */     throws SQLException
/*      */   {
/* 1418 */     checkClosed();
/*      */     
/* 1420 */     MySQLConnection locallyScopedConn = this.connection;
/*      */     
/* 1422 */     synchronized (locallyScopedConn) {
/* 1423 */       this.retrieveGeneratedKeys = false;
/*      */       
/* 1425 */       resetCancelledState();
/*      */       
/* 1427 */       checkNullOrEmptyQuery(sql);
/*      */       
/* 1429 */       boolean doStreaming = createStreamingResultSet();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1439 */       if ((doStreaming) && (this.connection.getNetTimeoutForStreamingResults() > 0))
/*      */       {
/* 1441 */         executeSimpleNonQuery(locallyScopedConn, "SET net_write_timeout=" + this.connection.getNetTimeoutForStreamingResults());
/*      */       }
/*      */       
/*      */ 
/* 1445 */       if (this.doEscapeProcessing) {
/* 1446 */         Object escapedSqlResult = EscapeProcessor.escapeSQL(sql, locallyScopedConn.serverSupportsConvertFn(), this.connection);
/*      */         
/*      */ 
/* 1449 */         if ((escapedSqlResult instanceof String)) {
/* 1450 */           sql = (String)escapedSqlResult;
/*      */         } else {
/* 1452 */           sql = ((EscapeProcessorResult)escapedSqlResult).escapedSql;
/*      */         }
/*      */       }
/*      */       
/* 1456 */       char firstStatementChar = StringUtils.firstNonWsCharUc(sql, findStartOfStatement(sql));
/*      */       
/*      */ 
/* 1459 */       if ((sql.charAt(0) == '/') && 
/* 1460 */         (sql.startsWith("/* ping */"))) {
/* 1461 */         doPingInstead();
/*      */         
/* 1463 */         return this.results;
/*      */       }
/*      */       
/*      */ 
/* 1467 */       checkForDml(sql, firstStatementChar);
/*      */       
/* 1469 */       if ((this.results != null) && 
/* 1470 */         (!locallyScopedConn.getHoldResultsOpenOverStatementClose())) {
/* 1471 */         this.results.realClose(false);
/*      */       }
/*      */       
/*      */ 
/* 1475 */       CachedResultSetMetaData cachedMetaData = null;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1484 */       if (useServerFetch()) {
/* 1485 */         this.results = createResultSetUsingServerFetch(sql);
/*      */         
/* 1487 */         return this.results;
/*      */       }
/*      */       
/* 1490 */       CancelTask timeoutTask = null;
/*      */       
/* 1492 */       String oldCatalog = null;
/*      */       try
/*      */       {
/* 1495 */         if ((locallyScopedConn.getEnableQueryTimeouts()) && (this.timeoutInMillis != 0) && (locallyScopedConn.versionMeetsMinimum(5, 0, 0)))
/*      */         {
/*      */ 
/* 1498 */           timeoutTask = new CancelTask(this);
/* 1499 */           locallyScopedConn.getCancelTimer().schedule(timeoutTask, this.timeoutInMillis);
/*      */         }
/*      */         
/*      */ 
/* 1503 */         if (!locallyScopedConn.getCatalog().equals(this.currentCatalog)) {
/* 1504 */           oldCatalog = locallyScopedConn.getCatalog();
/* 1505 */           locallyScopedConn.setCatalog(this.currentCatalog);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1512 */         Field[] cachedFields = null;
/*      */         
/* 1514 */         if (locallyScopedConn.getCacheResultSetMetadata()) {
/* 1515 */           cachedMetaData = locallyScopedConn.getCachedMetaData(sql);
/*      */           
/* 1517 */           if (cachedMetaData != null) {
/* 1518 */             cachedFields = cachedMetaData.fields;
/*      */           }
/*      */         }
/*      */         
/* 1522 */         if (locallyScopedConn.useMaxRows())
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/* 1527 */           if (StringUtils.indexOfIgnoreCase(sql, "LIMIT") != -1) {
/* 1528 */             this.results = locallyScopedConn.execSQL(this, sql, this.maxRows, null, this.resultSetType, this.resultSetConcurrency, doStreaming, this.currentCatalog, cachedFields);
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/* 1534 */             if (this.maxRows <= 0) {
/* 1535 */               executeSimpleNonQuery(locallyScopedConn, "SET OPTION SQL_SELECT_LIMIT=DEFAULT");
/*      */             }
/*      */             else {
/* 1538 */               executeSimpleNonQuery(locallyScopedConn, "SET OPTION SQL_SELECT_LIMIT=" + this.maxRows);
/*      */             }
/*      */             
/*      */ 
/* 1542 */             statementBegins();
/*      */             
/* 1544 */             this.results = locallyScopedConn.execSQL(this, sql, -1, null, this.resultSetType, this.resultSetConcurrency, doStreaming, this.currentCatalog, cachedFields);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1550 */             if (oldCatalog != null) {
/* 1551 */               locallyScopedConn.setCatalog(oldCatalog);
/*      */             }
/*      */           }
/*      */         } else {
/* 1555 */           statementBegins();
/*      */           
/* 1557 */           this.results = locallyScopedConn.execSQL(this, sql, -1, null, this.resultSetType, this.resultSetConcurrency, doStreaming, this.currentCatalog, cachedFields);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1563 */         if (timeoutTask != null) {
/* 1564 */           if (timeoutTask.caughtWhileCancelling != null) {
/* 1565 */             throw timeoutTask.caughtWhileCancelling;
/*      */           }
/*      */           
/* 1568 */           timeoutTask.cancel();
/*      */           
/* 1570 */           locallyScopedConn.getCancelTimer().purge();
/*      */           
/* 1572 */           timeoutTask = null;
/*      */         }
/*      */         
/* 1575 */         synchronized (this.cancelTimeoutMutex) {
/* 1576 */           if (this.wasCancelled) {
/* 1577 */             SQLException cause = null;
/*      */             
/* 1579 */             if (this.wasCancelledByTimeout) {
/* 1580 */               cause = new MySQLTimeoutException();
/*      */             } else {
/* 1582 */               cause = new MySQLStatementCancelledException();
/*      */             }
/*      */             
/* 1585 */             resetCancelledState();
/*      */             
/* 1587 */             throw cause;
/*      */           }
/*      */         }
/*      */       } finally {
/* 1591 */         this.statementExecuting.set(false);
/*      */         
/* 1593 */         if (timeoutTask != null) {
/* 1594 */           timeoutTask.cancel();
/*      */           
/* 1596 */           locallyScopedConn.getCancelTimer().purge();
/*      */         }
/*      */         
/* 1599 */         if (oldCatalog != null) {
/* 1600 */           locallyScopedConn.setCatalog(oldCatalog);
/*      */         }
/*      */       }
/*      */       
/* 1604 */       this.lastInsertId = this.results.getUpdateID();
/*      */       
/* 1606 */       if (cachedMetaData != null) {
/* 1607 */         locallyScopedConn.initializeResultsMetadataFromCache(sql, cachedMetaData, this.results);
/*      */ 
/*      */       }
/* 1610 */       else if (this.connection.getCacheResultSetMetadata()) {
/* 1611 */         locallyScopedConn.initializeResultsMetadataFromCache(sql, null, this.results);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1616 */       return this.results;
/*      */     }
/*      */   }
/*      */   
/*      */   protected synchronized void doPingInstead() throws SQLException {
/* 1621 */     if (this.pingTarget != null) {
/* 1622 */       this.pingTarget.doPing();
/*      */     } else {
/* 1624 */       this.connection.ping();
/*      */     }
/*      */     
/* 1627 */     ResultSetInternalMethods fakeSelectOneResultSet = generatePingResultSet();
/* 1628 */     this.results = fakeSelectOneResultSet;
/*      */   }
/*      */   
/*      */   protected synchronized ResultSetInternalMethods generatePingResultSet() throws SQLException {
/* 1632 */     Field[] fields = { new Field(null, "1", -5, 1) };
/* 1633 */     ArrayList rows = new ArrayList();
/* 1634 */     byte[] colVal = { 49 };
/*      */     
/* 1636 */     rows.add(new ByteArrayRow(new byte[][] { colVal }, getExceptionInterceptor()));
/*      */     
/* 1638 */     return (ResultSetInternalMethods)DatabaseMetaData.buildResultSet(fields, rows, this.connection);
/*      */   }
/*      */   
/*      */   protected void executeSimpleNonQuery(MySQLConnection c, String nonQuery)
/*      */     throws SQLException
/*      */   {
/* 1644 */     c.execSQL(this, nonQuery, -1, null, 1003, 1007, false, this.currentCatalog, null, false).close();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int executeUpdate(String sql)
/*      */     throws SQLException
/*      */   {
/* 1666 */     return executeUpdate(sql, false, false);
/*      */   }
/*      */   
/*      */   protected synchronized int executeUpdate(String sql, boolean isBatch, boolean returnGeneratedKeys) throws SQLException
/*      */   {
/* 1671 */     checkClosed();
/*      */     
/* 1673 */     MySQLConnection locallyScopedConn = this.connection;
/*      */     
/* 1675 */     char firstStatementChar = StringUtils.firstAlphaCharUc(sql, findStartOfStatement(sql));
/*      */     
/*      */ 
/* 1678 */     ResultSetInternalMethods rs = null;
/*      */     
/* 1680 */     synchronized (locallyScopedConn) {
/* 1681 */       this.retrieveGeneratedKeys = returnGeneratedKeys;
/*      */       
/* 1683 */       resetCancelledState();
/*      */       
/* 1685 */       checkNullOrEmptyQuery(sql);
/*      */       
/* 1687 */       if (this.doEscapeProcessing) {
/* 1688 */         Object escapedSqlResult = EscapeProcessor.escapeSQL(sql, this.connection.serverSupportsConvertFn(), this.connection);
/*      */         
/*      */ 
/* 1691 */         if ((escapedSqlResult instanceof String)) {
/* 1692 */           sql = (String)escapedSqlResult;
/*      */         } else {
/* 1694 */           sql = ((EscapeProcessorResult)escapedSqlResult).escapedSql;
/*      */         }
/*      */       }
/*      */       
/* 1698 */       if (locallyScopedConn.isReadOnly()) {
/* 1699 */         throw SQLError.createSQLException(Messages.getString("Statement.42") + Messages.getString("Statement.43"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1705 */       if (StringUtils.startsWithIgnoreCaseAndWs(sql, "select")) {
/* 1706 */         throw SQLError.createSQLException(Messages.getString("Statement.46"), "01S03", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1711 */       if ((this.results != null) && 
/* 1712 */         (!locallyScopedConn.getHoldResultsOpenOverStatementClose())) {
/* 1713 */         this.results.realClose(false);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1721 */       CancelTask timeoutTask = null;
/*      */       
/* 1723 */       String oldCatalog = null;
/*      */       try
/*      */       {
/* 1726 */         if ((locallyScopedConn.getEnableQueryTimeouts()) && (this.timeoutInMillis != 0) && (locallyScopedConn.versionMeetsMinimum(5, 0, 0)))
/*      */         {
/*      */ 
/* 1729 */           timeoutTask = new CancelTask(this);
/* 1730 */           locallyScopedConn.getCancelTimer().schedule(timeoutTask, this.timeoutInMillis);
/*      */         }
/*      */         
/*      */ 
/* 1734 */         if (!locallyScopedConn.getCatalog().equals(this.currentCatalog)) {
/* 1735 */           oldCatalog = locallyScopedConn.getCatalog();
/* 1736 */           locallyScopedConn.setCatalog(this.currentCatalog);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1742 */         if (locallyScopedConn.useMaxRows()) {
/* 1743 */           executeSimpleNonQuery(locallyScopedConn, "SET OPTION SQL_SELECT_LIMIT=DEFAULT");
/*      */         }
/*      */         
/*      */ 
/* 1747 */         statementBegins();
/*      */         
/* 1749 */         rs = locallyScopedConn.execSQL(this, sql, -1, null, 1003, 1007, false, this.currentCatalog, null, isBatch);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1756 */         if (timeoutTask != null) {
/* 1757 */           if (timeoutTask.caughtWhileCancelling != null) {
/* 1758 */             throw timeoutTask.caughtWhileCancelling;
/*      */           }
/*      */           
/* 1761 */           timeoutTask.cancel();
/*      */           
/* 1763 */           locallyScopedConn.getCancelTimer().purge();
/*      */           
/* 1765 */           timeoutTask = null;
/*      */         }
/*      */         
/* 1768 */         synchronized (this.cancelTimeoutMutex) {
/* 1769 */           if (this.wasCancelled) {
/* 1770 */             SQLException cause = null;
/*      */             
/* 1772 */             if (this.wasCancelledByTimeout) {
/* 1773 */               cause = new MySQLTimeoutException();
/*      */             } else {
/* 1775 */               cause = new MySQLStatementCancelledException();
/*      */             }
/*      */             
/* 1778 */             resetCancelledState();
/*      */             
/* 1780 */             throw cause;
/*      */           }
/*      */         }
/*      */       } finally {
/* 1784 */         if (timeoutTask != null) {
/* 1785 */           timeoutTask.cancel();
/*      */           
/* 1787 */           locallyScopedConn.getCancelTimer().purge();
/*      */         }
/*      */         
/* 1790 */         if (oldCatalog != null) {
/* 1791 */           locallyScopedConn.setCatalog(oldCatalog);
/*      */         }
/*      */         
/* 1794 */         if (!isBatch) {
/* 1795 */           this.statementExecuting.set(false);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1800 */     this.results = rs;
/*      */     
/* 1802 */     rs.setFirstCharOfQuery(firstStatementChar);
/*      */     
/* 1804 */     this.updateCount = rs.getUpdateCount();
/*      */     
/* 1806 */     int truncatedUpdateCount = 0;
/*      */     
/* 1808 */     if (this.updateCount > 2147483647L) {
/* 1809 */       truncatedUpdateCount = Integer.MAX_VALUE;
/*      */     } else {
/* 1811 */       truncatedUpdateCount = (int)this.updateCount;
/*      */     }
/*      */     
/* 1814 */     this.lastInsertId = rs.getUpdateID();
/*      */     
/* 1816 */     return truncatedUpdateCount;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int executeUpdate(String sql, int returnGeneratedKeys)
/*      */     throws SQLException
/*      */   {
/* 1825 */     if (returnGeneratedKeys == 1) {
/* 1826 */       checkClosed();
/*      */       
/* 1828 */       MySQLConnection locallyScopedConn = this.connection;
/*      */       
/* 1830 */       synchronized (locallyScopedConn)
/*      */       {
/*      */ 
/*      */ 
/* 1834 */         boolean readInfoMsgState = locallyScopedConn.isReadInfoMsgEnabled();
/*      */         
/* 1836 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */         try
/*      */         {
/* 1839 */           int i = executeUpdate(sql, false, true);jsr 17;return i;
/*      */         } finally {
/* 1841 */           jsr 6; } localObject2 = returnAddress;locallyScopedConn.setReadInfoMsgEnabled(readInfoMsgState);ret;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1846 */     return executeUpdate(sql);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized int executeUpdate(String sql, int[] generatedKeyIndices)
/*      */     throws SQLException
/*      */   {
/* 1854 */     if ((generatedKeyIndices != null) && (generatedKeyIndices.length > 0)) {
/* 1855 */       checkClosed();
/*      */       
/* 1857 */       MySQLConnection locallyScopedConn = this.connection;
/*      */       
/* 1859 */       synchronized (locallyScopedConn)
/*      */       {
/*      */ 
/*      */ 
/* 1863 */         boolean readInfoMsgState = locallyScopedConn.isReadInfoMsgEnabled();
/*      */         
/* 1865 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */         try
/*      */         {
/* 1868 */           int i = executeUpdate(sql, false, true);jsr 17;return i;
/*      */         } finally {
/* 1870 */           jsr 6; } localObject2 = returnAddress;locallyScopedConn.setReadInfoMsgEnabled(readInfoMsgState);ret;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1875 */     return executeUpdate(sql);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized int executeUpdate(String sql, String[] generatedKeyNames)
/*      */     throws SQLException
/*      */   {
/* 1883 */     if ((generatedKeyNames != null) && (generatedKeyNames.length > 0)) {
/* 1884 */       checkClosed();
/*      */       
/* 1886 */       MySQLConnection locallyScopedConn = this.connection;
/*      */       
/* 1888 */       synchronized (locallyScopedConn)
/*      */       {
/*      */ 
/*      */ 
/* 1892 */         boolean readInfoMsgState = this.connection.isReadInfoMsgEnabled();
/*      */         
/* 1894 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */         try
/*      */         {
/* 1897 */           int i = executeUpdate(sql, false, true);jsr 17;return i;
/*      */         } finally {
/* 1899 */           jsr 6; } localObject2 = returnAddress;locallyScopedConn.setReadInfoMsgEnabled(readInfoMsgState);ret;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1904 */     return executeUpdate(sql);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized Calendar getCalendarInstanceForSessionOrNew()
/*      */   {
/* 1912 */     if (this.connection != null) {
/* 1913 */       return this.connection.getCalendarInstanceForSessionOrNew();
/*      */     }
/*      */     
/* 1916 */     return new GregorianCalendar();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized java.sql.Connection getConnection()
/*      */     throws SQLException
/*      */   {
/* 1929 */     return this.connection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getFetchDirection()
/*      */     throws SQLException
/*      */   {
/* 1941 */     return 1000;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int getFetchSize()
/*      */     throws SQLException
/*      */   {
/* 1953 */     return this.fetchSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized ResultSet getGeneratedKeys()
/*      */     throws SQLException
/*      */   {
/* 1966 */     if (!this.retrieveGeneratedKeys) {
/* 1967 */       throw SQLError.createSQLException(Messages.getString("Statement.GeneratedKeysNotRequested"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/* 1970 */     if (this.batchedGeneratedKeys == null) {
/* 1971 */       if (this.lastQueryIsOnDupKeyUpdate) {
/* 1972 */         return getGeneratedKeysInternal(1);
/*      */       }
/* 1974 */       return getGeneratedKeysInternal();
/*      */     }
/*      */     
/* 1977 */     Field[] fields = new Field[1];
/* 1978 */     fields[0] = new Field("", "GENERATED_KEY", -5, 17);
/* 1979 */     fields[0].setConnection(this.connection);
/*      */     
/* 1981 */     return ResultSetImpl.getInstance(this.currentCatalog, fields, new RowDataStatic(this.batchedGeneratedKeys), this.connection, this, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ResultSet getGeneratedKeysInternal()
/*      */     throws SQLException
/*      */   {
/* 1993 */     int numKeys = getUpdateCount();
/* 1994 */     return getGeneratedKeysInternal(numKeys);
/*      */   }
/*      */   
/*      */   protected synchronized ResultSet getGeneratedKeysInternal(int numKeys) throws SQLException
/*      */   {
/* 1999 */     Field[] fields = new Field[1];
/* 2000 */     fields[0] = new Field("", "GENERATED_KEY", -5, 17);
/* 2001 */     fields[0].setConnection(this.connection);
/* 2002 */     fields[0].setUseOldNameMetadata(true);
/*      */     
/* 2004 */     ArrayList rowSet = new ArrayList();
/*      */     
/* 2006 */     long beginAt = getLastInsertID();
/*      */     
/* 2008 */     if (beginAt < 0L) {
/* 2009 */       fields[0].setUnsigned();
/*      */     }
/*      */     
/* 2012 */     if (this.results != null) {
/* 2013 */       String serverInfo = this.results.getServerInfo();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2019 */       if ((numKeys > 0) && (this.results.getFirstCharOfQuery() == 'R') && (serverInfo != null) && (serverInfo.length() > 0))
/*      */       {
/* 2021 */         numKeys = getRecordCountFromInfo(serverInfo);
/*      */       }
/*      */       
/* 2024 */       if ((beginAt != 0L) && (numKeys > 0)) {
/* 2025 */         for (int i = 0; i < numKeys; i++) {
/* 2026 */           byte[][] row = new byte[1][];
/* 2027 */           if (beginAt > 0L) {
/* 2028 */             row[0] = StringUtils.getBytes(Long.toString(beginAt));
/*      */           } else {
/* 2030 */             byte[] asBytes = new byte[8];
/* 2031 */             asBytes[7] = ((byte)(int)(beginAt & 0xFF));
/* 2032 */             asBytes[6] = ((byte)(int)(beginAt >>> 8));
/* 2033 */             asBytes[5] = ((byte)(int)(beginAt >>> 16));
/* 2034 */             asBytes[4] = ((byte)(int)(beginAt >>> 24));
/* 2035 */             asBytes[3] = ((byte)(int)(beginAt >>> 32));
/* 2036 */             asBytes[2] = ((byte)(int)(beginAt >>> 40));
/* 2037 */             asBytes[1] = ((byte)(int)(beginAt >>> 48));
/* 2038 */             asBytes[0] = ((byte)(int)(beginAt >>> 56));
/*      */             
/* 2040 */             BigInteger val = new BigInteger(1, asBytes);
/*      */             
/* 2042 */             row[0] = val.toString().getBytes();
/*      */           }
/* 2044 */           rowSet.add(new ByteArrayRow(row, getExceptionInterceptor()));
/* 2045 */           beginAt += this.connection.getAutoIncrementIncrement();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2050 */     ResultSetImpl gkRs = ResultSetImpl.getInstance(this.currentCatalog, fields, new RowDataStatic(rowSet), this.connection, this, false);
/*      */     
/*      */ 
/* 2053 */     this.openResults.add(gkRs);
/*      */     
/* 2055 */     return gkRs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int getId()
/*      */   {
/* 2064 */     return this.statementId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized long getLastInsertID()
/*      */   {
/* 2081 */     return this.lastInsertId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized long getLongUpdateCount()
/*      */   {
/* 2097 */     if (this.results == null) {
/* 2098 */       return -1L;
/*      */     }
/*      */     
/* 2101 */     if (this.results.reallyResult()) {
/* 2102 */       return -1L;
/*      */     }
/*      */     
/* 2105 */     return this.updateCount;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int getMaxFieldSize()
/*      */     throws SQLException
/*      */   {
/* 2120 */     return this.maxFieldSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int getMaxRows()
/*      */     throws SQLException
/*      */   {
/* 2134 */     if (this.maxRows <= 0) {
/* 2135 */       return 0;
/*      */     }
/*      */     
/* 2138 */     return this.maxRows;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getMoreResults()
/*      */     throws SQLException
/*      */   {
/* 2151 */     return getMoreResults(1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized boolean getMoreResults(int current)
/*      */     throws SQLException
/*      */   {
/* 2159 */     if (this.results == null) {
/* 2160 */       return false;
/*      */     }
/*      */     
/* 2163 */     boolean streamingMode = createStreamingResultSet();
/*      */     
/* 2165 */     while ((streamingMode) && 
/* 2166 */       (this.results.reallyResult()) && 
/* 2167 */       (this.results.next())) {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2172 */     ResultSetInternalMethods nextResultSet = this.results.getNextResultSet();
/*      */     
/* 2174 */     switch (current)
/*      */     {
/*      */     case 1: 
/* 2177 */       if (this.results != null) {
/* 2178 */         if (!streamingMode) {
/* 2179 */           this.results.close();
/*      */         }
/*      */         
/* 2182 */         this.results.clearNextResult();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       break;
/*      */     case 3: 
/* 2189 */       if (this.results != null) {
/* 2190 */         if (!streamingMode) {
/* 2191 */           this.results.close();
/*      */         }
/*      */         
/* 2194 */         this.results.clearNextResult();
/*      */       }
/*      */       
/* 2197 */       closeAllOpenResults();
/*      */       
/* 2199 */       break;
/*      */     
/*      */     case 2: 
/* 2202 */       if (!this.connection.getDontTrackOpenResources()) {
/* 2203 */         this.openResults.add(this.results);
/*      */       }
/*      */       
/* 2206 */       this.results.clearNextResult();
/*      */       
/* 2208 */       break;
/*      */     
/*      */     default: 
/* 2211 */       throw SQLError.createSQLException(Messages.getString("Statement.19"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */     
/*      */ 
/* 2216 */     this.results = nextResultSet;
/*      */     
/* 2218 */     if (this.results == null) {
/* 2219 */       this.updateCount = -1L;
/* 2220 */       this.lastInsertId = -1L;
/* 2221 */     } else if (this.results.reallyResult()) {
/* 2222 */       this.updateCount = -1L;
/* 2223 */       this.lastInsertId = -1L;
/*      */     } else {
/* 2225 */       this.updateCount = this.results.getUpdateCount();
/* 2226 */       this.lastInsertId = this.results.getUpdateID();
/*      */     }
/*      */     
/* 2229 */     return (this.results != null) && (this.results.reallyResult());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int getQueryTimeout()
/*      */     throws SQLException
/*      */   {
/* 2244 */     return this.timeoutInMillis / 1000;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getRecordCountFromInfo(String serverInfo)
/*      */   {
/* 2256 */     StringBuffer recordsBuf = new StringBuffer();
/* 2257 */     int recordsCount = 0;
/* 2258 */     int duplicatesCount = 0;
/*      */     
/* 2260 */     char c = '\000';
/*      */     
/* 2262 */     int length = serverInfo.length();
/* 2263 */     for (int i = 0; 
/*      */         
/* 2265 */         i < length; i++) {
/* 2266 */       c = serverInfo.charAt(i);
/*      */       
/* 2268 */       if (Character.isDigit(c)) {
/*      */         break;
/*      */       }
/*      */     }
/*      */     
/* 2273 */     recordsBuf.append(c);
/* 2274 */     i++;
/* 2276 */     for (; 
/* 2276 */         i < length; i++) {
/* 2277 */       c = serverInfo.charAt(i);
/*      */       
/* 2279 */       if (!Character.isDigit(c)) {
/*      */         break;
/*      */       }
/*      */       
/* 2283 */       recordsBuf.append(c);
/*      */     }
/*      */     
/* 2286 */     recordsCount = Integer.parseInt(recordsBuf.toString());
/*      */     
/* 2288 */     StringBuffer duplicatesBuf = new StringBuffer();
/* 2290 */     for (; 
/* 2290 */         i < length; i++) {
/* 2291 */       c = serverInfo.charAt(i);
/*      */       
/* 2293 */       if (Character.isDigit(c)) {
/*      */         break;
/*      */       }
/*      */     }
/*      */     
/* 2298 */     duplicatesBuf.append(c);
/* 2299 */     i++;
/* 2301 */     for (; 
/* 2301 */         i < length; i++) {
/* 2302 */       c = serverInfo.charAt(i);
/*      */       
/* 2304 */       if (!Character.isDigit(c)) {
/*      */         break;
/*      */       }
/*      */       
/* 2308 */       duplicatesBuf.append(c);
/*      */     }
/*      */     
/* 2311 */     duplicatesCount = Integer.parseInt(duplicatesBuf.toString());
/*      */     
/* 2313 */     return recordsCount - duplicatesCount;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized ResultSet getResultSet()
/*      */     throws SQLException
/*      */   {
/* 2326 */     return (this.results != null) && (this.results.reallyResult()) ? this.results : null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int getResultSetConcurrency()
/*      */     throws SQLException
/*      */   {
/* 2339 */     return this.resultSetConcurrency;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getResultSetHoldability()
/*      */     throws SQLException
/*      */   {
/* 2346 */     return 1;
/*      */   }
/*      */   
/*      */   protected synchronized ResultSetInternalMethods getResultSetInternal() {
/* 2350 */     return this.results;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int getResultSetType()
/*      */     throws SQLException
/*      */   {
/* 2362 */     return this.resultSetType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int getUpdateCount()
/*      */     throws SQLException
/*      */   {
/* 2376 */     if (this.results == null) {
/* 2377 */       return -1;
/*      */     }
/*      */     
/* 2380 */     if (this.results.reallyResult()) {
/* 2381 */       return -1;
/*      */     }
/*      */     
/* 2384 */     int truncatedUpdateCount = 0;
/*      */     
/* 2386 */     if (this.results.getUpdateCount() > 2147483647L) {
/* 2387 */       truncatedUpdateCount = Integer.MAX_VALUE;
/*      */     } else {
/* 2389 */       truncatedUpdateCount = (int)this.results.getUpdateCount();
/*      */     }
/*      */     
/* 2392 */     return truncatedUpdateCount;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized SQLWarning getWarnings()
/*      */     throws SQLException
/*      */   {
/* 2417 */     checkClosed();
/*      */     
/* 2419 */     if (this.clearWarningsCalled) {
/* 2420 */       return null;
/*      */     }
/*      */     
/* 2423 */     if ((this.connection != null) && (!this.connection.isClosed()) && (this.connection.versionMeetsMinimum(4, 1, 0)))
/*      */     {
/* 2425 */       SQLWarning pendingWarningsFromServer = SQLError.convertShowWarningsToSQLWarnings(this.connection);
/*      */       
/*      */ 
/* 2428 */       if (this.warningChain != null) {
/* 2429 */         this.warningChain.setNextWarning(pendingWarningsFromServer);
/*      */       } else {
/* 2431 */         this.warningChain = pendingWarningsFromServer;
/*      */       }
/*      */       
/* 2434 */       return this.warningChain;
/*      */     }
/*      */     
/* 2437 */     return this.warningChain;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void realClose(boolean calledExplicitly, boolean closeOpenResults)
/*      */     throws SQLException
/*      */   {
/* 2451 */     if (this.isClosed) {
/* 2452 */       return;
/*      */     }
/*      */     
/* 2455 */     if ((this.useUsageAdvisor) && 
/* 2456 */       (!calledExplicitly)) {
/* 2457 */       String message = Messages.getString("Statement.63") + Messages.getString("Statement.64");
/*      */       
/*      */ 
/* 2460 */       this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", this.currentCatalog, this.connectionId, getId(), -1, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, message));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2470 */     if (closeOpenResults) {
/* 2471 */       closeOpenResults = !this.holdResultsOpenOverClose;
/*      */     }
/*      */     
/* 2474 */     if (closeOpenResults) {
/* 2475 */       if (this.results != null) {
/*      */         try
/*      */         {
/* 2478 */           this.results.close();
/*      */         }
/*      */         catch (Exception ex) {}
/*      */       }
/*      */       
/*      */ 
/* 2484 */       closeAllOpenResults();
/*      */     }
/*      */     
/* 2487 */     if (this.connection != null) {
/* 2488 */       if (this.maxRowsChanged) {
/* 2489 */         this.connection.unsetMaxRows(this);
/*      */       }
/*      */       
/* 2492 */       if (!this.connection.getDontTrackOpenResources()) {
/* 2493 */         this.connection.unregisterStatement(this);
/*      */       }
/*      */     }
/*      */     
/* 2497 */     this.isClosed = true;
/*      */     
/* 2499 */     this.results = null;
/* 2500 */     this.connection = null;
/* 2501 */     this.warningChain = null;
/* 2502 */     this.openResults = null;
/* 2503 */     this.batchedGeneratedKeys = null;
/* 2504 */     this.localInfileInputStream = null;
/* 2505 */     this.pingTarget = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCursorName(String name)
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setEscapeProcessing(boolean enable)
/*      */     throws SQLException
/*      */   {
/* 2541 */     this.doEscapeProcessing = enable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFetchDirection(int direction)
/*      */     throws SQLException
/*      */   {
/* 2558 */     switch (direction)
/*      */     {
/*      */     case 1000: 
/*      */     case 1001: 
/*      */     case 1002: 
/*      */       break;
/*      */     default: 
/* 2565 */       throw SQLError.createSQLException(Messages.getString("Statement.5"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setFetchSize(int rows)
/*      */     throws SQLException
/*      */   {
/* 2586 */     if (((rows < 0) && (rows != Integer.MIN_VALUE)) || ((this.maxRows != 0) && (this.maxRows != -1) && (rows > getMaxRows())))
/*      */     {
/*      */ 
/* 2589 */       throw SQLError.createSQLException(Messages.getString("Statement.7"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2594 */     this.fetchSize = rows;
/*      */   }
/*      */   
/*      */   public synchronized void setHoldResultsOpenOverClose(boolean holdResultsOpenOverClose) {
/* 2598 */     this.holdResultsOpenOverClose = holdResultsOpenOverClose;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setMaxFieldSize(int max)
/*      */     throws SQLException
/*      */   {
/* 2611 */     if (max < 0) {
/* 2612 */       throw SQLError.createSQLException(Messages.getString("Statement.11"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2617 */     int maxBuf = this.connection != null ? this.connection.getMaxAllowedPacket() : MysqlIO.getMaxBuf();
/*      */     
/*      */ 
/* 2620 */     if (max > maxBuf) {
/* 2621 */       throw SQLError.createSQLException(Messages.getString("Statement.13", new Object[] { Long.valueOf(maxBuf) }), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2627 */     this.maxFieldSize = max;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setMaxRows(int max)
/*      */     throws SQLException
/*      */   {
/* 2642 */     if ((max > 50000000) || (max < 0)) {
/* 2643 */       throw SQLError.createSQLException(Messages.getString("Statement.15") + max + " > " + 50000000 + ".", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2650 */     if (max == 0) {
/* 2651 */       max = -1;
/*      */     }
/*      */     
/* 2654 */     this.maxRows = max;
/* 2655 */     this.maxRowsChanged = true;
/*      */     
/* 2657 */     if (this.maxRows == -1) {
/* 2658 */       this.connection.unsetMaxRows(this);
/* 2659 */       this.maxRowsChanged = false;
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/* 2666 */       this.connection.maxRowsChanged(this);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setQueryTimeout(int seconds)
/*      */     throws SQLException
/*      */   {
/* 2680 */     if (seconds < 0) {
/* 2681 */       throw SQLError.createSQLException(Messages.getString("Statement.21"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2686 */     this.timeoutInMillis = (seconds * 1000);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   synchronized void setResultSetConcurrency(int concurrencyFlag)
/*      */   {
/* 2696 */     this.resultSetConcurrency = concurrencyFlag;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   synchronized void setResultSetType(int typeFlag)
/*      */   {
/* 2706 */     this.resultSetType = typeFlag;
/*      */   }
/*      */   
/*      */   protected synchronized void getBatchedGeneratedKeys(java.sql.Statement batchedStatement) throws SQLException {
/* 2710 */     if (this.retrieveGeneratedKeys) {
/* 2711 */       ResultSet rs = null;
/*      */       try
/*      */       {
/* 2714 */         rs = batchedStatement.getGeneratedKeys();
/*      */         
/* 2716 */         while (rs.next()) {
/* 2717 */           this.batchedGeneratedKeys.add(new ByteArrayRow(new byte[][] { rs.getBytes(1) }, getExceptionInterceptor()));
/*      */         }
/*      */       }
/*      */       finally {
/* 2721 */         if (rs != null) {
/* 2722 */           rs.close();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected synchronized void getBatchedGeneratedKeys(int maxKeys) throws SQLException {
/* 2729 */     if (this.retrieveGeneratedKeys) {
/* 2730 */       ResultSet rs = null;
/*      */       try
/*      */       {
/* 2733 */         if (maxKeys == 0) {
/* 2734 */           rs = getGeneratedKeysInternal();
/*      */         } else {
/* 2736 */           rs = getGeneratedKeysInternal(maxKeys);
/*      */         }
/* 2738 */         while (rs.next()) {
/* 2739 */           this.batchedGeneratedKeys.add(new ByteArrayRow(new byte[][] { rs.getBytes(1) }, getExceptionInterceptor()));
/*      */         }
/*      */       }
/*      */       finally {
/* 2743 */         if (rs != null) {
/* 2744 */           rs.close();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private synchronized boolean useServerFetch()
/*      */     throws SQLException
/*      */   {
/* 2755 */     return (this.connection.isCursorFetchEnabled()) && (this.fetchSize > 0) && (this.resultSetConcurrency == 1007) && (this.resultSetType == 1003);
/*      */   }
/*      */   
/*      */   public synchronized boolean isClosed()
/*      */     throws SQLException
/*      */   {
/* 2761 */     return this.isClosed;
/*      */   }
/*      */   
/* 2764 */   private boolean isPoolable = true;
/*      */   private InputStream localInfileInputStream;
/*      */   
/* 2767 */   public boolean isPoolable() throws SQLException { return this.isPoolable; }
/*      */   
/*      */   public void setPoolable(boolean poolable) throws SQLException
/*      */   {
/* 2771 */     this.isPoolable = poolable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isWrapperFor(Class iface)
/*      */     throws SQLException
/*      */   {
/* 2790 */     checkClosed();
/*      */     
/*      */ 
/*      */ 
/* 2794 */     return iface.isInstance(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object unwrap(Class iface)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 2815 */       return Util.cast(iface, this);
/*      */     } catch (ClassCastException cce) {
/* 2817 */       throw SQLError.createSQLException("Unable to unwrap to " + iface.toString(), "S1009", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */   protected int findStartOfStatement(String sql)
/*      */   {
/* 2823 */     int statementStartPos = 0;
/*      */     
/* 2825 */     if (StringUtils.startsWithIgnoreCaseAndWs(sql, "/*")) {
/* 2826 */       statementStartPos = sql.indexOf("*/");
/*      */       
/* 2828 */       if (statementStartPos == -1) {
/* 2829 */         statementStartPos = 0;
/*      */       } else {
/* 2831 */         statementStartPos += 2;
/*      */       }
/* 2833 */     } else if ((StringUtils.startsWithIgnoreCaseAndWs(sql, "--")) || (StringUtils.startsWithIgnoreCaseAndWs(sql, "#")))
/*      */     {
/* 2835 */       statementStartPos = sql.indexOf('\n');
/*      */       
/* 2837 */       if (statementStartPos == -1) {
/* 2838 */         statementStartPos = sql.indexOf('\r');
/*      */         
/* 2840 */         if (statementStartPos == -1) {
/* 2841 */           statementStartPos = 0;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2846 */     return statementStartPos;
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized InputStream getLocalInfileInputStream()
/*      */   {
/* 2852 */     return this.localInfileInputStream;
/*      */   }
/*      */   
/*      */   public synchronized void setLocalInfileInputStream(InputStream stream) {
/* 2856 */     this.localInfileInputStream = stream;
/*      */   }
/*      */   
/*      */   public synchronized void setPingTarget(PingTarget pingTarget) {
/* 2860 */     this.pingTarget = pingTarget;
/*      */   }
/*      */   
/*      */   public ExceptionInterceptor getExceptionInterceptor() {
/* 2864 */     return this.exceptionInterceptor;
/*      */   }
/*      */   
/*      */   protected boolean containsOnDuplicateKeyInString(String sql) {
/* 2868 */     return getOnDuplicateKeyLocation(sql) != -1;
/*      */   }
/*      */   
/*      */   protected synchronized int getOnDuplicateKeyLocation(String sql) {
/* 2872 */     return StringUtils.indexOfIgnoreCaseRespectMarker(0, sql, "ON DUPLICATE KEY UPDATE ", "\"'`", "\"'`", !this.connection.isNoBackslashEscapesSet());
/*      */   }
/*      */ }


/* Location:              C:\Users\Static\Desktop\G10_Prototype_Client.jar!\mysql-connector-java-5.1.19-bin.jar!\com\mysql\jdbc\StatementImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */