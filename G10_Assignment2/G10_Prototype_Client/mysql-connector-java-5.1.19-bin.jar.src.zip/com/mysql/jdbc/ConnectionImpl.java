/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.log.Log;
/*      */ import com.mysql.jdbc.log.LogFactory;
/*      */ import com.mysql.jdbc.log.NullLogger;
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import com.mysql.jdbc.profiler.ProfilerEventHandler;
/*      */ import com.mysql.jdbc.util.LRUCache;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Method;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.CharBuffer;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.CharsetEncoder;
/*      */ import java.nio.charset.UnsupportedCharsetException;
/*      */ import java.sql.Blob;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Savepoint;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Enumeration;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Properties;
/*      */ import java.util.Random;
/*      */ import java.util.Set;
/*      */ import java.util.Stack;
/*      */ import java.util.TimeZone;
/*      */ import java.util.Timer;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ConnectionImpl
/*      */   extends ConnectionPropertiesImpl
/*      */   implements MySQLConnection
/*      */ {
/*      */   private static final String JDBC_LOCAL_CHARACTER_SET_RESULTS = "jdbc.local.character_set_results";
/*      */   
/*      */   public String getHost()
/*      */   {
/*   83 */     return this.host;
/*      */   }
/*      */   
/*   86 */   private MySQLConnection proxy = null;
/*      */   
/*      */   public boolean isProxySet() {
/*   89 */     return this.proxy != null;
/*      */   }
/*      */   
/*      */   public void setProxy(MySQLConnection proxy) {
/*   93 */     this.proxy = proxy;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private MySQLConnection getProxy()
/*      */   {
/*  100 */     return this.proxy != null ? this.proxy : this;
/*      */   }
/*      */   
/*      */   public MySQLConnection getLoadBalanceSafeProxy() {
/*  104 */     return getProxy();
/*      */   }
/*      */   
/*      */   class ExceptionInterceptorChain implements ExceptionInterceptor
/*      */   {
/*      */     List<Extension> interceptors;
/*      */     
/*      */     ExceptionInterceptorChain(String interceptorClasses) throws SQLException {
/*  112 */       this.interceptors = Util.loadExtensions(ConnectionImpl.this, ConnectionImpl.this.props, interceptorClasses, "Connection.BadExceptionInterceptor", this);
/*      */     }
/*      */     
/*      */     public SQLException interceptException(SQLException sqlEx, Connection conn) {
/*  116 */       if (this.interceptors != null) {
/*  117 */         Iterator<Extension> iter = this.interceptors.iterator();
/*      */         
/*  119 */         while (iter.hasNext()) {
/*  120 */           sqlEx = ((ExceptionInterceptor)iter.next()).interceptException(sqlEx, ConnectionImpl.this);
/*      */         }
/*      */       }
/*      */       
/*  124 */       return sqlEx;
/*      */     }
/*      */     
/*      */     public void destroy() {
/*  128 */       if (this.interceptors != null) {
/*  129 */         Iterator<Extension> iter = this.interceptors.iterator();
/*      */         
/*  131 */         while (iter.hasNext()) {
/*  132 */           ((ExceptionInterceptor)iter.next()).destroy();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public void init(Connection conn, Properties properties) throws SQLException
/*      */     {
/*  139 */       if (this.interceptors != null) {
/*  140 */         Iterator<Extension> iter = this.interceptors.iterator();
/*      */         
/*  142 */         while (iter.hasNext()) {
/*  143 */           ((ExceptionInterceptor)iter.next()).init(conn, properties);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static class CompoundCacheKey
/*      */   {
/*      */     String componentOne;
/*      */     
/*      */     String componentTwo;
/*      */     
/*      */     int hashCode;
/*      */     
/*      */ 
/*      */     CompoundCacheKey(String partOne, String partTwo)
/*      */     {
/*  162 */       this.componentOne = partOne;
/*  163 */       this.componentTwo = partTwo;
/*      */       
/*      */ 
/*      */ 
/*  167 */       this.hashCode = ((this.componentOne != null ? this.componentOne : "") + this.componentTwo).hashCode();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean equals(Object obj)
/*      */     {
/*  177 */       if ((obj instanceof CompoundCacheKey)) {
/*  178 */         CompoundCacheKey another = (CompoundCacheKey)obj;
/*      */         
/*  180 */         boolean firstPartEqual = false;
/*      */         
/*  182 */         if (this.componentOne == null) {
/*  183 */           firstPartEqual = another.componentOne == null;
/*      */         } else {
/*  185 */           firstPartEqual = this.componentOne.equals(another.componentOne);
/*      */         }
/*      */         
/*      */ 
/*  189 */         return (firstPartEqual) && (this.componentTwo.equals(another.componentTwo));
/*      */       }
/*      */       
/*      */ 
/*  193 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public int hashCode()
/*      */     {
/*  202 */       return this.hashCode;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  210 */   private static final Object CHARSET_CONVERTER_NOT_AVAILABLE_MARKER = new Object();
/*      */   
/*      */ 
/*      */ 
/*      */   public static Map<?, ?> charsetMap;
/*      */   
/*      */ 
/*      */ 
/*      */   protected static final String DEFAULT_LOGGER_CLASS = "com.mysql.jdbc.log.StandardLogger";
/*      */   
/*      */ 
/*      */ 
/*      */   private static final int HISTOGRAM_BUCKETS = 20;
/*      */   
/*      */ 
/*      */ 
/*      */   private static final String LOGGER_INSTANCE_NAME = "MySQL";
/*      */   
/*      */ 
/*      */ 
/*  230 */   private static Map<String, Integer> mapTransIsolationNameToValue = null;
/*      */   
/*      */ 
/*  233 */   private static final Log NULL_LOGGER = new NullLogger("MySQL");
/*      */   
/*      */   private static Map<?, ?> roundRobinStatsMap;
/*      */   
/*  237 */   private static final Map<String, Map<Long, String>> serverCollationByUrl = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  243 */   private static final Map<String, Map<Integer, String>> serverJavaCharsetByUrl = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  248 */   private static final Map<String, Map<Integer, String>> serverCustomCharsetByUrl = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  253 */   private static final Map<String, Map<String, Integer>> serverCustomMblenByUrl = new HashMap();
/*      */   
/*  255 */   private static final Map<String, Map<String, String>> serverConfigByUrl = new HashMap();
/*      */   
/*      */   private long queryTimeCount;
/*      */   
/*      */   private double queryTimeSum;
/*      */   
/*      */   private double queryTimeSumSquares;
/*      */   
/*      */   private double queryTimeMean;
/*      */   
/*      */   private transient Timer cancelTimer;
/*      */   private List<Extension> connectionLifecycleInterceptors;
/*      */   private static final Constructor<?> JDBC_4_CONNECTION_CTOR;
/*      */   private static final int DEFAULT_RESULT_SET_TYPE = 1003;
/*      */   private static final int DEFAULT_RESULT_SET_CONCURRENCY = 1007;
/*      */   
/*      */   static
/*      */   {
/*  273 */     mapTransIsolationNameToValue = new HashMap(8);
/*  274 */     mapTransIsolationNameToValue.put("READ-UNCOMMITED", Integer.valueOf(1));
/*  275 */     mapTransIsolationNameToValue.put("READ-UNCOMMITTED", Integer.valueOf(1));
/*  276 */     mapTransIsolationNameToValue.put("READ-COMMITTED", Integer.valueOf(2));
/*  277 */     mapTransIsolationNameToValue.put("REPEATABLE-READ", Integer.valueOf(4));
/*  278 */     mapTransIsolationNameToValue.put("SERIALIZABLE", Integer.valueOf(8));
/*      */     
/*  280 */     if (Util.isJdbc4()) {
/*      */       try {
/*  282 */         JDBC_4_CONNECTION_CTOR = Class.forName("com.mysql.jdbc.JDBC4Connection").getConstructor(new Class[] { String.class, Integer.TYPE, Properties.class, String.class, String.class });
/*      */ 
/*      */       }
/*      */       catch (SecurityException e)
/*      */       {
/*  287 */         throw new RuntimeException(e);
/*      */       } catch (NoSuchMethodException e) {
/*  289 */         throw new RuntimeException(e);
/*      */       } catch (ClassNotFoundException e) {
/*  291 */         throw new RuntimeException(e);
/*      */       }
/*      */     } else {
/*  294 */       JDBC_4_CONNECTION_CTOR = null;
/*      */     }
/*      */   }
/*      */   
/*      */   protected static SQLException appendMessageToException(SQLException sqlEx, String messageToAppend, ExceptionInterceptor interceptor)
/*      */   {
/*  300 */     String origMessage = sqlEx.getMessage();
/*  301 */     String sqlState = sqlEx.getSQLState();
/*  302 */     int vendorErrorCode = sqlEx.getErrorCode();
/*      */     
/*  304 */     StringBuffer messageBuf = new StringBuffer(origMessage.length() + messageToAppend.length());
/*      */     
/*  306 */     messageBuf.append(origMessage);
/*  307 */     messageBuf.append(messageToAppend);
/*      */     
/*  309 */     SQLException sqlExceptionWithNewMessage = SQLError.createSQLException(messageBuf.toString(), sqlState, vendorErrorCode, interceptor);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  319 */       Method getStackTraceMethod = null;
/*  320 */       Method setStackTraceMethod = null;
/*  321 */       Object theStackTraceAsObject = null;
/*      */       
/*  323 */       Class<?> stackTraceElementClass = Class.forName("java.lang.StackTraceElement");
/*  324 */       Class<?> stackTraceElementArrayClass = Array.newInstance(stackTraceElementClass, new int[] { 0 }).getClass();
/*      */       
/*      */ 
/*  327 */       getStackTraceMethod = Throwable.class.getMethod("getStackTrace", new Class[0]);
/*      */       
/*      */ 
/*  330 */       setStackTraceMethod = Throwable.class.getMethod("setStackTrace", new Class[] { stackTraceElementArrayClass });
/*      */       
/*      */ 
/*  333 */       if ((getStackTraceMethod != null) && (setStackTraceMethod != null)) {
/*  334 */         theStackTraceAsObject = getStackTraceMethod.invoke(sqlEx, new Object[0]);
/*      */         
/*  336 */         setStackTraceMethod.invoke(sqlExceptionWithNewMessage, new Object[] { theStackTraceAsObject });
/*      */       }
/*      */     }
/*      */     catch (NoClassDefFoundError noClassDefFound) {}catch (NoSuchMethodException noSuchMethodEx) {}catch (Throwable catchAll) {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  347 */     return sqlExceptionWithNewMessage;
/*      */   }
/*      */   
/*      */   public synchronized Timer getCancelTimer() {
/*  351 */     if (this.cancelTimer == null) {
/*  352 */       boolean createdNamedTimer = false;
/*      */       
/*      */ 
/*      */       try
/*      */       {
/*  357 */         Constructor<Timer> ctr = Timer.class.getConstructor(new Class[] { String.class, Boolean.TYPE });
/*      */         
/*  359 */         this.cancelTimer = ((Timer)ctr.newInstance(new Object[] { "MySQL Statement Cancellation Timer", Boolean.TRUE }));
/*  360 */         createdNamedTimer = true;
/*      */       } catch (Throwable t) {
/*  362 */         createdNamedTimer = false;
/*      */       }
/*      */       
/*  365 */       if (!createdNamedTimer) {
/*  366 */         this.cancelTimer = new Timer(true);
/*      */       }
/*      */     }
/*      */     
/*  370 */     return this.cancelTimer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static Connection getInstance(String hostToConnectTo, int portToConnectTo, Properties info, String databaseToConnectTo, String url)
/*      */     throws SQLException
/*      */   {
/*  384 */     if (!Util.isJdbc4()) {
/*  385 */       return new ConnectionImpl(hostToConnectTo, portToConnectTo, info, databaseToConnectTo, url);
/*      */     }
/*      */     
/*      */ 
/*  389 */     return (Connection)Util.handleNewInstance(JDBC_4_CONNECTION_CTOR, new Object[] { hostToConnectTo, Integer.valueOf(portToConnectTo), info, databaseToConnectTo, url }, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  395 */   private static final Random random = new Random();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static synchronized int getNextRoundRobinHostIndex(String url, List<?> hostList)
/*      */   {
/*  402 */     int indexRange = hostList.size();
/*      */     
/*  404 */     int index = random.nextInt(indexRange);
/*      */     
/*  406 */     return index;
/*      */   }
/*      */   
/*      */   private static boolean nullSafeCompare(String s1, String s2) {
/*  410 */     if ((s1 == null) && (s2 == null)) {
/*  411 */       return true;
/*      */     }
/*      */     
/*  414 */     if ((s1 == null) && (s2 != null)) {
/*  415 */       return false;
/*      */     }
/*      */     
/*  418 */     return (s1 != null) && (s1.equals(s2));
/*      */   }
/*      */   
/*      */ 
/*  422 */   private boolean autoCommit = true;
/*      */   
/*      */ 
/*      */ 
/*      */   private Map<Object, Object> cachedPreparedStatementParams;
/*      */   
/*      */ 
/*      */ 
/*  430 */   private String characterSetMetadata = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  436 */   private String characterSetResultsOnServer = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  443 */   private Map<String, Object> charsetConverterMap = new HashMap(CharsetMapping.getNumberOfCharsetsConfigured());
/*      */   
/*      */ 
/*      */ 
/*  447 */   private long connectionCreationTimeMillis = 0L;
/*      */   
/*      */ 
/*      */   private long connectionId;
/*      */   
/*      */ 
/*  453 */   private String database = null;
/*      */   
/*      */ 
/*  456 */   private java.sql.DatabaseMetaData dbmd = null;
/*      */   
/*      */ 
/*      */   private TimeZone defaultTimeZone;
/*      */   
/*      */ 
/*      */   private ProfilerEventHandler eventSink;
/*      */   
/*      */ 
/*      */   private Throwable forceClosedReason;
/*      */   
/*  467 */   private boolean hasIsolationLevels = false;
/*      */   
/*      */ 
/*  470 */   private boolean hasQuotedIdentifiers = false;
/*      */   
/*      */ 
/*  473 */   private String host = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  479 */   public Map<Integer, String> indexToJavaCharset = new HashMap();
/*      */   
/*  481 */   public Map<Integer, String> indexToCustomMysqlCharset = new HashMap();
/*      */   
/*  483 */   private Map<String, Integer> mysqlCharsetToCustomMblen = new HashMap();
/*      */   
/*      */ 
/*  486 */   private transient MysqlIO io = null;
/*      */   
/*  488 */   private boolean isClientTzUTC = false;
/*      */   
/*      */ 
/*  491 */   private boolean isClosed = true;
/*      */   
/*      */ 
/*  494 */   private boolean isInGlobalTx = false;
/*      */   
/*      */ 
/*  497 */   private boolean isRunningOnJDK13 = false;
/*      */   
/*      */ 
/*  500 */   private int isolationLevel = 2;
/*      */   
/*  502 */   private boolean isServerTzUTC = false;
/*      */   
/*      */ 
/*  505 */   private long lastQueryFinishedTime = 0L;
/*      */   
/*      */ 
/*  508 */   private transient Log log = NULL_LOGGER;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  514 */   private long longestQueryTimeMs = 0L;
/*      */   
/*      */ 
/*  517 */   private boolean lowerCaseTableNames = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  522 */   private long maximumNumberTablesAccessed = 0L;
/*      */   
/*      */ 
/*  525 */   private boolean maxRowsChanged = false;
/*      */   
/*      */ 
/*      */   private long metricsLastReportedMs;
/*      */   
/*  530 */   private long minimumNumberTablesAccessed = Long.MAX_VALUE;
/*      */   
/*      */ 
/*  533 */   private String myURL = null;
/*      */   
/*      */ 
/*  536 */   private boolean needsPing = false;
/*      */   
/*  538 */   private int netBufferLength = 16384;
/*      */   
/*  540 */   private boolean noBackslashEscapes = false;
/*      */   
/*  542 */   private long numberOfPreparedExecutes = 0L;
/*      */   
/*  544 */   private long numberOfPrepares = 0L;
/*      */   
/*  546 */   private long numberOfQueriesIssued = 0L;
/*      */   
/*  548 */   private long numberOfResultSetsCreated = 0L;
/*      */   
/*      */   private long[] numTablesMetricsHistBreakpoints;
/*      */   
/*      */   private int[] numTablesMetricsHistCounts;
/*      */   
/*  554 */   private long[] oldHistBreakpoints = null;
/*      */   
/*  556 */   private int[] oldHistCounts = null;
/*      */   
/*      */ 
/*      */   private Map<Statement, Statement> openStatements;
/*      */   
/*      */   private LRUCache parsedCallableStatementCache;
/*      */   
/*  563 */   private boolean parserKnowsUnicode = false;
/*      */   
/*      */ 
/*  566 */   private String password = null;
/*      */   
/*      */ 
/*      */   private long[] perfMetricsHistBreakpoints;
/*      */   
/*      */ 
/*      */   private int[] perfMetricsHistCounts;
/*      */   
/*      */   private Throwable pointOfOrigin;
/*      */   
/*  576 */   private int port = 3306;
/*      */   
/*      */ 
/*  579 */   protected Properties props = null;
/*      */   
/*      */ 
/*  582 */   private boolean readInfoMsg = false;
/*      */   
/*      */ 
/*  585 */   private boolean readOnly = false;
/*      */   
/*      */ 
/*      */   protected LRUCache resultSetMetadataCache;
/*      */   
/*      */ 
/*  591 */   private TimeZone serverTimezoneTZ = null;
/*      */   
/*      */ 
/*  594 */   private Map<String, String> serverVariables = null;
/*      */   
/*  596 */   private long shortestQueryTimeMs = Long.MAX_VALUE;
/*      */   
/*      */ 
/*      */   private Map<Statement, Statement> statementsUsingMaxRows;
/*      */   
/*  601 */   private double totalQueryTimeMs = 0.0D;
/*      */   
/*      */ 
/*  604 */   private boolean transactionsSupported = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private Map<?, ?> typeMap;
/*      */   
/*      */ 
/*      */ 
/*  613 */   private boolean useAnsiQuotes = false;
/*      */   
/*      */ 
/*  616 */   private String user = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  622 */   private boolean useServerPreparedStmts = false;
/*      */   
/*      */   private LRUCache serverSideStatementCheckCache;
/*      */   
/*      */   private LRUCache serverSideStatementCache;
/*      */   
/*      */   private Calendar sessionCalendar;
/*      */   
/*      */   private Calendar utcCalendar;
/*      */   
/*      */   private String origHostToConnectTo;
/*      */   
/*      */   private int origPortToConnectTo;
/*      */   
/*      */   private String origDatabaseToConnectTo;
/*      */   
/*  638 */   private String errorMessageEncoding = "Cp1252";
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean usePlatformCharsetConverters;
/*      */   
/*      */ 
/*  645 */   private boolean hasTriedMasterFlag = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  651 */   private String statementComment = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean storesLowerCaseTableName;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private List<StatementInterceptorV2> statementInterceptors;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean requiresEscapingEncoder;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String hostPortPair;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ConnectionImpl(String hostToConnectTo, int portToConnectTo, Properties info, String databaseToConnectTo, String url)
/*      */     throws SQLException
/*      */   {
/*  693 */     this.connectionCreationTimeMillis = System.currentTimeMillis();
/*  694 */     this.pointOfOrigin = new Throwable();
/*      */     
/*  696 */     if (databaseToConnectTo == null) {
/*  697 */       databaseToConnectTo = "";
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  704 */     this.origHostToConnectTo = hostToConnectTo;
/*  705 */     this.origPortToConnectTo = portToConnectTo;
/*  706 */     this.origDatabaseToConnectTo = databaseToConnectTo;
/*      */     try
/*      */     {
/*  709 */       Blob.class.getMethod("truncate", new Class[] { Long.TYPE });
/*      */       
/*  711 */       this.isRunningOnJDK13 = false;
/*      */     } catch (NoSuchMethodException nsme) {
/*  713 */       this.isRunningOnJDK13 = true;
/*      */     }
/*      */     
/*  716 */     this.sessionCalendar = new GregorianCalendar();
/*  717 */     this.utcCalendar = new GregorianCalendar();
/*  718 */     this.utcCalendar.setTimeZone(TimeZone.getTimeZone("GMT"));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  730 */     this.log = LogFactory.getLogger(getLogger(), "MySQL", getExceptionInterceptor());
/*      */     
/*      */ 
/*      */ 
/*  734 */     this.defaultTimeZone = Util.getDefaultTimeZone();
/*      */     
/*  736 */     if ("GMT".equalsIgnoreCase(this.defaultTimeZone.getID())) {
/*  737 */       this.isClientTzUTC = true;
/*      */     } else {
/*  739 */       this.isClientTzUTC = false;
/*      */     }
/*      */     
/*  742 */     this.openStatements = new HashMap();
/*      */     
/*  744 */     if (NonRegisteringDriver.isHostPropertiesList(hostToConnectTo)) {
/*  745 */       Properties hostSpecificProps = NonRegisteringDriver.expandHostKeyValues(hostToConnectTo);
/*      */       
/*  747 */       Enumeration<?> propertyNames = hostSpecificProps.propertyNames();
/*      */       
/*  749 */       while (propertyNames.hasMoreElements()) {
/*  750 */         String propertyName = propertyNames.nextElement().toString();
/*  751 */         String propertyValue = hostSpecificProps.getProperty(propertyName);
/*      */         
/*  753 */         info.setProperty(propertyName, propertyValue);
/*      */       }
/*      */       
/*      */     }
/*  757 */     else if (hostToConnectTo == null) {
/*  758 */       this.host = "localhost";
/*  759 */       this.hostPortPair = (this.host + ":" + portToConnectTo);
/*      */     } else {
/*  761 */       this.host = hostToConnectTo;
/*      */       
/*  763 */       if (hostToConnectTo.indexOf(":") == -1) {
/*  764 */         this.hostPortPair = (this.host + ":" + portToConnectTo);
/*      */       } else {
/*  766 */         this.hostPortPair = this.host;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  771 */     this.port = portToConnectTo;
/*      */     
/*  773 */     this.database = databaseToConnectTo;
/*  774 */     this.myURL = url;
/*  775 */     this.user = info.getProperty("user");
/*  776 */     this.password = info.getProperty("password");
/*      */     
/*      */ 
/*  779 */     if ((this.user == null) || (this.user.equals(""))) {
/*  780 */       this.user = "";
/*      */     }
/*      */     
/*  783 */     if (this.password == null) {
/*  784 */       this.password = "";
/*      */     }
/*      */     
/*  787 */     this.props = info;
/*      */     
/*      */ 
/*      */ 
/*  791 */     initializeDriverProperties(info);
/*      */     
/*      */     try
/*      */     {
/*  795 */       this.dbmd = getMetaData(false, false);
/*  796 */       initializeSafeStatementInterceptors();
/*  797 */       createNewIO(false);
/*  798 */       unSafeStatementInterceptors();
/*      */     } catch (SQLException ex) {
/*  800 */       cleanup(ex);
/*      */       
/*      */ 
/*  803 */       throw ex;
/*      */     } catch (Exception ex) {
/*  805 */       cleanup(ex);
/*      */       
/*  807 */       StringBuffer mesg = new StringBuffer(128);
/*      */       
/*  809 */       if (!getParanoid()) {
/*  810 */         mesg.append("Cannot connect to MySQL server on ");
/*  811 */         mesg.append(this.host);
/*  812 */         mesg.append(":");
/*  813 */         mesg.append(this.port);
/*  814 */         mesg.append(".\n\n");
/*  815 */         mesg.append("Make sure that there is a MySQL server ");
/*  816 */         mesg.append("running on the machine/port you are trying ");
/*  817 */         mesg.append("to connect to and that the machine this software is running on ");
/*      */         
/*      */ 
/*  820 */         mesg.append("is able to connect to this host/port (i.e. not firewalled). ");
/*      */         
/*  822 */         mesg.append("Also make sure that the server has not been started with the --skip-networking ");
/*      */         
/*      */ 
/*  825 */         mesg.append("flag.\n\n");
/*      */       } else {
/*  827 */         mesg.append("Unable to connect to database.");
/*      */       }
/*      */       
/*  830 */       SQLException sqlEx = SQLError.createSQLException(mesg.toString(), "08S01", getExceptionInterceptor());
/*      */       
/*      */ 
/*  833 */       sqlEx.initCause(ex);
/*      */       
/*  835 */       throw sqlEx;
/*      */     }
/*      */   }
/*      */   
/*      */   public void unSafeStatementInterceptors() throws SQLException
/*      */   {
/*  841 */     ArrayList<StatementInterceptorV2> unSafedStatementInterceptors = new ArrayList(this.statementInterceptors.size());
/*      */     
/*  843 */     for (int i = 0; i < this.statementInterceptors.size(); i++) {
/*  844 */       NoSubInterceptorWrapper wrappedInterceptor = (NoSubInterceptorWrapper)this.statementInterceptors.get(i);
/*      */       
/*  846 */       unSafedStatementInterceptors.add(wrappedInterceptor.getUnderlyingInterceptor());
/*      */     }
/*      */     
/*  849 */     this.statementInterceptors = unSafedStatementInterceptors;
/*      */     
/*  851 */     if (this.io != null) {
/*  852 */       this.io.setStatementInterceptors(this.statementInterceptors);
/*      */     }
/*      */   }
/*      */   
/*      */   public void initializeSafeStatementInterceptors() throws SQLException {
/*  857 */     this.isClosed = false;
/*      */     
/*  859 */     List<Extension> unwrappedInterceptors = Util.loadExtensions(this, this.props, getStatementInterceptors(), "MysqlIo.BadStatementInterceptor", getExceptionInterceptor());
/*      */     
/*      */ 
/*      */ 
/*  863 */     this.statementInterceptors = new ArrayList(unwrappedInterceptors.size());
/*      */     
/*  865 */     for (int i = 0; i < unwrappedInterceptors.size(); i++) {
/*  866 */       Extension interceptor = (Extension)unwrappedInterceptors.get(i);
/*      */       
/*      */ 
/*      */ 
/*  870 */       if ((interceptor instanceof StatementInterceptor)) {
/*  871 */         if (ReflectiveStatementInterceptorAdapter.getV2PostProcessMethod(interceptor.getClass()) != null) {
/*  872 */           this.statementInterceptors.add(new NoSubInterceptorWrapper(new ReflectiveStatementInterceptorAdapter((StatementInterceptor)interceptor)));
/*      */         } else {
/*  874 */           this.statementInterceptors.add(new NoSubInterceptorWrapper(new V1toV2StatementInterceptorAdapter((StatementInterceptor)interceptor)));
/*      */         }
/*      */       } else {
/*  877 */         this.statementInterceptors.add(new NoSubInterceptorWrapper((StatementInterceptorV2)interceptor));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public List<StatementInterceptorV2> getStatementInterceptorsInstances()
/*      */   {
/*  885 */     return this.statementInterceptors;
/*      */   }
/*      */   
/*      */ 
/*      */   private void addToHistogram(int[] histogramCounts, long[] histogramBreakpoints, long value, int numberOfTimes, long currentLowerBound, long currentUpperBound)
/*      */   {
/*  891 */     if (histogramCounts == null) {
/*  892 */       createInitialHistogram(histogramBreakpoints, currentLowerBound, currentUpperBound);
/*      */     }
/*      */     else {
/*  895 */       for (int i = 0; i < 20; i++) {
/*  896 */         if (histogramBreakpoints[i] >= value) {
/*  897 */           histogramCounts[i] += numberOfTimes;
/*      */           
/*  899 */           break;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void addToPerformanceHistogram(long value, int numberOfTimes) {
/*  906 */     checkAndCreatePerformanceHistogram();
/*      */     
/*  908 */     addToHistogram(this.perfMetricsHistCounts, this.perfMetricsHistBreakpoints, value, numberOfTimes, this.shortestQueryTimeMs == Long.MAX_VALUE ? 0L : this.shortestQueryTimeMs, this.longestQueryTimeMs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void addToTablesAccessedHistogram(long value, int numberOfTimes)
/*      */   {
/*  915 */     checkAndCreateTablesAccessedHistogram();
/*      */     
/*  917 */     addToHistogram(this.numTablesMetricsHistCounts, this.numTablesMetricsHistBreakpoints, value, numberOfTimes, this.minimumNumberTablesAccessed == Long.MAX_VALUE ? 0L : this.minimumNumberTablesAccessed, this.maximumNumberTablesAccessed);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void buildCollationMapping()
/*      */     throws SQLException
/*      */   {
/*  933 */     HashMap<Integer, String> javaCharset = null;
/*      */     
/*  935 */     if (versionMeetsMinimum(4, 1, 0))
/*      */     {
/*  937 */       TreeMap<Long, String> sortedCollationMap = null;
/*  938 */       HashMap<Integer, String> customCharset = null;
/*  939 */       HashMap<String, Integer> customMblen = null;
/*      */       
/*  941 */       if (getCacheServerConfiguration()) {
/*  942 */         synchronized (serverConfigByUrl) {
/*  943 */           sortedCollationMap = (TreeMap)serverCollationByUrl.get(getURL());
/*  944 */           javaCharset = (HashMap)serverJavaCharsetByUrl.get(getURL());
/*  945 */           customCharset = (HashMap)serverCustomCharsetByUrl.get(getURL());
/*  946 */           customMblen = (HashMap)serverCustomMblenByUrl.get(getURL());
/*      */         }
/*      */       }
/*      */       
/*  950 */       java.sql.Statement stmt = null;
/*  951 */       ResultSet results = null;
/*      */       try
/*      */       {
/*  954 */         if (sortedCollationMap == null) {
/*  955 */           sortedCollationMap = new TreeMap();
/*  956 */           javaCharset = new HashMap();
/*  957 */           customCharset = new HashMap();
/*  958 */           customMblen = new HashMap();
/*      */           
/*  960 */           stmt = getMetadataSafeStatement();
/*      */           
/*  962 */           results = stmt.executeQuery("SHOW COLLATION");
/*  963 */           Util.resultSetToMap(sortedCollationMap, results, 3, 2);
/*      */           
/*  965 */           for (Iterator<Map.Entry<Long, String>> indexIter = sortedCollationMap.entrySet().iterator(); indexIter.hasNext();) {
/*  966 */             Map.Entry<Long, String> indexEntry = (Map.Entry)indexIter.next();
/*      */             
/*  968 */             int collationIndex = ((Long)indexEntry.getKey()).intValue();
/*  969 */             String charsetName = (String)indexEntry.getValue();
/*      */             
/*  971 */             javaCharset.put(Integer.valueOf(collationIndex), getJavaEncodingForMysqlEncoding(charsetName));
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*  976 */             if ((collationIndex >= 255) || (!charsetName.equals(CharsetMapping.STATIC_INDEX_TO_MYSQL_CHARSET_MAP.get(Integer.valueOf(collationIndex)))))
/*      */             {
/*  978 */               customCharset.put(Integer.valueOf(collationIndex), charsetName);
/*      */             }
/*      */             
/*      */ 
/*  982 */             if ((!CharsetMapping.STATIC_CHARSET_TO_NUM_BYTES_MAP.containsKey(charsetName)) && (!CharsetMapping.STATIC_4_0_CHARSET_TO_NUM_BYTES_MAP.containsKey(charsetName)))
/*      */             {
/*  984 */               customMblen.put(charsetName, null);
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*  989 */           if (customMblen.size() > 0) {
/*  990 */             results = stmt.executeQuery("SHOW CHARACTER SET");
/*  991 */             while (results.next()) {
/*  992 */               String charsetName = results.getString("Charset");
/*  993 */               if (customMblen.containsKey(charsetName)) {
/*  994 */                 customMblen.put(charsetName, Integer.valueOf(results.getInt("Maxlen")));
/*      */               }
/*      */             }
/*      */           }
/*      */           
/*  999 */           if (getCacheServerConfiguration()) {
/* 1000 */             synchronized (serverConfigByUrl) {
/* 1001 */               serverCollationByUrl.put(getURL(), sortedCollationMap);
/* 1002 */               serverJavaCharsetByUrl.put(getURL(), javaCharset);
/* 1003 */               serverCustomCharsetByUrl.put(getURL(), customCharset);
/* 1004 */               serverCustomMblenByUrl.put(getURL(), customMblen);
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/* 1010 */         this.indexToJavaCharset = Collections.unmodifiableMap(javaCharset);
/* 1011 */         this.indexToCustomMysqlCharset = Collections.unmodifiableMap(customCharset);
/* 1012 */         this.mysqlCharsetToCustomMblen = Collections.unmodifiableMap(customMblen);
/*      */       }
/*      */       catch (SQLException ex) {
/* 1015 */         throw ex;
/*      */       } catch (RuntimeException ex) {
/* 1017 */         SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", null);
/* 1018 */         sqlEx.initCause(ex);
/* 1019 */         throw sqlEx;
/*      */       } finally {
/* 1021 */         if (results != null) {
/*      */           try {
/* 1023 */             results.close();
/*      */           }
/*      */           catch (SQLException sqlE) {}
/*      */         }
/*      */         
/*      */ 
/* 1029 */         if (stmt != null) {
/*      */           try {
/* 1031 */             stmt.close();
/*      */           }
/*      */           catch (SQLException sqlE) {}
/*      */         }
/*      */       }
/*      */     }
/*      */     else {
/* 1038 */       javaCharset = new HashMap();
/* 1039 */       for (int i = 0; i < CharsetMapping.INDEX_TO_CHARSET.length; i++) {
/* 1040 */         javaCharset.put(Integer.valueOf(i), CharsetMapping.INDEX_TO_CHARSET[i]);
/*      */       }
/* 1042 */       this.indexToJavaCharset = Collections.unmodifiableMap(javaCharset);
/*      */     }
/*      */   }
/*      */   
/*      */   public String getJavaEncodingForMysqlEncoding(String mysqlEncoding) throws SQLException
/*      */   {
/* 1048 */     if ((versionMeetsMinimum(4, 1, 0)) && ("latin1".equalsIgnoreCase(mysqlEncoding))) {
/* 1049 */       return "Cp1252";
/*      */     }
/*      */     
/* 1052 */     return (String)CharsetMapping.MYSQL_TO_JAVA_CHARSET_MAP.get(mysqlEncoding);
/*      */   }
/*      */   
/*      */   private boolean canHandleAsServerPreparedStatement(String sql) throws SQLException
/*      */   {
/* 1057 */     if ((sql == null) || (sql.length() == 0)) {
/* 1058 */       return true;
/*      */     }
/*      */     
/* 1061 */     if (!this.useServerPreparedStmts) {
/* 1062 */       return false;
/*      */     }
/*      */     
/* 1065 */     if (getCachePreparedStatements()) {
/* 1066 */       synchronized (this.serverSideStatementCheckCache) {
/* 1067 */         Boolean flag = (Boolean)this.serverSideStatementCheckCache.get(sql);
/*      */         
/* 1069 */         if (flag != null) {
/* 1070 */           return flag.booleanValue();
/*      */         }
/*      */         
/* 1073 */         boolean canHandle = canHandleAsServerPreparedStatementNoCache(sql);
/*      */         
/* 1075 */         if (sql.length() < getPreparedStatementCacheSqlLimit()) {
/* 1076 */           this.serverSideStatementCheckCache.put(sql, canHandle ? Boolean.TRUE : Boolean.FALSE);
/*      */         }
/*      */         
/*      */ 
/* 1080 */         return canHandle;
/*      */       }
/*      */     }
/*      */     
/* 1084 */     return canHandleAsServerPreparedStatementNoCache(sql);
/*      */   }
/*      */   
/*      */ 
/*      */   private boolean canHandleAsServerPreparedStatementNoCache(String sql)
/*      */     throws SQLException
/*      */   {
/* 1091 */     if (StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(sql, "CALL")) {
/* 1092 */       return false;
/*      */     }
/*      */     
/* 1095 */     boolean canHandleAsStatement = true;
/*      */     
/* 1097 */     if ((!versionMeetsMinimum(5, 0, 7)) && ((StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(sql, "SELECT")) || (StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(sql, "DELETE")) || (StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(sql, "INSERT")) || (StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(sql, "UPDATE")) || (StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(sql, "REPLACE"))))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1115 */       int currentPos = 0;
/* 1116 */       int statementLength = sql.length();
/* 1117 */       int lastPosToLook = statementLength - 7;
/* 1118 */       boolean allowBackslashEscapes = !this.noBackslashEscapes;
/* 1119 */       char quoteChar = this.useAnsiQuotes ? '"' : '\'';
/* 1120 */       boolean foundLimitWithPlaceholder = false;
/*      */       
/* 1122 */       while (currentPos < lastPosToLook) {
/* 1123 */         int limitStart = StringUtils.indexOfIgnoreCaseRespectQuotes(currentPos, sql, "LIMIT ", quoteChar, allowBackslashEscapes);
/*      */         
/*      */ 
/*      */ 
/* 1127 */         if (limitStart == -1) {
/*      */           break;
/*      */         }
/*      */         
/* 1131 */         currentPos = limitStart + 7;
/*      */         
/* 1133 */         while (currentPos < statementLength) {
/* 1134 */           char c = sql.charAt(currentPos);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1141 */           if ((!Character.isDigit(c)) && (!Character.isWhitespace(c)) && (c != ',') && (c != '?')) {
/*      */             break;
/*      */           }
/*      */           
/*      */ 
/* 1146 */           if (c == '?') {
/* 1147 */             foundLimitWithPlaceholder = true;
/* 1148 */             break;
/*      */           }
/*      */           
/* 1151 */           currentPos++;
/*      */         }
/*      */       }
/*      */       
/* 1155 */       canHandleAsStatement = !foundLimitWithPlaceholder;
/* 1156 */     } else if (StringUtils.startsWithIgnoreCaseAndWs(sql, "CREATE TABLE")) {
/* 1157 */       canHandleAsStatement = false;
/* 1158 */     } else if (StringUtils.startsWithIgnoreCaseAndWs(sql, "DO")) {
/* 1159 */       canHandleAsStatement = false;
/* 1160 */     } else if (StringUtils.startsWithIgnoreCaseAndWs(sql, "SET")) {
/* 1161 */       canHandleAsStatement = false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1166 */     return canHandleAsStatement;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void changeUser(String userName, String newPassword)
/*      */     throws SQLException
/*      */   {
/* 1184 */     checkClosed();
/*      */     
/* 1186 */     if ((userName == null) || (userName.equals(""))) {
/* 1187 */       userName = "";
/*      */     }
/*      */     
/* 1190 */     if (newPassword == null) {
/* 1191 */       newPassword = "";
/*      */     }
/*      */     
/* 1194 */     this.io.changeUser(userName, newPassword, this.database);
/* 1195 */     this.user = userName;
/* 1196 */     this.password = newPassword;
/*      */     
/* 1198 */     if (versionMeetsMinimum(4, 1, 0)) {
/* 1199 */       configureClientCharacterSet(true);
/*      */     }
/*      */     
/* 1202 */     setSessionVariables();
/*      */     
/* 1204 */     setupServerForTruncationChecks();
/*      */   }
/*      */   
/*      */ 
/*      */   private boolean characterSetNamesMatches(String mysqlEncodingName)
/*      */   {
/* 1210 */     return (mysqlEncodingName != null) && (mysqlEncodingName.equalsIgnoreCase((String)this.serverVariables.get("character_set_client"))) && (mysqlEncodingName.equalsIgnoreCase((String)this.serverVariables.get("character_set_connection")));
/*      */   }
/*      */   
/*      */ 
/*      */   private void checkAndCreatePerformanceHistogram()
/*      */   {
/* 1216 */     if (this.perfMetricsHistCounts == null) {
/* 1217 */       this.perfMetricsHistCounts = new int[20];
/*      */     }
/*      */     
/* 1220 */     if (this.perfMetricsHistBreakpoints == null) {
/* 1221 */       this.perfMetricsHistBreakpoints = new long[20];
/*      */     }
/*      */   }
/*      */   
/*      */   private void checkAndCreateTablesAccessedHistogram() {
/* 1226 */     if (this.numTablesMetricsHistCounts == null) {
/* 1227 */       this.numTablesMetricsHistCounts = new int[20];
/*      */     }
/*      */     
/* 1230 */     if (this.numTablesMetricsHistBreakpoints == null) {
/* 1231 */       this.numTablesMetricsHistBreakpoints = new long[20];
/*      */     }
/*      */   }
/*      */   
/*      */   public void checkClosed() throws SQLException {
/* 1236 */     if (this.isClosed) {
/* 1237 */       throwConnectionClosedException();
/*      */     }
/*      */   }
/*      */   
/*      */   public void throwConnectionClosedException() throws SQLException {
/* 1242 */     StringBuffer messageBuf = new StringBuffer("No operations allowed after connection closed.");
/*      */     
/*      */ 
/* 1245 */     SQLException ex = SQLError.createSQLException(messageBuf.toString(), "08003", getExceptionInterceptor());
/*      */     
/*      */ 
/* 1248 */     if (this.forceClosedReason != null) {
/* 1249 */       ex.initCause(this.forceClosedReason);
/*      */     }
/*      */     
/* 1252 */     throw ex;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void checkServerEncoding()
/*      */     throws SQLException
/*      */   {
/* 1263 */     if ((getUseUnicode()) && (getEncoding() != null))
/*      */     {
/* 1265 */       return;
/*      */     }
/*      */     
/* 1268 */     String serverEncoding = (String)this.serverVariables.get("character_set");
/*      */     
/* 1270 */     if (serverEncoding == null)
/*      */     {
/* 1272 */       serverEncoding = (String)this.serverVariables.get("character_set_server");
/*      */     }
/*      */     
/* 1275 */     String mappedServerEncoding = null;
/*      */     
/* 1277 */     if (serverEncoding != null) {
/*      */       try {
/* 1279 */         mappedServerEncoding = getJavaEncodingForMysqlEncoding(serverEncoding.toUpperCase(Locale.ENGLISH));
/*      */       }
/*      */       catch (SQLException ex) {
/* 1282 */         throw ex;
/*      */       } catch (RuntimeException ex) {
/* 1284 */         SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", null);
/* 1285 */         sqlEx.initCause(ex);
/* 1286 */         throw sqlEx;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1293 */     if ((!getUseUnicode()) && (mappedServerEncoding != null)) {
/* 1294 */       SingleByteCharsetConverter converter = getCharsetConverter(mappedServerEncoding);
/*      */       
/* 1296 */       if (converter != null) {
/* 1297 */         setUseUnicode(true);
/* 1298 */         setEncoding(mappedServerEncoding);
/*      */         
/* 1300 */         return;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1308 */     if (serverEncoding != null) {
/* 1309 */       if (mappedServerEncoding == null)
/*      */       {
/*      */ 
/* 1312 */         if (Character.isLowerCase(serverEncoding.charAt(0))) {
/* 1313 */           char[] ach = serverEncoding.toCharArray();
/* 1314 */           ach[0] = Character.toUpperCase(serverEncoding.charAt(0));
/* 1315 */           setEncoding(new String(ach));
/*      */         }
/*      */       }
/*      */       
/* 1319 */       if (mappedServerEncoding == null) {
/* 1320 */         throw SQLError.createSQLException("Unknown character encoding on server '" + serverEncoding + "', use 'characterEncoding=' property " + " to provide correct mapping", "01S00", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/* 1332 */         StringUtils.getBytes("abc", mappedServerEncoding);
/* 1333 */         setEncoding(mappedServerEncoding);
/* 1334 */         setUseUnicode(true);
/*      */       } catch (UnsupportedEncodingException UE) {
/* 1336 */         throw SQLError.createSQLException("The driver can not map the character encoding '" + getEncoding() + "' that your server is using " + "to a character encoding your JVM understands. You " + "can specify this mapping manually by adding \"useUnicode=true\" " + "as well as \"characterEncoding=[an_encoding_your_jvm_understands]\" " + "to your JDBC URL.", "0S100", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void checkTransactionIsolationLevel()
/*      */     throws SQLException
/*      */   {
/* 1356 */     String txIsolationName = null;
/*      */     
/* 1358 */     if (versionMeetsMinimum(4, 0, 3)) {
/* 1359 */       txIsolationName = "tx_isolation";
/*      */     } else {
/* 1361 */       txIsolationName = "transaction_isolation";
/*      */     }
/*      */     
/* 1364 */     String s = (String)this.serverVariables.get(txIsolationName);
/*      */     
/* 1366 */     if (s != null) {
/* 1367 */       Integer intTI = (Integer)mapTransIsolationNameToValue.get(s);
/*      */       
/* 1369 */       if (intTI != null) {
/* 1370 */         this.isolationLevel = intTI.intValue();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void abortInternal()
/*      */     throws SQLException
/*      */   {
/* 1382 */     if (this.io != null) {
/*      */       try {
/* 1384 */         this.io.forceClose();
/*      */       }
/*      */       catch (Throwable t) {}
/*      */       
/* 1388 */       this.io = null;
/*      */     }
/*      */     
/* 1391 */     this.isClosed = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void cleanup(Throwable whyCleanedUp)
/*      */   {
/*      */     try
/*      */     {
/* 1404 */       if ((this.io != null) && (!isClosed())) {
/* 1405 */         realClose(false, false, false, whyCleanedUp);
/* 1406 */       } else if (this.io != null) {
/* 1407 */         this.io.forceClose();
/*      */       }
/*      */     }
/*      */     catch (SQLException sqlEx) {}
/*      */     
/*      */ 
/*      */ 
/* 1414 */     this.isClosed = true;
/*      */   }
/*      */   
/*      */   public void clearHasTriedMaster() {
/* 1418 */     this.hasTriedMasterFlag = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.PreparedStatement clientPrepareStatement(String sql)
/*      */     throws SQLException
/*      */   {
/* 1443 */     return clientPrepareStatement(sql, 1003, 1007);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.PreparedStatement clientPrepareStatement(String sql, int autoGenKeyIndex)
/*      */     throws SQLException
/*      */   {
/* 1453 */     java.sql.PreparedStatement pStmt = clientPrepareStatement(sql);
/*      */     
/* 1455 */     ((PreparedStatement)pStmt).setRetrieveGeneratedKeys(autoGenKeyIndex == 1);
/*      */     
/*      */ 
/* 1458 */     return pStmt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency)
/*      */     throws SQLException
/*      */   {
/* 1476 */     return clientPrepareStatement(sql, resultSetType, resultSetConcurrency, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public java.sql.PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, boolean processEscapeCodesIfNeeded)
/*      */     throws SQLException
/*      */   {
/* 1484 */     checkClosed();
/*      */     
/* 1486 */     String nativeSql = (processEscapeCodesIfNeeded) && (getProcessEscapeCodesForPrepStmts()) ? nativeSQL(sql) : sql;
/*      */     
/* 1488 */     PreparedStatement pStmt = null;
/*      */     
/* 1490 */     if (getCachePreparedStatements()) {
/* 1491 */       synchronized (this.cachedPreparedStatementParams) {
/* 1492 */         PreparedStatement.ParseInfo pStmtInfo = (PreparedStatement.ParseInfo)this.cachedPreparedStatementParams.get(nativeSql);
/*      */         
/*      */ 
/* 1495 */         if (pStmtInfo == null) {
/* 1496 */           pStmt = PreparedStatement.getInstance(getLoadBalanceSafeProxy(), nativeSql, this.database);
/*      */           
/*      */ 
/* 1499 */           PreparedStatement.ParseInfo parseInfo = pStmt.getParseInfo();
/*      */           
/* 1501 */           if (parseInfo.statementLength < getPreparedStatementCacheSqlLimit()) {
/* 1502 */             if (this.cachedPreparedStatementParams.size() >= getPreparedStatementCacheSize()) {
/* 1503 */               Iterator<Object> oldestIter = this.cachedPreparedStatementParams.keySet().iterator();
/*      */               
/* 1505 */               long lruTime = Long.MAX_VALUE;
/* 1506 */               String oldestSql = null;
/*      */               
/* 1508 */               while (oldestIter.hasNext()) {
/* 1509 */                 String sqlKey = (String)oldestIter.next();
/* 1510 */                 PreparedStatement.ParseInfo lruInfo = (PreparedStatement.ParseInfo)this.cachedPreparedStatementParams.get(sqlKey);
/*      */                 
/*      */ 
/* 1513 */                 if (lruInfo.lastUsed < lruTime) {
/* 1514 */                   lruTime = lruInfo.lastUsed;
/* 1515 */                   oldestSql = sqlKey;
/*      */                 }
/*      */               }
/*      */               
/* 1519 */               if (oldestSql != null) {
/* 1520 */                 this.cachedPreparedStatementParams.remove(oldestSql);
/*      */               }
/*      */             }
/*      */             
/*      */ 
/* 1525 */             this.cachedPreparedStatementParams.put(nativeSql, pStmt.getParseInfo());
/*      */           }
/*      */         }
/*      */         else {
/* 1529 */           pStmtInfo.lastUsed = System.currentTimeMillis();
/* 1530 */           pStmt = new PreparedStatement(getLoadBalanceSafeProxy(), nativeSql, this.database, pStmtInfo);
/*      */         }
/*      */         
/*      */       }
/*      */     } else {
/* 1535 */       pStmt = PreparedStatement.getInstance(getLoadBalanceSafeProxy(), nativeSql, this.database);
/*      */     }
/*      */     
/*      */ 
/* 1539 */     pStmt.setResultSetType(resultSetType);
/* 1540 */     pStmt.setResultSetConcurrency(resultSetConcurrency);
/*      */     
/* 1542 */     return pStmt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.PreparedStatement clientPrepareStatement(String sql, int[] autoGenKeyIndexes)
/*      */     throws SQLException
/*      */   {
/* 1551 */     PreparedStatement pStmt = (PreparedStatement)clientPrepareStatement(sql);
/*      */     
/* 1553 */     pStmt.setRetrieveGeneratedKeys((autoGenKeyIndexes != null) && (autoGenKeyIndexes.length > 0));
/*      */     
/*      */ 
/*      */ 
/* 1557 */     return pStmt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public java.sql.PreparedStatement clientPrepareStatement(String sql, String[] autoGenKeyColNames)
/*      */     throws SQLException
/*      */   {
/* 1565 */     PreparedStatement pStmt = (PreparedStatement)clientPrepareStatement(sql);
/*      */     
/* 1567 */     pStmt.setRetrieveGeneratedKeys((autoGenKeyColNames != null) && (autoGenKeyColNames.length > 0));
/*      */     
/*      */ 
/*      */ 
/* 1571 */     return pStmt;
/*      */   }
/*      */   
/*      */   public java.sql.PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability)
/*      */     throws SQLException
/*      */   {
/* 1577 */     return clientPrepareStatement(sql, resultSetType, resultSetConcurrency, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void close()
/*      */     throws SQLException
/*      */   {
/* 1593 */     if (this.connectionLifecycleInterceptors != null) {
/* 1594 */       new IterateBlock(this.connectionLifecycleInterceptors.iterator()) {
/*      */         void forEach(Object each) throws SQLException {
/* 1596 */           ((ConnectionLifecycleInterceptor)each).close();
/*      */         }
/*      */       }.doForAll();
/*      */     }
/*      */     
/* 1601 */     realClose(true, true, false, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void closeAllOpenStatements()
/*      */     throws SQLException
/*      */   {
/* 1611 */     SQLException postponedException = null;
/*      */     
/* 1613 */     if (this.openStatements != null) {
/* 1614 */       List<Statement> currentlyOpenStatements = new ArrayList();
/*      */       
/*      */ 
/*      */ 
/* 1618 */       for (Iterator<Statement> iter = this.openStatements.keySet().iterator(); iter.hasNext();) {
/* 1619 */         currentlyOpenStatements.add(iter.next());
/*      */       }
/*      */       
/* 1622 */       int numStmts = currentlyOpenStatements.size();
/*      */       
/* 1624 */       for (int i = 0; i < numStmts; i++) {
/* 1625 */         StatementImpl stmt = (StatementImpl)currentlyOpenStatements.get(i);
/*      */         try
/*      */         {
/* 1628 */           stmt.realClose(false, true);
/*      */         } catch (SQLException sqlEx) {
/* 1630 */           postponedException = sqlEx;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1635 */       if (postponedException != null) {
/* 1636 */         throw postponedException;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void closeStatement(java.sql.Statement stmt) {
/* 1642 */     if (stmt != null) {
/*      */       try {
/* 1644 */         stmt.close();
/*      */       }
/*      */       catch (SQLException sqlEx) {}
/*      */       
/*      */ 
/* 1649 */       stmt = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void commit()
/*      */     throws SQLException
/*      */   {
/* 1668 */     checkClosed();
/*      */     try
/*      */     {
/* 1671 */       if (this.connectionLifecycleInterceptors != null) {
/* 1672 */         IterateBlock iter = new IterateBlock(this.connectionLifecycleInterceptors.iterator())
/*      */         {
/*      */           void forEach(Object each) throws SQLException {
/* 1675 */             if (!((ConnectionLifecycleInterceptor)each).commit()) {
/* 1676 */               this.stopIterating = true;
/*      */             }
/*      */             
/*      */           }
/* 1680 */         };
/* 1681 */         iter.doForAll();
/*      */         
/* 1683 */         if (!iter.fullIteration()) {
/* 1684 */           return;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1689 */       if ((this.autoCommit) && (!getRelaxAutoCommit()))
/* 1690 */         throw SQLError.createSQLException("Can't call commit when autocommit=true", getExceptionInterceptor());
/* 1691 */       if (this.transactionsSupported) {
/* 1692 */         if ((getUseLocalTransactionState()) && (versionMeetsMinimum(5, 0, 0)) && 
/* 1693 */           (!this.io.inTransactionOnServer())) {
/* 1694 */           return;
/*      */         }
/*      */         
/*      */ 
/* 1698 */         execSQL(null, "commit", -1, null, 1003, 1007, false, this.database, null, false);
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*      */     catch (SQLException sqlException)
/*      */     {
/* 1705 */       if ("08S01".equals(sqlException.getSQLState()))
/*      */       {
/* 1707 */         throw SQLError.createSQLException("Communications link failure during commit(). Transaction resolution unknown.", "08007", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1714 */       throw sqlException;
/*      */     } finally {
/* 1716 */       this.needsPing = getReconnectAtTxEnd();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void configureCharsetProperties()
/*      */     throws SQLException
/*      */   {
/* 1729 */     if (getEncoding() != null)
/*      */     {
/*      */       try
/*      */       {
/* 1733 */         String testString = "abc";
/* 1734 */         StringUtils.getBytes(testString, getEncoding());
/*      */       }
/*      */       catch (UnsupportedEncodingException UE) {
/* 1737 */         String oldEncoding = getEncoding();
/*      */         try
/*      */         {
/* 1740 */           setEncoding(getJavaEncodingForMysqlEncoding(oldEncoding));
/*      */         } catch (SQLException ex) {
/* 1742 */           throw ex;
/*      */         } catch (RuntimeException ex) {
/* 1744 */           SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", null);
/* 1745 */           sqlEx.initCause(ex);
/* 1746 */           throw sqlEx;
/*      */         }
/*      */         
/* 1749 */         if (getEncoding() == null) {
/* 1750 */           throw SQLError.createSQLException("Java does not support the MySQL character encoding  encoding '" + oldEncoding + "'.", "01S00", getExceptionInterceptor());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */         try
/*      */         {
/* 1757 */           String testString = "abc";
/* 1758 */           StringUtils.getBytes(testString, getEncoding());
/*      */         } catch (UnsupportedEncodingException encodingEx) {
/* 1760 */           throw SQLError.createSQLException("Unsupported character encoding '" + getEncoding() + "'.", "01S00", getExceptionInterceptor());
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean configureClientCharacterSet(boolean dontCheckServerMatch)
/*      */     throws SQLException
/*      */   {
/* 1782 */     String realJavaEncoding = getEncoding();
/* 1783 */     boolean characterSetAlreadyConfigured = false;
/*      */     try
/*      */     {
/* 1786 */       if (versionMeetsMinimum(4, 1, 0)) {
/* 1787 */         characterSetAlreadyConfigured = true;
/*      */         
/* 1789 */         setUseUnicode(true);
/*      */         
/* 1791 */         configureCharsetProperties();
/* 1792 */         realJavaEncoding = getEncoding();
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         try
/*      */         {
/* 1800 */           if ((this.props != null) && (this.props.getProperty("com.mysql.jdbc.faultInjection.serverCharsetIndex") != null)) {
/* 1801 */             this.io.serverCharsetIndex = Integer.parseInt(this.props.getProperty("com.mysql.jdbc.faultInjection.serverCharsetIndex"));
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 1806 */           String serverEncodingToSet = CharsetMapping.INDEX_TO_CHARSET[this.io.serverCharsetIndex];
/*      */           
/*      */ 
/* 1809 */           if ((serverEncodingToSet == null) || (serverEncodingToSet.length() == 0)) {
/* 1810 */             if (realJavaEncoding != null)
/*      */             {
/* 1812 */               setEncoding(realJavaEncoding);
/*      */             } else {
/* 1814 */               throw SQLError.createSQLException("Unknown initial character set index '" + this.io.serverCharsetIndex + "' received from server. Initial client character set can be forced via the 'characterEncoding' property.", "S1000", getExceptionInterceptor());
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1823 */           if ((versionMeetsMinimum(4, 1, 0)) && ("ISO8859_1".equalsIgnoreCase(serverEncodingToSet)))
/*      */           {
/* 1825 */             serverEncodingToSet = "Cp1252";
/*      */           }
/*      */           
/* 1828 */           setEncoding(serverEncodingToSet);
/*      */         }
/*      */         catch (ArrayIndexOutOfBoundsException outOfBoundsEx) {
/* 1831 */           if (realJavaEncoding != null)
/*      */           {
/* 1833 */             setEncoding(realJavaEncoding);
/*      */           } else {
/* 1835 */             throw SQLError.createSQLException("Unknown initial character set index '" + this.io.serverCharsetIndex + "' received from server. Initial client character set can be forced via the 'characterEncoding' property.", "S1000", getExceptionInterceptor());
/*      */           }
/*      */           
/*      */ 
/*      */         }
/*      */         catch (SQLException ex)
/*      */         {
/* 1842 */           throw ex;
/*      */         } catch (RuntimeException ex) {
/* 1844 */           SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", null);
/* 1845 */           sqlEx.initCause(ex);
/* 1846 */           throw sqlEx;
/*      */         }
/*      */         
/* 1849 */         if (getEncoding() == null)
/*      */         {
/* 1851 */           setEncoding("ISO8859_1");
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1858 */         if (getUseUnicode()) {
/* 1859 */           if (realJavaEncoding != null)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1865 */             if ((realJavaEncoding.equalsIgnoreCase("UTF-8")) || (realJavaEncoding.equalsIgnoreCase("UTF8")))
/*      */             {
/*      */ 
/*      */ 
/* 1869 */               boolean utf8mb4Supported = versionMeetsMinimum(5, 5, 2);
/* 1870 */               boolean useutf8mb4 = false;
/*      */               
/* 1872 */               if (utf8mb4Supported) {
/* 1873 */                 useutf8mb4 = this.io.serverCharsetIndex == 45;
/*      */               }
/*      */               
/* 1876 */               if (!getUseOldUTF8Behavior()) {
/* 1877 */                 if ((dontCheckServerMatch) || (!characterSetNamesMatches("utf8")) || ((utf8mb4Supported) && (!characterSetNamesMatches("utf8mb4"))))
/*      */                 {
/* 1879 */                   execSQL(null, "SET NAMES " + (useutf8mb4 ? "utf8mb4" : "utf8"), -1, null, 1003, 1007, false, this.database, null, false);
/*      */                 }
/*      */                 
/*      */ 
/*      */               }
/*      */               else {
/* 1885 */                 execSQL(null, "SET NAMES latin1", -1, null, 1003, 1007, false, this.database, null, false);
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*      */ 
/* 1891 */               setEncoding(realJavaEncoding);
/*      */             } else {
/* 1893 */               String mysqlEncodingName = CharsetMapping.getMysqlEncodingForJavaEncoding(realJavaEncoding.toUpperCase(Locale.ENGLISH), this);
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1908 */               if (mysqlEncodingName != null)
/*      */               {
/* 1910 */                 if ((dontCheckServerMatch) || (!characterSetNamesMatches(mysqlEncodingName))) {
/* 1911 */                   execSQL(null, "SET NAMES " + mysqlEncodingName, -1, null, 1003, 1007, false, this.database, null, false);
/*      */                 }
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1922 */               setEncoding(realJavaEncoding);
/*      */             }
/* 1924 */           } else if (getEncoding() != null)
/*      */           {
/*      */ 
/*      */ 
/* 1928 */             String mysqlEncodingName = CharsetMapping.getMysqlEncodingForJavaEncoding(getEncoding().toUpperCase(Locale.ENGLISH), this);
/*      */             
/*      */ 
/*      */ 
/* 1932 */             if (getUseOldUTF8Behavior()) {
/* 1933 */               mysqlEncodingName = "latin1";
/*      */             }
/*      */             
/* 1936 */             if ((dontCheckServerMatch) || (!characterSetNamesMatches(mysqlEncodingName))) {
/* 1937 */               execSQL(null, "SET NAMES " + mysqlEncodingName, -1, null, 1003, 1007, false, this.database, null, false);
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/* 1943 */             realJavaEncoding = getEncoding();
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1954 */         String onServer = null;
/* 1955 */         boolean isNullOnServer = false;
/*      */         
/* 1957 */         if (this.serverVariables != null) {
/* 1958 */           onServer = (String)this.serverVariables.get("character_set_results");
/*      */           
/* 1960 */           isNullOnServer = (onServer == null) || ("NULL".equalsIgnoreCase(onServer)) || (onServer.length() == 0);
/*      */         }
/*      */         
/* 1963 */         if (getCharacterSetResults() == null)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1970 */           if (!isNullOnServer) {
/* 1971 */             execSQL(null, "SET character_set_results = NULL", -1, null, 1003, 1007, false, this.database, null, false);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/* 1976 */             if (!this.usingCachedConfig) {
/* 1977 */               this.serverVariables.put("jdbc.local.character_set_results", null);
/*      */             }
/*      */           }
/* 1980 */           else if (!this.usingCachedConfig) {
/* 1981 */             this.serverVariables.put("jdbc.local.character_set_results", onServer);
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/* 1986 */           if (getUseOldUTF8Behavior()) {
/* 1987 */             execSQL(null, "SET NAMES latin1", -1, null, 1003, 1007, false, this.database, null, false);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 1992 */           String charsetResults = getCharacterSetResults();
/* 1993 */           String mysqlEncodingName = null;
/*      */           
/* 1995 */           if (("UTF-8".equalsIgnoreCase(charsetResults)) || ("UTF8".equalsIgnoreCase(charsetResults)))
/*      */           {
/* 1997 */             mysqlEncodingName = "utf8";
/*      */           } else {
/* 1999 */             mysqlEncodingName = CharsetMapping.getMysqlEncodingForJavaEncoding(charsetResults.toUpperCase(Locale.ENGLISH), this);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2008 */           if (!mysqlEncodingName.equalsIgnoreCase((String)this.serverVariables.get("character_set_results")))
/*      */           {
/* 2010 */             StringBuffer setBuf = new StringBuffer("SET character_set_results = ".length() + mysqlEncodingName.length());
/*      */             
/*      */ 
/* 2013 */             setBuf.append("SET character_set_results = ").append(mysqlEncodingName);
/*      */             
/*      */ 
/* 2016 */             execSQL(null, setBuf.toString(), -1, null, 1003, 1007, false, this.database, null, false);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/* 2021 */             if (!this.usingCachedConfig) {
/* 2022 */               this.serverVariables.put("jdbc.local.character_set_results", mysqlEncodingName);
/*      */             }
/*      */             
/*      */           }
/* 2026 */           else if (!this.usingCachedConfig) {
/* 2027 */             this.serverVariables.put("jdbc.local.character_set_results", onServer);
/*      */           }
/*      */         }
/*      */         
/*      */ 
/* 2032 */         if (getConnectionCollation() != null) {
/* 2033 */           StringBuffer setBuf = new StringBuffer("SET collation_connection = ".length() + getConnectionCollation().length());
/*      */           
/*      */ 
/* 2036 */           setBuf.append("SET collation_connection = ").append(getConnectionCollation());
/*      */           
/*      */ 
/* 2039 */           execSQL(null, setBuf.toString(), -1, null, 1003, 1007, false, this.database, null, false);
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 2046 */         realJavaEncoding = getEncoding();
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*      */ 
/* 2054 */       setEncoding(realJavaEncoding);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/* 2062 */       CharsetEncoder enc = Charset.forName(getEncoding()).newEncoder();
/* 2063 */       CharBuffer cbuf = CharBuffer.allocate(1);
/* 2064 */       ByteBuffer bbuf = ByteBuffer.allocate(1);
/*      */       
/* 2066 */       cbuf.put("¥");
/* 2067 */       cbuf.position(0);
/* 2068 */       enc.encode(cbuf, bbuf, true);
/* 2069 */       if (bbuf.get(0) == 92) {
/* 2070 */         this.requiresEscapingEncoder = true;
/*      */       } else {
/* 2072 */         cbuf.clear();
/* 2073 */         bbuf.clear();
/*      */         
/* 2075 */         cbuf.put("₩");
/* 2076 */         cbuf.position(0);
/* 2077 */         enc.encode(cbuf, bbuf, true);
/* 2078 */         if (bbuf.get(0) == 92) {
/* 2079 */           this.requiresEscapingEncoder = true;
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (UnsupportedCharsetException ucex) {
/*      */       try {
/* 2085 */         byte[] bbuf = StringUtils.getBytes("¥", getEncoding());
/* 2086 */         if (bbuf[0] == 92) {
/* 2087 */           this.requiresEscapingEncoder = true;
/*      */         } else {
/* 2089 */           bbuf = StringUtils.getBytes("₩", getEncoding());
/* 2090 */           if (bbuf[0] == 92) {
/* 2091 */             this.requiresEscapingEncoder = true;
/*      */           }
/*      */         }
/*      */       } catch (UnsupportedEncodingException ueex) {
/* 2095 */         throw SQLError.createSQLException("Unable to use encoding: " + getEncoding(), "S1000", ueex, getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2101 */     return characterSetAlreadyConfigured;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void configureTimezone()
/*      */     throws SQLException
/*      */   {
/* 2112 */     String configuredTimeZoneOnServer = (String)this.serverVariables.get("timezone");
/*      */     
/* 2114 */     if (configuredTimeZoneOnServer == null) {
/* 2115 */       configuredTimeZoneOnServer = (String)this.serverVariables.get("time_zone");
/*      */       
/* 2117 */       if ("SYSTEM".equalsIgnoreCase(configuredTimeZoneOnServer)) {
/* 2118 */         configuredTimeZoneOnServer = (String)this.serverVariables.get("system_time_zone");
/*      */       }
/*      */     }
/*      */     
/* 2122 */     String canoncicalTimezone = getServerTimezone();
/*      */     
/* 2124 */     if (((getUseTimezone()) || (!getUseLegacyDatetimeCode())) && (configuredTimeZoneOnServer != null))
/*      */     {
/* 2126 */       if ((canoncicalTimezone == null) || (StringUtils.isEmptyOrWhitespaceOnly(canoncicalTimezone))) {
/*      */         try {
/* 2128 */           canoncicalTimezone = TimeUtil.getCanoncialTimezone(configuredTimeZoneOnServer, getExceptionInterceptor());
/*      */           
/*      */ 
/* 2131 */           if (canoncicalTimezone == null) {
/* 2132 */             throw SQLError.createSQLException("Can't map timezone '" + configuredTimeZoneOnServer + "' to " + " canonical timezone.", "S1009", getExceptionInterceptor());
/*      */           }
/*      */           
/*      */         }
/*      */         catch (IllegalArgumentException iae)
/*      */         {
/* 2138 */           throw SQLError.createSQLException(iae.getMessage(), "S1000", getExceptionInterceptor());
/*      */         }
/*      */       }
/*      */     }
/*      */     else {
/* 2143 */       canoncicalTimezone = getServerTimezone();
/*      */     }
/*      */     
/* 2146 */     if ((canoncicalTimezone != null) && (canoncicalTimezone.length() > 0)) {
/* 2147 */       this.serverTimezoneTZ = TimeZone.getTimeZone(canoncicalTimezone);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2154 */       if ((!canoncicalTimezone.equalsIgnoreCase("GMT")) && (this.serverTimezoneTZ.getID().equals("GMT")))
/*      */       {
/* 2156 */         throw SQLError.createSQLException("No timezone mapping entry for '" + canoncicalTimezone + "'", "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2161 */       if ("GMT".equalsIgnoreCase(this.serverTimezoneTZ.getID())) {
/* 2162 */         this.isServerTzUTC = true;
/*      */       } else {
/* 2164 */         this.isServerTzUTC = false;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void createInitialHistogram(long[] breakpoints, long lowerBound, long upperBound)
/*      */   {
/* 2172 */     double bucketSize = (upperBound - lowerBound) / 20.0D * 1.25D;
/*      */     
/* 2174 */     if (bucketSize < 1.0D) {
/* 2175 */       bucketSize = 1.0D;
/*      */     }
/*      */     
/* 2178 */     for (int i = 0; i < 20; i++) {
/* 2179 */       breakpoints[i] = lowerBound;
/* 2180 */       lowerBound = (lowerBound + bucketSize);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void createNewIO(boolean isForReconnect)
/*      */     throws SQLException
/*      */   {
/* 2204 */     Properties mergedProps = exposeAsProperties(this.props);
/*      */     
/* 2206 */     if (!getHighAvailability()) {
/* 2207 */       connectOneTryOnly(isForReconnect, mergedProps);
/*      */       
/* 2209 */       return;
/*      */     }
/*      */     
/* 2212 */     connectWithRetries(isForReconnect, mergedProps);
/*      */   }
/*      */   
/*      */   private void connectWithRetries(boolean isForReconnect, Properties mergedProps)
/*      */     throws SQLException
/*      */   {
/* 2218 */     double timeout = getInitialTimeout();
/* 2219 */     boolean connectionGood = false;
/*      */     
/* 2221 */     Exception connectionException = null;
/*      */     
/* 2223 */     for (int attemptCount = 0; 
/* 2224 */         (attemptCount < getMaxReconnects()) && (!connectionGood); attemptCount++) {
/*      */       try {
/* 2226 */         if (this.io != null) {
/* 2227 */           this.io.forceClose();
/*      */         }
/*      */         
/* 2230 */         coreConnect(mergedProps);
/* 2231 */         pingInternal(false, 0);
/*      */         
/*      */         boolean oldAutoCommit;
/*      */         
/*      */         int oldIsolationLevel;
/*      */         boolean oldReadOnly;
/*      */         String oldCatalog;
/* 2238 */         synchronized (this) {
/* 2239 */           this.connectionId = this.io.getThreadId();
/* 2240 */           this.isClosed = false;
/*      */           
/*      */ 
/* 2243 */           oldAutoCommit = getAutoCommit();
/* 2244 */           oldIsolationLevel = this.isolationLevel;
/* 2245 */           oldReadOnly = isReadOnly();
/* 2246 */           oldCatalog = getCatalog();
/*      */           
/* 2248 */           this.io.setStatementInterceptors(this.statementInterceptors);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 2254 */         initializePropsFromServer();
/*      */         
/* 2256 */         if (isForReconnect)
/*      */         {
/* 2258 */           setAutoCommit(oldAutoCommit);
/*      */           
/* 2260 */           if (this.hasIsolationLevels) {
/* 2261 */             setTransactionIsolation(oldIsolationLevel);
/*      */           }
/*      */           
/* 2264 */           setCatalog(oldCatalog);
/* 2265 */           setReadOnly(oldReadOnly);
/*      */         }
/*      */         
/* 2268 */         connectionGood = true;
/*      */       }
/*      */       catch (Exception EEE)
/*      */       {
/* 2272 */         connectionException = EEE;
/* 2273 */         connectionGood = false;
/*      */         
/*      */ 
/* 2276 */         if (!connectionGood) break label186; }
/* 2277 */       break;
/*      */       
/*      */       label186:
/* 2280 */       if (attemptCount > 0) {
/*      */         try {
/* 2282 */           Thread.sleep(timeout * 1000L);
/*      */         }
/*      */         catch (InterruptedException IE) {}
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2289 */     if (!connectionGood)
/*      */     {
/* 2291 */       SQLException chainedEx = SQLError.createSQLException(Messages.getString("Connection.UnableToConnectWithRetries", new Object[] { Integer.valueOf(getMaxReconnects()) }), "08001", getExceptionInterceptor());
/*      */       
/*      */ 
/*      */ 
/* 2295 */       chainedEx.initCause(connectionException);
/*      */       
/* 2297 */       throw chainedEx;
/*      */     }
/*      */     
/* 2300 */     if ((getParanoid()) && (!getHighAvailability())) {
/* 2301 */       this.password = null;
/* 2302 */       this.user = null;
/*      */     }
/*      */     
/* 2305 */     if (isForReconnect)
/*      */     {
/*      */ 
/*      */ 
/* 2309 */       Iterator<Statement> statementIter = this.openStatements.values().iterator();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2320 */       Stack<Statement> serverPreparedStatements = null;
/*      */       
/* 2322 */       while (statementIter.hasNext()) {
/* 2323 */         Statement statementObj = (Statement)statementIter.next();
/*      */         
/* 2325 */         if ((statementObj instanceof ServerPreparedStatement)) {
/* 2326 */           if (serverPreparedStatements == null) {
/* 2327 */             serverPreparedStatements = new Stack();
/*      */           }
/*      */           
/* 2330 */           serverPreparedStatements.add(statementObj);
/*      */         }
/*      */       }
/*      */       
/* 2334 */       if (serverPreparedStatements != null) {
/* 2335 */         while (!serverPreparedStatements.isEmpty()) {
/* 2336 */           ((ServerPreparedStatement)serverPreparedStatements.pop()).rePrepare();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void coreConnect(Properties mergedProps)
/*      */     throws SQLException, IOException
/*      */   {
/* 2345 */     int newPort = 3306;
/* 2346 */     String newHost = "localhost";
/*      */     
/* 2348 */     String protocol = mergedProps.getProperty("PROTOCOL");
/*      */     
/* 2350 */     if (protocol != null)
/*      */     {
/*      */ 
/* 2353 */       if ("tcp".equalsIgnoreCase(protocol)) {
/* 2354 */         newHost = normalizeHost(mergedProps.getProperty("HOST"));
/* 2355 */         newPort = parsePortNumber(mergedProps.getProperty("PORT", "3306"));
/* 2356 */       } else if ("pipe".equalsIgnoreCase(protocol)) {
/* 2357 */         setSocketFactoryClassName(NamedPipeSocketFactory.class.getName());
/*      */         
/* 2359 */         String path = mergedProps.getProperty("PATH");
/*      */         
/* 2361 */         if (path != null) {
/* 2362 */           mergedProps.setProperty("namedPipePath", path);
/*      */         }
/*      */       }
/*      */       else {
/* 2366 */         newHost = normalizeHost(mergedProps.getProperty("HOST"));
/* 2367 */         newPort = parsePortNumber(mergedProps.getProperty("PORT", "3306"));
/*      */       }
/*      */     }
/*      */     else {
/* 2371 */       String[] parsedHostPortPair = NonRegisteringDriver.parseHostPortPair(this.hostPortPair);
/*      */       
/* 2373 */       newHost = parsedHostPortPair[0];
/*      */       
/* 2375 */       newHost = normalizeHost(newHost);
/*      */       
/* 2377 */       if (parsedHostPortPair[1] != null) {
/* 2378 */         newPort = parsePortNumber(parsedHostPortPair[1]);
/*      */       }
/*      */     }
/*      */     
/* 2382 */     this.port = newPort;
/* 2383 */     this.host = newHost;
/*      */     
/* 2385 */     this.io = new MysqlIO(newHost, newPort, mergedProps, getSocketFactoryClassName(), getProxy(), getSocketTimeout(), this.largeRowSizeThreshold.getValueAsInt());
/*      */     
/*      */ 
/*      */ 
/* 2389 */     this.io.doHandshake(this.user, this.password, this.database);
/*      */   }
/*      */   
/*      */   private String normalizeHost(String hostname)
/*      */   {
/* 2394 */     if ((hostname == null) || (StringUtils.isEmptyOrWhitespaceOnly(hostname))) {
/* 2395 */       return "localhost";
/*      */     }
/*      */     
/* 2398 */     return hostname;
/*      */   }
/*      */   
/*      */   private int parsePortNumber(String portAsString) throws SQLException {
/* 2402 */     int portNumber = 3306;
/*      */     try {
/* 2404 */       portNumber = Integer.parseInt(portAsString);
/*      */     }
/*      */     catch (NumberFormatException nfe) {
/* 2407 */       throw SQLError.createSQLException("Illegal connection port value '" + portAsString + "'", "01S00", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2413 */     return portNumber;
/*      */   }
/*      */   
/*      */   private void connectOneTryOnly(boolean isForReconnect, Properties mergedProps) throws SQLException
/*      */   {
/* 2418 */     Exception connectionNotEstablishedBecause = null;
/*      */     
/*      */     try
/*      */     {
/* 2422 */       coreConnect(mergedProps);
/* 2423 */       this.connectionId = this.io.getThreadId();
/* 2424 */       this.isClosed = false;
/*      */       
/*      */ 
/* 2427 */       boolean oldAutoCommit = getAutoCommit();
/* 2428 */       int oldIsolationLevel = this.isolationLevel;
/* 2429 */       boolean oldReadOnly = isReadOnly();
/* 2430 */       String oldCatalog = getCatalog();
/*      */       
/* 2432 */       this.io.setStatementInterceptors(this.statementInterceptors);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2437 */       initializePropsFromServer();
/*      */       
/* 2439 */       if (isForReconnect)
/*      */       {
/* 2441 */         setAutoCommit(oldAutoCommit);
/*      */         
/* 2443 */         if (this.hasIsolationLevels) {
/* 2444 */           setTransactionIsolation(oldIsolationLevel);
/*      */         }
/*      */         
/* 2447 */         setCatalog(oldCatalog);
/*      */         
/* 2449 */         setReadOnly(oldReadOnly);
/*      */       }
/* 2451 */       return;
/*      */     }
/*      */     catch (Exception EEE) {
/* 2454 */       if (this.io != null) {
/* 2455 */         this.io.forceClose();
/*      */       }
/*      */       
/* 2458 */       connectionNotEstablishedBecause = EEE;
/*      */       
/* 2460 */       if ((EEE instanceof SQLException)) {
/* 2461 */         throw ((SQLException)EEE);
/*      */       }
/*      */       
/* 2464 */       SQLException chainedEx = SQLError.createSQLException(Messages.getString("Connection.UnableToConnect"), "08001", getExceptionInterceptor());
/*      */       
/*      */ 
/* 2467 */       chainedEx.initCause(connectionNotEstablishedBecause);
/*      */       
/* 2469 */       throw chainedEx;
/*      */     }
/*      */   }
/*      */   
/*      */   private synchronized void createPreparedStatementCaches() {
/* 2474 */     int cacheSize = getPreparedStatementCacheSize();
/*      */     
/* 2476 */     this.cachedPreparedStatementParams = new HashMap(cacheSize);
/*      */     
/* 2478 */     if (getUseServerPreparedStmts()) {
/* 2479 */       this.serverSideStatementCheckCache = new LRUCache(cacheSize);
/*      */       
/* 2481 */       this.serverSideStatementCache = new LRUCache(cacheSize) {
/*      */         protected boolean removeEldestEntry(Map.Entry<Object, Object> eldest) {
/* 2483 */           if (this.maxElements <= 1) {
/* 2484 */             return false;
/*      */           }
/*      */           
/* 2487 */           boolean removeIt = super.removeEldestEntry(eldest);
/*      */           
/* 2489 */           if (removeIt) {
/* 2490 */             ServerPreparedStatement ps = (ServerPreparedStatement)eldest.getValue();
/*      */             
/* 2492 */             ps.isCached = false;
/* 2493 */             ps.setClosed(false);
/*      */             try
/*      */             {
/* 2496 */               ps.close();
/*      */             }
/*      */             catch (SQLException sqlEx) {}
/*      */           }
/*      */           
/*      */ 
/* 2502 */           return removeIt;
/*      */         }
/*      */       };
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.Statement createStatement()
/*      */     throws SQLException
/*      */   {
/* 2518 */     return createStatement(1003, 1007);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.Statement createStatement(int resultSetType, int resultSetConcurrency)
/*      */     throws SQLException
/*      */   {
/* 2536 */     checkClosed();
/*      */     
/* 2538 */     StatementImpl stmt = new StatementImpl(getLoadBalanceSafeProxy(), this.database);
/* 2539 */     stmt.setResultSetType(resultSetType);
/* 2540 */     stmt.setResultSetConcurrency(resultSetConcurrency);
/*      */     
/* 2542 */     return stmt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.Statement createStatement(int resultSetType, int resultSetConcurrency, int resultSetHoldability)
/*      */     throws SQLException
/*      */   {
/* 2551 */     if ((getPedantic()) && 
/* 2552 */       (resultSetHoldability != 1)) {
/* 2553 */       throw SQLError.createSQLException("HOLD_CUSRORS_OVER_COMMIT is only supported holdability level", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2559 */     return createStatement(resultSetType, resultSetConcurrency);
/*      */   }
/*      */   
/*      */   public void dumpTestcaseQuery(String query) {
/* 2563 */     System.err.println(query);
/*      */   }
/*      */   
/*      */   public Connection duplicate() throws SQLException {
/* 2567 */     return new ConnectionImpl(this.origHostToConnectTo, this.origPortToConnectTo, this.props, this.origDatabaseToConnectTo, this.myURL);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSetInternalMethods execSQL(StatementImpl callingStatement, String sql, int maxRows, Buffer packet, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, Field[] cachedMetadata)
/*      */     throws SQLException
/*      */   {
/* 2621 */     return execSQL(callingStatement, sql, maxRows, packet, resultSetType, resultSetConcurrency, streamResults, catalog, cachedMetadata, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized ResultSetInternalMethods execSQL(StatementImpl callingStatement, String sql, int maxRows, Buffer packet, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, Field[] cachedMetadata, boolean isBatch)
/*      */     throws SQLException
/*      */   {
/* 2637 */     long queryStartTime = 0L;
/*      */     
/* 2639 */     int endOfQueryPacketPosition = 0;
/*      */     
/* 2641 */     if (packet != null) {
/* 2642 */       endOfQueryPacketPosition = packet.getPosition();
/*      */     }
/*      */     
/* 2645 */     if (getGatherPerformanceMetrics()) {
/* 2646 */       queryStartTime = System.currentTimeMillis();
/*      */     }
/*      */     
/* 2649 */     this.lastQueryFinishedTime = 0L;
/*      */     
/* 2651 */     if ((getHighAvailability()) && ((this.autoCommit) || (getAutoReconnectForPools())) && (this.needsPing) && (!isBatch))
/*      */     {
/*      */       try
/*      */       {
/* 2655 */         pingInternal(false, 0);
/*      */         
/* 2657 */         this.needsPing = false;
/*      */       } catch (Exception Ex) {
/* 2659 */         createNewIO(true);
/*      */       }
/*      */     }
/*      */     try {
/*      */       String encoding;
/* 2664 */       if (packet == null) {
/* 2665 */         encoding = null;
/*      */         
/* 2667 */         if (getUseUnicode()) {
/* 2668 */           encoding = getEncoding();
/*      */         }
/*      */         
/* 2671 */         return this.io.sqlQueryDirect(callingStatement, sql, encoding, null, maxRows, resultSetType, resultSetConcurrency, streamResults, catalog, cachedMetadata);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2677 */       return this.io.sqlQueryDirect(callingStatement, null, null, packet, maxRows, resultSetType, resultSetConcurrency, streamResults, catalog, cachedMetadata);
/*      */ 
/*      */ 
/*      */     }
/*      */     catch (SQLException sqlE)
/*      */     {
/*      */ 
/* 2684 */       if (getDumpQueriesOnException()) {
/* 2685 */         String extractedSql = extractSqlFromPacket(sql, packet, endOfQueryPacketPosition);
/*      */         
/* 2687 */         StringBuffer messageBuf = new StringBuffer(extractedSql.length() + 32);
/*      */         
/* 2689 */         messageBuf.append("\n\nQuery being executed when exception was thrown:\n");
/*      */         
/* 2691 */         messageBuf.append(extractedSql);
/* 2692 */         messageBuf.append("\n\n");
/*      */         
/* 2694 */         sqlE = appendMessageToException(sqlE, messageBuf.toString(), getExceptionInterceptor());
/*      */       }
/*      */       
/* 2697 */       if (getHighAvailability()) {
/* 2698 */         this.needsPing = true;
/*      */       } else {
/* 2700 */         String sqlState = sqlE.getSQLState();
/*      */         
/* 2702 */         if ((sqlState != null) && (sqlState.equals("08S01")))
/*      */         {
/*      */ 
/* 2705 */           cleanup(sqlE);
/*      */         }
/*      */       }
/*      */       
/* 2709 */       throw sqlE;
/*      */     } catch (Exception ex) {
/* 2711 */       if (getHighAvailability()) {
/* 2712 */         this.needsPing = true;
/* 2713 */       } else if ((ex instanceof IOException)) {
/* 2714 */         cleanup(ex);
/*      */       }
/*      */       
/* 2717 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("Connection.UnexpectedException"), "S1000", getExceptionInterceptor());
/*      */       
/*      */ 
/* 2720 */       sqlEx.initCause(ex);
/*      */       
/* 2722 */       throw sqlEx;
/*      */     } finally {
/* 2724 */       if (getMaintainTimeStats()) {
/* 2725 */         this.lastQueryFinishedTime = System.currentTimeMillis();
/*      */       }
/*      */       
/*      */ 
/* 2729 */       if (getGatherPerformanceMetrics()) {
/* 2730 */         long queryTime = System.currentTimeMillis() - queryStartTime;
/*      */         
/*      */ 
/* 2733 */         registerQueryExecutionTime(queryTime);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public String extractSqlFromPacket(String possibleSqlQuery, Buffer queryPacket, int endOfQueryPacketPosition)
/*      */     throws SQLException
/*      */   {
/* 2742 */     String extractedSql = null;
/*      */     
/* 2744 */     if (possibleSqlQuery != null) {
/* 2745 */       if (possibleSqlQuery.length() > getMaxQuerySizeToLog()) {
/* 2746 */         StringBuffer truncatedQueryBuf = new StringBuffer(possibleSqlQuery.substring(0, getMaxQuerySizeToLog()));
/*      */         
/* 2748 */         truncatedQueryBuf.append(Messages.getString("MysqlIO.25"));
/* 2749 */         extractedSql = truncatedQueryBuf.toString();
/*      */       } else {
/* 2751 */         extractedSql = possibleSqlQuery;
/*      */       }
/*      */     }
/*      */     
/* 2755 */     if (extractedSql == null)
/*      */     {
/*      */ 
/*      */ 
/* 2759 */       int extractPosition = endOfQueryPacketPosition;
/*      */       
/* 2761 */       boolean truncated = false;
/*      */       
/* 2763 */       if (endOfQueryPacketPosition > getMaxQuerySizeToLog()) {
/* 2764 */         extractPosition = getMaxQuerySizeToLog();
/* 2765 */         truncated = true;
/*      */       }
/*      */       
/* 2768 */       extractedSql = StringUtils.toString(queryPacket.getByteBuffer(), 5, extractPosition - 5);
/*      */       
/*      */ 
/* 2771 */       if (truncated) {
/* 2772 */         extractedSql = extractedSql + Messages.getString("MysqlIO.25");
/*      */       }
/*      */     }
/*      */     
/* 2776 */     return extractedSql;
/*      */   }
/*      */   
/*      */   protected void finalize() throws Throwable
/*      */   {
/* 2781 */     cleanup(null);
/*      */     
/* 2783 */     super.finalize();
/*      */   }
/*      */   
/*      */   public StringBuffer generateConnectionCommentBlock(StringBuffer buf) {
/* 2787 */     buf.append("/* conn id ");
/* 2788 */     buf.append(getId());
/* 2789 */     buf.append(" clock: ");
/* 2790 */     buf.append(System.currentTimeMillis());
/* 2791 */     buf.append(" */ ");
/*      */     
/* 2793 */     return buf;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean getAutoCommit()
/*      */     throws SQLException
/*      */   {
/* 2817 */     return this.autoCommit;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Calendar getCalendarInstanceForSessionOrNew()
/*      */   {
/* 2825 */     if (getDynamicCalendars()) {
/* 2826 */       return Calendar.getInstance();
/*      */     }
/*      */     
/* 2829 */     return getSessionLockedCalendar();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized String getCatalog()
/*      */     throws SQLException
/*      */   {
/* 2844 */     return this.database;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized String getCharacterSetMetadata()
/*      */   {
/* 2851 */     return this.characterSetMetadata;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SingleByteCharsetConverter getCharsetConverter(String javaEncodingName)
/*      */     throws SQLException
/*      */   {
/* 2864 */     if (javaEncodingName == null) {
/* 2865 */       return null;
/*      */     }
/*      */     
/* 2868 */     if (this.usePlatformCharsetConverters) {
/* 2869 */       return null;
/*      */     }
/*      */     
/*      */ 
/* 2873 */     SingleByteCharsetConverter converter = null;
/*      */     
/* 2875 */     synchronized (this.charsetConverterMap) {
/* 2876 */       Object asObject = this.charsetConverterMap.get(javaEncodingName);
/*      */       
/*      */ 
/* 2879 */       if (asObject == CHARSET_CONVERTER_NOT_AVAILABLE_MARKER) {
/* 2880 */         return null;
/*      */       }
/*      */       
/* 2883 */       converter = (SingleByteCharsetConverter)asObject;
/*      */       
/* 2885 */       if (converter == null) {
/*      */         try {
/* 2887 */           converter = SingleByteCharsetConverter.getInstance(javaEncodingName, this);
/*      */           
/*      */ 
/* 2890 */           if (converter == null) {
/* 2891 */             this.charsetConverterMap.put(javaEncodingName, CHARSET_CONVERTER_NOT_AVAILABLE_MARKER);
/*      */           }
/*      */           else {
/* 2894 */             this.charsetConverterMap.put(javaEncodingName, converter);
/*      */           }
/*      */         } catch (UnsupportedEncodingException unsupEncEx) {
/* 2897 */           this.charsetConverterMap.put(javaEncodingName, CHARSET_CONVERTER_NOT_AVAILABLE_MARKER);
/*      */           
/*      */ 
/* 2900 */           converter = null;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2905 */     return converter;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCharsetNameForIndex(int charsetIndex)
/*      */     throws SQLException
/*      */   {
/* 2920 */     String charsetName = null;
/*      */     
/* 2922 */     if (getUseOldUTF8Behavior()) {
/* 2923 */       return getEncoding();
/*      */     }
/*      */     
/* 2926 */     if (charsetIndex != -1) {
/*      */       try {
/* 2928 */         charsetName = (String)this.indexToJavaCharset.get(Integer.valueOf(charsetIndex));
/*      */         
/* 2930 */         if (charsetName == null) { charsetName = CharsetMapping.INDEX_TO_CHARSET[charsetIndex];
/*      */         }
/* 2932 */         if (("sjis".equalsIgnoreCase(charsetName)) || ("MS932".equalsIgnoreCase(charsetName)))
/*      */         {
/*      */ 
/* 2935 */           if (CharsetMapping.isAliasForSjis(getEncoding())) {
/* 2936 */             charsetName = getEncoding();
/*      */           }
/*      */         }
/*      */       } catch (ArrayIndexOutOfBoundsException outOfBoundsEx) {
/* 2940 */         throw SQLError.createSQLException("Unknown character set index for field '" + charsetIndex + "' received from server.", "S1000", getExceptionInterceptor());
/*      */ 
/*      */       }
/*      */       catch (RuntimeException ex)
/*      */       {
/* 2945 */         SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", null);
/* 2946 */         sqlEx.initCause(ex);
/* 2947 */         throw sqlEx;
/*      */       }
/*      */       
/*      */ 
/* 2951 */       if (charsetName == null) {
/* 2952 */         charsetName = getEncoding();
/*      */       }
/*      */     } else {
/* 2955 */       charsetName = getEncoding();
/*      */     }
/*      */     
/* 2958 */     return charsetName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TimeZone getDefaultTimeZone()
/*      */   {
/* 2967 */     return this.defaultTimeZone;
/*      */   }
/*      */   
/*      */   public String getErrorMessageEncoding() {
/* 2971 */     return this.errorMessageEncoding;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getHoldability()
/*      */     throws SQLException
/*      */   {
/* 2978 */     return 2;
/*      */   }
/*      */   
/*      */   public long getId() {
/* 2982 */     return this.connectionId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized long getIdleFor()
/*      */   {
/* 2994 */     if (this.lastQueryFinishedTime == 0L) {
/* 2995 */       return 0L;
/*      */     }
/*      */     
/* 2998 */     long now = System.currentTimeMillis();
/* 2999 */     long idleTime = now - this.lastQueryFinishedTime;
/*      */     
/* 3001 */     return idleTime;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MysqlIO getIO()
/*      */     throws SQLException
/*      */   {
/* 3012 */     if ((this.io == null) || (this.isClosed)) {
/* 3013 */       throw SQLError.createSQLException("Operation not allowed on closed connection", "08003", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3018 */     return this.io;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Log getLog()
/*      */     throws SQLException
/*      */   {
/* 3030 */     return this.log;
/*      */   }
/*      */   
/*      */   public int getMaxBytesPerChar(String javaCharsetName) throws SQLException {
/* 3034 */     return getMaxBytesPerChar(null, javaCharsetName);
/*      */   }
/*      */   
/*      */   public int getMaxBytesPerChar(Integer charsetIndex, String javaCharsetName) throws SQLException
/*      */   {
/* 3039 */     String charset = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/* 3047 */       charset = (String)this.indexToCustomMysqlCharset.get(charsetIndex);
/*      */       
/* 3049 */       if (charset == null) { charset = (String)CharsetMapping.STATIC_INDEX_TO_MYSQL_CHARSET_MAP.get(charsetIndex);
/*      */       }
/*      */       
/* 3052 */       if (charset == null) {
/* 3053 */         charset = CharsetMapping.getMysqlEncodingForJavaEncoding(javaCharsetName, this);
/* 3054 */         if ((this.io.serverCharsetIndex == 33) && (versionMeetsMinimum(5, 5, 3)) && (javaCharsetName.equalsIgnoreCase("UTF-8")))
/*      */         {
/* 3056 */           charset = "utf8";
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 3061 */       Integer mblen = (Integer)this.mysqlCharsetToCustomMblen.get(charset);
/*      */       
/*      */ 
/* 3064 */       if (mblen == null) mblen = (Integer)CharsetMapping.STATIC_CHARSET_TO_NUM_BYTES_MAP.get(charset);
/* 3065 */       if (mblen == null) { mblen = (Integer)CharsetMapping.STATIC_4_0_CHARSET_TO_NUM_BYTES_MAP.get(charset);
/*      */       }
/* 3067 */       if (mblen != null) return mblen.intValue();
/*      */     } catch (SQLException ex) {
/* 3069 */       throw ex;
/*      */     } catch (RuntimeException ex) {
/* 3071 */       SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", null);
/* 3072 */       sqlEx.initCause(ex);
/* 3073 */       throw sqlEx;
/*      */     }
/*      */     
/* 3076 */     return 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.DatabaseMetaData getMetaData()
/*      */     throws SQLException
/*      */   {
/* 3090 */     return getMetaData(true, true);
/*      */   }
/*      */   
/*      */   private java.sql.DatabaseMetaData getMetaData(boolean checkClosed, boolean checkForInfoSchema) throws SQLException {
/* 3094 */     if (checkClosed) {
/* 3095 */       checkClosed();
/*      */     }
/*      */     
/* 3098 */     return DatabaseMetaData.getInstance(getLoadBalanceSafeProxy(), this.database, checkForInfoSchema);
/*      */   }
/*      */   
/*      */   public java.sql.Statement getMetadataSafeStatement() throws SQLException {
/* 3102 */     java.sql.Statement stmt = createStatement();
/*      */     
/* 3104 */     if (stmt.getMaxRows() != 0) {
/* 3105 */       stmt.setMaxRows(0);
/*      */     }
/*      */     
/* 3108 */     stmt.setEscapeProcessing(false);
/*      */     
/* 3110 */     if (stmt.getFetchSize() != 0) {
/* 3111 */       stmt.setFetchSize(0);
/*      */     }
/*      */     
/* 3114 */     return stmt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getNetBufferLength()
/*      */   {
/* 3123 */     return this.netBufferLength;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getServerCharacterEncoding()
/*      */   {
/* 3132 */     if (this.io.versionMeetsMinimum(4, 1, 0)) {
/* 3133 */       String charset = (String)this.indexToCustomMysqlCharset.get(Integer.valueOf(this.io.serverCharsetIndex));
/* 3134 */       if (charset == null) charset = (String)CharsetMapping.STATIC_INDEX_TO_MYSQL_CHARSET_MAP.get(Integer.valueOf(this.io.serverCharsetIndex));
/* 3135 */       return charset != null ? charset : (String)this.serverVariables.get("character_set_server");
/*      */     }
/* 3137 */     return (String)this.serverVariables.get("character_set");
/*      */   }
/*      */   
/*      */   public int getServerMajorVersion() {
/* 3141 */     return this.io.getServerMajorVersion();
/*      */   }
/*      */   
/*      */   public int getServerMinorVersion() {
/* 3145 */     return this.io.getServerMinorVersion();
/*      */   }
/*      */   
/*      */   public int getServerSubMinorVersion() {
/* 3149 */     return this.io.getServerSubMinorVersion();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TimeZone getServerTimezoneTZ()
/*      */   {
/* 3158 */     return this.serverTimezoneTZ;
/*      */   }
/*      */   
/*      */   public String getServerVariable(String variableName)
/*      */   {
/* 3163 */     if (this.serverVariables != null) {
/* 3164 */       return (String)this.serverVariables.get(variableName);
/*      */     }
/*      */     
/* 3167 */     return null;
/*      */   }
/*      */   
/*      */   public String getServerVersion() {
/* 3171 */     return this.io.getServerVersion();
/*      */   }
/*      */   
/*      */   public Calendar getSessionLockedCalendar()
/*      */   {
/* 3176 */     return this.sessionCalendar;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int getTransactionIsolation()
/*      */     throws SQLException
/*      */   {
/* 3188 */     if ((this.hasIsolationLevels) && (!getUseLocalSessionState())) {
/* 3189 */       java.sql.Statement stmt = null;
/* 3190 */       ResultSet rs = null;
/*      */       try
/*      */       {
/* 3193 */         stmt = getMetadataSafeStatement();
/*      */         
/* 3195 */         String query = null;
/*      */         
/* 3197 */         int offset = 0;
/*      */         
/* 3199 */         if (versionMeetsMinimum(4, 0, 3)) {
/* 3200 */           query = "SELECT @@session.tx_isolation";
/* 3201 */           offset = 1;
/*      */         } else {
/* 3203 */           query = "SHOW VARIABLES LIKE 'transaction_isolation'";
/* 3204 */           offset = 2;
/*      */         }
/*      */         
/* 3207 */         rs = stmt.executeQuery(query);
/*      */         
/* 3209 */         if (rs.next()) {
/* 3210 */           String s = rs.getString(offset);
/*      */           
/* 3212 */           if (s != null) {
/* 3213 */             Integer intTI = (Integer)mapTransIsolationNameToValue.get(s);
/*      */             
/* 3215 */             if (intTI != null) {
/* 3216 */               return intTI.intValue();
/*      */             }
/*      */           }
/*      */           
/* 3220 */           throw SQLError.createSQLException("Could not map transaction isolation '" + s + " to a valid JDBC level.", "S1000", getExceptionInterceptor());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 3226 */         throw SQLError.createSQLException("Could not retrieve transaction isolation level from server", "S1000", getExceptionInterceptor());
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/* 3231 */         if (rs != null) {
/*      */           try {
/* 3233 */             rs.close();
/*      */           }
/*      */           catch (Exception ex) {}
/*      */           
/*      */ 
/*      */ 
/* 3239 */           rs = null;
/*      */         }
/*      */         
/* 3242 */         if (stmt != null) {
/*      */           try {
/* 3244 */             stmt.close();
/*      */           }
/*      */           catch (Exception ex) {}
/*      */           
/*      */ 
/*      */ 
/* 3250 */           stmt = null;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 3255 */     return this.isolationLevel;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized Map getTypeMap()
/*      */     throws SQLException
/*      */   {
/* 3267 */     if (this.typeMap == null) {
/* 3268 */       this.typeMap = new HashMap();
/*      */     }
/*      */     
/* 3271 */     return this.typeMap;
/*      */   }
/*      */   
/*      */   public String getURL() {
/* 3275 */     return this.myURL;
/*      */   }
/*      */   
/*      */   public String getUser() {
/* 3279 */     return this.user;
/*      */   }
/*      */   
/*      */   public Calendar getUtcCalendar() {
/* 3283 */     return this.utcCalendar;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SQLWarning getWarnings()
/*      */     throws SQLException
/*      */   {
/* 3296 */     return null;
/*      */   }
/*      */   
/*      */   public boolean hasSameProperties(Connection c) {
/* 3300 */     return this.props.equals(c.getProperties());
/*      */   }
/*      */   
/*      */   public Properties getProperties() {
/* 3304 */     return this.props;
/*      */   }
/*      */   
/*      */   public boolean hasTriedMaster() {
/* 3308 */     return this.hasTriedMasterFlag;
/*      */   }
/*      */   
/*      */   public void incrementNumberOfPreparedExecutes() {
/* 3312 */     if (getGatherPerformanceMetrics()) {
/* 3313 */       this.numberOfPreparedExecutes += 1L;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 3318 */       this.numberOfQueriesIssued += 1L;
/*      */     }
/*      */   }
/*      */   
/*      */   public void incrementNumberOfPrepares() {
/* 3323 */     if (getGatherPerformanceMetrics()) {
/* 3324 */       this.numberOfPrepares += 1L;
/*      */     }
/*      */   }
/*      */   
/*      */   public void incrementNumberOfResultSetsCreated() {
/* 3329 */     if (getGatherPerformanceMetrics()) {
/* 3330 */       this.numberOfResultSetsCreated += 1L;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void initializeDriverProperties(Properties info)
/*      */     throws SQLException
/*      */   {
/* 3345 */     initializeProperties(info);
/*      */     
/* 3347 */     String exceptionInterceptorClasses = getExceptionInterceptors();
/*      */     
/* 3349 */     if ((exceptionInterceptorClasses != null) && (!"".equals(exceptionInterceptorClasses))) {
/* 3350 */       this.exceptionInterceptor = new ExceptionInterceptorChain(exceptionInterceptorClasses);
/* 3351 */       this.exceptionInterceptor.init(this, info);
/*      */     }
/*      */     
/* 3354 */     this.usePlatformCharsetConverters = getUseJvmCharsetConverters();
/*      */     
/* 3356 */     this.log = LogFactory.getLogger(getLogger(), "MySQL", getExceptionInterceptor());
/*      */     
/* 3358 */     if ((getProfileSql()) || (getUseUsageAdvisor())) {
/* 3359 */       this.eventSink = ProfilerEventHandlerFactory.getInstance(getLoadBalanceSafeProxy());
/*      */     }
/*      */     
/* 3362 */     if (getCachePreparedStatements()) {
/* 3363 */       createPreparedStatementCaches();
/*      */     }
/*      */     
/* 3366 */     if ((getNoDatetimeStringSync()) && (getUseTimezone())) {
/* 3367 */       throw SQLError.createSQLException("Can't enable noDatetimeSync and useTimezone configuration properties at the same time", "01S00", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 3373 */     if (getCacheCallableStatements()) {
/* 3374 */       this.parsedCallableStatementCache = new LRUCache(getCallableStatementCacheSize());
/*      */     }
/*      */     
/*      */ 
/* 3378 */     if (getAllowMultiQueries()) {
/* 3379 */       setCacheResultSetMetadata(false);
/*      */     }
/*      */     
/* 3382 */     if (getCacheResultSetMetadata()) {
/* 3383 */       this.resultSetMetadataCache = new LRUCache(getMetadataCacheSize());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void initializePropsFromServer()
/*      */     throws SQLException
/*      */   {
/* 3398 */     String connectionInterceptorClasses = getConnectionLifecycleInterceptors();
/*      */     
/* 3400 */     this.connectionLifecycleInterceptors = null;
/*      */     
/* 3402 */     if (connectionInterceptorClasses != null) {
/* 3403 */       this.connectionLifecycleInterceptors = Util.loadExtensions(this, this.props, connectionInterceptorClasses, "Connection.badLifecycleInterceptor", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3408 */     setSessionVariables();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3414 */     if (!versionMeetsMinimum(4, 1, 0)) {
/* 3415 */       setTransformedBitIsBoolean(false);
/*      */     }
/*      */     
/* 3418 */     this.parserKnowsUnicode = versionMeetsMinimum(4, 1, 0);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 3423 */     if ((getUseServerPreparedStmts()) && (versionMeetsMinimum(4, 1, 0))) {
/* 3424 */       this.useServerPreparedStmts = true;
/*      */       
/* 3426 */       if ((versionMeetsMinimum(5, 0, 0)) && (!versionMeetsMinimum(5, 0, 3))) {
/* 3427 */         this.useServerPreparedStmts = false;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3436 */     if (versionMeetsMinimum(3, 21, 22)) {
/* 3437 */       loadServerVariables();
/*      */       
/* 3439 */       if (versionMeetsMinimum(5, 0, 2)) {
/* 3440 */         this.autoIncrementIncrement = getServerVariableAsInt("auto_increment_increment", 1);
/*      */       } else {
/* 3442 */         this.autoIncrementIncrement = 1;
/*      */       }
/*      */       
/* 3445 */       buildCollationMapping();
/*      */       
/* 3447 */       LicenseConfiguration.checkLicenseType(this.serverVariables);
/*      */       
/* 3449 */       String lowerCaseTables = (String)this.serverVariables.get("lower_case_table_names");
/*      */       
/* 3451 */       this.lowerCaseTableNames = (("on".equalsIgnoreCase(lowerCaseTables)) || ("1".equalsIgnoreCase(lowerCaseTables)) || ("2".equalsIgnoreCase(lowerCaseTables)));
/*      */       
/*      */ 
/*      */ 
/* 3455 */       this.storesLowerCaseTableName = (("1".equalsIgnoreCase(lowerCaseTables)) || ("on".equalsIgnoreCase(lowerCaseTables)));
/*      */       
/*      */ 
/* 3458 */       configureTimezone();
/*      */       
/* 3460 */       if (this.serverVariables.containsKey("max_allowed_packet")) {
/* 3461 */         int serverMaxAllowedPacket = getServerVariableAsInt("max_allowed_packet", -1);
/*      */         
/* 3463 */         if ((serverMaxAllowedPacket != -1) && ((serverMaxAllowedPacket < getMaxAllowedPacket()) || (getMaxAllowedPacket() <= 0)))
/*      */         {
/* 3465 */           setMaxAllowedPacket(serverMaxAllowedPacket);
/* 3466 */         } else if ((serverMaxAllowedPacket == -1) && (getMaxAllowedPacket() == -1)) {
/* 3467 */           setMaxAllowedPacket(65535);
/*      */         }
/* 3469 */         int preferredBlobSendChunkSize = getBlobSendChunkSize();
/*      */         
/* 3471 */         int allowedBlobSendChunkSize = Math.min(preferredBlobSendChunkSize, getMaxAllowedPacket()) - 8192 - 11;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 3476 */         setBlobSendChunkSize(String.valueOf(allowedBlobSendChunkSize));
/*      */       }
/*      */       
/* 3479 */       if (this.serverVariables.containsKey("net_buffer_length")) {
/* 3480 */         this.netBufferLength = getServerVariableAsInt("net_buffer_length", 16384);
/*      */       }
/*      */       
/* 3483 */       checkTransactionIsolationLevel();
/*      */       
/* 3485 */       if (!versionMeetsMinimum(4, 1, 0)) {
/* 3486 */         checkServerEncoding();
/*      */       }
/*      */       
/* 3489 */       this.io.checkForCharsetMismatch();
/*      */       
/* 3491 */       if (this.serverVariables.containsKey("sql_mode")) {
/* 3492 */         int sqlMode = 0;
/*      */         
/* 3494 */         String sqlModeAsString = (String)this.serverVariables.get("sql_mode");
/*      */         try {
/* 3496 */           sqlMode = Integer.parseInt(sqlModeAsString);
/*      */         }
/*      */         catch (NumberFormatException nfe)
/*      */         {
/* 3500 */           sqlMode = 0;
/*      */           
/* 3502 */           if (sqlModeAsString != null) {
/* 3503 */             if (sqlModeAsString.indexOf("ANSI_QUOTES") != -1) {
/* 3504 */               sqlMode |= 0x4;
/*      */             }
/*      */             
/* 3507 */             if (sqlModeAsString.indexOf("NO_BACKSLASH_ESCAPES") != -1) {
/* 3508 */               this.noBackslashEscapes = true;
/*      */             }
/*      */           }
/*      */         }
/*      */         
/* 3513 */         if ((sqlMode & 0x4) > 0) {
/* 3514 */           this.useAnsiQuotes = true;
/*      */         } else {
/* 3516 */           this.useAnsiQuotes = false;
/*      */         }
/*      */       }
/*      */     }
/*      */     try
/*      */     {
/* 3522 */       this.errorMessageEncoding = CharsetMapping.getCharacterEncodingForErrorMessages(this);
/*      */     }
/*      */     catch (SQLException ex) {
/* 3525 */       throw ex;
/*      */     } catch (RuntimeException ex) {
/* 3527 */       SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", null);
/* 3528 */       sqlEx.initCause(ex);
/* 3529 */       throw sqlEx;
/*      */     }
/*      */     
/*      */ 
/* 3533 */     boolean overrideDefaultAutocommit = isAutoCommitNonDefaultOnServer();
/*      */     
/* 3535 */     configureClientCharacterSet(false);
/*      */     
/* 3537 */     if (versionMeetsMinimum(3, 23, 15)) {
/* 3538 */       this.transactionsSupported = true;
/*      */       
/* 3540 */       if (!overrideDefaultAutocommit) {
/* 3541 */         setAutoCommit(true);
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 3546 */       this.transactionsSupported = false;
/*      */     }
/*      */     
/*      */ 
/* 3550 */     if (versionMeetsMinimum(3, 23, 36)) {
/* 3551 */       this.hasIsolationLevels = true;
/*      */     } else {
/* 3553 */       this.hasIsolationLevels = false;
/*      */     }
/*      */     
/* 3556 */     this.hasQuotedIdentifiers = versionMeetsMinimum(3, 23, 6);
/*      */     
/* 3558 */     this.io.resetMaxBuf();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3568 */     if (this.io.versionMeetsMinimum(4, 1, 0)) {
/* 3569 */       String characterSetResultsOnServerMysql = (String)this.serverVariables.get("jdbc.local.character_set_results");
/*      */       
/* 3571 */       if ((characterSetResultsOnServerMysql == null) || (StringUtils.startsWithIgnoreCaseAndWs(characterSetResultsOnServerMysql, "NULL")) || (characterSetResultsOnServerMysql.length() == 0))
/*      */       {
/*      */ 
/*      */ 
/* 3575 */         String defaultMetadataCharsetMysql = (String)this.serverVariables.get("character_set_system");
/* 3576 */         String defaultMetadataCharset = null;
/*      */         
/* 3578 */         if (defaultMetadataCharsetMysql != null) {
/* 3579 */           defaultMetadataCharset = getJavaEncodingForMysqlEncoding(defaultMetadataCharsetMysql);
/*      */         } else {
/* 3581 */           defaultMetadataCharset = "UTF-8";
/*      */         }
/*      */         
/* 3584 */         this.characterSetMetadata = defaultMetadataCharset;
/*      */       } else {
/* 3586 */         this.characterSetResultsOnServer = getJavaEncodingForMysqlEncoding(characterSetResultsOnServerMysql);
/* 3587 */         this.characterSetMetadata = this.characterSetResultsOnServer;
/*      */       }
/*      */     } else {
/* 3590 */       this.characterSetMetadata = getEncoding();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3597 */     if ((versionMeetsMinimum(4, 1, 0)) && (!versionMeetsMinimum(4, 1, 10)) && (getAllowMultiQueries()))
/*      */     {
/*      */ 
/* 3600 */       if (isQueryCacheEnabled()) {
/* 3601 */         setAllowMultiQueries(false);
/*      */       }
/*      */     }
/*      */     
/* 3605 */     if ((versionMeetsMinimum(5, 0, 0)) && ((getUseLocalTransactionState()) || (getElideSetAutoCommits())) && (isQueryCacheEnabled()) && (!versionMeetsMinimum(6, 0, 10)))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3610 */       setUseLocalTransactionState(false);
/* 3611 */       setElideSetAutoCommits(false);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3618 */     setupServerForTruncationChecks();
/*      */   }
/*      */   
/*      */   private boolean isQueryCacheEnabled() {
/* 3622 */     return ("ON".equalsIgnoreCase((String)this.serverVariables.get("query_cache_type"))) && (!"0".equalsIgnoreCase((String)this.serverVariables.get("query_cache_size")));
/*      */   }
/*      */   
/*      */   private int getServerVariableAsInt(String variableName, int fallbackValue) throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 3629 */       return Integer.parseInt((String)this.serverVariables.get(variableName));
/*      */     } catch (NumberFormatException nfe) {
/* 3631 */       getLog().logWarn(Messages.getString("Connection.BadValueInServerVariables", new Object[] { variableName, this.serverVariables.get(variableName), Integer.valueOf(fallbackValue) }));
/*      */     }
/*      */     
/* 3634 */     return fallbackValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean isAutoCommitNonDefaultOnServer()
/*      */     throws SQLException
/*      */   {
/* 3647 */     boolean overrideDefaultAutocommit = false;
/*      */     
/* 3649 */     String initConnectValue = (String)this.serverVariables.get("init_connect");
/*      */     
/* 3651 */     if ((versionMeetsMinimum(4, 1, 2)) && (initConnectValue != null) && (initConnectValue.length() > 0))
/*      */     {
/* 3653 */       if (!getElideSetAutoCommits())
/*      */       {
/* 3655 */         ResultSet rs = null;
/* 3656 */         java.sql.Statement stmt = null;
/*      */         try
/*      */         {
/* 3659 */           stmt = getMetadataSafeStatement();
/*      */           
/* 3661 */           rs = stmt.executeQuery("SELECT @@session.autocommit");
/*      */           
/* 3663 */           if (rs.next()) {
/* 3664 */             this.autoCommit = rs.getBoolean(1);
/* 3665 */             if (this.autoCommit != true) {
/* 3666 */               overrideDefaultAutocommit = true;
/*      */             }
/*      */           }
/*      */         }
/*      */         finally {
/* 3671 */           if (rs != null) {
/*      */             try {
/* 3673 */               rs.close();
/*      */             }
/*      */             catch (SQLException sqlEx) {}
/*      */           }
/*      */           
/*      */ 
/* 3679 */           if (stmt != null) {
/*      */             try {
/* 3681 */               stmt.close();
/*      */ 
/*      */             }
/*      */             catch (SQLException sqlEx) {}
/*      */           }
/*      */         }
/*      */       }
/* 3688 */       else if (getIO().isSetNeededForAutoCommitMode(true))
/*      */       {
/* 3690 */         this.autoCommit = false;
/* 3691 */         overrideDefaultAutocommit = true;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 3696 */     return overrideDefaultAutocommit;
/*      */   }
/*      */   
/*      */   public boolean isClientTzUTC() {
/* 3700 */     return this.isClientTzUTC;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isClosed()
/*      */   {
/* 3709 */     return this.isClosed;
/*      */   }
/*      */   
/*      */   public boolean isCursorFetchEnabled() throws SQLException {
/* 3713 */     return (versionMeetsMinimum(5, 0, 2)) && (getUseCursorFetch());
/*      */   }
/*      */   
/*      */   public boolean isInGlobalTx() {
/* 3717 */     return this.isInGlobalTx;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean isMasterConnection()
/*      */   {
/* 3728 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isNoBackslashEscapesSet()
/*      */   {
/* 3738 */     return this.noBackslashEscapes;
/*      */   }
/*      */   
/*      */   public boolean isReadInfoMsgEnabled() {
/* 3742 */     return this.readInfoMsg;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isReadOnly()
/*      */     throws SQLException
/*      */   {
/* 3755 */     return this.readOnly;
/*      */   }
/*      */   
/*      */   public boolean isRunningOnJDK13() {
/* 3759 */     return this.isRunningOnJDK13;
/*      */   }
/*      */   
/*      */   public synchronized boolean isSameResource(Connection otherConnection) {
/* 3763 */     if (otherConnection == null) {
/* 3764 */       return false;
/*      */     }
/*      */     
/* 3767 */     boolean directCompare = true;
/*      */     
/* 3769 */     String otherHost = ((ConnectionImpl)otherConnection).origHostToConnectTo;
/* 3770 */     String otherOrigDatabase = ((ConnectionImpl)otherConnection).origDatabaseToConnectTo;
/* 3771 */     String otherCurrentCatalog = ((ConnectionImpl)otherConnection).database;
/*      */     
/* 3773 */     if (!nullSafeCompare(otherHost, this.origHostToConnectTo)) {
/* 3774 */       directCompare = false;
/* 3775 */     } else if ((otherHost != null) && (otherHost.indexOf(',') == -1) && (otherHost.indexOf(':') == -1))
/*      */     {
/*      */ 
/* 3778 */       directCompare = ((ConnectionImpl)otherConnection).origPortToConnectTo == this.origPortToConnectTo;
/*      */     }
/*      */     
/*      */ 
/* 3782 */     if (directCompare) {
/* 3783 */       if (!nullSafeCompare(otherOrigDatabase, this.origDatabaseToConnectTo)) { directCompare = false;
/* 3784 */         directCompare = false;
/* 3785 */       } else if (!nullSafeCompare(otherCurrentCatalog, this.database)) {
/* 3786 */         directCompare = false;
/*      */       }
/*      */     }
/*      */     
/* 3790 */     if (directCompare) {
/* 3791 */       return true;
/*      */     }
/*      */     
/*      */ 
/* 3795 */     String otherResourceId = ((ConnectionImpl)otherConnection).getResourceId();
/* 3796 */     String myResourceId = getResourceId();
/*      */     
/* 3798 */     if ((otherResourceId != null) || (myResourceId != null)) {
/* 3799 */       directCompare = nullSafeCompare(otherResourceId, myResourceId);
/*      */       
/* 3801 */       if (directCompare) {
/* 3802 */         return true;
/*      */       }
/*      */     }
/*      */     
/* 3806 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isServerTzUTC() {
/* 3810 */     return this.isServerTzUTC;
/*      */   }
/*      */   
/* 3813 */   private boolean usingCachedConfig = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void loadServerVariables()
/*      */     throws SQLException
/*      */   {
/* 3824 */     if (getCacheServerConfiguration()) {
/* 3825 */       synchronized (serverConfigByUrl) {
/* 3826 */         Map<String, String> cachedVariableMap = (Map)serverConfigByUrl.get(getURL());
/*      */         
/* 3828 */         if (cachedVariableMap != null) {
/* 3829 */           this.serverVariables = cachedVariableMap;
/* 3830 */           this.usingCachedConfig = true;
/*      */           
/* 3832 */           return;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 3837 */     java.sql.Statement stmt = null;
/* 3838 */     ResultSet results = null;
/*      */     try
/*      */     {
/* 3841 */       stmt = getMetadataSafeStatement();
/*      */       
/* 3843 */       String version = this.dbmd.getDriverVersion();
/*      */       
/* 3845 */       if ((version != null) && (version.indexOf('*') != -1)) {
/* 3846 */         StringBuffer buf = new StringBuffer(version.length() + 10);
/*      */         
/* 3848 */         for (int i = 0; i < version.length(); i++) {
/* 3849 */           char c = version.charAt(i);
/*      */           
/* 3851 */           if (c == '*') {
/* 3852 */             buf.append("[star]");
/*      */           } else {
/* 3854 */             buf.append(c);
/*      */           }
/*      */         }
/*      */         
/* 3858 */         version = buf.toString();
/*      */       }
/*      */       
/* 3861 */       String versionComment = "/* " + version + " */";
/*      */       
/*      */ 
/* 3864 */       String query = versionComment + "SHOW VARIABLES";
/*      */       
/* 3866 */       if (versionMeetsMinimum(5, 0, 3)) {
/* 3867 */         query = versionComment + "SHOW VARIABLES WHERE Variable_name ='language'" + " OR Variable_name = 'net_write_timeout'" + " OR Variable_name = 'interactive_timeout'" + " OR Variable_name = 'wait_timeout'" + " OR Variable_name = 'character_set_client'" + " OR Variable_name = 'character_set_connection'" + " OR Variable_name = 'character_set'" + " OR Variable_name = 'character_set_server'" + " OR Variable_name = 'tx_isolation'" + " OR Variable_name = 'transaction_isolation'" + " OR Variable_name = 'character_set_results'" + " OR Variable_name = 'timezone'" + " OR Variable_name = 'time_zone'" + " OR Variable_name = 'system_time_zone'" + " OR Variable_name = 'lower_case_table_names'" + " OR Variable_name = 'max_allowed_packet'" + " OR Variable_name = 'net_buffer_length'" + " OR Variable_name = 'sql_mode'" + " OR Variable_name = 'query_cache_type'" + " OR Variable_name = 'query_cache_size'" + " OR Variable_name = 'init_connect'";
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3890 */       this.serverVariables = new HashMap();
/*      */       
/* 3892 */       results = stmt.executeQuery(query);
/*      */       
/* 3894 */       while (results.next()) {
/* 3895 */         this.serverVariables.put(results.getString(1), results.getString(2));
/*      */       }
/*      */       
/*      */ 
/* 3899 */       results.close();
/* 3900 */       results = null;
/*      */       
/* 3902 */       if (versionMeetsMinimum(5, 0, 2)) {
/* 3903 */         results = stmt.executeQuery(versionComment + "SELECT @@session.auto_increment_increment");
/*      */         
/* 3905 */         if (results.next()) {
/* 3906 */           this.serverVariables.put("auto_increment_increment", results.getString(1));
/*      */         }
/*      */       }
/*      */       
/* 3910 */       if (getCacheServerConfiguration()) {
/* 3911 */         synchronized (serverConfigByUrl) {
/* 3912 */           serverConfigByUrl.put(getURL(), this.serverVariables);
/*      */           
/* 3914 */           this.usingCachedConfig = true;
/*      */         }
/*      */       }
/*      */     } catch (SQLException e) {
/* 3918 */       throw e;
/*      */     } finally {
/* 3920 */       if (results != null) {
/*      */         try {
/* 3922 */           results.close();
/*      */         }
/*      */         catch (SQLException sqlE) {}
/*      */       }
/*      */       
/*      */ 
/* 3928 */       if (stmt != null) {
/*      */         try {
/* 3930 */           stmt.close();
/*      */         }
/*      */         catch (SQLException sqlE) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/* 3938 */   private int autoIncrementIncrement = 0;
/*      */   private ExceptionInterceptor exceptionInterceptor;
/*      */   
/* 3941 */   public int getAutoIncrementIncrement() { return this.autoIncrementIncrement; }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean lowerCaseTableNames()
/*      */   {
/* 3950 */     return this.lowerCaseTableNames;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void maxRowsChanged(Statement stmt)
/*      */   {
/* 3960 */     if (this.statementsUsingMaxRows == null) {
/* 3961 */       this.statementsUsingMaxRows = new HashMap();
/*      */     }
/*      */     
/* 3964 */     this.statementsUsingMaxRows.put(stmt, stmt);
/*      */     
/* 3966 */     this.maxRowsChanged = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String nativeSQL(String sql)
/*      */     throws SQLException
/*      */   {
/* 3982 */     if (sql == null) {
/* 3983 */       return null;
/*      */     }
/*      */     
/* 3986 */     Object escapedSqlResult = EscapeProcessor.escapeSQL(sql, serverSupportsConvertFn(), getLoadBalanceSafeProxy());
/*      */     
/*      */ 
/*      */ 
/* 3990 */     if ((escapedSqlResult instanceof String)) {
/* 3991 */       return (String)escapedSqlResult;
/*      */     }
/*      */     
/* 3994 */     return ((EscapeProcessorResult)escapedSqlResult).escapedSql;
/*      */   }
/*      */   
/*      */   private CallableStatement parseCallableStatement(String sql) throws SQLException
/*      */   {
/* 3999 */     Object escapedSqlResult = EscapeProcessor.escapeSQL(sql, serverSupportsConvertFn(), getLoadBalanceSafeProxy());
/*      */     
/*      */ 
/* 4002 */     boolean isFunctionCall = false;
/* 4003 */     String parsedSql = null;
/*      */     
/* 4005 */     if ((escapedSqlResult instanceof EscapeProcessorResult)) {
/* 4006 */       parsedSql = ((EscapeProcessorResult)escapedSqlResult).escapedSql;
/* 4007 */       isFunctionCall = ((EscapeProcessorResult)escapedSqlResult).callingStoredFunction;
/*      */     } else {
/* 4009 */       parsedSql = (String)escapedSqlResult;
/* 4010 */       isFunctionCall = false;
/*      */     }
/*      */     
/* 4013 */     return CallableStatement.getInstance(getLoadBalanceSafeProxy(), parsedSql, this.database, isFunctionCall);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean parserKnowsUnicode()
/*      */   {
/* 4023 */     return this.parserKnowsUnicode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void ping()
/*      */     throws SQLException
/*      */   {
/* 4033 */     pingInternal(true, 0);
/*      */   }
/*      */   
/*      */   public void pingInternal(boolean checkForClosedConnection, int timeoutMillis) throws SQLException
/*      */   {
/* 4038 */     if (checkForClosedConnection) {
/* 4039 */       checkClosed();
/*      */     }
/*      */     
/* 4042 */     long pingMillisLifetime = getSelfDestructOnPingSecondsLifetime();
/* 4043 */     int pingMaxOperations = getSelfDestructOnPingMaxOperations();
/*      */     
/* 4045 */     if (((pingMillisLifetime > 0L) && (System.currentTimeMillis() - this.connectionCreationTimeMillis > pingMillisLifetime)) || ((pingMaxOperations > 0) && (pingMaxOperations <= this.io.getCommandCount())))
/*      */     {
/*      */ 
/*      */ 
/* 4049 */       close();
/*      */       
/* 4051 */       throw SQLError.createSQLException(Messages.getString("Connection.exceededConnectionLifetime"), "08S01", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 4056 */     this.io.sendCommand(14, null, null, false, null, timeoutMillis);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.CallableStatement prepareCall(String sql)
/*      */     throws SQLException
/*      */   {
/* 4071 */     return prepareCall(sql, 1003, 1007);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency)
/*      */     throws SQLException
/*      */   {
/* 4092 */     if (versionMeetsMinimum(5, 0, 0)) {
/* 4093 */       CallableStatement cStmt = null;
/*      */       
/* 4095 */       if (!getCacheCallableStatements())
/*      */       {
/* 4097 */         cStmt = parseCallableStatement(sql);
/*      */       } else {
/* 4099 */         synchronized (this.parsedCallableStatementCache) {
/* 4100 */           CompoundCacheKey key = new CompoundCacheKey(getCatalog(), sql);
/*      */           
/* 4102 */           CallableStatement.CallableStatementParamInfo cachedParamInfo = (CallableStatement.CallableStatementParamInfo)this.parsedCallableStatementCache.get(key);
/*      */           
/*      */ 
/* 4105 */           if (cachedParamInfo != null) {
/* 4106 */             cStmt = CallableStatement.getInstance(getLoadBalanceSafeProxy(), cachedParamInfo);
/*      */           } else {
/* 4108 */             cStmt = parseCallableStatement(sql);
/*      */             
/* 4110 */             synchronized (cStmt) {
/* 4111 */               cachedParamInfo = cStmt.paramInfo;
/*      */             }
/*      */             
/* 4114 */             this.parsedCallableStatementCache.put(key, cachedParamInfo);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 4119 */       cStmt.setResultSetType(resultSetType);
/* 4120 */       cStmt.setResultSetConcurrency(resultSetConcurrency);
/*      */       
/* 4122 */       return cStmt;
/*      */     }
/*      */     
/* 4125 */     throw SQLError.createSQLException("Callable statements not supported.", "S1C00", getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability)
/*      */     throws SQLException
/*      */   {
/* 4135 */     if ((getPedantic()) && 
/* 4136 */       (resultSetHoldability != 1)) {
/* 4137 */       throw SQLError.createSQLException("HOLD_CUSRORS_OVER_COMMIT is only supported holdability level", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4143 */     CallableStatement cStmt = (CallableStatement)prepareCall(sql, resultSetType, resultSetConcurrency);
/*      */     
/*      */ 
/* 4146 */     return cStmt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.PreparedStatement prepareStatement(String sql)
/*      */     throws SQLException
/*      */   {
/* 4176 */     return prepareStatement(sql, 1003, 1007);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.PreparedStatement prepareStatement(String sql, int autoGenKeyIndex)
/*      */     throws SQLException
/*      */   {
/* 4185 */     java.sql.PreparedStatement pStmt = prepareStatement(sql);
/*      */     
/* 4187 */     ((PreparedStatement)pStmt).setRetrieveGeneratedKeys(autoGenKeyIndex == 1);
/*      */     
/*      */ 
/* 4190 */     return pStmt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized java.sql.PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency)
/*      */     throws SQLException
/*      */   {
/* 4210 */     checkClosed();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4216 */     PreparedStatement pStmt = null;
/*      */     
/* 4218 */     boolean canServerPrepare = true;
/*      */     
/* 4220 */     String nativeSql = getProcessEscapeCodesForPrepStmts() ? nativeSQL(sql) : sql;
/*      */     
/* 4222 */     if ((this.useServerPreparedStmts) && (getEmulateUnsupportedPstmts())) {
/* 4223 */       canServerPrepare = canHandleAsServerPreparedStatement(nativeSql);
/*      */     }
/*      */     
/* 4226 */     if ((this.useServerPreparedStmts) && (canServerPrepare)) {
/* 4227 */       if (getCachePreparedStatements()) {
/* 4228 */         synchronized (this.serverSideStatementCache) {
/* 4229 */           pStmt = (ServerPreparedStatement)this.serverSideStatementCache.remove(sql);
/*      */           
/* 4231 */           if (pStmt != null) {
/* 4232 */             ((ServerPreparedStatement)pStmt).setClosed(false);
/* 4233 */             pStmt.clearParameters();
/*      */           }
/*      */           
/* 4236 */           if (pStmt == null) {
/*      */             try {
/* 4238 */               pStmt = ServerPreparedStatement.getInstance(getLoadBalanceSafeProxy(), nativeSql, this.database, resultSetType, resultSetConcurrency);
/*      */               
/* 4240 */               if (sql.length() < getPreparedStatementCacheSqlLimit()) {
/* 4241 */                 ((ServerPreparedStatement)pStmt).isCached = true;
/*      */               }
/*      */               
/* 4244 */               pStmt.setResultSetType(resultSetType);
/* 4245 */               pStmt.setResultSetConcurrency(resultSetConcurrency);
/*      */             }
/*      */             catch (SQLException sqlEx) {
/* 4248 */               if (getEmulateUnsupportedPstmts()) {
/* 4249 */                 pStmt = (PreparedStatement)clientPrepareStatement(nativeSql, resultSetType, resultSetConcurrency, false);
/*      */                 
/* 4251 */                 if (sql.length() < getPreparedStatementCacheSqlLimit()) {
/* 4252 */                   this.serverSideStatementCheckCache.put(sql, Boolean.FALSE);
/*      */                 }
/*      */               } else {
/* 4255 */                 throw sqlEx;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       } else {
/*      */         try {
/* 4262 */           pStmt = ServerPreparedStatement.getInstance(getLoadBalanceSafeProxy(), nativeSql, this.database, resultSetType, resultSetConcurrency);
/*      */           
/*      */ 
/* 4265 */           pStmt.setResultSetType(resultSetType);
/* 4266 */           pStmt.setResultSetConcurrency(resultSetConcurrency);
/*      */         }
/*      */         catch (SQLException sqlEx) {
/* 4269 */           if (getEmulateUnsupportedPstmts()) {
/* 4270 */             pStmt = (PreparedStatement)clientPrepareStatement(nativeSql, resultSetType, resultSetConcurrency, false);
/*      */           } else {
/* 4272 */             throw sqlEx;
/*      */           }
/*      */         }
/*      */       }
/*      */     } else {
/* 4277 */       pStmt = (PreparedStatement)clientPrepareStatement(nativeSql, resultSetType, resultSetConcurrency, false);
/*      */     }
/*      */     
/* 4280 */     return pStmt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability)
/*      */     throws SQLException
/*      */   {
/* 4289 */     if ((getPedantic()) && 
/* 4290 */       (resultSetHoldability != 1)) {
/* 4291 */       throw SQLError.createSQLException("HOLD_CUSRORS_OVER_COMMIT is only supported holdability level", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4297 */     return prepareStatement(sql, resultSetType, resultSetConcurrency);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public java.sql.PreparedStatement prepareStatement(String sql, int[] autoGenKeyIndexes)
/*      */     throws SQLException
/*      */   {
/* 4305 */     java.sql.PreparedStatement pStmt = prepareStatement(sql);
/*      */     
/* 4307 */     ((PreparedStatement)pStmt).setRetrieveGeneratedKeys((autoGenKeyIndexes != null) && (autoGenKeyIndexes.length > 0));
/*      */     
/*      */ 
/*      */ 
/* 4311 */     return pStmt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public java.sql.PreparedStatement prepareStatement(String sql, String[] autoGenKeyColNames)
/*      */     throws SQLException
/*      */   {
/* 4319 */     java.sql.PreparedStatement pStmt = prepareStatement(sql);
/*      */     
/* 4321 */     ((PreparedStatement)pStmt).setRetrieveGeneratedKeys((autoGenKeyColNames != null) && (autoGenKeyColNames.length > 0));
/*      */     
/*      */ 
/*      */ 
/* 4325 */     return pStmt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void realClose(boolean calledExplicitly, boolean issueRollback, boolean skipLocalTeardown, Throwable reason)
/*      */     throws SQLException
/*      */   {
/* 4340 */     SQLException sqlEx = null;
/*      */     
/* 4342 */     if (isClosed()) {
/* 4343 */       return;
/*      */     }
/*      */     
/* 4346 */     this.forceClosedReason = reason;
/*      */     try
/*      */     {
/* 4349 */       if (!skipLocalTeardown) {
/* 4350 */         if ((!getAutoCommit()) && (issueRollback)) {
/*      */           try {
/* 4352 */             rollback();
/*      */           } catch (SQLException ex) {
/* 4354 */             sqlEx = ex;
/*      */           }
/*      */         }
/*      */         
/* 4358 */         reportMetrics();
/*      */         
/* 4360 */         if (getUseUsageAdvisor()) {
/* 4361 */           if (!calledExplicitly) {
/* 4362 */             String message = "Connection implicitly closed by Driver. You should call Connection.close() from your code to free resources more efficiently and avoid resource leaks.";
/*      */             
/* 4364 */             this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", getCatalog(), getId(), -1, -1, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, message));
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4372 */           long connectionLifeTime = System.currentTimeMillis() - this.connectionCreationTimeMillis;
/*      */           
/*      */ 
/* 4375 */           if (connectionLifeTime < 500L) {
/* 4376 */             String message = "Connection lifetime of < .5 seconds. You might be un-necessarily creating short-lived connections and should investigate connection pooling to be more efficient.";
/*      */             
/* 4378 */             this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", getCatalog(), getId(), -1, -1, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, message));
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         try
/*      */         {
/* 4388 */           closeAllOpenStatements();
/*      */         } catch (SQLException ex) {
/* 4390 */           sqlEx = ex;
/*      */         }
/*      */         
/* 4393 */         if (this.io != null) {
/*      */           try {
/* 4395 */             this.io.quit();
/*      */           }
/*      */           catch (Exception e) {}
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 4402 */         this.io.forceClose();
/*      */       }
/*      */       
/* 4405 */       if (this.statementInterceptors != null) {
/* 4406 */         for (int i = 0; i < this.statementInterceptors.size(); i++) {
/* 4407 */           ((StatementInterceptorV2)this.statementInterceptors.get(i)).destroy();
/*      */         }
/*      */       }
/*      */       
/* 4411 */       if (this.exceptionInterceptor != null) {
/* 4412 */         this.exceptionInterceptor.destroy();
/*      */       }
/*      */     } finally {
/* 4415 */       this.openStatements = null;
/* 4416 */       this.io = null;
/* 4417 */       this.statementInterceptors = null;
/* 4418 */       this.exceptionInterceptor = null;
/* 4419 */       ProfilerEventHandlerFactory.removeInstance(this);
/*      */       
/* 4421 */       synchronized (this) {
/* 4422 */         if (this.cancelTimer != null) {
/* 4423 */           this.cancelTimer.cancel();
/*      */         }
/*      */       }
/*      */       
/* 4427 */       this.isClosed = true;
/*      */     }
/*      */     
/* 4430 */     if (sqlEx != null) {
/* 4431 */       throw sqlEx;
/*      */     }
/*      */   }
/*      */   
/*      */   public synchronized void recachePreparedStatement(ServerPreparedStatement pstmt) throws SQLException
/*      */   {
/* 4437 */     if (pstmt.isPoolable()) {
/* 4438 */       synchronized (this.serverSideStatementCache) {
/* 4439 */         this.serverSideStatementCache.put(pstmt.originalSql, pstmt);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void registerQueryExecutionTime(long queryTimeMs)
/*      */   {
/* 4450 */     if (queryTimeMs > this.longestQueryTimeMs) {
/* 4451 */       this.longestQueryTimeMs = queryTimeMs;
/*      */       
/* 4453 */       repartitionPerformanceHistogram();
/*      */     }
/*      */     
/* 4456 */     addToPerformanceHistogram(queryTimeMs, 1);
/*      */     
/* 4458 */     if (queryTimeMs < this.shortestQueryTimeMs) {
/* 4459 */       this.shortestQueryTimeMs = (queryTimeMs == 0L ? 1L : queryTimeMs);
/*      */     }
/*      */     
/* 4462 */     this.numberOfQueriesIssued += 1L;
/*      */     
/* 4464 */     this.totalQueryTimeMs += queryTimeMs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void registerStatement(Statement stmt)
/*      */   {
/* 4474 */     synchronized (this.openStatements) {
/* 4475 */       this.openStatements.put(stmt, stmt);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void repartitionHistogram(int[] histCounts, long[] histBreakpoints, long currentLowerBound, long currentUpperBound)
/*      */   {
/* 4489 */     if (this.oldHistCounts == null) {
/* 4490 */       this.oldHistCounts = new int[histCounts.length];
/* 4491 */       this.oldHistBreakpoints = new long[histBreakpoints.length];
/*      */     }
/*      */     
/* 4494 */     System.arraycopy(histCounts, 0, this.oldHistCounts, 0, histCounts.length);
/*      */     
/* 4496 */     System.arraycopy(histBreakpoints, 0, this.oldHistBreakpoints, 0, histBreakpoints.length);
/*      */     
/*      */ 
/* 4499 */     createInitialHistogram(histBreakpoints, currentLowerBound, currentUpperBound);
/*      */     
/*      */ 
/* 4502 */     for (int i = 0; i < 20; i++) {
/* 4503 */       addToHistogram(histCounts, histBreakpoints, this.oldHistBreakpoints[i], this.oldHistCounts[i], currentLowerBound, currentUpperBound);
/*      */     }
/*      */   }
/*      */   
/*      */   private void repartitionPerformanceHistogram()
/*      */   {
/* 4509 */     checkAndCreatePerformanceHistogram();
/*      */     
/* 4511 */     repartitionHistogram(this.perfMetricsHistCounts, this.perfMetricsHistBreakpoints, this.shortestQueryTimeMs == Long.MAX_VALUE ? 0L : this.shortestQueryTimeMs, this.longestQueryTimeMs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void repartitionTablesAccessedHistogram()
/*      */   {
/* 4518 */     checkAndCreateTablesAccessedHistogram();
/*      */     
/* 4520 */     repartitionHistogram(this.numTablesMetricsHistCounts, this.numTablesMetricsHistBreakpoints, this.minimumNumberTablesAccessed == Long.MAX_VALUE ? 0L : this.minimumNumberTablesAccessed, this.maximumNumberTablesAccessed);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void reportMetrics()
/*      */   {
/* 4528 */     if (getGatherPerformanceMetrics()) {
/* 4529 */       StringBuffer logMessage = new StringBuffer(256);
/*      */       
/* 4531 */       logMessage.append("** Performance Metrics Report **\n");
/* 4532 */       logMessage.append("\nLongest reported query: " + this.longestQueryTimeMs + " ms");
/*      */       
/* 4534 */       logMessage.append("\nShortest reported query: " + this.shortestQueryTimeMs + " ms");
/*      */       
/* 4536 */       logMessage.append("\nAverage query execution time: " + this.totalQueryTimeMs / this.numberOfQueriesIssued + " ms");
/*      */       
/*      */ 
/*      */ 
/* 4540 */       logMessage.append("\nNumber of statements executed: " + this.numberOfQueriesIssued);
/*      */       
/* 4542 */       logMessage.append("\nNumber of result sets created: " + this.numberOfResultSetsCreated);
/*      */       
/* 4544 */       logMessage.append("\nNumber of statements prepared: " + this.numberOfPrepares);
/*      */       
/* 4546 */       logMessage.append("\nNumber of prepared statement executions: " + this.numberOfPreparedExecutes);
/*      */       
/*      */ 
/* 4549 */       if (this.perfMetricsHistBreakpoints != null) {
/* 4550 */         logMessage.append("\n\n\tTiming Histogram:\n");
/* 4551 */         int maxNumPoints = 20;
/* 4552 */         int highestCount = Integer.MIN_VALUE;
/*      */         
/* 4554 */         for (int i = 0; i < 20; i++) {
/* 4555 */           if (this.perfMetricsHistCounts[i] > highestCount) {
/* 4556 */             highestCount = this.perfMetricsHistCounts[i];
/*      */           }
/*      */         }
/*      */         
/* 4560 */         if (highestCount == 0) {
/* 4561 */           highestCount = 1;
/*      */         }
/*      */         
/* 4564 */         for (int i = 0; i < 19; i++)
/*      */         {
/* 4566 */           if (i == 0) {
/* 4567 */             logMessage.append("\n\tless than " + this.perfMetricsHistBreakpoints[(i + 1)] + " ms: \t" + this.perfMetricsHistCounts[i]);
/*      */           }
/*      */           else
/*      */           {
/* 4571 */             logMessage.append("\n\tbetween " + this.perfMetricsHistBreakpoints[i] + " and " + this.perfMetricsHistBreakpoints[(i + 1)] + " ms: \t" + this.perfMetricsHistCounts[i]);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 4577 */           logMessage.append("\t");
/*      */           
/* 4579 */           int numPointsToGraph = (int)(maxNumPoints * (this.perfMetricsHistCounts[i] / highestCount));
/*      */           
/* 4581 */           for (int j = 0; j < numPointsToGraph; j++) {
/* 4582 */             logMessage.append("*");
/*      */           }
/*      */           
/* 4585 */           if (this.longestQueryTimeMs < this.perfMetricsHistCounts[(i + 1)]) {
/*      */             break;
/*      */           }
/*      */         }
/*      */         
/* 4590 */         if (this.perfMetricsHistBreakpoints[18] < this.longestQueryTimeMs) {
/* 4591 */           logMessage.append("\n\tbetween ");
/* 4592 */           logMessage.append(this.perfMetricsHistBreakpoints[18]);
/*      */           
/* 4594 */           logMessage.append(" and ");
/* 4595 */           logMessage.append(this.perfMetricsHistBreakpoints[19]);
/*      */           
/* 4597 */           logMessage.append(" ms: \t");
/* 4598 */           logMessage.append(this.perfMetricsHistCounts[19]);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 4603 */       if (this.numTablesMetricsHistBreakpoints != null) {
/* 4604 */         logMessage.append("\n\n\tTable Join Histogram:\n");
/* 4605 */         int maxNumPoints = 20;
/* 4606 */         int highestCount = Integer.MIN_VALUE;
/*      */         
/* 4608 */         for (int i = 0; i < 20; i++) {
/* 4609 */           if (this.numTablesMetricsHistCounts[i] > highestCount) {
/* 4610 */             highestCount = this.numTablesMetricsHistCounts[i];
/*      */           }
/*      */         }
/*      */         
/* 4614 */         if (highestCount == 0) {
/* 4615 */           highestCount = 1;
/*      */         }
/*      */         
/* 4618 */         for (int i = 0; i < 19; i++)
/*      */         {
/* 4620 */           if (i == 0) {
/* 4621 */             logMessage.append("\n\t" + this.numTablesMetricsHistBreakpoints[(i + 1)] + " tables or less: \t\t" + this.numTablesMetricsHistCounts[i]);
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/* 4626 */             logMessage.append("\n\tbetween " + this.numTablesMetricsHistBreakpoints[i] + " and " + this.numTablesMetricsHistBreakpoints[(i + 1)] + " tables: \t" + this.numTablesMetricsHistCounts[i]);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4634 */           logMessage.append("\t");
/*      */           
/* 4636 */           int numPointsToGraph = (int)(maxNumPoints * (this.numTablesMetricsHistCounts[i] / highestCount));
/*      */           
/* 4638 */           for (int j = 0; j < numPointsToGraph; j++) {
/* 4639 */             logMessage.append("*");
/*      */           }
/*      */           
/* 4642 */           if (this.maximumNumberTablesAccessed < this.numTablesMetricsHistBreakpoints[(i + 1)]) {
/*      */             break;
/*      */           }
/*      */         }
/*      */         
/* 4647 */         if (this.numTablesMetricsHistBreakpoints[18] < this.maximumNumberTablesAccessed) {
/* 4648 */           logMessage.append("\n\tbetween ");
/* 4649 */           logMessage.append(this.numTablesMetricsHistBreakpoints[18]);
/*      */           
/* 4651 */           logMessage.append(" and ");
/* 4652 */           logMessage.append(this.numTablesMetricsHistBreakpoints[19]);
/*      */           
/* 4654 */           logMessage.append(" tables: ");
/* 4655 */           logMessage.append(this.numTablesMetricsHistCounts[19]);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 4660 */       this.log.logInfo(logMessage);
/*      */       
/* 4662 */       this.metricsLastReportedMs = System.currentTimeMillis();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void reportMetricsIfNeeded()
/*      */   {
/* 4671 */     if ((getGatherPerformanceMetrics()) && 
/* 4672 */       (System.currentTimeMillis() - this.metricsLastReportedMs > getReportMetricsIntervalMillis())) {
/* 4673 */       reportMetrics();
/*      */     }
/*      */   }
/*      */   
/*      */   public void reportNumberOfTablesAccessed(int numTablesAccessed)
/*      */   {
/* 4679 */     if (numTablesAccessed < this.minimumNumberTablesAccessed) {
/* 4680 */       this.minimumNumberTablesAccessed = numTablesAccessed;
/*      */     }
/*      */     
/* 4683 */     if (numTablesAccessed > this.maximumNumberTablesAccessed) {
/* 4684 */       this.maximumNumberTablesAccessed = numTablesAccessed;
/*      */       
/* 4686 */       repartitionTablesAccessedHistogram();
/*      */     }
/*      */     
/* 4689 */     addToTablesAccessedHistogram(numTablesAccessed, 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void resetServerState()
/*      */     throws SQLException
/*      */   {
/* 4701 */     if ((!getParanoid()) && (this.io != null) && (versionMeetsMinimum(4, 0, 6)))
/*      */     {
/* 4703 */       changeUser(this.user, this.password);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void rollback()
/*      */     throws SQLException
/*      */   {
/* 4717 */     checkClosed();
/*      */     try
/*      */     {
/* 4720 */       if (this.connectionLifecycleInterceptors != null) {
/* 4721 */         IterateBlock iter = new IterateBlock(this.connectionLifecycleInterceptors.iterator())
/*      */         {
/*      */           void forEach(Object each) throws SQLException {
/* 4724 */             if (!((ConnectionLifecycleInterceptor)each).rollback()) {
/* 4725 */               this.stopIterating = true;
/*      */             }
/*      */             
/*      */           }
/* 4729 */         };
/* 4730 */         iter.doForAll();
/*      */         
/* 4732 */         if (!iter.fullIteration()) {
/* 4733 */           return;
/*      */         }
/*      */       }
/*      */       
/* 4737 */       if ((this.autoCommit) && (!getRelaxAutoCommit())) {
/* 4738 */         throw SQLError.createSQLException("Can't call rollback when autocommit=true", "08003", getExceptionInterceptor());
/*      */       }
/*      */       
/* 4741 */       if (this.transactionsSupported) {
/*      */         try {
/* 4743 */           rollbackNoChecks();
/*      */         }
/*      */         catch (SQLException sqlEx) {
/* 4746 */           if ((getIgnoreNonTxTables()) && (sqlEx.getErrorCode() == 1196))
/*      */           {
/* 4748 */             return;
/*      */           }
/* 4750 */           throw sqlEx;
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (SQLException sqlException) {
/* 4755 */       if ("08S01".equals(sqlException.getSQLState()))
/*      */       {
/* 4757 */         throw SQLError.createSQLException("Communications link failure during rollback(). Transaction resolution unknown.", "08007", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 4762 */       throw sqlException;
/*      */     } finally {
/* 4764 */       this.needsPing = getReconnectAtTxEnd();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized void rollback(final Savepoint savepoint)
/*      */     throws SQLException
/*      */   {
/* 4773 */     if ((versionMeetsMinimum(4, 0, 14)) || (versionMeetsMinimum(4, 1, 1))) {
/* 4774 */       checkClosed();
/*      */       try
/*      */       {
/* 4777 */         if (this.connectionLifecycleInterceptors != null) {
/* 4778 */           IterateBlock iter = new IterateBlock(this.connectionLifecycleInterceptors.iterator())
/*      */           {
/*      */             void forEach(Object each) throws SQLException {
/* 4781 */               if (!((ConnectionLifecycleInterceptor)each).rollback(savepoint)) {
/* 4782 */                 this.stopIterating = true;
/*      */               }
/*      */               
/*      */             }
/* 4786 */           };
/* 4787 */           iter.doForAll();
/*      */           
/* 4789 */           if (!iter.fullIteration()) {
/* 4790 */             return;
/*      */           }
/*      */         }
/*      */         
/* 4794 */         StringBuffer rollbackQuery = new StringBuffer("ROLLBACK TO SAVEPOINT ");
/*      */         
/* 4796 */         rollbackQuery.append('`');
/* 4797 */         rollbackQuery.append(savepoint.getSavepointName());
/* 4798 */         rollbackQuery.append('`');
/*      */         
/* 4800 */         java.sql.Statement stmt = null;
/*      */         try
/*      */         {
/* 4803 */           stmt = getMetadataSafeStatement();
/*      */           
/* 4805 */           stmt.executeUpdate(rollbackQuery.toString());
/*      */         } catch (SQLException sqlEx) {
/* 4807 */           int errno = sqlEx.getErrorCode();
/*      */           
/* 4809 */           if (errno == 1181) {
/* 4810 */             String msg = sqlEx.getMessage();
/*      */             
/* 4812 */             if (msg != null) {
/* 4813 */               int indexOfError153 = msg.indexOf("153");
/*      */               
/* 4815 */               if (indexOfError153 != -1) {
/* 4816 */                 throw SQLError.createSQLException("Savepoint '" + savepoint.getSavepointName() + "' does not exist", "S1009", errno, getExceptionInterceptor());
/*      */               }
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4826 */           if ((getIgnoreNonTxTables()) && (sqlEx.getErrorCode() != 1196))
/*      */           {
/* 4828 */             throw sqlEx;
/*      */           }
/*      */           
/* 4831 */           if ("08S01".equals(sqlEx.getSQLState()))
/*      */           {
/* 4833 */             throw SQLError.createSQLException("Communications link failure during rollback(). Transaction resolution unknown.", "08007", getExceptionInterceptor());
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 4838 */           throw sqlEx;
/*      */         } finally {
/* 4840 */           closeStatement(stmt);
/*      */         }
/*      */       } finally {
/* 4843 */         this.needsPing = getReconnectAtTxEnd();
/*      */       }
/*      */     } else {
/* 4846 */       throw SQLError.notImplemented();
/*      */     }
/*      */   }
/*      */   
/*      */   private void rollbackNoChecks() throws SQLException {
/* 4851 */     if ((getUseLocalTransactionState()) && (versionMeetsMinimum(5, 0, 0)) && 
/* 4852 */       (!this.io.inTransactionOnServer())) {
/* 4853 */       return;
/*      */     }
/*      */     
/*      */ 
/* 4857 */     execSQL(null, "rollback", -1, null, 1003, 1007, false, this.database, null, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.PreparedStatement serverPrepareStatement(String sql)
/*      */     throws SQLException
/*      */   {
/* 4869 */     String nativeSql = getProcessEscapeCodesForPrepStmts() ? nativeSQL(sql) : sql;
/*      */     
/* 4871 */     return ServerPreparedStatement.getInstance(getLoadBalanceSafeProxy(), nativeSql, getCatalog(), 1003, 1007);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.PreparedStatement serverPrepareStatement(String sql, int autoGenKeyIndex)
/*      */     throws SQLException
/*      */   {
/* 4881 */     String nativeSql = getProcessEscapeCodesForPrepStmts() ? nativeSQL(sql) : sql;
/*      */     
/* 4883 */     PreparedStatement pStmt = ServerPreparedStatement.getInstance(getLoadBalanceSafeProxy(), nativeSql, getCatalog(), 1003, 1007);
/*      */     
/*      */ 
/*      */ 
/* 4887 */     pStmt.setRetrieveGeneratedKeys(autoGenKeyIndex == 1);
/*      */     
/*      */ 
/* 4890 */     return pStmt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public java.sql.PreparedStatement serverPrepareStatement(String sql, int resultSetType, int resultSetConcurrency)
/*      */     throws SQLException
/*      */   {
/* 4898 */     String nativeSql = getProcessEscapeCodesForPrepStmts() ? nativeSQL(sql) : sql;
/*      */     
/* 4900 */     return ServerPreparedStatement.getInstance(getLoadBalanceSafeProxy(), nativeSql, getCatalog(), resultSetType, resultSetConcurrency);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.PreparedStatement serverPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability)
/*      */     throws SQLException
/*      */   {
/* 4911 */     if ((getPedantic()) && 
/* 4912 */       (resultSetHoldability != 1)) {
/* 4913 */       throw SQLError.createSQLException("HOLD_CUSRORS_OVER_COMMIT is only supported holdability level", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4919 */     return serverPrepareStatement(sql, resultSetType, resultSetConcurrency);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.PreparedStatement serverPrepareStatement(String sql, int[] autoGenKeyIndexes)
/*      */     throws SQLException
/*      */   {
/* 4928 */     PreparedStatement pStmt = (PreparedStatement)serverPrepareStatement(sql);
/*      */     
/* 4930 */     pStmt.setRetrieveGeneratedKeys((autoGenKeyIndexes != null) && (autoGenKeyIndexes.length > 0));
/*      */     
/*      */ 
/*      */ 
/* 4934 */     return pStmt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public java.sql.PreparedStatement serverPrepareStatement(String sql, String[] autoGenKeyColNames)
/*      */     throws SQLException
/*      */   {
/* 4942 */     PreparedStatement pStmt = (PreparedStatement)serverPrepareStatement(sql);
/*      */     
/* 4944 */     pStmt.setRetrieveGeneratedKeys((autoGenKeyColNames != null) && (autoGenKeyColNames.length > 0));
/*      */     
/*      */ 
/*      */ 
/* 4948 */     return pStmt;
/*      */   }
/*      */   
/*      */   public boolean serverSupportsConvertFn() throws SQLException {
/* 4952 */     return versionMeetsMinimum(4, 0, 2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setAutoCommit(final boolean autoCommitFlag)
/*      */     throws SQLException
/*      */   {
/* 4978 */     checkClosed();
/*      */     
/* 4980 */     if (this.connectionLifecycleInterceptors != null) {
/* 4981 */       IterateBlock iter = new IterateBlock(this.connectionLifecycleInterceptors.iterator())
/*      */       {
/*      */         void forEach(Object each) throws SQLException {
/* 4984 */           if (!((ConnectionLifecycleInterceptor)each).setAutoCommit(autoCommitFlag)) {
/* 4985 */             this.stopIterating = true;
/*      */           }
/*      */           
/*      */         }
/* 4989 */       };
/* 4990 */       iter.doForAll();
/*      */       
/* 4992 */       if (!iter.fullIteration()) {
/* 4993 */         return;
/*      */       }
/*      */     }
/*      */     
/* 4997 */     if (getAutoReconnectForPools()) {
/* 4998 */       setHighAvailability(true);
/*      */     }
/*      */     try
/*      */     {
/* 5002 */       if (this.transactionsSupported)
/*      */       {
/* 5004 */         boolean needsSetOnServer = true;
/*      */         
/* 5006 */         if ((getUseLocalSessionState()) && (this.autoCommit == autoCommitFlag))
/*      */         {
/* 5008 */           needsSetOnServer = false;
/* 5009 */         } else if (!getHighAvailability()) {
/* 5010 */           needsSetOnServer = getIO().isSetNeededForAutoCommitMode(autoCommitFlag);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5021 */         this.autoCommit = autoCommitFlag;
/*      */         
/* 5023 */         if (needsSetOnServer) {
/* 5024 */           execSQL(null, autoCommitFlag ? "SET autocommit=1" : "SET autocommit=0", -1, null, 1003, 1007, false, this.database, null, false);
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/* 5032 */         if ((!autoCommitFlag) && (!getRelaxAutoCommit())) {
/* 5033 */           throw SQLError.createSQLException("MySQL Versions Older than 3.23.15 do not support transactions", "08003", getExceptionInterceptor());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 5038 */         this.autoCommit = autoCommitFlag;
/*      */       }
/*      */     } finally {
/* 5041 */       if (getAutoReconnectForPools()) {
/* 5042 */         setHighAvailability(false);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setCatalog(final String catalog)
/*      */     throws SQLException
/*      */   {
/* 5063 */     checkClosed();
/*      */     
/* 5065 */     if (catalog == null) {
/* 5066 */       throw SQLError.createSQLException("Catalog can not be null", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 5070 */     if (this.connectionLifecycleInterceptors != null) {
/* 5071 */       IterateBlock iter = new IterateBlock(this.connectionLifecycleInterceptors.iterator())
/*      */       {
/*      */         void forEach(Object each) throws SQLException {
/* 5074 */           if (!((ConnectionLifecycleInterceptor)each).setCatalog(catalog)) {
/* 5075 */             this.stopIterating = true;
/*      */           }
/*      */           
/*      */         }
/* 5079 */       };
/* 5080 */       iter.doForAll();
/*      */       
/* 5082 */       if (!iter.fullIteration()) {
/* 5083 */         return;
/*      */       }
/*      */     }
/*      */     
/* 5087 */     if (getUseLocalSessionState()) {
/* 5088 */       if (this.lowerCaseTableNames) {
/* 5089 */         if (!this.database.equalsIgnoreCase(catalog)) {}
/*      */ 
/*      */ 
/*      */       }
/* 5093 */       else if (this.database.equals(catalog)) {
/* 5094 */         return;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 5099 */     String quotedId = this.dbmd.getIdentifierQuoteString();
/*      */     
/* 5101 */     if ((quotedId == null) || (quotedId.equals(" "))) {
/* 5102 */       quotedId = "";
/*      */     }
/*      */     
/* 5105 */     StringBuffer query = new StringBuffer("USE ");
/* 5106 */     query.append(quotedId);
/* 5107 */     query.append(catalog);
/* 5108 */     query.append(quotedId);
/*      */     
/* 5110 */     execSQL(null, query.toString(), -1, null, 1003, 1007, false, this.database, null, false);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5115 */     this.database = catalog;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setInGlobalTx(boolean flag)
/*      */   {
/* 5134 */     this.isInGlobalTx = flag;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReadInfoMsgEnabled(boolean flag)
/*      */   {
/* 5147 */     this.readInfoMsg = flag;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReadOnly(boolean readOnlyFlag)
/*      */     throws SQLException
/*      */   {
/* 5161 */     checkClosed();
/*      */     
/* 5163 */     setReadOnlyInternal(readOnlyFlag);
/*      */   }
/*      */   
/*      */   public void setReadOnlyInternal(boolean readOnlyFlag) throws SQLException {
/* 5167 */     this.readOnly = readOnlyFlag;
/*      */   }
/*      */   
/*      */ 
/*      */   public Savepoint setSavepoint()
/*      */     throws SQLException
/*      */   {
/* 5174 */     MysqlSavepoint savepoint = new MysqlSavepoint(getExceptionInterceptor());
/*      */     
/* 5176 */     setSavepoint(savepoint);
/*      */     
/* 5178 */     return savepoint;
/*      */   }
/*      */   
/*      */   private synchronized void setSavepoint(MysqlSavepoint savepoint) throws SQLException
/*      */   {
/* 5183 */     if ((versionMeetsMinimum(4, 0, 14)) || (versionMeetsMinimum(4, 1, 1))) {
/* 5184 */       checkClosed();
/*      */       
/* 5186 */       StringBuffer savePointQuery = new StringBuffer("SAVEPOINT ");
/* 5187 */       savePointQuery.append('`');
/* 5188 */       savePointQuery.append(savepoint.getSavepointName());
/* 5189 */       savePointQuery.append('`');
/*      */       
/* 5191 */       java.sql.Statement stmt = null;
/*      */       try
/*      */       {
/* 5194 */         stmt = getMetadataSafeStatement();
/*      */         
/* 5196 */         stmt.executeUpdate(savePointQuery.toString());
/*      */       } finally {
/* 5198 */         closeStatement(stmt);
/*      */       }
/*      */     } else {
/* 5201 */       throw SQLError.notImplemented();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized Savepoint setSavepoint(String name)
/*      */     throws SQLException
/*      */   {
/* 5209 */     MysqlSavepoint savepoint = new MysqlSavepoint(name, getExceptionInterceptor());
/*      */     
/* 5211 */     setSavepoint(savepoint);
/*      */     
/* 5213 */     return savepoint;
/*      */   }
/*      */   
/*      */ 
/*      */   private void setSessionVariables()
/*      */     throws SQLException
/*      */   {
/* 5220 */     if ((versionMeetsMinimum(4, 0, 0)) && (getSessionVariables() != null)) {
/* 5221 */       List<String> variablesToSet = StringUtils.split(getSessionVariables(), ",", "\"'", "\"'", false);
/*      */       
/*      */ 
/* 5224 */       int numVariablesToSet = variablesToSet.size();
/*      */       
/* 5226 */       java.sql.Statement stmt = null;
/*      */       try
/*      */       {
/* 5229 */         stmt = getMetadataSafeStatement();
/*      */         
/* 5231 */         for (int i = 0; i < numVariablesToSet; i++) {
/* 5232 */           String variableValuePair = (String)variablesToSet.get(i);
/*      */           
/* 5234 */           if (variableValuePair.startsWith("@")) {
/* 5235 */             stmt.executeUpdate("SET " + variableValuePair);
/*      */           } else {
/* 5237 */             stmt.executeUpdate("SET SESSION " + variableValuePair);
/*      */           }
/*      */         }
/*      */       } finally {
/* 5241 */         if (stmt != null) {
/* 5242 */           stmt.close();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setTransactionIsolation(int level)
/*      */     throws SQLException
/*      */   {
/* 5258 */     checkClosed();
/*      */     
/* 5260 */     if (this.hasIsolationLevels) {
/* 5261 */       String sql = null;
/*      */       
/* 5263 */       boolean shouldSendSet = false;
/*      */       
/* 5265 */       if (getAlwaysSendSetIsolation()) {
/* 5266 */         shouldSendSet = true;
/*      */       }
/* 5268 */       else if (level != this.isolationLevel) {
/* 5269 */         shouldSendSet = true;
/*      */       }
/*      */       
/*      */ 
/* 5273 */       if (getUseLocalSessionState()) {
/* 5274 */         shouldSendSet = this.isolationLevel != level;
/*      */       }
/*      */       
/* 5277 */       if (shouldSendSet) {
/* 5278 */         switch (level) {
/*      */         case 0: 
/* 5280 */           throw SQLError.createSQLException("Transaction isolation level NONE not supported by MySQL", getExceptionInterceptor());
/*      */         
/*      */ 
/*      */         case 2: 
/* 5284 */           sql = "SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED";
/*      */           
/* 5286 */           break;
/*      */         
/*      */         case 1: 
/* 5289 */           sql = "SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED";
/*      */           
/* 5291 */           break;
/*      */         
/*      */         case 4: 
/* 5294 */           sql = "SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ";
/*      */           
/* 5296 */           break;
/*      */         
/*      */         case 8: 
/* 5299 */           sql = "SET SESSION TRANSACTION ISOLATION LEVEL SERIALIZABLE";
/*      */           
/* 5301 */           break;
/*      */         case 3: case 5: case 6: 
/*      */         case 7: default: 
/* 5304 */           throw SQLError.createSQLException("Unsupported transaction isolation level '" + level + "'", "S1C00", getExceptionInterceptor());
/*      */         }
/*      */         
/*      */         
/*      */ 
/* 5309 */         execSQL(null, sql, -1, null, 1003, 1007, false, this.database, null, false);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 5314 */         this.isolationLevel = level;
/*      */       }
/*      */     } else {
/* 5317 */       throw SQLError.createSQLException("Transaction Isolation Levels are not supported on MySQL versions older than 3.23.36.", "S1C00", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setTypeMap(Map map)
/*      */     throws SQLException
/*      */   {
/* 5333 */     this.typeMap = map;
/*      */   }
/*      */   
/*      */   private void setupServerForTruncationChecks() throws SQLException {
/* 5337 */     if ((getJdbcCompliantTruncation()) && 
/* 5338 */       (versionMeetsMinimum(5, 0, 2))) {
/* 5339 */       String currentSqlMode = (String)this.serverVariables.get("sql_mode");
/*      */       
/*      */ 
/* 5342 */       boolean strictTransTablesIsSet = StringUtils.indexOfIgnoreCase(currentSqlMode, "STRICT_TRANS_TABLES") != -1;
/*      */       
/* 5344 */       if ((currentSqlMode == null) || (currentSqlMode.length() == 0) || (!strictTransTablesIsSet))
/*      */       {
/* 5346 */         StringBuffer commandBuf = new StringBuffer("SET sql_mode='");
/*      */         
/* 5348 */         if ((currentSqlMode != null) && (currentSqlMode.length() > 0)) {
/* 5349 */           commandBuf.append(currentSqlMode);
/* 5350 */           commandBuf.append(",");
/*      */         }
/*      */         
/* 5353 */         commandBuf.append("STRICT_TRANS_TABLES'");
/*      */         
/* 5355 */         execSQL(null, commandBuf.toString(), -1, null, 1003, 1007, false, this.database, null, false);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 5360 */         setJdbcCompliantTruncation(false);
/* 5361 */       } else if (strictTransTablesIsSet)
/*      */       {
/* 5363 */         setJdbcCompliantTruncation(false);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void shutdownServer()
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 5379 */       this.io.sendCommand(8, null, null, false, null, 0);
/*      */     } catch (Exception ex) {
/* 5381 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("Connection.UnhandledExceptionDuringShutdown"), "S1000", getExceptionInterceptor());
/*      */       
/*      */ 
/*      */ 
/* 5385 */       sqlEx.initCause(ex);
/*      */       
/* 5387 */       throw sqlEx;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsIsolationLevel()
/*      */   {
/* 5397 */     return this.hasIsolationLevels;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsQuotedIdentifiers()
/*      */   {
/* 5406 */     return this.hasQuotedIdentifiers;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsTransactions()
/*      */   {
/* 5415 */     return this.transactionsSupported;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void unregisterStatement(Statement stmt)
/*      */   {
/* 5425 */     if (this.openStatements != null) {
/* 5426 */       synchronized (this.openStatements) {
/* 5427 */         this.openStatements.remove(stmt);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void unsetMaxRows(Statement stmt)
/*      */     throws SQLException
/*      */   {
/* 5443 */     if (this.statementsUsingMaxRows != null) {
/* 5444 */       Object found = this.statementsUsingMaxRows.remove(stmt);
/*      */       
/* 5446 */       if ((found != null) && (this.statementsUsingMaxRows.size() == 0))
/*      */       {
/* 5448 */         execSQL(null, "SET OPTION SQL_SELECT_LIMIT=DEFAULT", -1, null, 1003, 1007, false, this.database, null, false);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 5453 */         this.maxRowsChanged = false;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public synchronized boolean useAnsiQuotedIdentifiers() {
/* 5459 */     return this.useAnsiQuotes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean useMaxRows()
/*      */   {
/* 5468 */     return this.maxRowsChanged;
/*      */   }
/*      */   
/*      */   public boolean versionMeetsMinimum(int major, int minor, int subminor) throws SQLException
/*      */   {
/* 5473 */     checkClosed();
/*      */     
/* 5475 */     return this.io.versionMeetsMinimum(major, minor, subminor);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void initializeResultsMetadataFromCache(String sql, CachedResultSetMetaData cachedMetaData, ResultSetInternalMethods resultSet)
/*      */     throws SQLException
/*      */   {
/* 5521 */     if (cachedMetaData == null)
/*      */     {
/*      */ 
/* 5524 */       cachedMetaData = new CachedResultSetMetaData();
/*      */       
/*      */ 
/*      */ 
/* 5528 */       resultSet.buildIndexMapping();
/* 5529 */       resultSet.initializeWithMetadata();
/*      */       
/* 5531 */       if ((resultSet instanceof UpdatableResultSet)) {
/* 5532 */         ((UpdatableResultSet)resultSet).checkUpdatability();
/*      */       }
/*      */       
/* 5535 */       resultSet.populateCachedMetaData(cachedMetaData);
/*      */       
/* 5537 */       this.resultSetMetadataCache.put(sql, cachedMetaData);
/*      */     } else {
/* 5539 */       resultSet.initializeFromCachedMetaData(cachedMetaData);
/* 5540 */       resultSet.initializeWithMetadata();
/*      */       
/* 5542 */       if ((resultSet instanceof UpdatableResultSet)) {
/* 5543 */         ((UpdatableResultSet)resultSet).checkUpdatability();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getStatementComment()
/*      */   {
/* 5556 */     return this.statementComment;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setStatementComment(String comment)
/*      */   {
/* 5568 */     this.statementComment = comment;
/*      */   }
/*      */   
/*      */   public synchronized void reportQueryTime(long millisOrNanos) {
/* 5572 */     this.queryTimeCount += 1L;
/* 5573 */     this.queryTimeSum += millisOrNanos;
/* 5574 */     this.queryTimeSumSquares += millisOrNanos * millisOrNanos;
/* 5575 */     this.queryTimeMean = ((this.queryTimeMean * (this.queryTimeCount - 1L) + millisOrNanos) / this.queryTimeCount);
/*      */   }
/*      */   
/*      */   public synchronized boolean isAbonormallyLongQuery(long millisOrNanos)
/*      */   {
/* 5580 */     if (this.queryTimeCount < 15L) {
/* 5581 */       return false;
/*      */     }
/*      */     
/* 5584 */     double stddev = Math.sqrt((this.queryTimeSumSquares - this.queryTimeSum * this.queryTimeSum / this.queryTimeCount) / (this.queryTimeCount - 1L));
/*      */     
/* 5586 */     return millisOrNanos > this.queryTimeMean + 5.0D * stddev;
/*      */   }
/*      */   
/*      */   public void initializeExtension(Extension ex) throws SQLException {
/* 5590 */     ex.init(this, this.props);
/*      */   }
/*      */   
/*      */   public synchronized void transactionBegun() throws SQLException {
/* 5594 */     if (this.connectionLifecycleInterceptors != null) {
/* 5595 */       IterateBlock iter = new IterateBlock(this.connectionLifecycleInterceptors.iterator())
/*      */       {
/*      */         void forEach(Object each) throws SQLException {
/* 5598 */           ((ConnectionLifecycleInterceptor)each).transactionBegun();
/*      */         }
/*      */         
/* 5601 */       };
/* 5602 */       iter.doForAll();
/*      */     }
/*      */   }
/*      */   
/*      */   public synchronized void transactionCompleted() throws SQLException {
/* 5607 */     if (this.connectionLifecycleInterceptors != null) {
/* 5608 */       IterateBlock iter = new IterateBlock(this.connectionLifecycleInterceptors.iterator())
/*      */       {
/*      */         void forEach(Object each) throws SQLException {
/* 5611 */           ((ConnectionLifecycleInterceptor)each).transactionCompleted();
/*      */         }
/*      */         
/* 5614 */       };
/* 5615 */       iter.doForAll();
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean storesLowerCaseTableName() {
/* 5620 */     return this.storesLowerCaseTableName;
/*      */   }
/*      */   
/*      */ 
/*      */   public ExceptionInterceptor getExceptionInterceptor()
/*      */   {
/* 5626 */     return this.exceptionInterceptor;
/*      */   }
/*      */   
/*      */   public boolean getRequiresEscapingEncoder() {
/* 5630 */     return this.requiresEscapingEncoder;
/*      */   }
/*      */   
/*      */   public synchronized boolean isServerLocal() throws SQLException {
/* 5634 */     SocketFactory factory = getIO().socketFactory;
/*      */     
/* 5636 */     if ((factory instanceof SocketMetadata)) {
/* 5637 */       return ((SocketMetadata)factory).isLocallyConnected(this);
/*      */     }
/* 5639 */     getLog().logWarn(Messages.getString("Connection.NoMetadataOnSocketFactory"));
/* 5640 */     return false;
/*      */   }
/*      */   
/*      */   protected ConnectionImpl() {}
/*      */   
/*      */   public void clearWarnings()
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */   /* Error */
/*      */   public int getActiveStatementCount()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 135	com/mysql/jdbc/ConnectionImpl:openStatements	Ljava/util/Map;
/*      */     //   4: ifnull +27 -> 31
/*      */     //   7: aload_0
/*      */     //   8: getfield 135	com/mysql/jdbc/ConnectionImpl:openStatements	Ljava/util/Map;
/*      */     //   11: dup
/*      */     //   12: astore_1
/*      */     //   13: monitorenter
/*      */     //   14: aload_0
/*      */     //   15: getfield 135	com/mysql/jdbc/ConnectionImpl:openStatements	Ljava/util/Map;
/*      */     //   18: invokeinterface 339 1 0
/*      */     //   23: aload_1
/*      */     //   24: monitorexit
/*      */     //   25: ireturn
/*      */     //   26: astore_2
/*      */     //   27: aload_1
/*      */     //   28: monitorexit
/*      */     //   29: aload_2
/*      */     //   30: athrow
/*      */     //   31: iconst_0
/*      */     //   32: ireturn
/*      */     // Line number table:
/*      */     //   Java source line #2799	-> byte code offset #0
/*      */     //   Java source line #2800	-> byte code offset #7
/*      */     //   Java source line #2801	-> byte code offset #14
/*      */     //   Java source line #2802	-> byte code offset #26
/*      */     //   Java source line #2805	-> byte code offset #31
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	33	0	this	ConnectionImpl
/*      */     //   12	16	1	Ljava/lang/Object;	Object
/*      */     //   26	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   14	25	26	finally
/*      */     //   26	29	26	finally
/*      */   }
/*      */   
/*      */   public void releaseSavepoint(Savepoint arg0)
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */   public synchronized void setFailedOver(boolean flag) {}
/*      */   
/*      */   public void setHoldability(int arg0)
/*      */     throws SQLException
/*      */   {}
/*      */   
/*      */   public void setPreferSlaveDuringFailover(boolean flag) {}
/*      */   
/*      */   /* Error */
/*      */   public CachedResultSetMetaData getCachedMetaData(String sql)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 590	com/mysql/jdbc/ConnectionImpl:resultSetMetadataCache	Lcom/mysql/jdbc/util/LRUCache;
/*      */     //   4: ifnull +29 -> 33
/*      */     //   7: aload_0
/*      */     //   8: getfield 590	com/mysql/jdbc/ConnectionImpl:resultSetMetadataCache	Lcom/mysql/jdbc/util/LRUCache;
/*      */     //   11: dup
/*      */     //   12: astore_2
/*      */     //   13: monitorenter
/*      */     //   14: aload_0
/*      */     //   15: getfield 590	com/mysql/jdbc/ConnectionImpl:resultSetMetadataCache	Lcom/mysql/jdbc/util/LRUCache;
/*      */     //   18: aload_1
/*      */     //   19: invokevirtual 256	com/mysql/jdbc/util/LRUCache:get	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   22: checkcast 822	com/mysql/jdbc/CachedResultSetMetaData
/*      */     //   25: aload_2
/*      */     //   26: monitorexit
/*      */     //   27: areturn
/*      */     //   28: astore_3
/*      */     //   29: aload_2
/*      */     //   30: monitorexit
/*      */     //   31: aload_3
/*      */     //   32: athrow
/*      */     //   33: aconst_null
/*      */     //   34: areturn
/*      */     // Line number table:
/*      */     //   Java source line #5493	-> byte code offset #0
/*      */     //   Java source line #5494	-> byte code offset #7
/*      */     //   Java source line #5495	-> byte code offset #14
/*      */     //   Java source line #5497	-> byte code offset #28
/*      */     //   Java source line #5500	-> byte code offset #33
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	35	0	this	ConnectionImpl
/*      */     //   0	35	1	sql	String
/*      */     //   12	18	2	Ljava/lang/Object;	Object
/*      */     //   28	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   14	27	28	finally
/*      */     //   28	31	28	finally
/*      */   }
/*      */ }


/* Location:              C:\Users\Static\Desktop\G10_Prototype_Client.jar!\mysql-connector-java-5.1.19-bin.jar!\com\mysql\jdbc\ConnectionImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */