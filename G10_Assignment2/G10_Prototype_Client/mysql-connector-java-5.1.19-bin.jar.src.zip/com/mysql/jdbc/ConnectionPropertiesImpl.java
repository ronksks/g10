/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.log.Log;
/*      */ import com.mysql.jdbc.log.StandardLogger;
/*      */ import java.io.Serializable;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.Field;
/*      */ import java.sql.DriverPropertyInfo;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.TreeMap;
/*      */ import javax.naming.RefAddr;
/*      */ import javax.naming.Reference;
/*      */ import javax.naming.StringRefAddr;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ConnectionPropertiesImpl
/*      */   implements Serializable, ConnectionProperties
/*      */ {
/*      */   private static final long serialVersionUID = 4257801713007640580L;
/*      */   
/*      */   class BooleanConnectionProperty
/*      */     extends ConnectionPropertiesImpl.ConnectionProperty
/*      */     implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 2540132501709159404L;
/*      */     
/*      */     BooleanConnectionProperty(String propertyNameToSet, boolean defaultValueToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory)
/*      */     {
/*   72 */       super(propertyNameToSet, Boolean.valueOf(defaultValueToSet), null, 0, 0, descriptionToSet, sinceVersionToSet, category, orderInCategory);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     String[] getAllowableValues()
/*      */     {
/*   81 */       return new String[] { "true", "false", "yes", "no" };
/*      */     }
/*      */     
/*      */     boolean getValueAsBoolean() {
/*   85 */       return ((Boolean)this.valueAsObject).booleanValue();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     boolean hasValueConstraints()
/*      */     {
/*   92 */       return true;
/*      */     }
/*      */     
/*      */ 
/*      */     void initializeFrom(String extractedValue)
/*      */       throws SQLException
/*      */     {
/*   99 */       if (extractedValue != null) {
/*  100 */         validateStringValues(extractedValue);
/*      */         
/*  102 */         this.valueAsObject = Boolean.valueOf((extractedValue.equalsIgnoreCase("TRUE")) || (extractedValue.equalsIgnoreCase("YES")));
/*      */       }
/*      */       else
/*      */       {
/*  106 */         this.valueAsObject = this.defaultValue;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     boolean isRangeBased()
/*      */     {
/*  114 */       return false;
/*      */     }
/*      */     
/*      */     void setValue(boolean valueFlag) {
/*  118 */       this.valueAsObject = Boolean.valueOf(valueFlag);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   abstract class ConnectionProperty
/*      */     implements Serializable
/*      */   {
/*      */     String[] allowableValues;
/*      */     
/*      */     String categoryName;
/*      */     
/*      */     Object defaultValue;
/*      */     
/*      */     int lowerBound;
/*      */     
/*      */     int order;
/*      */     
/*      */     String propertyName;
/*      */     
/*      */     String sinceVersion;
/*      */     
/*      */     int upperBound;
/*      */     
/*      */     Object valueAsObject;
/*      */     
/*      */     boolean required;
/*      */     
/*      */     String description;
/*      */     
/*      */     public ConnectionProperty() {}
/*      */     
/*      */     ConnectionProperty(String propertyNameToSet, Object defaultValueToSet, String[] allowableValuesToSet, int lowerBoundToSet, int upperBoundToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory)
/*      */     {
/*  152 */       this.description = descriptionToSet;
/*  153 */       this.propertyName = propertyNameToSet;
/*  154 */       this.defaultValue = defaultValueToSet;
/*  155 */       this.valueAsObject = defaultValueToSet;
/*  156 */       this.allowableValues = allowableValuesToSet;
/*  157 */       this.lowerBound = lowerBoundToSet;
/*  158 */       this.upperBound = upperBoundToSet;
/*  159 */       this.required = false;
/*  160 */       this.sinceVersion = sinceVersionToSet;
/*  161 */       this.categoryName = category;
/*  162 */       this.order = orderInCategory;
/*      */     }
/*      */     
/*      */     String[] getAllowableValues() {
/*  166 */       return this.allowableValues;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     String getCategoryName()
/*      */     {
/*  173 */       return this.categoryName;
/*      */     }
/*      */     
/*      */     Object getDefaultValue() {
/*  177 */       return this.defaultValue;
/*      */     }
/*      */     
/*      */     int getLowerBound() {
/*  181 */       return this.lowerBound;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     int getOrder()
/*      */     {
/*  188 */       return this.order;
/*      */     }
/*      */     
/*      */     String getPropertyName() {
/*  192 */       return this.propertyName;
/*      */     }
/*      */     
/*      */     int getUpperBound() {
/*  196 */       return this.upperBound;
/*      */     }
/*      */     
/*      */     Object getValueAsObject() {
/*  200 */       return this.valueAsObject;
/*      */     }
/*      */     
/*      */     abstract boolean hasValueConstraints();
/*      */     
/*      */     void initializeFrom(Properties extractFrom) throws SQLException {
/*  206 */       String extractedValue = extractFrom.getProperty(getPropertyName());
/*  207 */       extractFrom.remove(getPropertyName());
/*  208 */       initializeFrom(extractedValue);
/*      */     }
/*      */     
/*      */     void initializeFrom(Reference ref) throws SQLException {
/*  212 */       RefAddr refAddr = ref.get(getPropertyName());
/*      */       
/*  214 */       if (refAddr != null) {
/*  215 */         String refContentAsString = (String)refAddr.getContent();
/*      */         
/*  217 */         initializeFrom(refContentAsString);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     abstract void initializeFrom(String paramString)
/*      */       throws SQLException;
/*      */     
/*      */ 
/*      */     abstract boolean isRangeBased();
/*      */     
/*      */     void setCategoryName(String categoryName)
/*      */     {
/*  230 */       this.categoryName = categoryName;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     void setOrder(int order)
/*      */     {
/*  238 */       this.order = order;
/*      */     }
/*      */     
/*      */     void setValueAsObject(Object obj) {
/*  242 */       this.valueAsObject = obj;
/*      */     }
/*      */     
/*      */     void storeTo(Reference ref) {
/*  246 */       if (getValueAsObject() != null) {
/*  247 */         ref.add(new StringRefAddr(getPropertyName(), getValueAsObject().toString()));
/*      */       }
/*      */     }
/*      */     
/*      */     DriverPropertyInfo getAsDriverPropertyInfo()
/*      */     {
/*  253 */       DriverPropertyInfo dpi = new DriverPropertyInfo(this.propertyName, null);
/*  254 */       dpi.choices = getAllowableValues();
/*  255 */       dpi.value = (this.valueAsObject != null ? this.valueAsObject.toString() : null);
/*  256 */       dpi.required = this.required;
/*  257 */       dpi.description = this.description;
/*      */       
/*  259 */       return dpi;
/*      */     }
/*      */     
/*      */     void validateStringValues(String valueToValidate) throws SQLException
/*      */     {
/*  264 */       String[] validateAgainst = getAllowableValues();
/*      */       
/*  266 */       if (valueToValidate == null) {
/*  267 */         return;
/*      */       }
/*      */       
/*  270 */       if ((validateAgainst == null) || (validateAgainst.length == 0)) {
/*  271 */         return;
/*      */       }
/*      */       
/*  274 */       for (int i = 0; i < validateAgainst.length; i++) {
/*  275 */         if ((validateAgainst[i] != null) && (validateAgainst[i].equalsIgnoreCase(valueToValidate)))
/*      */         {
/*  277 */           return;
/*      */         }
/*      */       }
/*      */       
/*  281 */       StringBuffer errorMessageBuf = new StringBuffer();
/*      */       
/*  283 */       errorMessageBuf.append("The connection property '");
/*  284 */       errorMessageBuf.append(getPropertyName());
/*  285 */       errorMessageBuf.append("' only accepts values of the form: ");
/*      */       
/*  287 */       if (validateAgainst.length != 0) {
/*  288 */         errorMessageBuf.append("'");
/*  289 */         errorMessageBuf.append(validateAgainst[0]);
/*  290 */         errorMessageBuf.append("'");
/*      */         
/*  292 */         for (int i = 1; i < validateAgainst.length - 1; i++) {
/*  293 */           errorMessageBuf.append(", ");
/*  294 */           errorMessageBuf.append("'");
/*  295 */           errorMessageBuf.append(validateAgainst[i]);
/*  296 */           errorMessageBuf.append("'");
/*      */         }
/*      */         
/*  299 */         errorMessageBuf.append(" or '");
/*  300 */         errorMessageBuf.append(validateAgainst[(validateAgainst.length - 1)]);
/*      */         
/*  302 */         errorMessageBuf.append("'");
/*      */       }
/*      */       
/*  305 */       errorMessageBuf.append(". The value '");
/*  306 */       errorMessageBuf.append(valueToValidate);
/*  307 */       errorMessageBuf.append("' is not in this set.");
/*      */       
/*  309 */       throw SQLError.createSQLException(errorMessageBuf.toString(), "S1009", ConnectionPropertiesImpl.this.getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   class IntegerConnectionProperty
/*      */     extends ConnectionPropertiesImpl.ConnectionProperty
/*      */     implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = -3004305481796850832L;
/*      */     
/*      */ 
/*      */     public IntegerConnectionProperty(String propertyNameToSet, Object defaultValueToSet, String[] allowableValuesToSet, int lowerBoundToSet, int upperBoundToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory)
/*      */     {
/*  323 */       super(propertyNameToSet, defaultValueToSet, allowableValuesToSet, lowerBoundToSet, upperBoundToSet, descriptionToSet, sinceVersionToSet, category, orderInCategory);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  328 */     int multiplier = 1;
/*      */     
/*      */ 
/*      */ 
/*      */     IntegerConnectionProperty(String propertyNameToSet, int defaultValueToSet, int lowerBoundToSet, int upperBoundToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory)
/*      */     {
/*  334 */       super(propertyNameToSet, Integer.valueOf(defaultValueToSet), null, lowerBoundToSet, upperBoundToSet, descriptionToSet, sinceVersionToSet, category, orderInCategory);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     IntegerConnectionProperty(String propertyNameToSet, int defaultValueToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory)
/*      */     {
/*  352 */       this(propertyNameToSet, defaultValueToSet, 0, 0, descriptionToSet, sinceVersionToSet, category, orderInCategory);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     String[] getAllowableValues()
/*      */     {
/*  360 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     int getLowerBound()
/*      */     {
/*  367 */       return this.lowerBound;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     int getUpperBound()
/*      */     {
/*  374 */       return this.upperBound;
/*      */     }
/*      */     
/*      */     int getValueAsInt() {
/*  378 */       return ((Integer)this.valueAsObject).intValue();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     boolean hasValueConstraints()
/*      */     {
/*  385 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */     void initializeFrom(String extractedValue)
/*      */       throws SQLException
/*      */     {
/*  392 */       if (extractedValue != null) {
/*      */         try
/*      */         {
/*  395 */           int intValue = Double.valueOf(extractedValue).intValue();
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  406 */           this.valueAsObject = Integer.valueOf(intValue * this.multiplier);
/*      */         } catch (NumberFormatException nfe) {
/*  408 */           throw SQLError.createSQLException("The connection property '" + getPropertyName() + "' only accepts integer values. The value '" + extractedValue + "' can not be converted to an integer.", "S1009", ConnectionPropertiesImpl.this.getExceptionInterceptor());
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  416 */         this.valueAsObject = this.defaultValue;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     boolean isRangeBased()
/*      */     {
/*  424 */       return getUpperBound() != getLowerBound();
/*      */     }
/*      */     
/*      */     void setValue(int valueFlag) {
/*  428 */       this.valueAsObject = Integer.valueOf(valueFlag);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public class LongConnectionProperty
/*      */     extends ConnectionPropertiesImpl.IntegerConnectionProperty
/*      */   {
/*      */     private static final long serialVersionUID = 6068572984340480895L;
/*      */     
/*      */     LongConnectionProperty(String propertyNameToSet, long defaultValueToSet, long lowerBoundToSet, long upperBoundToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory)
/*      */     {
/*  440 */       super(propertyNameToSet, Long.valueOf(defaultValueToSet), null, (int)lowerBoundToSet, (int)upperBoundToSet, descriptionToSet, sinceVersionToSet, category, orderInCategory);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     LongConnectionProperty(String propertyNameToSet, long defaultValueToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory)
/*      */     {
/*  449 */       this(propertyNameToSet, defaultValueToSet, 0L, 0L, descriptionToSet, sinceVersionToSet, category, orderInCategory);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     void setValue(long value)
/*      */     {
/*  456 */       this.valueAsObject = Long.valueOf(value);
/*      */     }
/*      */     
/*      */     long getValueAsLong() {
/*  460 */       return ((Long)this.valueAsObject).longValue();
/*      */     }
/*      */     
/*      */     void initializeFrom(String extractedValue) throws SQLException {
/*  464 */       if (extractedValue != null) {
/*      */         try
/*      */         {
/*  467 */           long longValue = Double.valueOf(extractedValue).longValue();
/*      */           
/*  469 */           this.valueAsObject = Long.valueOf(longValue);
/*      */         } catch (NumberFormatException nfe) {
/*  471 */           throw SQLError.createSQLException("The connection property '" + getPropertyName() + "' only accepts long integer values. The value '" + extractedValue + "' can not be converted to a long integer.", "S1009", ConnectionPropertiesImpl.this.getExceptionInterceptor());
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  479 */         this.valueAsObject = this.defaultValue;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   class MemorySizeConnectionProperty
/*      */     extends ConnectionPropertiesImpl.IntegerConnectionProperty
/*      */     implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 7351065128998572656L;
/*      */     private String valueAsString;
/*      */     
/*      */     MemorySizeConnectionProperty(String propertyNameToSet, int defaultValueToSet, int lowerBoundToSet, int upperBoundToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory)
/*      */     {
/*  494 */       super(propertyNameToSet, defaultValueToSet, lowerBoundToSet, upperBoundToSet, descriptionToSet, sinceVersionToSet, category, orderInCategory);
/*      */     }
/*      */     
/*      */     void initializeFrom(String extractedValue)
/*      */       throws SQLException
/*      */     {
/*  500 */       this.valueAsString = extractedValue;
/*      */       
/*  502 */       if (extractedValue != null) {
/*  503 */         if ((extractedValue.endsWith("k")) || (extractedValue.endsWith("K")) || (extractedValue.endsWith("kb")) || (extractedValue.endsWith("Kb")) || (extractedValue.endsWith("kB")))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*  508 */           this.multiplier = 1024;
/*  509 */           int indexOfK = StringUtils.indexOfIgnoreCase(extractedValue, "k");
/*      */           
/*  511 */           extractedValue = extractedValue.substring(0, indexOfK);
/*  512 */         } else if ((extractedValue.endsWith("m")) || (extractedValue.endsWith("M")) || (extractedValue.endsWith("G")) || (extractedValue.endsWith("mb")) || (extractedValue.endsWith("Mb")) || (extractedValue.endsWith("mB")))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  518 */           this.multiplier = 1048576;
/*  519 */           int indexOfM = StringUtils.indexOfIgnoreCase(extractedValue, "m");
/*      */           
/*  521 */           extractedValue = extractedValue.substring(0, indexOfM);
/*  522 */         } else if ((extractedValue.endsWith("g")) || (extractedValue.endsWith("G")) || (extractedValue.endsWith("gb")) || (extractedValue.endsWith("Gb")) || (extractedValue.endsWith("gB")))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*  527 */           this.multiplier = 1073741824;
/*  528 */           int indexOfG = StringUtils.indexOfIgnoreCase(extractedValue, "g");
/*      */           
/*  530 */           extractedValue = extractedValue.substring(0, indexOfG);
/*      */         }
/*      */       }
/*      */       
/*  534 */       super.initializeFrom(extractedValue);
/*      */     }
/*      */     
/*      */     void setValue(String value) throws SQLException {
/*  538 */       initializeFrom(value);
/*      */     }
/*      */     
/*      */     String getValueAsString() {
/*  542 */       return this.valueAsString;
/*      */     }
/*      */   }
/*      */   
/*      */   class StringConnectionProperty
/*      */     extends ConnectionPropertiesImpl.ConnectionProperty implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 5432127962785948272L;
/*      */     
/*      */     StringConnectionProperty(String propertyNameToSet, String defaultValueToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory)
/*      */     {
/*  553 */       this(propertyNameToSet, defaultValueToSet, null, descriptionToSet, sinceVersionToSet, category, orderInCategory);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     StringConnectionProperty(String propertyNameToSet, String defaultValueToSet, String[] allowableValuesToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory)
/*      */     {
/*  571 */       super(propertyNameToSet, defaultValueToSet, allowableValuesToSet, 0, 0, descriptionToSet, sinceVersionToSet, category, orderInCategory);
/*      */     }
/*      */     
/*      */ 
/*      */     String getValueAsString()
/*      */     {
/*  577 */       return (String)this.valueAsObject;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     boolean hasValueConstraints()
/*      */     {
/*  584 */       return (this.allowableValues != null) && (this.allowableValues.length > 0);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     void initializeFrom(String extractedValue)
/*      */       throws SQLException
/*      */     {
/*  592 */       if (extractedValue != null) {
/*  593 */         validateStringValues(extractedValue);
/*      */         
/*  595 */         this.valueAsObject = extractedValue;
/*      */       } else {
/*  597 */         this.valueAsObject = this.defaultValue;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     boolean isRangeBased()
/*      */     {
/*  605 */       return false;
/*      */     }
/*      */     
/*      */     void setValue(String valueFlag) {
/*  609 */       this.valueAsObject = valueFlag;
/*      */     }
/*      */   }
/*      */   
/*  613 */   private static final String CONNECTION_AND_AUTH_CATEGORY = Messages.getString("ConnectionProperties.categoryConnectionAuthentication");
/*      */   
/*  615 */   private static final String NETWORK_CATEGORY = Messages.getString("ConnectionProperties.categoryNetworking");
/*      */   
/*  617 */   private static final String DEBUGING_PROFILING_CATEGORY = Messages.getString("ConnectionProperties.categoryDebuggingProfiling");
/*      */   
/*  619 */   private static final String HA_CATEGORY = Messages.getString("ConnectionProperties.categorryHA");
/*      */   
/*  621 */   private static final String MISC_CATEGORY = Messages.getString("ConnectionProperties.categoryMisc");
/*      */   
/*  623 */   private static final String PERFORMANCE_CATEGORY = Messages.getString("ConnectionProperties.categoryPerformance");
/*      */   
/*  625 */   private static final String SECURITY_CATEGORY = Messages.getString("ConnectionProperties.categorySecurity");
/*      */   
/*  627 */   private static final String[] PROPERTY_CATEGORIES = { CONNECTION_AND_AUTH_CATEGORY, NETWORK_CATEGORY, HA_CATEGORY, SECURITY_CATEGORY, PERFORMANCE_CATEGORY, DEBUGING_PROFILING_CATEGORY, MISC_CATEGORY };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  632 */   private static final ArrayList PROPERTY_LIST = new ArrayList();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  637 */   private static final String STANDARD_LOGGER_NAME = StandardLogger.class.getName();
/*      */   
/*      */   protected static final String ZERO_DATETIME_BEHAVIOR_CONVERT_TO_NULL = "convertToNull";
/*      */   protected static final String ZERO_DATETIME_BEHAVIOR_EXCEPTION = "exception";
/*      */   protected static final String ZERO_DATETIME_BEHAVIOR_ROUND = "round";
/*      */   
/*      */   static
/*      */   {
/*      */     try
/*      */     {
/*  647 */       Field[] declaredFields = ConnectionPropertiesImpl.class.getDeclaredFields();
/*      */       
/*      */ 
/*  650 */       for (int i = 0; i < declaredFields.length; i++) {
/*  651 */         if (ConnectionProperty.class.isAssignableFrom(declaredFields[i].getType()))
/*      */         {
/*  653 */           PROPERTY_LIST.add(declaredFields[i]);
/*      */         }
/*      */       }
/*      */     } catch (Exception ex) {
/*  657 */       RuntimeException rtEx = new RuntimeException();
/*  658 */       rtEx.initCause(ex);
/*      */       
/*  660 */       throw rtEx;
/*      */     }
/*      */   }
/*      */   
/*      */   public ExceptionInterceptor getExceptionInterceptor() {
/*  665 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static DriverPropertyInfo[] exposeAsDriverPropertyInfo(Properties info, int slotsToReserve)
/*      */     throws SQLException
/*      */   {
/*  684 */     new ConnectionPropertiesImpl() {}.exposeAsDriverPropertyInfoInternal(info, slotsToReserve);
/*      */   }
/*      */   
/*      */ 
/*  688 */   private BooleanConnectionProperty allowLoadLocalInfile = new BooleanConnectionProperty("allowLoadLocalInfile", true, Messages.getString("ConnectionProperties.loadDataLocal"), "3.0.3", SECURITY_CATEGORY, Integer.MAX_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  694 */   private BooleanConnectionProperty allowMultiQueries = new BooleanConnectionProperty("allowMultiQueries", false, Messages.getString("ConnectionProperties.allowMultiQueries"), "3.1.1", SECURITY_CATEGORY, 1);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  700 */   private BooleanConnectionProperty allowNanAndInf = new BooleanConnectionProperty("allowNanAndInf", false, Messages.getString("ConnectionProperties.allowNANandINF"), "3.1.5", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  706 */   private BooleanConnectionProperty allowUrlInLocalInfile = new BooleanConnectionProperty("allowUrlInLocalInfile", false, Messages.getString("ConnectionProperties.allowUrlInLoadLocal"), "3.1.4", SECURITY_CATEGORY, Integer.MAX_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  712 */   private BooleanConnectionProperty alwaysSendSetIsolation = new BooleanConnectionProperty("alwaysSendSetIsolation", true, Messages.getString("ConnectionProperties.alwaysSendSetIsolation"), "3.1.7", PERFORMANCE_CATEGORY, Integer.MAX_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  718 */   private BooleanConnectionProperty autoClosePStmtStreams = new BooleanConnectionProperty("autoClosePStmtStreams", false, Messages.getString("ConnectionProperties.autoClosePstmtStreams"), "3.1.12", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  726 */   private BooleanConnectionProperty autoDeserialize = new BooleanConnectionProperty("autoDeserialize", false, Messages.getString("ConnectionProperties.autoDeserialize"), "3.1.5", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  732 */   private BooleanConnectionProperty autoGenerateTestcaseScript = new BooleanConnectionProperty("autoGenerateTestcaseScript", false, Messages.getString("ConnectionProperties.autoGenerateTestcaseScript"), "3.1.9", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  737 */   private boolean autoGenerateTestcaseScriptAsBoolean = false;
/*      */   
/*  739 */   private BooleanConnectionProperty autoReconnect = new BooleanConnectionProperty("autoReconnect", false, Messages.getString("ConnectionProperties.autoReconnect"), "1.1", HA_CATEGORY, 0);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  745 */   private BooleanConnectionProperty autoReconnectForPools = new BooleanConnectionProperty("autoReconnectForPools", false, Messages.getString("ConnectionProperties.autoReconnectForPools"), "3.1.3", HA_CATEGORY, 1);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  751 */   private boolean autoReconnectForPoolsAsBoolean = false;
/*      */   
/*  753 */   private MemorySizeConnectionProperty blobSendChunkSize = new MemorySizeConnectionProperty("blobSendChunkSize", 1048576, 1, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.blobSendChunkSize"), "3.1.9", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  761 */   private BooleanConnectionProperty autoSlowLog = new BooleanConnectionProperty("autoSlowLog", true, Messages.getString("ConnectionProperties.autoSlowLog"), "5.1.4", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  766 */   private BooleanConnectionProperty blobsAreStrings = new BooleanConnectionProperty("blobsAreStrings", false, "Should the driver always treat BLOBs as Strings - specifically to work around dubious metadata returned by the server for GROUP BY clauses?", "5.0.8", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  772 */   private BooleanConnectionProperty functionsNeverReturnBlobs = new BooleanConnectionProperty("functionsNeverReturnBlobs", false, "Should the driver always treat data from functions returning BLOBs as Strings - specifically to work around dubious metadata returned by the server for GROUP BY clauses?", "5.0.8", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  778 */   private BooleanConnectionProperty cacheCallableStatements = new BooleanConnectionProperty("cacheCallableStmts", false, Messages.getString("ConnectionProperties.cacheCallableStatements"), "3.1.2", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  783 */   private BooleanConnectionProperty cachePreparedStatements = new BooleanConnectionProperty("cachePrepStmts", false, Messages.getString("ConnectionProperties.cachePrepStmts"), "3.0.10", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  789 */   private BooleanConnectionProperty cacheResultSetMetadata = new BooleanConnectionProperty("cacheResultSetMetadata", false, Messages.getString("ConnectionProperties.cacheRSMetadata"), "3.1.1", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean cacheResultSetMetaDataAsBoolean;
/*      */   
/*      */ 
/*      */ 
/*  797 */   private BooleanConnectionProperty cacheServerConfiguration = new BooleanConnectionProperty("cacheServerConfiguration", false, Messages.getString("ConnectionProperties.cacheServerConfiguration"), "3.1.5", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  803 */   private IntegerConnectionProperty callableStatementCacheSize = new IntegerConnectionProperty("callableStmtCacheSize", 100, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.callableStmtCacheSize"), "3.1.2", PERFORMANCE_CATEGORY, 5);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  811 */   private BooleanConnectionProperty capitalizeTypeNames = new BooleanConnectionProperty("capitalizeTypeNames", true, Messages.getString("ConnectionProperties.capitalizeTypeNames"), "2.0.7", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  817 */   private StringConnectionProperty characterEncoding = new StringConnectionProperty("characterEncoding", null, Messages.getString("ConnectionProperties.characterEncoding"), "1.1g", MISC_CATEGORY, 5);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  823 */   private String characterEncodingAsString = null;
/*      */   
/*  825 */   private StringConnectionProperty characterSetResults = new StringConnectionProperty("characterSetResults", null, Messages.getString("ConnectionProperties.characterSetResults"), "3.0.13", MISC_CATEGORY, 6);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  830 */   private StringConnectionProperty clientInfoProvider = new StringConnectionProperty("clientInfoProvider", "com.mysql.jdbc.JDBC4CommentClientInfoProvider", Messages.getString("ConnectionProperties.clientInfoProvider"), "5.1.0", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  836 */   private BooleanConnectionProperty clobberStreamingResults = new BooleanConnectionProperty("clobberStreamingResults", false, Messages.getString("ConnectionProperties.clobberStreamingResults"), "3.0.9", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  842 */   private StringConnectionProperty clobCharacterEncoding = new StringConnectionProperty("clobCharacterEncoding", null, Messages.getString("ConnectionProperties.clobCharacterEncoding"), "5.0.0", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  848 */   private BooleanConnectionProperty compensateOnDuplicateKeyUpdateCounts = new BooleanConnectionProperty("compensateOnDuplicateKeyUpdateCounts", false, Messages.getString("ConnectionProperties.compensateOnDuplicateKeyUpdateCounts"), "5.1.7", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  853 */   private StringConnectionProperty connectionCollation = new StringConnectionProperty("connectionCollation", null, Messages.getString("ConnectionProperties.connectionCollation"), "3.0.13", MISC_CATEGORY, 7);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  859 */   private StringConnectionProperty connectionLifecycleInterceptors = new StringConnectionProperty("connectionLifecycleInterceptors", null, Messages.getString("ConnectionProperties.connectionLifecycleInterceptors"), "5.1.4", CONNECTION_AND_AUTH_CATEGORY, Integer.MAX_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  865 */   private IntegerConnectionProperty connectTimeout = new IntegerConnectionProperty("connectTimeout", 0, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.connectTimeout"), "3.0.1", CONNECTION_AND_AUTH_CATEGORY, 9);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  870 */   private BooleanConnectionProperty continueBatchOnError = new BooleanConnectionProperty("continueBatchOnError", true, Messages.getString("ConnectionProperties.continueBatchOnError"), "3.0.3", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  876 */   private BooleanConnectionProperty createDatabaseIfNotExist = new BooleanConnectionProperty("createDatabaseIfNotExist", false, Messages.getString("ConnectionProperties.createDatabaseIfNotExist"), "3.1.9", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  882 */   private IntegerConnectionProperty defaultFetchSize = new IntegerConnectionProperty("defaultFetchSize", 0, Messages.getString("ConnectionProperties.defaultFetchSize"), "3.1.9", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*  884 */   private BooleanConnectionProperty detectServerPreparedStmts = new BooleanConnectionProperty("useServerPrepStmts", false, Messages.getString("ConnectionProperties.useServerPrepStmts"), "3.1.0", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  890 */   private BooleanConnectionProperty dontTrackOpenResources = new BooleanConnectionProperty("dontTrackOpenResources", false, Messages.getString("ConnectionProperties.dontTrackOpenResources"), "3.1.7", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  896 */   private BooleanConnectionProperty dumpQueriesOnException = new BooleanConnectionProperty("dumpQueriesOnException", false, Messages.getString("ConnectionProperties.dumpQueriesOnException"), "3.1.3", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  902 */   private BooleanConnectionProperty dynamicCalendars = new BooleanConnectionProperty("dynamicCalendars", false, Messages.getString("ConnectionProperties.dynamicCalendars"), "3.1.5", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  908 */   private BooleanConnectionProperty elideSetAutoCommits = new BooleanConnectionProperty("elideSetAutoCommits", false, Messages.getString("ConnectionProperties.eliseSetAutoCommit"), "3.1.3", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  914 */   private BooleanConnectionProperty emptyStringsConvertToZero = new BooleanConnectionProperty("emptyStringsConvertToZero", true, Messages.getString("ConnectionProperties.emptyStringsConvertToZero"), "3.1.8", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  919 */   private BooleanConnectionProperty emulateLocators = new BooleanConnectionProperty("emulateLocators", false, Messages.getString("ConnectionProperties.emulateLocators"), "3.1.0", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*  923 */   private BooleanConnectionProperty emulateUnsupportedPstmts = new BooleanConnectionProperty("emulateUnsupportedPstmts", true, Messages.getString("ConnectionProperties.emulateUnsupportedPstmts"), "3.1.7", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  929 */   private BooleanConnectionProperty enablePacketDebug = new BooleanConnectionProperty("enablePacketDebug", false, Messages.getString("ConnectionProperties.enablePacketDebug"), "3.1.3", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  935 */   private BooleanConnectionProperty enableQueryTimeouts = new BooleanConnectionProperty("enableQueryTimeouts", true, Messages.getString("ConnectionProperties.enableQueryTimeouts"), "5.0.6", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  942 */   private BooleanConnectionProperty explainSlowQueries = new BooleanConnectionProperty("explainSlowQueries", false, Messages.getString("ConnectionProperties.explainSlowQueries"), "3.1.2", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  948 */   private StringConnectionProperty exceptionInterceptors = new StringConnectionProperty("exceptionInterceptors", null, Messages.getString("ConnectionProperties.exceptionInterceptors"), "5.1.8", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  955 */   private BooleanConnectionProperty failOverReadOnly = new BooleanConnectionProperty("failOverReadOnly", true, Messages.getString("ConnectionProperties.failoverReadOnly"), "3.0.12", HA_CATEGORY, 2);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  961 */   private BooleanConnectionProperty gatherPerformanceMetrics = new BooleanConnectionProperty("gatherPerfMetrics", false, Messages.getString("ConnectionProperties.gatherPerfMetrics"), "3.1.2", DEBUGING_PROFILING_CATEGORY, 1);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  967 */   private BooleanConnectionProperty generateSimpleParameterMetadata = new BooleanConnectionProperty("generateSimpleParameterMetadata", false, Messages.getString("ConnectionProperties.generateSimpleParameterMetadata"), "5.0.5", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*  970 */   private boolean highAvailabilityAsBoolean = false;
/*      */   
/*  972 */   private BooleanConnectionProperty holdResultsOpenOverStatementClose = new BooleanConnectionProperty("holdResultsOpenOverStatementClose", false, Messages.getString("ConnectionProperties.holdRSOpenOverStmtClose"), "3.1.7", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  978 */   private BooleanConnectionProperty includeInnodbStatusInDeadlockExceptions = new BooleanConnectionProperty("includeInnodbStatusInDeadlockExceptions", false, Messages.getString("ConnectionProperties.includeInnodbStatusInDeadlockExceptions"), "5.0.7", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  984 */   private BooleanConnectionProperty includeThreadDumpInDeadlockExceptions = new BooleanConnectionProperty("includeThreadDumpInDeadlockExceptions", false, Messages.getString("ConnectionProperties.includeThreadDumpInDeadlockExceptions"), "5.1.15", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  990 */   private BooleanConnectionProperty includeThreadNamesAsStatementComment = new BooleanConnectionProperty("includeThreadNamesAsStatementComment", false, Messages.getString("ConnectionProperties.includeThreadNamesAsStatementComment"), "5.1.15", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  996 */   private BooleanConnectionProperty ignoreNonTxTables = new BooleanConnectionProperty("ignoreNonTxTables", false, Messages.getString("ConnectionProperties.ignoreNonTxTables"), "3.0.9", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1002 */   private IntegerConnectionProperty initialTimeout = new IntegerConnectionProperty("initialTimeout", 2, 1, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.initialTimeout"), "1.1", HA_CATEGORY, 5);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1007 */   private BooleanConnectionProperty isInteractiveClient = new BooleanConnectionProperty("interactiveClient", false, Messages.getString("ConnectionProperties.interactiveClient"), "3.1.0", CONNECTION_AND_AUTH_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1013 */   private BooleanConnectionProperty jdbcCompliantTruncation = new BooleanConnectionProperty("jdbcCompliantTruncation", true, Messages.getString("ConnectionProperties.jdbcCompliantTruncation"), "3.1.2", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1019 */   private boolean jdbcCompliantTruncationForReads = this.jdbcCompliantTruncation.getValueAsBoolean();
/*      */   
/*      */ 
/* 1022 */   protected MemorySizeConnectionProperty largeRowSizeThreshold = new MemorySizeConnectionProperty("largeRowSizeThreshold", 2048, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.largeRowSizeThreshold"), "5.1.1", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1027 */   private StringConnectionProperty loadBalanceStrategy = new StringConnectionProperty("loadBalanceStrategy", "random", null, Messages.getString("ConnectionProperties.loadBalanceStrategy"), "5.0.6", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1034 */   private IntegerConnectionProperty loadBalanceBlacklistTimeout = new IntegerConnectionProperty("loadBalanceBlacklistTimeout", 0, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.loadBalanceBlacklistTimeout"), "5.1.0", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1040 */   private IntegerConnectionProperty loadBalancePingTimeout = new IntegerConnectionProperty("loadBalancePingTimeout", 0, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.loadBalancePingTimeout"), "5.1.13", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1046 */   private BooleanConnectionProperty loadBalanceValidateConnectionOnSwapServer = new BooleanConnectionProperty("loadBalanceValidateConnectionOnSwapServer", false, Messages.getString("ConnectionProperties.loadBalanceValidateConnectionOnSwapServer"), "5.1.13", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1052 */   private StringConnectionProperty loadBalanceConnectionGroup = new StringConnectionProperty("loadBalanceConnectionGroup", null, Messages.getString("ConnectionProperties.loadBalanceConnectionGroup"), "5.1.13", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1058 */   private StringConnectionProperty loadBalanceExceptionChecker = new StringConnectionProperty("loadBalanceExceptionChecker", "com.mysql.jdbc.StandardLoadBalanceExceptionChecker", null, Messages.getString("ConnectionProperties.loadBalanceExceptionChecker"), "5.1.13", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1065 */   private StringConnectionProperty loadBalanceSQLStateFailover = new StringConnectionProperty("loadBalanceSQLStateFailover", null, Messages.getString("ConnectionProperties.loadBalanceSQLStateFailover"), "5.1.13", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1071 */   private StringConnectionProperty loadBalanceSQLExceptionSubclassFailover = new StringConnectionProperty("loadBalanceSQLExceptionSubclassFailover", null, Messages.getString("ConnectionProperties.loadBalanceSQLExceptionSubclassFailover"), "5.1.13", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1077 */   private BooleanConnectionProperty loadBalanceEnableJMX = new BooleanConnectionProperty("loadBalanceEnableJMX", false, Messages.getString("ConnectionProperties.loadBalanceEnableJMX"), "5.1.13", MISC_CATEGORY, Integer.MAX_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1083 */   private StringConnectionProperty loadBalanceAutoCommitStatementRegex = new StringConnectionProperty("loadBalanceAutoCommitStatementRegex", null, Messages.getString("ConnectionProperties.loadBalanceAutoCommitStatementRegex"), "5.1.15", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1089 */   private IntegerConnectionProperty loadBalanceAutoCommitStatementThreshold = new IntegerConnectionProperty("loadBalanceAutoCommitStatementThreshold", 0, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.loadBalanceAutoCommitStatementThreshold"), "5.1.15", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1096 */   private StringConnectionProperty localSocketAddress = new StringConnectionProperty("localSocketAddress", null, Messages.getString("ConnectionProperties.localSocketAddress"), "5.0.5", CONNECTION_AND_AUTH_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/* 1100 */   private MemorySizeConnectionProperty locatorFetchBufferSize = new MemorySizeConnectionProperty("locatorFetchBufferSize", 1048576, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.locatorFetchBufferSize"), "3.2.1", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1108 */   private StringConnectionProperty loggerClassName = new StringConnectionProperty("logger", STANDARD_LOGGER_NAME, Messages.getString("ConnectionProperties.logger", new Object[] { Log.class.getName(), STANDARD_LOGGER_NAME }), "3.1.1", DEBUGING_PROFILING_CATEGORY, 0);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1114 */   private BooleanConnectionProperty logSlowQueries = new BooleanConnectionProperty("logSlowQueries", false, Messages.getString("ConnectionProperties.logSlowQueries"), "3.1.2", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1120 */   private BooleanConnectionProperty logXaCommands = new BooleanConnectionProperty("logXaCommands", false, Messages.getString("ConnectionProperties.logXaCommands"), "5.0.5", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1126 */   private BooleanConnectionProperty maintainTimeStats = new BooleanConnectionProperty("maintainTimeStats", true, Messages.getString("ConnectionProperties.maintainTimeStats"), "3.1.9", PERFORMANCE_CATEGORY, Integer.MAX_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1132 */   private boolean maintainTimeStatsAsBoolean = true;
/*      */   
/* 1134 */   private IntegerConnectionProperty maxQuerySizeToLog = new IntegerConnectionProperty("maxQuerySizeToLog", 2048, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.maxQuerySizeToLog"), "3.1.3", DEBUGING_PROFILING_CATEGORY, 4);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1142 */   private IntegerConnectionProperty maxReconnects = new IntegerConnectionProperty("maxReconnects", 3, 1, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.maxReconnects"), "1.1", HA_CATEGORY, 4);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1150 */   private IntegerConnectionProperty retriesAllDown = new IntegerConnectionProperty("retriesAllDown", 120, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.retriesAllDown"), "5.1.6", HA_CATEGORY, 4);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1158 */   private IntegerConnectionProperty maxRows = new IntegerConnectionProperty("maxRows", -1, -1, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.maxRows"), Messages.getString("ConnectionProperties.allVersions"), MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1163 */   private int maxRowsAsInt = -1;
/*      */   
/* 1165 */   private IntegerConnectionProperty metadataCacheSize = new IntegerConnectionProperty("metadataCacheSize", 50, 1, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.metadataCacheSize"), "3.1.1", PERFORMANCE_CATEGORY, 5);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1173 */   private IntegerConnectionProperty netTimeoutForStreamingResults = new IntegerConnectionProperty("netTimeoutForStreamingResults", 600, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.netTimeoutForStreamingResults"), "5.1.0", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1179 */   private BooleanConnectionProperty noAccessToProcedureBodies = new BooleanConnectionProperty("noAccessToProcedureBodies", false, "When determining procedure parameter types for CallableStatements, and the connected user  can't access procedure bodies through \"SHOW CREATE PROCEDURE\" or select on mysql.proc  should the driver instead create basic metadata (all parameters reported as IN VARCHARs, but allowing registerOutParameter() to be called on them anyway) instead  of throwing an exception?", "5.0.3", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1189 */   private BooleanConnectionProperty noDatetimeStringSync = new BooleanConnectionProperty("noDatetimeStringSync", false, Messages.getString("ConnectionProperties.noDatetimeStringSync"), "3.1.7", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1195 */   private BooleanConnectionProperty noTimezoneConversionForTimeType = new BooleanConnectionProperty("noTimezoneConversionForTimeType", false, Messages.getString("ConnectionProperties.noTzConversionForTimeType"), "5.0.0", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1201 */   private BooleanConnectionProperty nullCatalogMeansCurrent = new BooleanConnectionProperty("nullCatalogMeansCurrent", true, Messages.getString("ConnectionProperties.nullCatalogMeansCurrent"), "3.1.8", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1207 */   private BooleanConnectionProperty nullNamePatternMatchesAll = new BooleanConnectionProperty("nullNamePatternMatchesAll", true, Messages.getString("ConnectionProperties.nullNamePatternMatchesAll"), "3.1.8", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1213 */   private IntegerConnectionProperty packetDebugBufferSize = new IntegerConnectionProperty("packetDebugBufferSize", 20, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.packetDebugBufferSize"), "3.1.3", DEBUGING_PROFILING_CATEGORY, 7);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1221 */   private BooleanConnectionProperty padCharsWithSpace = new BooleanConnectionProperty("padCharsWithSpace", false, Messages.getString("ConnectionProperties.padCharsWithSpace"), "5.0.6", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1229 */   private BooleanConnectionProperty paranoid = new BooleanConnectionProperty("paranoid", false, Messages.getString("ConnectionProperties.paranoid"), "3.0.1", SECURITY_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1235 */   private BooleanConnectionProperty pedantic = new BooleanConnectionProperty("pedantic", false, Messages.getString("ConnectionProperties.pedantic"), "3.0.0", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/* 1239 */   private BooleanConnectionProperty pinGlobalTxToPhysicalConnection = new BooleanConnectionProperty("pinGlobalTxToPhysicalConnection", false, Messages.getString("ConnectionProperties.pinGlobalTxToPhysicalConnection"), "5.0.1", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/* 1243 */   private BooleanConnectionProperty populateInsertRowWithDefaultValues = new BooleanConnectionProperty("populateInsertRowWithDefaultValues", false, Messages.getString("ConnectionProperties.populateInsertRowWithDefaultValues"), "5.0.5", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1248 */   private IntegerConnectionProperty preparedStatementCacheSize = new IntegerConnectionProperty("prepStmtCacheSize", 25, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.prepStmtCacheSize"), "3.0.10", PERFORMANCE_CATEGORY, 10);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1253 */   private IntegerConnectionProperty preparedStatementCacheSqlLimit = new IntegerConnectionProperty("prepStmtCacheSqlLimit", 256, 1, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.prepStmtCacheSqlLimit"), "3.0.10", PERFORMANCE_CATEGORY, 11);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1261 */   private BooleanConnectionProperty processEscapeCodesForPrepStmts = new BooleanConnectionProperty("processEscapeCodesForPrepStmts", true, Messages.getString("ConnectionProperties.processEscapeCodesForPrepStmts"), "3.1.12", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1268 */   private StringConnectionProperty profilerEventHandler = new StringConnectionProperty("profilerEventHandler", "com.mysql.jdbc.profiler.LoggingProfilerEventHandler", Messages.getString("ConnectionProperties.profilerEventHandler"), "5.1.6", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1274 */   private StringConnectionProperty profileSql = new StringConnectionProperty("profileSql", null, Messages.getString("ConnectionProperties.profileSqlDeprecated"), "2.0.14", DEBUGING_PROFILING_CATEGORY, 3);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1280 */   private BooleanConnectionProperty profileSQL = new BooleanConnectionProperty("profileSQL", false, Messages.getString("ConnectionProperties.profileSQL"), "3.1.0", DEBUGING_PROFILING_CATEGORY, 1);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1286 */   private boolean profileSQLAsBoolean = false;
/*      */   
/* 1288 */   private StringConnectionProperty propertiesTransform = new StringConnectionProperty("propertiesTransform", null, Messages.getString("ConnectionProperties.connectionPropertiesTransform"), "3.1.4", CONNECTION_AND_AUTH_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1294 */   private IntegerConnectionProperty queriesBeforeRetryMaster = new IntegerConnectionProperty("queriesBeforeRetryMaster", 50, 1, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.queriesBeforeRetryMaster"), "3.0.2", HA_CATEGORY, 7);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1302 */   private BooleanConnectionProperty queryTimeoutKillsConnection = new BooleanConnectionProperty("queryTimeoutKillsConnection", false, Messages.getString("ConnectionProperties.queryTimeoutKillsConnection"), "5.1.9", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/* 1306 */   private BooleanConnectionProperty reconnectAtTxEnd = new BooleanConnectionProperty("reconnectAtTxEnd", false, Messages.getString("ConnectionProperties.reconnectAtTxEnd"), "3.0.10", HA_CATEGORY, 4);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1311 */   private boolean reconnectTxAtEndAsBoolean = false;
/*      */   
/* 1313 */   private BooleanConnectionProperty relaxAutoCommit = new BooleanConnectionProperty("relaxAutoCommit", false, Messages.getString("ConnectionProperties.relaxAutoCommit"), "2.0.13", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1319 */   private IntegerConnectionProperty reportMetricsIntervalMillis = new IntegerConnectionProperty("reportMetricsIntervalMillis", 30000, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.reportMetricsIntervalMillis"), "3.1.2", DEBUGING_PROFILING_CATEGORY, 3);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1327 */   private BooleanConnectionProperty requireSSL = new BooleanConnectionProperty("requireSSL", false, Messages.getString("ConnectionProperties.requireSSL"), "3.1.0", SECURITY_CATEGORY, 3);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1332 */   private StringConnectionProperty resourceId = new StringConnectionProperty("resourceId", null, Messages.getString("ConnectionProperties.resourceId"), "5.0.1", HA_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1339 */   private IntegerConnectionProperty resultSetSizeThreshold = new IntegerConnectionProperty("resultSetSizeThreshold", 100, Messages.getString("ConnectionProperties.resultSetSizeThreshold"), "5.0.5", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/* 1342 */   private BooleanConnectionProperty retainStatementAfterResultSetClose = new BooleanConnectionProperty("retainStatementAfterResultSetClose", false, Messages.getString("ConnectionProperties.retainStatementAfterResultSetClose"), "3.1.11", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1348 */   private BooleanConnectionProperty rewriteBatchedStatements = new BooleanConnectionProperty("rewriteBatchedStatements", false, Messages.getString("ConnectionProperties.rewriteBatchedStatements"), "3.1.13", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1354 */   private BooleanConnectionProperty rollbackOnPooledClose = new BooleanConnectionProperty("rollbackOnPooledClose", true, Messages.getString("ConnectionProperties.rollbackOnPooledClose"), "3.0.15", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1360 */   private BooleanConnectionProperty roundRobinLoadBalance = new BooleanConnectionProperty("roundRobinLoadBalance", false, Messages.getString("ConnectionProperties.roundRobinLoadBalance"), "3.1.2", HA_CATEGORY, 5);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1366 */   private BooleanConnectionProperty runningCTS13 = new BooleanConnectionProperty("runningCTS13", false, Messages.getString("ConnectionProperties.runningCTS13"), "3.1.7", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1372 */   private IntegerConnectionProperty secondsBeforeRetryMaster = new IntegerConnectionProperty("secondsBeforeRetryMaster", 30, 1, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.secondsBeforeRetryMaster"), "3.0.2", HA_CATEGORY, 8);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1380 */   private IntegerConnectionProperty selfDestructOnPingSecondsLifetime = new IntegerConnectionProperty("selfDestructOnPingSecondsLifetime", 0, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.selfDestructOnPingSecondsLifetime"), "5.1.6", HA_CATEGORY, Integer.MAX_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1388 */   private IntegerConnectionProperty selfDestructOnPingMaxOperations = new IntegerConnectionProperty("selfDestructOnPingMaxOperations", 0, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.selfDestructOnPingMaxOperations"), "5.1.6", HA_CATEGORY, Integer.MAX_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1396 */   private StringConnectionProperty serverTimezone = new StringConnectionProperty("serverTimezone", null, Messages.getString("ConnectionProperties.serverTimezone"), "3.0.2", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1402 */   private StringConnectionProperty sessionVariables = new StringConnectionProperty("sessionVariables", null, Messages.getString("ConnectionProperties.sessionVariables"), "3.1.8", MISC_CATEGORY, Integer.MAX_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1407 */   private IntegerConnectionProperty slowQueryThresholdMillis = new IntegerConnectionProperty("slowQueryThresholdMillis", 2000, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.slowQueryThresholdMillis"), "3.1.2", DEBUGING_PROFILING_CATEGORY, 9);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1415 */   private LongConnectionProperty slowQueryThresholdNanos = new LongConnectionProperty("slowQueryThresholdNanos", 0L, Messages.getString("ConnectionProperties.slowQueryThresholdNanos"), "5.0.7", DEBUGING_PROFILING_CATEGORY, 10);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1423 */   private StringConnectionProperty socketFactoryClassName = new StringConnectionProperty("socketFactory", StandardSocketFactory.class.getName(), Messages.getString("ConnectionProperties.socketFactory"), "3.0.3", CONNECTION_AND_AUTH_CATEGORY, 4);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1429 */   private IntegerConnectionProperty socketTimeout = new IntegerConnectionProperty("socketTimeout", 0, 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.socketTimeout"), "3.0.1", CONNECTION_AND_AUTH_CATEGORY, 10);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1437 */   private StringConnectionProperty statementInterceptors = new StringConnectionProperty("statementInterceptors", null, Messages.getString("ConnectionProperties.statementInterceptors"), "5.1.1", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/* 1440 */   private BooleanConnectionProperty strictFloatingPoint = new BooleanConnectionProperty("strictFloatingPoint", false, Messages.getString("ConnectionProperties.strictFloatingPoint"), "3.0.0", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1445 */   private BooleanConnectionProperty strictUpdates = new BooleanConnectionProperty("strictUpdates", true, Messages.getString("ConnectionProperties.strictUpdates"), "3.0.4", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1451 */   private BooleanConnectionProperty overrideSupportsIntegrityEnhancementFacility = new BooleanConnectionProperty("overrideSupportsIntegrityEnhancementFacility", false, Messages.getString("ConnectionProperties.overrideSupportsIEF"), "3.1.12", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1457 */   private BooleanConnectionProperty tcpNoDelay = new BooleanConnectionProperty("tcpNoDelay", Boolean.valueOf("true").booleanValue(), Messages.getString("ConnectionProperties.tcpNoDelay"), "5.0.7", NETWORK_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1463 */   private BooleanConnectionProperty tcpKeepAlive = new BooleanConnectionProperty("tcpKeepAlive", Boolean.valueOf("true").booleanValue(), Messages.getString("ConnectionProperties.tcpKeepAlive"), "5.0.7", NETWORK_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1469 */   private IntegerConnectionProperty tcpRcvBuf = new IntegerConnectionProperty("tcpRcvBuf", Integer.parseInt("0"), 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.tcpSoRcvBuf"), "5.0.7", NETWORK_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1476 */   private IntegerConnectionProperty tcpSndBuf = new IntegerConnectionProperty("tcpSndBuf", Integer.parseInt("0"), 0, Integer.MAX_VALUE, Messages.getString("ConnectionProperties.tcpSoSndBuf"), "5.0.7", NETWORK_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1483 */   private IntegerConnectionProperty tcpTrafficClass = new IntegerConnectionProperty("tcpTrafficClass", Integer.parseInt("0"), 0, 255, Messages.getString("ConnectionProperties.tcpTrafficClass"), "5.0.7", NETWORK_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1490 */   private BooleanConnectionProperty tinyInt1isBit = new BooleanConnectionProperty("tinyInt1isBit", true, Messages.getString("ConnectionProperties.tinyInt1isBit"), "3.0.16", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1496 */   private BooleanConnectionProperty traceProtocol = new BooleanConnectionProperty("traceProtocol", false, Messages.getString("ConnectionProperties.traceProtocol"), "3.1.2", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1501 */   private BooleanConnectionProperty treatUtilDateAsTimestamp = new BooleanConnectionProperty("treatUtilDateAsTimestamp", true, Messages.getString("ConnectionProperties.treatUtilDateAsTimestamp"), "5.0.5", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1506 */   private BooleanConnectionProperty transformedBitIsBoolean = new BooleanConnectionProperty("transformedBitIsBoolean", false, Messages.getString("ConnectionProperties.transformedBitIsBoolean"), "3.1.9", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1512 */   private BooleanConnectionProperty useBlobToStoreUTF8OutsideBMP = new BooleanConnectionProperty("useBlobToStoreUTF8OutsideBMP", false, Messages.getString("ConnectionProperties.useBlobToStoreUTF8OutsideBMP"), "5.1.3", MISC_CATEGORY, 128);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1518 */   private StringConnectionProperty utf8OutsideBmpExcludedColumnNamePattern = new StringConnectionProperty("utf8OutsideBmpExcludedColumnNamePattern", null, Messages.getString("ConnectionProperties.utf8OutsideBmpExcludedColumnNamePattern"), "5.1.3", MISC_CATEGORY, 129);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1524 */   private StringConnectionProperty utf8OutsideBmpIncludedColumnNamePattern = new StringConnectionProperty("utf8OutsideBmpIncludedColumnNamePattern", null, Messages.getString("ConnectionProperties.utf8OutsideBmpIncludedColumnNamePattern"), "5.1.3", MISC_CATEGORY, 129);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1530 */   private BooleanConnectionProperty useCompression = new BooleanConnectionProperty("useCompression", false, Messages.getString("ConnectionProperties.useCompression"), "3.0.17", CONNECTION_AND_AUTH_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1536 */   private BooleanConnectionProperty useColumnNamesInFindColumn = new BooleanConnectionProperty("useColumnNamesInFindColumn", false, Messages.getString("ConnectionProperties.useColumnNamesInFindColumn"), "5.1.7", MISC_CATEGORY, Integer.MAX_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1542 */   private StringConnectionProperty useConfigs = new StringConnectionProperty("useConfigs", null, Messages.getString("ConnectionProperties.useConfigs"), "3.1.5", CONNECTION_AND_AUTH_CATEGORY, Integer.MAX_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1548 */   private BooleanConnectionProperty useCursorFetch = new BooleanConnectionProperty("useCursorFetch", false, Messages.getString("ConnectionProperties.useCursorFetch"), "5.0.0", PERFORMANCE_CATEGORY, Integer.MAX_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1554 */   private BooleanConnectionProperty useDynamicCharsetInfo = new BooleanConnectionProperty("useDynamicCharsetInfo", true, Messages.getString("ConnectionProperties.useDynamicCharsetInfo"), "5.0.6", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1560 */   private BooleanConnectionProperty useDirectRowUnpack = new BooleanConnectionProperty("useDirectRowUnpack", true, "Use newer result set row unpacking code that skips a copy from network buffers  to a MySQL packet instance and instead reads directly into the result set row data buffers.", "5.1.1", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1566 */   private BooleanConnectionProperty useFastIntParsing = new BooleanConnectionProperty("useFastIntParsing", true, Messages.getString("ConnectionProperties.useFastIntParsing"), "3.1.4", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1572 */   private BooleanConnectionProperty useFastDateParsing = new BooleanConnectionProperty("useFastDateParsing", true, Messages.getString("ConnectionProperties.useFastDateParsing"), "5.0.5", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1578 */   private BooleanConnectionProperty useHostsInPrivileges = new BooleanConnectionProperty("useHostsInPrivileges", true, Messages.getString("ConnectionProperties.useHostsInPrivileges"), "3.0.2", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1583 */   private BooleanConnectionProperty useInformationSchema = new BooleanConnectionProperty("useInformationSchema", false, Messages.getString("ConnectionProperties.useInformationSchema"), "5.0.0", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1588 */   private BooleanConnectionProperty useJDBCCompliantTimezoneShift = new BooleanConnectionProperty("useJDBCCompliantTimezoneShift", false, Messages.getString("ConnectionProperties.useJDBCCompliantTimezoneShift"), "5.0.0", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1595 */   private BooleanConnectionProperty useLocalSessionState = new BooleanConnectionProperty("useLocalSessionState", false, Messages.getString("ConnectionProperties.useLocalSessionState"), "3.1.7", PERFORMANCE_CATEGORY, 5);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1601 */   private BooleanConnectionProperty useLocalTransactionState = new BooleanConnectionProperty("useLocalTransactionState", false, Messages.getString("ConnectionProperties.useLocalTransactionState"), "5.1.7", PERFORMANCE_CATEGORY, 6);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1607 */   private BooleanConnectionProperty useLegacyDatetimeCode = new BooleanConnectionProperty("useLegacyDatetimeCode", true, Messages.getString("ConnectionProperties.useLegacyDatetimeCode"), "5.1.6", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1613 */   private BooleanConnectionProperty useNanosForElapsedTime = new BooleanConnectionProperty("useNanosForElapsedTime", false, Messages.getString("ConnectionProperties.useNanosForElapsedTime"), "5.0.7", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1620 */   private BooleanConnectionProperty useOldAliasMetadataBehavior = new BooleanConnectionProperty("useOldAliasMetadataBehavior", false, Messages.getString("ConnectionProperties.useOldAliasMetadataBehavior"), "5.0.4", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1628 */   private BooleanConnectionProperty useOldUTF8Behavior = new BooleanConnectionProperty("useOldUTF8Behavior", false, Messages.getString("ConnectionProperties.useOldUtf8Behavior"), "3.1.6", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1634 */   private boolean useOldUTF8BehaviorAsBoolean = false;
/*      */   
/* 1636 */   private BooleanConnectionProperty useOnlyServerErrorMessages = new BooleanConnectionProperty("useOnlyServerErrorMessages", true, Messages.getString("ConnectionProperties.useOnlyServerErrorMessages"), "3.0.15", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1642 */   private BooleanConnectionProperty useReadAheadInput = new BooleanConnectionProperty("useReadAheadInput", true, Messages.getString("ConnectionProperties.useReadAheadInput"), "3.1.5", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1648 */   private BooleanConnectionProperty useSqlStateCodes = new BooleanConnectionProperty("useSqlStateCodes", true, Messages.getString("ConnectionProperties.useSqlStateCodes"), "3.1.3", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1654 */   private BooleanConnectionProperty useSSL = new BooleanConnectionProperty("useSSL", false, Messages.getString("ConnectionProperties.useSSL"), "3.0.2", SECURITY_CATEGORY, 2);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1660 */   private BooleanConnectionProperty useSSPSCompatibleTimezoneShift = new BooleanConnectionProperty("useSSPSCompatibleTimezoneShift", false, Messages.getString("ConnectionProperties.useSSPSCompatibleTimezoneShift"), "5.0.5", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1666 */   private BooleanConnectionProperty useStreamLengthsInPrepStmts = new BooleanConnectionProperty("useStreamLengthsInPrepStmts", true, Messages.getString("ConnectionProperties.useStreamLengthsInPrepStmts"), "3.0.2", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1672 */   private BooleanConnectionProperty useTimezone = new BooleanConnectionProperty("useTimezone", false, Messages.getString("ConnectionProperties.useTimezone"), "3.0.2", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1678 */   private BooleanConnectionProperty useUltraDevWorkAround = new BooleanConnectionProperty("ultraDevHack", false, Messages.getString("ConnectionProperties.ultraDevHack"), "2.0.3", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1684 */   private BooleanConnectionProperty useUnbufferedInput = new BooleanConnectionProperty("useUnbufferedInput", true, Messages.getString("ConnectionProperties.useUnbufferedInput"), "3.0.11", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1689 */   private BooleanConnectionProperty useUnicode = new BooleanConnectionProperty("useUnicode", true, Messages.getString("ConnectionProperties.useUnicode"), "1.1g", MISC_CATEGORY, 0);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1696 */   private boolean useUnicodeAsBoolean = true;
/*      */   
/* 1698 */   private BooleanConnectionProperty useUsageAdvisor = new BooleanConnectionProperty("useUsageAdvisor", false, Messages.getString("ConnectionProperties.useUsageAdvisor"), "3.1.1", DEBUGING_PROFILING_CATEGORY, 10);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1704 */   private boolean useUsageAdvisorAsBoolean = false;
/*      */   
/* 1706 */   private BooleanConnectionProperty yearIsDateType = new BooleanConnectionProperty("yearIsDateType", true, Messages.getString("ConnectionProperties.yearIsDateType"), "3.1.9", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1712 */   private StringConnectionProperty zeroDateTimeBehavior = new StringConnectionProperty("zeroDateTimeBehavior", "exception", new String[] { "exception", "round", "convertToNull" }, Messages.getString("ConnectionProperties.zeroDateTimeBehavior", new Object[] { "exception", "round", "convertToNull" }), "3.1.4", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1722 */   private BooleanConnectionProperty useJvmCharsetConverters = new BooleanConnectionProperty("useJvmCharsetConverters", false, Messages.getString("ConnectionProperties.useJvmCharsetConverters"), "5.0.1", PERFORMANCE_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/* 1725 */   private BooleanConnectionProperty useGmtMillisForDatetimes = new BooleanConnectionProperty("useGmtMillisForDatetimes", false, Messages.getString("ConnectionProperties.useGmtMillisForDatetimes"), "3.1.12", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/* 1727 */   private BooleanConnectionProperty dumpMetadataOnColumnNotFound = new BooleanConnectionProperty("dumpMetadataOnColumnNotFound", false, Messages.getString("ConnectionProperties.dumpMetadataOnColumnNotFound"), "3.1.13", DEBUGING_PROFILING_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/* 1731 */   private StringConnectionProperty clientCertificateKeyStoreUrl = new StringConnectionProperty("clientCertificateKeyStoreUrl", null, Messages.getString("ConnectionProperties.clientCertificateKeyStoreUrl"), "5.1.0", SECURITY_CATEGORY, 5);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1736 */   private StringConnectionProperty trustCertificateKeyStoreUrl = new StringConnectionProperty("trustCertificateKeyStoreUrl", null, Messages.getString("ConnectionProperties.trustCertificateKeyStoreUrl"), "5.1.0", SECURITY_CATEGORY, 8);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1741 */   private StringConnectionProperty clientCertificateKeyStoreType = new StringConnectionProperty("clientCertificateKeyStoreType", "JKS", Messages.getString("ConnectionProperties.clientCertificateKeyStoreType"), "5.1.0", SECURITY_CATEGORY, 6);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1746 */   private StringConnectionProperty clientCertificateKeyStorePassword = new StringConnectionProperty("clientCertificateKeyStorePassword", null, Messages.getString("ConnectionProperties.clientCertificateKeyStorePassword"), "5.1.0", SECURITY_CATEGORY, 7);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1751 */   private StringConnectionProperty trustCertificateKeyStoreType = new StringConnectionProperty("trustCertificateKeyStoreType", "JKS", Messages.getString("ConnectionProperties.trustCertificateKeyStoreType"), "5.1.0", SECURITY_CATEGORY, 9);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1756 */   private StringConnectionProperty trustCertificateKeyStorePassword = new StringConnectionProperty("trustCertificateKeyStorePassword", null, Messages.getString("ConnectionProperties.trustCertificateKeyStorePassword"), "5.1.0", SECURITY_CATEGORY, 10);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1761 */   private BooleanConnectionProperty verifyServerCertificate = new BooleanConnectionProperty("verifyServerCertificate", true, Messages.getString("ConnectionProperties.verifyServerCertificate"), "5.1.6", SECURITY_CATEGORY, 4);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1767 */   private BooleanConnectionProperty useAffectedRows = new BooleanConnectionProperty("useAffectedRows", false, Messages.getString("ConnectionProperties.useAffectedRows"), "5.1.7", MISC_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1772 */   private StringConnectionProperty passwordCharacterEncoding = new StringConnectionProperty("passwordCharacterEncoding", null, Messages.getString("ConnectionProperties.passwordCharacterEncoding"), "5.1.7", SECURITY_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1777 */   private IntegerConnectionProperty maxAllowedPacket = new IntegerConnectionProperty("maxAllowedPacket", -1, Messages.getString("ConnectionProperties.maxAllowedPacket"), "5.1.8", NETWORK_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/* 1781 */   private StringConnectionProperty authenticationPlugins = new StringConnectionProperty("authenticationPlugins", null, Messages.getString("ConnectionProperties.authenticationPlugins"), "5.1.19", CONNECTION_AND_AUTH_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1787 */   private StringConnectionProperty disabledAuthenticationPlugins = new StringConnectionProperty("disabledAuthenticationPlugins", null, Messages.getString("ConnectionProperties.disabledAuthenticationPlugins"), "5.1.19", CONNECTION_AND_AUTH_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1793 */   private StringConnectionProperty defaultAuthenticationPlugin = new StringConnectionProperty("defaultAuthenticationPlugin", "com.mysql.jdbc.authentication.MysqlNativePasswordPlugin", Messages.getString("ConnectionProperties.defaultAuthenticationPlugin"), "5.1.19", CONNECTION_AND_AUTH_CATEGORY, Integer.MIN_VALUE);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected DriverPropertyInfo[] exposeAsDriverPropertyInfoInternal(Properties info, int slotsToReserve)
/*      */     throws SQLException
/*      */   {
/* 1801 */     initializeProperties(info);
/*      */     
/* 1803 */     int numProperties = PROPERTY_LIST.size();
/*      */     
/* 1805 */     int listSize = numProperties + slotsToReserve;
/*      */     
/* 1807 */     DriverPropertyInfo[] driverProperties = new DriverPropertyInfo[listSize];
/*      */     
/* 1809 */     for (int i = slotsToReserve; i < listSize; i++) {
/* 1810 */       Field propertyField = (Field)PROPERTY_LIST.get(i - slotsToReserve);
/*      */       
/*      */       try
/*      */       {
/* 1814 */         ConnectionProperty propToExpose = (ConnectionProperty)propertyField.get(this);
/*      */         
/*      */ 
/* 1817 */         if (info != null) {
/* 1818 */           propToExpose.initializeFrom(info);
/*      */         }
/*      */         
/*      */ 
/* 1822 */         driverProperties[i] = propToExpose.getAsDriverPropertyInfo();
/*      */       } catch (IllegalAccessException iae) {
/* 1824 */         throw SQLError.createSQLException(Messages.getString("ConnectionProperties.InternalPropertiesFailure"), "S1000", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1829 */     return driverProperties;
/*      */   }
/*      */   
/*      */   protected Properties exposeAsProperties(Properties info) throws SQLException
/*      */   {
/* 1834 */     if (info == null) {
/* 1835 */       info = new Properties();
/*      */     }
/*      */     
/* 1838 */     int numPropertiesToSet = PROPERTY_LIST.size();
/*      */     
/* 1840 */     for (int i = 0; i < numPropertiesToSet; i++) {
/* 1841 */       Field propertyField = (Field)PROPERTY_LIST.get(i);
/*      */       
/*      */       try
/*      */       {
/* 1845 */         ConnectionProperty propToGet = (ConnectionProperty)propertyField.get(this);
/*      */         
/*      */ 
/* 1848 */         Object propValue = propToGet.getValueAsObject();
/*      */         
/* 1850 */         if (propValue != null) {
/* 1851 */           info.setProperty(propToGet.getPropertyName(), propValue.toString());
/*      */         }
/*      */       }
/*      */       catch (IllegalAccessException iae) {
/* 1855 */         throw SQLError.createSQLException("Internal properties failure", "S1000", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1860 */     return info;
/*      */   }
/*      */   
/*      */ 
/*      */   public String exposeAsXml()
/*      */     throws SQLException
/*      */   {
/* 1867 */     StringBuffer xmlBuf = new StringBuffer();
/* 1868 */     xmlBuf.append("<ConnectionProperties>");
/*      */     
/* 1870 */     int numPropertiesToSet = PROPERTY_LIST.size();
/*      */     
/* 1872 */     int numCategories = PROPERTY_CATEGORIES.length;
/*      */     
/* 1874 */     Map propertyListByCategory = new HashMap();
/*      */     
/* 1876 */     for (int i = 0; i < numCategories; i++) {
/* 1877 */       propertyListByCategory.put(PROPERTY_CATEGORIES[i], new Map[] { new TreeMap(), new TreeMap() });
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1887 */     StringConnectionProperty userProp = new StringConnectionProperty("user", null, Messages.getString("ConnectionProperties.Username"), Messages.getString("ConnectionProperties.allVersions"), CONNECTION_AND_AUTH_CATEGORY, -2147483647);
/*      */     
/*      */ 
/*      */ 
/* 1891 */     StringConnectionProperty passwordProp = new StringConnectionProperty("password", null, Messages.getString("ConnectionProperties.Password"), Messages.getString("ConnectionProperties.allVersions"), CONNECTION_AND_AUTH_CATEGORY, -2147483646);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1896 */     Map[] connectionSortMaps = (Map[])propertyListByCategory.get(CONNECTION_AND_AUTH_CATEGORY);
/*      */     
/* 1898 */     TreeMap userMap = new TreeMap();
/* 1899 */     userMap.put(userProp.getPropertyName(), userProp);
/*      */     
/* 1901 */     connectionSortMaps[0].put(Integer.valueOf(userProp.getOrder()), userMap);
/*      */     
/* 1903 */     TreeMap passwordMap = new TreeMap();
/* 1904 */     passwordMap.put(passwordProp.getPropertyName(), passwordProp);
/*      */     
/* 1906 */     connectionSortMaps[0].put(new Integer(passwordProp.getOrder()), passwordMap);
/*      */     
/*      */     try
/*      */     {
/* 1910 */       for (int i = 0; i < numPropertiesToSet; i++) {
/* 1911 */         Field propertyField = (Field)PROPERTY_LIST.get(i);
/*      */         
/* 1913 */         ConnectionProperty propToGet = (ConnectionProperty)propertyField.get(this);
/*      */         
/* 1915 */         Map[] sortMaps = (Map[])propertyListByCategory.get(propToGet.getCategoryName());
/*      */         
/* 1917 */         int orderInCategory = propToGet.getOrder();
/*      */         
/* 1919 */         if (orderInCategory == Integer.MIN_VALUE) {
/* 1920 */           sortMaps[1].put(propToGet.getPropertyName(), propToGet);
/*      */         } else {
/* 1922 */           Integer order = Integer.valueOf(orderInCategory);
/*      */           
/* 1924 */           Map orderMap = (Map)sortMaps[0].get(order);
/*      */           
/* 1926 */           if (orderMap == null) {
/* 1927 */             orderMap = new TreeMap();
/* 1928 */             sortMaps[0].put(order, orderMap);
/*      */           }
/*      */           
/* 1931 */           orderMap.put(propToGet.getPropertyName(), propToGet);
/*      */         }
/*      */       }
/*      */       
/* 1935 */       for (int j = 0; j < numCategories; j++) {
/* 1936 */         Map[] sortMaps = (Map[])propertyListByCategory.get(PROPERTY_CATEGORIES[j]);
/*      */         
/* 1938 */         Iterator orderedIter = sortMaps[0].values().iterator();
/* 1939 */         Iterator alphaIter = sortMaps[1].values().iterator();
/*      */         
/* 1941 */         xmlBuf.append("\n <PropertyCategory name=\"");
/* 1942 */         xmlBuf.append(PROPERTY_CATEGORIES[j]);
/* 1943 */         xmlBuf.append("\">");
/*      */         
/* 1945 */         while (orderedIter.hasNext()) {
/* 1946 */           Iterator orderedAlphaIter = ((Map)orderedIter.next()).values().iterator();
/*      */           
/* 1948 */           while (orderedAlphaIter.hasNext()) {
/* 1949 */             ConnectionProperty propToGet = (ConnectionProperty)orderedAlphaIter.next();
/*      */             
/*      */ 
/* 1952 */             xmlBuf.append("\n  <Property name=\"");
/* 1953 */             xmlBuf.append(propToGet.getPropertyName());
/* 1954 */             xmlBuf.append("\" required=\"");
/* 1955 */             xmlBuf.append(propToGet.required ? "Yes" : "No");
/*      */             
/* 1957 */             xmlBuf.append("\" default=\"");
/*      */             
/* 1959 */             if (propToGet.getDefaultValue() != null) {
/* 1960 */               xmlBuf.append(propToGet.getDefaultValue());
/*      */             }
/*      */             
/* 1963 */             xmlBuf.append("\" sortOrder=\"");
/* 1964 */             xmlBuf.append(propToGet.getOrder());
/* 1965 */             xmlBuf.append("\" since=\"");
/* 1966 */             xmlBuf.append(propToGet.sinceVersion);
/* 1967 */             xmlBuf.append("\">\n");
/* 1968 */             xmlBuf.append("    ");
/* 1969 */             xmlBuf.append(propToGet.description);
/* 1970 */             xmlBuf.append("\n  </Property>");
/*      */           }
/*      */         }
/*      */         
/* 1974 */         while (alphaIter.hasNext()) {
/* 1975 */           ConnectionProperty propToGet = (ConnectionProperty)alphaIter.next();
/*      */           
/*      */ 
/* 1978 */           xmlBuf.append("\n  <Property name=\"");
/* 1979 */           xmlBuf.append(propToGet.getPropertyName());
/* 1980 */           xmlBuf.append("\" required=\"");
/* 1981 */           xmlBuf.append(propToGet.required ? "Yes" : "No");
/*      */           
/* 1983 */           xmlBuf.append("\" default=\"");
/*      */           
/* 1985 */           if (propToGet.getDefaultValue() != null) {
/* 1986 */             xmlBuf.append(propToGet.getDefaultValue());
/*      */           }
/*      */           
/* 1989 */           xmlBuf.append("\" sortOrder=\"alpha\" since=\"");
/* 1990 */           xmlBuf.append(propToGet.sinceVersion);
/* 1991 */           xmlBuf.append("\">\n");
/* 1992 */           xmlBuf.append("    ");
/* 1993 */           xmlBuf.append(propToGet.description);
/* 1994 */           xmlBuf.append("\n  </Property>");
/*      */         }
/*      */         
/* 1997 */         xmlBuf.append("\n </PropertyCategory>");
/*      */       }
/*      */     } catch (IllegalAccessException iae) {
/* 2000 */       throw SQLError.createSQLException("Internal properties failure", "S1000", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 2004 */     xmlBuf.append("\n</ConnectionProperties>");
/*      */     
/* 2006 */     return xmlBuf.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getAllowLoadLocalInfile()
/*      */   {
/* 2013 */     return this.allowLoadLocalInfile.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getAllowMultiQueries()
/*      */   {
/* 2020 */     return this.allowMultiQueries.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getAllowNanAndInf()
/*      */   {
/* 2027 */     return this.allowNanAndInf.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getAllowUrlInLocalInfile()
/*      */   {
/* 2034 */     return this.allowUrlInLocalInfile.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getAlwaysSendSetIsolation()
/*      */   {
/* 2041 */     return this.alwaysSendSetIsolation.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getAutoDeserialize()
/*      */   {
/* 2048 */     return this.autoDeserialize.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getAutoGenerateTestcaseScript()
/*      */   {
/* 2055 */     return this.autoGenerateTestcaseScriptAsBoolean;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getAutoReconnectForPools()
/*      */   {
/* 2062 */     return this.autoReconnectForPoolsAsBoolean;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getBlobSendChunkSize()
/*      */   {
/* 2069 */     return this.blobSendChunkSize.getValueAsInt();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getCacheCallableStatements()
/*      */   {
/* 2076 */     return this.cacheCallableStatements.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getCachePreparedStatements()
/*      */   {
/* 2083 */     return ((Boolean)this.cachePreparedStatements.getValueAsObject()).booleanValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getCacheResultSetMetadata()
/*      */   {
/* 2091 */     return this.cacheResultSetMetaDataAsBoolean;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getCacheServerConfiguration()
/*      */   {
/* 2098 */     return this.cacheServerConfiguration.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getCallableStatementCacheSize()
/*      */   {
/* 2105 */     return this.callableStatementCacheSize.getValueAsInt();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getCapitalizeTypeNames()
/*      */   {
/* 2112 */     return this.capitalizeTypeNames.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getCharacterSetResults()
/*      */   {
/* 2119 */     return this.characterSetResults.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getClobberStreamingResults()
/*      */   {
/* 2126 */     return this.clobberStreamingResults.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getClobCharacterEncoding()
/*      */   {
/* 2133 */     return this.clobCharacterEncoding.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getConnectionCollation()
/*      */   {
/* 2140 */     return this.connectionCollation.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getConnectTimeout()
/*      */   {
/* 2147 */     return this.connectTimeout.getValueAsInt();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getContinueBatchOnError()
/*      */   {
/* 2154 */     return this.continueBatchOnError.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getCreateDatabaseIfNotExist()
/*      */   {
/* 2161 */     return this.createDatabaseIfNotExist.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getDefaultFetchSize()
/*      */   {
/* 2168 */     return this.defaultFetchSize.getValueAsInt();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getDontTrackOpenResources()
/*      */   {
/* 2175 */     return this.dontTrackOpenResources.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getDumpQueriesOnException()
/*      */   {
/* 2182 */     return this.dumpQueriesOnException.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getDynamicCalendars()
/*      */   {
/* 2189 */     return this.dynamicCalendars.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getElideSetAutoCommits()
/*      */   {
/* 2196 */     return this.elideSetAutoCommits.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getEmptyStringsConvertToZero()
/*      */   {
/* 2203 */     return this.emptyStringsConvertToZero.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getEmulateLocators()
/*      */   {
/* 2210 */     return this.emulateLocators.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getEmulateUnsupportedPstmts()
/*      */   {
/* 2217 */     return this.emulateUnsupportedPstmts.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getEnablePacketDebug()
/*      */   {
/* 2224 */     return this.enablePacketDebug.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getEncoding()
/*      */   {
/* 2231 */     return this.characterEncodingAsString;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getExplainSlowQueries()
/*      */   {
/* 2238 */     return this.explainSlowQueries.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getFailOverReadOnly()
/*      */   {
/* 2245 */     return this.failOverReadOnly.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getGatherPerformanceMetrics()
/*      */   {
/* 2252 */     return this.gatherPerformanceMetrics.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean getHighAvailability()
/*      */   {
/* 2261 */     return this.highAvailabilityAsBoolean;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getHoldResultsOpenOverStatementClose()
/*      */   {
/* 2268 */     return this.holdResultsOpenOverStatementClose.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getIgnoreNonTxTables()
/*      */   {
/* 2275 */     return this.ignoreNonTxTables.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getInitialTimeout()
/*      */   {
/* 2282 */     return this.initialTimeout.getValueAsInt();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getInteractiveClient()
/*      */   {
/* 2289 */     return this.isInteractiveClient.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getIsInteractiveClient()
/*      */   {
/* 2296 */     return this.isInteractiveClient.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getJdbcCompliantTruncation()
/*      */   {
/* 2303 */     return this.jdbcCompliantTruncation.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getLocatorFetchBufferSize()
/*      */   {
/* 2310 */     return this.locatorFetchBufferSize.getValueAsInt();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getLogger()
/*      */   {
/* 2317 */     return this.loggerClassName.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getLoggerClassName()
/*      */   {
/* 2324 */     return this.loggerClassName.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getLogSlowQueries()
/*      */   {
/* 2331 */     return this.logSlowQueries.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getMaintainTimeStats()
/*      */   {
/* 2338 */     return this.maintainTimeStatsAsBoolean;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getMaxQuerySizeToLog()
/*      */   {
/* 2345 */     return this.maxQuerySizeToLog.getValueAsInt();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getMaxReconnects()
/*      */   {
/* 2352 */     return this.maxReconnects.getValueAsInt();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getMaxRows()
/*      */   {
/* 2359 */     return this.maxRowsAsInt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getMetadataCacheSize()
/*      */   {
/* 2366 */     return this.metadataCacheSize.getValueAsInt();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getNoDatetimeStringSync()
/*      */   {
/* 2373 */     return this.noDatetimeStringSync.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getNullCatalogMeansCurrent()
/*      */   {
/* 2380 */     return this.nullCatalogMeansCurrent.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getNullNamePatternMatchesAll()
/*      */   {
/* 2387 */     return this.nullNamePatternMatchesAll.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getPacketDebugBufferSize()
/*      */   {
/* 2394 */     return this.packetDebugBufferSize.getValueAsInt();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getParanoid()
/*      */   {
/* 2401 */     return this.paranoid.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getPedantic()
/*      */   {
/* 2408 */     return this.pedantic.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getPreparedStatementCacheSize()
/*      */   {
/* 2415 */     return ((Integer)this.preparedStatementCacheSize.getValueAsObject()).intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getPreparedStatementCacheSqlLimit()
/*      */   {
/* 2423 */     return ((Integer)this.preparedStatementCacheSqlLimit.getValueAsObject()).intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getProfileSql()
/*      */   {
/* 2431 */     return this.profileSQLAsBoolean;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getProfileSQL()
/*      */   {
/* 2438 */     return this.profileSQL.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getPropertiesTransform()
/*      */   {
/* 2445 */     return this.propertiesTransform.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getQueriesBeforeRetryMaster()
/*      */   {
/* 2452 */     return this.queriesBeforeRetryMaster.getValueAsInt();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getReconnectAtTxEnd()
/*      */   {
/* 2459 */     return this.reconnectTxAtEndAsBoolean;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getRelaxAutoCommit()
/*      */   {
/* 2466 */     return this.relaxAutoCommit.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getReportMetricsIntervalMillis()
/*      */   {
/* 2473 */     return this.reportMetricsIntervalMillis.getValueAsInt();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getRequireSSL()
/*      */   {
/* 2480 */     return this.requireSSL.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public boolean getRetainStatementAfterResultSetClose() {
/* 2484 */     return this.retainStatementAfterResultSetClose.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getRollbackOnPooledClose()
/*      */   {
/* 2491 */     return this.rollbackOnPooledClose.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getRoundRobinLoadBalance()
/*      */   {
/* 2498 */     return this.roundRobinLoadBalance.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getRunningCTS13()
/*      */   {
/* 2505 */     return this.runningCTS13.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getSecondsBeforeRetryMaster()
/*      */   {
/* 2512 */     return this.secondsBeforeRetryMaster.getValueAsInt();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getServerTimezone()
/*      */   {
/* 2519 */     return this.serverTimezone.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getSessionVariables()
/*      */   {
/* 2526 */     return this.sessionVariables.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getSlowQueryThresholdMillis()
/*      */   {
/* 2533 */     return this.slowQueryThresholdMillis.getValueAsInt();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getSocketFactoryClassName()
/*      */   {
/* 2540 */     return this.socketFactoryClassName.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getSocketTimeout()
/*      */   {
/* 2547 */     return this.socketTimeout.getValueAsInt();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getStrictFloatingPoint()
/*      */   {
/* 2554 */     return this.strictFloatingPoint.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getStrictUpdates()
/*      */   {
/* 2561 */     return this.strictUpdates.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getTinyInt1isBit()
/*      */   {
/* 2568 */     return this.tinyInt1isBit.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getTraceProtocol()
/*      */   {
/* 2575 */     return this.traceProtocol.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getTransformedBitIsBoolean()
/*      */   {
/* 2582 */     return this.transformedBitIsBoolean.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getUseCompression()
/*      */   {
/* 2591 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getUseFastIntParsing()
/*      */   {
/* 2598 */     return this.useFastIntParsing.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getUseHostsInPrivileges()
/*      */   {
/* 2605 */     return this.useHostsInPrivileges.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getUseInformationSchema()
/*      */   {
/* 2612 */     return this.useInformationSchema.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getUseLocalSessionState()
/*      */   {
/* 2619 */     return this.useLocalSessionState.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getUseOldUTF8Behavior()
/*      */   {
/* 2626 */     return this.useOldUTF8BehaviorAsBoolean;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getUseOnlyServerErrorMessages()
/*      */   {
/* 2633 */     return this.useOnlyServerErrorMessages.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getUseReadAheadInput()
/*      */   {
/* 2640 */     return this.useReadAheadInput.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getUseServerPreparedStmts()
/*      */   {
/* 2647 */     return this.detectServerPreparedStmts.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getUseSqlStateCodes()
/*      */   {
/* 2654 */     return this.useSqlStateCodes.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getUseSSL()
/*      */   {
/* 2661 */     return this.useSSL.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getUseStreamLengthsInPrepStmts()
/*      */   {
/* 2668 */     return this.useStreamLengthsInPrepStmts.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getUseTimezone()
/*      */   {
/* 2675 */     return this.useTimezone.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getUseUltraDevWorkAround()
/*      */   {
/* 2682 */     return this.useUltraDevWorkAround.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getUseUnbufferedInput()
/*      */   {
/* 2689 */     return this.useUnbufferedInput.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getUseUnicode()
/*      */   {
/* 2696 */     return this.useUnicodeAsBoolean;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getUseUsageAdvisor()
/*      */   {
/* 2703 */     return this.useUsageAdvisorAsBoolean;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getYearIsDateType()
/*      */   {
/* 2710 */     return this.yearIsDateType.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getZeroDateTimeBehavior()
/*      */   {
/* 2717 */     return this.zeroDateTimeBehavior.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void initializeFromRef(Reference ref)
/*      */     throws SQLException
/*      */   {
/* 2731 */     int numPropertiesToSet = PROPERTY_LIST.size();
/*      */     
/* 2733 */     for (int i = 0; i < numPropertiesToSet; i++) {
/* 2734 */       Field propertyField = (Field)PROPERTY_LIST.get(i);
/*      */       
/*      */       try
/*      */       {
/* 2738 */         ConnectionProperty propToSet = (ConnectionProperty)propertyField.get(this);
/*      */         
/*      */ 
/* 2741 */         if (ref != null) {
/* 2742 */           propToSet.initializeFrom(ref);
/*      */         }
/*      */       } catch (IllegalAccessException iae) {
/* 2745 */         throw SQLError.createSQLException("Internal properties failure", "S1000", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2750 */     postInitialization();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void initializeProperties(Properties info)
/*      */     throws SQLException
/*      */   {
/* 2763 */     if (info != null)
/*      */     {
/* 2765 */       String profileSqlLc = info.getProperty("profileSql");
/*      */       
/* 2767 */       if (profileSqlLc != null) {
/* 2768 */         info.put("profileSQL", profileSqlLc);
/*      */       }
/*      */       
/* 2771 */       Properties infoCopy = (Properties)info.clone();
/*      */       
/* 2773 */       infoCopy.remove("HOST");
/* 2774 */       infoCopy.remove("user");
/* 2775 */       infoCopy.remove("password");
/* 2776 */       infoCopy.remove("DBNAME");
/* 2777 */       infoCopy.remove("PORT");
/* 2778 */       infoCopy.remove("profileSql");
/*      */       
/* 2780 */       int numPropertiesToSet = PROPERTY_LIST.size();
/*      */       
/* 2782 */       for (int i = 0; i < numPropertiesToSet; i++) {
/* 2783 */         Field propertyField = (Field)PROPERTY_LIST.get(i);
/*      */         
/*      */         try
/*      */         {
/* 2787 */           ConnectionProperty propToSet = (ConnectionProperty)propertyField.get(this);
/*      */           
/*      */ 
/* 2790 */           propToSet.initializeFrom(infoCopy);
/*      */         } catch (IllegalAccessException iae) {
/* 2792 */           throw SQLError.createSQLException(Messages.getString("ConnectionProperties.unableToInitDriverProperties") + iae.toString(), "S1000", getExceptionInterceptor());
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2799 */       postInitialization();
/*      */     }
/*      */   }
/*      */   
/*      */   protected void postInitialization()
/*      */     throws SQLException
/*      */   {
/* 2806 */     if (this.profileSql.getValueAsObject() != null) {
/* 2807 */       this.profileSQL.initializeFrom(this.profileSql.getValueAsObject().toString());
/*      */     }
/*      */     
/*      */ 
/* 2811 */     this.reconnectTxAtEndAsBoolean = ((Boolean)this.reconnectAtTxEnd.getValueAsObject()).booleanValue();
/*      */     
/*      */ 
/*      */ 
/* 2815 */     if (getMaxRows() == 0)
/*      */     {
/*      */ 
/* 2818 */       this.maxRows.setValueAsObject(Integer.valueOf(-1));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2824 */     String testEncoding = getEncoding();
/*      */     
/* 2826 */     if (testEncoding != null)
/*      */     {
/*      */       try
/*      */       {
/* 2830 */         String testString = "abc";
/* 2831 */         StringUtils.getBytes(testString, testEncoding);
/*      */       } catch (UnsupportedEncodingException UE) {
/* 2833 */         throw SQLError.createSQLException(Messages.getString("ConnectionProperties.unsupportedCharacterEncoding", new Object[] { testEncoding }), "0S100", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2842 */     if (((Boolean)this.cacheResultSetMetadata.getValueAsObject()).booleanValue()) {
/*      */       try
/*      */       {
/* 2845 */         Class.forName("java.util.LinkedHashMap");
/*      */       } catch (ClassNotFoundException cnfe) {
/* 2847 */         this.cacheResultSetMetadata.setValue(false);
/*      */       }
/*      */     }
/*      */     
/* 2851 */     this.cacheResultSetMetaDataAsBoolean = this.cacheResultSetMetadata.getValueAsBoolean();
/*      */     
/* 2853 */     this.useUnicodeAsBoolean = this.useUnicode.getValueAsBoolean();
/* 2854 */     this.characterEncodingAsString = ((String)this.characterEncoding.getValueAsObject());
/*      */     
/* 2856 */     this.highAvailabilityAsBoolean = this.autoReconnect.getValueAsBoolean();
/* 2857 */     this.autoReconnectForPoolsAsBoolean = this.autoReconnectForPools.getValueAsBoolean();
/*      */     
/* 2859 */     this.maxRowsAsInt = ((Integer)this.maxRows.getValueAsObject()).intValue();
/*      */     
/* 2861 */     this.profileSQLAsBoolean = this.profileSQL.getValueAsBoolean();
/* 2862 */     this.useUsageAdvisorAsBoolean = this.useUsageAdvisor.getValueAsBoolean();
/*      */     
/* 2864 */     this.useOldUTF8BehaviorAsBoolean = this.useOldUTF8Behavior.getValueAsBoolean();
/*      */     
/* 2866 */     this.autoGenerateTestcaseScriptAsBoolean = this.autoGenerateTestcaseScript.getValueAsBoolean();
/*      */     
/* 2868 */     this.maintainTimeStatsAsBoolean = this.maintainTimeStats.getValueAsBoolean();
/*      */     
/* 2870 */     this.jdbcCompliantTruncationForReads = getJdbcCompliantTruncation();
/*      */     
/* 2872 */     if (getUseCursorFetch())
/*      */     {
/*      */ 
/* 2875 */       setDetectServerPreparedStmts(true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setAllowLoadLocalInfile(boolean property)
/*      */   {
/* 2883 */     this.allowLoadLocalInfile.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setAllowMultiQueries(boolean property)
/*      */   {
/* 2890 */     this.allowMultiQueries.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setAllowNanAndInf(boolean flag)
/*      */   {
/* 2897 */     this.allowNanAndInf.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setAllowUrlInLocalInfile(boolean flag)
/*      */   {
/* 2904 */     this.allowUrlInLocalInfile.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setAlwaysSendSetIsolation(boolean flag)
/*      */   {
/* 2911 */     this.alwaysSendSetIsolation.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setAutoDeserialize(boolean flag)
/*      */   {
/* 2918 */     this.autoDeserialize.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setAutoGenerateTestcaseScript(boolean flag)
/*      */   {
/* 2925 */     this.autoGenerateTestcaseScript.setValue(flag);
/* 2926 */     this.autoGenerateTestcaseScriptAsBoolean = this.autoGenerateTestcaseScript.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAutoReconnect(boolean flag)
/*      */   {
/* 2934 */     this.autoReconnect.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setAutoReconnectForConnectionPools(boolean property)
/*      */   {
/* 2941 */     this.autoReconnectForPools.setValue(property);
/* 2942 */     this.autoReconnectForPoolsAsBoolean = this.autoReconnectForPools.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAutoReconnectForPools(boolean flag)
/*      */   {
/* 2950 */     this.autoReconnectForPools.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBlobSendChunkSize(String value)
/*      */     throws SQLException
/*      */   {
/* 2957 */     this.blobSendChunkSize.setValue(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setCacheCallableStatements(boolean flag)
/*      */   {
/* 2964 */     this.cacheCallableStatements.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setCachePreparedStatements(boolean flag)
/*      */   {
/* 2971 */     this.cachePreparedStatements.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setCacheResultSetMetadata(boolean property)
/*      */   {
/* 2978 */     this.cacheResultSetMetadata.setValue(property);
/* 2979 */     this.cacheResultSetMetaDataAsBoolean = this.cacheResultSetMetadata.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCacheServerConfiguration(boolean flag)
/*      */   {
/* 2987 */     this.cacheServerConfiguration.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setCallableStatementCacheSize(int size)
/*      */   {
/* 2994 */     this.callableStatementCacheSize.setValue(size);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setCapitalizeDBMDTypes(boolean property)
/*      */   {
/* 3001 */     this.capitalizeTypeNames.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setCapitalizeTypeNames(boolean flag)
/*      */   {
/* 3008 */     this.capitalizeTypeNames.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setCharacterEncoding(String encoding)
/*      */   {
/* 3015 */     this.characterEncoding.setValue(encoding);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setCharacterSetResults(String characterSet)
/*      */   {
/* 3022 */     this.characterSetResults.setValue(characterSet);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setClobberStreamingResults(boolean flag)
/*      */   {
/* 3029 */     this.clobberStreamingResults.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setClobCharacterEncoding(String encoding)
/*      */   {
/* 3036 */     this.clobCharacterEncoding.setValue(encoding);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setConnectionCollation(String collation)
/*      */   {
/* 3043 */     this.connectionCollation.setValue(collation);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setConnectTimeout(int timeoutMs)
/*      */   {
/* 3050 */     this.connectTimeout.setValue(timeoutMs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setContinueBatchOnError(boolean property)
/*      */   {
/* 3057 */     this.continueBatchOnError.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setCreateDatabaseIfNotExist(boolean flag)
/*      */   {
/* 3064 */     this.createDatabaseIfNotExist.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setDefaultFetchSize(int n)
/*      */   {
/* 3071 */     this.defaultFetchSize.setValue(n);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setDetectServerPreparedStmts(boolean property)
/*      */   {
/* 3078 */     this.detectServerPreparedStmts.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setDontTrackOpenResources(boolean flag)
/*      */   {
/* 3085 */     this.dontTrackOpenResources.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setDumpQueriesOnException(boolean flag)
/*      */   {
/* 3092 */     this.dumpQueriesOnException.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setDynamicCalendars(boolean flag)
/*      */   {
/* 3099 */     this.dynamicCalendars.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setElideSetAutoCommits(boolean flag)
/*      */   {
/* 3106 */     this.elideSetAutoCommits.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setEmptyStringsConvertToZero(boolean flag)
/*      */   {
/* 3113 */     this.emptyStringsConvertToZero.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setEmulateLocators(boolean property)
/*      */   {
/* 3120 */     this.emulateLocators.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setEmulateUnsupportedPstmts(boolean flag)
/*      */   {
/* 3127 */     this.emulateUnsupportedPstmts.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setEnablePacketDebug(boolean flag)
/*      */   {
/* 3134 */     this.enablePacketDebug.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setEncoding(String property)
/*      */   {
/* 3141 */     this.characterEncoding.setValue(property);
/* 3142 */     this.characterEncodingAsString = this.characterEncoding.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setExplainSlowQueries(boolean flag)
/*      */   {
/* 3150 */     this.explainSlowQueries.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setFailOverReadOnly(boolean flag)
/*      */   {
/* 3157 */     this.failOverReadOnly.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setGatherPerformanceMetrics(boolean flag)
/*      */   {
/* 3164 */     this.gatherPerformanceMetrics.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setHighAvailability(boolean property)
/*      */   {
/* 3173 */     this.autoReconnect.setValue(property);
/* 3174 */     this.highAvailabilityAsBoolean = this.autoReconnect.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setHoldResultsOpenOverStatementClose(boolean flag)
/*      */   {
/* 3181 */     this.holdResultsOpenOverStatementClose.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setIgnoreNonTxTables(boolean property)
/*      */   {
/* 3188 */     this.ignoreNonTxTables.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setInitialTimeout(int property)
/*      */   {
/* 3195 */     this.initialTimeout.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setIsInteractiveClient(boolean property)
/*      */   {
/* 3202 */     this.isInteractiveClient.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setJdbcCompliantTruncation(boolean flag)
/*      */   {
/* 3209 */     this.jdbcCompliantTruncation.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setLocatorFetchBufferSize(String value)
/*      */     throws SQLException
/*      */   {
/* 3216 */     this.locatorFetchBufferSize.setValue(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setLogger(String property)
/*      */   {
/* 3223 */     this.loggerClassName.setValueAsObject(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setLoggerClassName(String className)
/*      */   {
/* 3230 */     this.loggerClassName.setValue(className);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setLogSlowQueries(boolean flag)
/*      */   {
/* 3237 */     this.logSlowQueries.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setMaintainTimeStats(boolean flag)
/*      */   {
/* 3244 */     this.maintainTimeStats.setValue(flag);
/* 3245 */     this.maintainTimeStatsAsBoolean = this.maintainTimeStats.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaxQuerySizeToLog(int sizeInBytes)
/*      */   {
/* 3253 */     this.maxQuerySizeToLog.setValue(sizeInBytes);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setMaxReconnects(int property)
/*      */   {
/* 3260 */     this.maxReconnects.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setMaxRows(int property)
/*      */   {
/* 3267 */     this.maxRows.setValue(property);
/* 3268 */     this.maxRowsAsInt = this.maxRows.getValueAsInt();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setMetadataCacheSize(int value)
/*      */   {
/* 3275 */     this.metadataCacheSize.setValue(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setNoDatetimeStringSync(boolean flag)
/*      */   {
/* 3282 */     this.noDatetimeStringSync.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setNullCatalogMeansCurrent(boolean value)
/*      */   {
/* 3289 */     this.nullCatalogMeansCurrent.setValue(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setNullNamePatternMatchesAll(boolean value)
/*      */   {
/* 3296 */     this.nullNamePatternMatchesAll.setValue(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setPacketDebugBufferSize(int size)
/*      */   {
/* 3303 */     this.packetDebugBufferSize.setValue(size);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setParanoid(boolean property)
/*      */   {
/* 3310 */     this.paranoid.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setPedantic(boolean property)
/*      */   {
/* 3317 */     this.pedantic.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setPreparedStatementCacheSize(int cacheSize)
/*      */   {
/* 3324 */     this.preparedStatementCacheSize.setValue(cacheSize);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setPreparedStatementCacheSqlLimit(int cacheSqlLimit)
/*      */   {
/* 3331 */     this.preparedStatementCacheSqlLimit.setValue(cacheSqlLimit);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setProfileSql(boolean property)
/*      */   {
/* 3338 */     this.profileSQL.setValue(property);
/* 3339 */     this.profileSQLAsBoolean = this.profileSQL.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setProfileSQL(boolean flag)
/*      */   {
/* 3346 */     this.profileSQL.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setPropertiesTransform(String value)
/*      */   {
/* 3353 */     this.propertiesTransform.setValue(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setQueriesBeforeRetryMaster(int property)
/*      */   {
/* 3360 */     this.queriesBeforeRetryMaster.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setReconnectAtTxEnd(boolean property)
/*      */   {
/* 3367 */     this.reconnectAtTxEnd.setValue(property);
/* 3368 */     this.reconnectTxAtEndAsBoolean = this.reconnectAtTxEnd.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRelaxAutoCommit(boolean property)
/*      */   {
/* 3376 */     this.relaxAutoCommit.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setReportMetricsIntervalMillis(int millis)
/*      */   {
/* 3383 */     this.reportMetricsIntervalMillis.setValue(millis);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setRequireSSL(boolean property)
/*      */   {
/* 3390 */     this.requireSSL.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setRetainStatementAfterResultSetClose(boolean flag)
/*      */   {
/* 3397 */     this.retainStatementAfterResultSetClose.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setRollbackOnPooledClose(boolean flag)
/*      */   {
/* 3404 */     this.rollbackOnPooledClose.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setRoundRobinLoadBalance(boolean flag)
/*      */   {
/* 3411 */     this.roundRobinLoadBalance.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setRunningCTS13(boolean flag)
/*      */   {
/* 3418 */     this.runningCTS13.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setSecondsBeforeRetryMaster(int property)
/*      */   {
/* 3425 */     this.secondsBeforeRetryMaster.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setServerTimezone(String property)
/*      */   {
/* 3432 */     this.serverTimezone.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setSessionVariables(String variables)
/*      */   {
/* 3439 */     this.sessionVariables.setValue(variables);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setSlowQueryThresholdMillis(int millis)
/*      */   {
/* 3446 */     this.slowQueryThresholdMillis.setValue(millis);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setSocketFactoryClassName(String property)
/*      */   {
/* 3453 */     this.socketFactoryClassName.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setSocketTimeout(int property)
/*      */   {
/* 3460 */     this.socketTimeout.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setStrictFloatingPoint(boolean property)
/*      */   {
/* 3467 */     this.strictFloatingPoint.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setStrictUpdates(boolean property)
/*      */   {
/* 3474 */     this.strictUpdates.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setTinyInt1isBit(boolean flag)
/*      */   {
/* 3481 */     this.tinyInt1isBit.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setTraceProtocol(boolean flag)
/*      */   {
/* 3488 */     this.traceProtocol.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setTransformedBitIsBoolean(boolean flag)
/*      */   {
/* 3495 */     this.transformedBitIsBoolean.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUseCompression(boolean property)
/*      */   {
/* 3502 */     this.useCompression.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUseFastIntParsing(boolean flag)
/*      */   {
/* 3509 */     this.useFastIntParsing.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUseHostsInPrivileges(boolean property)
/*      */   {
/* 3516 */     this.useHostsInPrivileges.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUseInformationSchema(boolean flag)
/*      */   {
/* 3523 */     this.useInformationSchema.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUseLocalSessionState(boolean flag)
/*      */   {
/* 3530 */     this.useLocalSessionState.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUseOldUTF8Behavior(boolean flag)
/*      */   {
/* 3537 */     this.useOldUTF8Behavior.setValue(flag);
/* 3538 */     this.useOldUTF8BehaviorAsBoolean = this.useOldUTF8Behavior.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseOnlyServerErrorMessages(boolean flag)
/*      */   {
/* 3546 */     this.useOnlyServerErrorMessages.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUseReadAheadInput(boolean flag)
/*      */   {
/* 3553 */     this.useReadAheadInput.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUseServerPreparedStmts(boolean flag)
/*      */   {
/* 3560 */     this.detectServerPreparedStmts.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUseSqlStateCodes(boolean flag)
/*      */   {
/* 3567 */     this.useSqlStateCodes.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUseSSL(boolean property)
/*      */   {
/* 3574 */     this.useSSL.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUseStreamLengthsInPrepStmts(boolean property)
/*      */   {
/* 3581 */     this.useStreamLengthsInPrepStmts.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUseTimezone(boolean property)
/*      */   {
/* 3588 */     this.useTimezone.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUseUltraDevWorkAround(boolean property)
/*      */   {
/* 3595 */     this.useUltraDevWorkAround.setValue(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUseUnbufferedInput(boolean flag)
/*      */   {
/* 3602 */     this.useUnbufferedInput.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUseUnicode(boolean flag)
/*      */   {
/* 3609 */     this.useUnicode.setValue(flag);
/* 3610 */     this.useUnicodeAsBoolean = this.useUnicode.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUseUsageAdvisor(boolean useUsageAdvisorFlag)
/*      */   {
/* 3617 */     this.useUsageAdvisor.setValue(useUsageAdvisorFlag);
/* 3618 */     this.useUsageAdvisorAsBoolean = this.useUsageAdvisor.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setYearIsDateType(boolean flag)
/*      */   {
/* 3626 */     this.yearIsDateType.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setZeroDateTimeBehavior(String behavior)
/*      */   {
/* 3633 */     this.zeroDateTimeBehavior.setValue(behavior);
/*      */   }
/*      */   
/*      */   protected void storeToRef(Reference ref) throws SQLException {
/* 3637 */     int numPropertiesToSet = PROPERTY_LIST.size();
/*      */     
/* 3639 */     for (int i = 0; i < numPropertiesToSet; i++) {
/* 3640 */       Field propertyField = (Field)PROPERTY_LIST.get(i);
/*      */       
/*      */       try
/*      */       {
/* 3644 */         ConnectionProperty propToStore = (ConnectionProperty)propertyField.get(this);
/*      */         
/*      */ 
/* 3647 */         if (ref != null) {
/* 3648 */           propToStore.storeTo(ref);
/*      */         }
/*      */       } catch (IllegalAccessException iae) {
/* 3651 */         throw SQLError.createSQLException(Messages.getString("ConnectionProperties.errorNotExpected"), getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean useUnbufferedInput()
/*      */   {
/* 3660 */     return this.useUnbufferedInput.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getUseCursorFetch()
/*      */   {
/* 3667 */     return this.useCursorFetch.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUseCursorFetch(boolean flag)
/*      */   {
/* 3674 */     this.useCursorFetch.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getOverrideSupportsIntegrityEnhancementFacility()
/*      */   {
/* 3681 */     return this.overrideSupportsIntegrityEnhancementFacility.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setOverrideSupportsIntegrityEnhancementFacility(boolean flag)
/*      */   {
/* 3688 */     this.overrideSupportsIntegrityEnhancementFacility.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getNoTimezoneConversionForTimeType()
/*      */   {
/* 3695 */     return this.noTimezoneConversionForTimeType.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setNoTimezoneConversionForTimeType(boolean flag)
/*      */   {
/* 3702 */     this.noTimezoneConversionForTimeType.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getUseJDBCCompliantTimezoneShift()
/*      */   {
/* 3709 */     return this.useJDBCCompliantTimezoneShift.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUseJDBCCompliantTimezoneShift(boolean flag)
/*      */   {
/* 3716 */     this.useJDBCCompliantTimezoneShift.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getAutoClosePStmtStreams()
/*      */   {
/* 3723 */     return this.autoClosePStmtStreams.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setAutoClosePStmtStreams(boolean flag)
/*      */   {
/* 3730 */     this.autoClosePStmtStreams.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getProcessEscapeCodesForPrepStmts()
/*      */   {
/* 3737 */     return this.processEscapeCodesForPrepStmts.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setProcessEscapeCodesForPrepStmts(boolean flag)
/*      */   {
/* 3744 */     this.processEscapeCodesForPrepStmts.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getUseGmtMillisForDatetimes()
/*      */   {
/* 3751 */     return this.useGmtMillisForDatetimes.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUseGmtMillisForDatetimes(boolean flag)
/*      */   {
/* 3758 */     this.useGmtMillisForDatetimes.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getDumpMetadataOnColumnNotFound()
/*      */   {
/* 3765 */     return this.dumpMetadataOnColumnNotFound.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setDumpMetadataOnColumnNotFound(boolean flag)
/*      */   {
/* 3772 */     this.dumpMetadataOnColumnNotFound.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getResourceId()
/*      */   {
/* 3779 */     return this.resourceId.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setResourceId(String resourceId)
/*      */   {
/* 3786 */     this.resourceId.setValue(resourceId);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getRewriteBatchedStatements()
/*      */   {
/* 3793 */     return this.rewriteBatchedStatements.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setRewriteBatchedStatements(boolean flag)
/*      */   {
/* 3800 */     this.rewriteBatchedStatements.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getJdbcCompliantTruncationForReads()
/*      */   {
/* 3807 */     return this.jdbcCompliantTruncationForReads;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setJdbcCompliantTruncationForReads(boolean jdbcCompliantTruncationForReads)
/*      */   {
/* 3815 */     this.jdbcCompliantTruncationForReads = jdbcCompliantTruncationForReads;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getUseJvmCharsetConverters()
/*      */   {
/* 3822 */     return this.useJvmCharsetConverters.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUseJvmCharsetConverters(boolean flag)
/*      */   {
/* 3829 */     this.useJvmCharsetConverters.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getPinGlobalTxToPhysicalConnection()
/*      */   {
/* 3836 */     return this.pinGlobalTxToPhysicalConnection.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setPinGlobalTxToPhysicalConnection(boolean flag)
/*      */   {
/* 3843 */     this.pinGlobalTxToPhysicalConnection.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setGatherPerfMetrics(boolean flag)
/*      */   {
/* 3855 */     setGatherPerformanceMetrics(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getGatherPerfMetrics()
/*      */   {
/* 3862 */     return getGatherPerformanceMetrics();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUltraDevHack(boolean flag)
/*      */   {
/* 3869 */     setUseUltraDevWorkAround(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getUltraDevHack()
/*      */   {
/* 3876 */     return getUseUltraDevWorkAround();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setInteractiveClient(boolean property)
/*      */   {
/* 3883 */     setIsInteractiveClient(property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setSocketFactory(String name)
/*      */   {
/* 3890 */     setSocketFactoryClassName(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getSocketFactory()
/*      */   {
/* 3897 */     return getSocketFactoryClassName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUseServerPrepStmts(boolean flag)
/*      */   {
/* 3904 */     setUseServerPreparedStmts(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getUseServerPrepStmts()
/*      */   {
/* 3911 */     return getUseServerPreparedStmts();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setCacheCallableStmts(boolean flag)
/*      */   {
/* 3918 */     setCacheCallableStatements(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getCacheCallableStmts()
/*      */   {
/* 3925 */     return getCacheCallableStatements();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setCachePrepStmts(boolean flag)
/*      */   {
/* 3932 */     setCachePreparedStatements(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getCachePrepStmts()
/*      */   {
/* 3939 */     return getCachePreparedStatements();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setCallableStmtCacheSize(int cacheSize)
/*      */   {
/* 3946 */     setCallableStatementCacheSize(cacheSize);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getCallableStmtCacheSize()
/*      */   {
/* 3953 */     return getCallableStatementCacheSize();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setPrepStmtCacheSize(int cacheSize)
/*      */   {
/* 3960 */     setPreparedStatementCacheSize(cacheSize);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getPrepStmtCacheSize()
/*      */   {
/* 3967 */     return getPreparedStatementCacheSize();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setPrepStmtCacheSqlLimit(int sqlLimit)
/*      */   {
/* 3974 */     setPreparedStatementCacheSqlLimit(sqlLimit);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getPrepStmtCacheSqlLimit()
/*      */   {
/* 3981 */     return getPreparedStatementCacheSqlLimit();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getNoAccessToProcedureBodies()
/*      */   {
/* 3988 */     return this.noAccessToProcedureBodies.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setNoAccessToProcedureBodies(boolean flag)
/*      */   {
/* 3995 */     this.noAccessToProcedureBodies.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getUseOldAliasMetadataBehavior()
/*      */   {
/* 4002 */     return this.useOldAliasMetadataBehavior.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUseOldAliasMetadataBehavior(boolean flag)
/*      */   {
/* 4009 */     this.useOldAliasMetadataBehavior.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getClientCertificateKeyStorePassword()
/*      */   {
/* 4016 */     return this.clientCertificateKeyStorePassword.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClientCertificateKeyStorePassword(String value)
/*      */   {
/* 4024 */     this.clientCertificateKeyStorePassword.setValue(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getClientCertificateKeyStoreType()
/*      */   {
/* 4031 */     return this.clientCertificateKeyStoreType.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClientCertificateKeyStoreType(String value)
/*      */   {
/* 4039 */     this.clientCertificateKeyStoreType.setValue(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getClientCertificateKeyStoreUrl()
/*      */   {
/* 4046 */     return this.clientCertificateKeyStoreUrl.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClientCertificateKeyStoreUrl(String value)
/*      */   {
/* 4054 */     this.clientCertificateKeyStoreUrl.setValue(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getTrustCertificateKeyStorePassword()
/*      */   {
/* 4061 */     return this.trustCertificateKeyStorePassword.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTrustCertificateKeyStorePassword(String value)
/*      */   {
/* 4069 */     this.trustCertificateKeyStorePassword.setValue(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getTrustCertificateKeyStoreType()
/*      */   {
/* 4076 */     return this.trustCertificateKeyStoreType.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTrustCertificateKeyStoreType(String value)
/*      */   {
/* 4084 */     this.trustCertificateKeyStoreType.setValue(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getTrustCertificateKeyStoreUrl()
/*      */   {
/* 4091 */     return this.trustCertificateKeyStoreUrl.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTrustCertificateKeyStoreUrl(String value)
/*      */   {
/* 4099 */     this.trustCertificateKeyStoreUrl.setValue(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getUseSSPSCompatibleTimezoneShift()
/*      */   {
/* 4106 */     return this.useSSPSCompatibleTimezoneShift.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUseSSPSCompatibleTimezoneShift(boolean flag)
/*      */   {
/* 4113 */     this.useSSPSCompatibleTimezoneShift.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getTreatUtilDateAsTimestamp()
/*      */   {
/* 4120 */     return this.treatUtilDateAsTimestamp.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setTreatUtilDateAsTimestamp(boolean flag)
/*      */   {
/* 4127 */     this.treatUtilDateAsTimestamp.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getUseFastDateParsing()
/*      */   {
/* 4134 */     return this.useFastDateParsing.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUseFastDateParsing(boolean flag)
/*      */   {
/* 4141 */     this.useFastDateParsing.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getLocalSocketAddress()
/*      */   {
/* 4148 */     return this.localSocketAddress.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setLocalSocketAddress(String address)
/*      */   {
/* 4155 */     this.localSocketAddress.setValue(address);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUseConfigs(String configs)
/*      */   {
/* 4162 */     this.useConfigs.setValue(configs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getUseConfigs()
/*      */   {
/* 4169 */     return this.useConfigs.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getGenerateSimpleParameterMetadata()
/*      */   {
/* 4177 */     return this.generateSimpleParameterMetadata.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setGenerateSimpleParameterMetadata(boolean flag)
/*      */   {
/* 4184 */     this.generateSimpleParameterMetadata.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getLogXaCommands()
/*      */   {
/* 4191 */     return this.logXaCommands.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setLogXaCommands(boolean flag)
/*      */   {
/* 4198 */     this.logXaCommands.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getResultSetSizeThreshold()
/*      */   {
/* 4205 */     return this.resultSetSizeThreshold.getValueAsInt();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setResultSetSizeThreshold(int threshold)
/*      */   {
/* 4212 */     this.resultSetSizeThreshold.setValue(threshold);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getNetTimeoutForStreamingResults()
/*      */   {
/* 4219 */     return this.netTimeoutForStreamingResults.getValueAsInt();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setNetTimeoutForStreamingResults(int value)
/*      */   {
/* 4226 */     this.netTimeoutForStreamingResults.setValue(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getEnableQueryTimeouts()
/*      */   {
/* 4233 */     return this.enableQueryTimeouts.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setEnableQueryTimeouts(boolean flag)
/*      */   {
/* 4240 */     this.enableQueryTimeouts.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getPadCharsWithSpace()
/*      */   {
/* 4247 */     return this.padCharsWithSpace.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setPadCharsWithSpace(boolean flag)
/*      */   {
/* 4254 */     this.padCharsWithSpace.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getUseDynamicCharsetInfo()
/*      */   {
/* 4261 */     return this.useDynamicCharsetInfo.getValueAsBoolean();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUseDynamicCharsetInfo(boolean flag)
/*      */   {
/* 4268 */     this.useDynamicCharsetInfo.setValue(flag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getClientInfoProvider()
/*      */   {
/* 4275 */     return this.clientInfoProvider.getValueAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setClientInfoProvider(String classname)
/*      */   {
/* 4282 */     this.clientInfoProvider.setValue(classname);
/*      */   }
/*      */   
/*      */   public boolean getPopulateInsertRowWithDefaultValues() {
/* 4286 */     return this.populateInsertRowWithDefaultValues.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setPopulateInsertRowWithDefaultValues(boolean flag) {
/* 4290 */     this.populateInsertRowWithDefaultValues.setValue(flag);
/*      */   }
/*      */   
/*      */   public String getLoadBalanceStrategy() {
/* 4294 */     return this.loadBalanceStrategy.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setLoadBalanceStrategy(String strategy) {
/* 4298 */     this.loadBalanceStrategy.setValue(strategy);
/*      */   }
/*      */   
/*      */   public boolean getTcpNoDelay() {
/* 4302 */     return this.tcpNoDelay.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setTcpNoDelay(boolean flag) {
/* 4306 */     this.tcpNoDelay.setValue(flag);
/*      */   }
/*      */   
/*      */   public boolean getTcpKeepAlive() {
/* 4310 */     return this.tcpKeepAlive.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setTcpKeepAlive(boolean flag) {
/* 4314 */     this.tcpKeepAlive.setValue(flag);
/*      */   }
/*      */   
/*      */   public int getTcpRcvBuf() {
/* 4318 */     return this.tcpRcvBuf.getValueAsInt();
/*      */   }
/*      */   
/*      */   public void setTcpRcvBuf(int bufSize) {
/* 4322 */     this.tcpRcvBuf.setValue(bufSize);
/*      */   }
/*      */   
/*      */   public int getTcpSndBuf() {
/* 4326 */     return this.tcpSndBuf.getValueAsInt();
/*      */   }
/*      */   
/*      */   public void setTcpSndBuf(int bufSize) {
/* 4330 */     this.tcpSndBuf.setValue(bufSize);
/*      */   }
/*      */   
/*      */   public int getTcpTrafficClass() {
/* 4334 */     return this.tcpTrafficClass.getValueAsInt();
/*      */   }
/*      */   
/*      */   public void setTcpTrafficClass(int classFlags) {
/* 4338 */     this.tcpTrafficClass.setValue(classFlags);
/*      */   }
/*      */   
/*      */   public boolean getUseNanosForElapsedTime() {
/* 4342 */     return this.useNanosForElapsedTime.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setUseNanosForElapsedTime(boolean flag) {
/* 4346 */     this.useNanosForElapsedTime.setValue(flag);
/*      */   }
/*      */   
/*      */   public long getSlowQueryThresholdNanos() {
/* 4350 */     return this.slowQueryThresholdNanos.getValueAsLong();
/*      */   }
/*      */   
/*      */   public void setSlowQueryThresholdNanos(long nanos) {
/* 4354 */     this.slowQueryThresholdNanos.setValue(nanos);
/*      */   }
/*      */   
/*      */   public String getStatementInterceptors() {
/* 4358 */     return this.statementInterceptors.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setStatementInterceptors(String value) {
/* 4362 */     this.statementInterceptors.setValue(value);
/*      */   }
/*      */   
/*      */   public boolean getUseDirectRowUnpack() {
/* 4366 */     return this.useDirectRowUnpack.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setUseDirectRowUnpack(boolean flag) {
/* 4370 */     this.useDirectRowUnpack.setValue(flag);
/*      */   }
/*      */   
/*      */   public String getLargeRowSizeThreshold() {
/* 4374 */     return this.largeRowSizeThreshold.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setLargeRowSizeThreshold(String value) {
/*      */     try {
/* 4379 */       this.largeRowSizeThreshold.setValue(value);
/*      */     } catch (SQLException sqlEx) {
/* 4381 */       RuntimeException ex = new RuntimeException(sqlEx.getMessage());
/* 4382 */       ex.initCause(sqlEx);
/*      */       
/* 4384 */       throw ex;
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean getUseBlobToStoreUTF8OutsideBMP() {
/* 4389 */     return this.useBlobToStoreUTF8OutsideBMP.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setUseBlobToStoreUTF8OutsideBMP(boolean flag) {
/* 4393 */     this.useBlobToStoreUTF8OutsideBMP.setValue(flag);
/*      */   }
/*      */   
/*      */   public String getUtf8OutsideBmpExcludedColumnNamePattern() {
/* 4397 */     return this.utf8OutsideBmpExcludedColumnNamePattern.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setUtf8OutsideBmpExcludedColumnNamePattern(String regexPattern) {
/* 4401 */     this.utf8OutsideBmpExcludedColumnNamePattern.setValue(regexPattern);
/*      */   }
/*      */   
/*      */   public String getUtf8OutsideBmpIncludedColumnNamePattern() {
/* 4405 */     return this.utf8OutsideBmpIncludedColumnNamePattern.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setUtf8OutsideBmpIncludedColumnNamePattern(String regexPattern) {
/* 4409 */     this.utf8OutsideBmpIncludedColumnNamePattern.setValue(regexPattern);
/*      */   }
/*      */   
/*      */   public boolean getIncludeInnodbStatusInDeadlockExceptions() {
/* 4413 */     return this.includeInnodbStatusInDeadlockExceptions.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setIncludeInnodbStatusInDeadlockExceptions(boolean flag) {
/* 4417 */     this.includeInnodbStatusInDeadlockExceptions.setValue(flag);
/*      */   }
/*      */   
/*      */   public boolean getBlobsAreStrings() {
/* 4421 */     return this.blobsAreStrings.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setBlobsAreStrings(boolean flag) {
/* 4425 */     this.blobsAreStrings.setValue(flag);
/*      */   }
/*      */   
/*      */   public boolean getFunctionsNeverReturnBlobs() {
/* 4429 */     return this.functionsNeverReturnBlobs.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setFunctionsNeverReturnBlobs(boolean flag) {
/* 4433 */     this.functionsNeverReturnBlobs.setValue(flag);
/*      */   }
/*      */   
/*      */   public boolean getAutoSlowLog() {
/* 4437 */     return this.autoSlowLog.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setAutoSlowLog(boolean flag) {
/* 4441 */     this.autoSlowLog.setValue(flag);
/*      */   }
/*      */   
/*      */   public String getConnectionLifecycleInterceptors() {
/* 4445 */     return this.connectionLifecycleInterceptors.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setConnectionLifecycleInterceptors(String interceptors) {
/* 4449 */     this.connectionLifecycleInterceptors.setValue(interceptors);
/*      */   }
/*      */   
/*      */   public String getProfilerEventHandler() {
/* 4453 */     return this.profilerEventHandler.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setProfilerEventHandler(String handler) {
/* 4457 */     this.profilerEventHandler.setValue(handler);
/*      */   }
/*      */   
/*      */   public boolean getVerifyServerCertificate() {
/* 4461 */     return this.verifyServerCertificate.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setVerifyServerCertificate(boolean flag) {
/* 4465 */     this.verifyServerCertificate.setValue(flag);
/*      */   }
/*      */   
/*      */   public boolean getUseLegacyDatetimeCode() {
/* 4469 */     return this.useLegacyDatetimeCode.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setUseLegacyDatetimeCode(boolean flag) {
/* 4473 */     this.useLegacyDatetimeCode.setValue(flag);
/*      */   }
/*      */   
/*      */   public int getSelfDestructOnPingSecondsLifetime() {
/* 4477 */     return this.selfDestructOnPingSecondsLifetime.getValueAsInt();
/*      */   }
/*      */   
/*      */   public void setSelfDestructOnPingSecondsLifetime(int seconds) {
/* 4481 */     this.selfDestructOnPingSecondsLifetime.setValue(seconds);
/*      */   }
/*      */   
/*      */   public int getSelfDestructOnPingMaxOperations() {
/* 4485 */     return this.selfDestructOnPingMaxOperations.getValueAsInt();
/*      */   }
/*      */   
/*      */   public void setSelfDestructOnPingMaxOperations(int maxOperations) {
/* 4489 */     this.selfDestructOnPingMaxOperations.setValue(maxOperations);
/*      */   }
/*      */   
/*      */   public boolean getUseColumnNamesInFindColumn() {
/* 4493 */     return this.useColumnNamesInFindColumn.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setUseColumnNamesInFindColumn(boolean flag) {
/* 4497 */     this.useColumnNamesInFindColumn.setValue(flag);
/*      */   }
/*      */   
/*      */   public boolean getUseLocalTransactionState() {
/* 4501 */     return this.useLocalTransactionState.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setUseLocalTransactionState(boolean flag) {
/* 4505 */     this.useLocalTransactionState.setValue(flag);
/*      */   }
/*      */   
/*      */   public boolean getCompensateOnDuplicateKeyUpdateCounts() {
/* 4509 */     return this.compensateOnDuplicateKeyUpdateCounts.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setCompensateOnDuplicateKeyUpdateCounts(boolean flag) {
/* 4513 */     this.compensateOnDuplicateKeyUpdateCounts.setValue(flag);
/*      */   }
/*      */   
/*      */   public int getLoadBalanceBlacklistTimeout() {
/* 4517 */     return this.loadBalanceBlacklistTimeout.getValueAsInt();
/*      */   }
/*      */   
/*      */   public void setLoadBalanceBlacklistTimeout(int loadBalanceBlacklistTimeout) {
/* 4521 */     this.loadBalanceBlacklistTimeout.setValue(loadBalanceBlacklistTimeout);
/*      */   }
/*      */   
/*      */   public int getLoadBalancePingTimeout() {
/* 4525 */     return this.loadBalancePingTimeout.getValueAsInt();
/*      */   }
/*      */   
/*      */   public void setLoadBalancePingTimeout(int loadBalancePingTimeout) {
/* 4529 */     this.loadBalancePingTimeout.setValue(loadBalancePingTimeout);
/*      */   }
/*      */   
/*      */   public void setRetriesAllDown(int retriesAllDown) {
/* 4533 */     this.retriesAllDown.setValue(retriesAllDown);
/*      */   }
/*      */   
/*      */   public int getRetriesAllDown() {
/* 4537 */     return this.retriesAllDown.getValueAsInt();
/*      */   }
/*      */   
/*      */   public void setUseAffectedRows(boolean flag) {
/* 4541 */     this.useAffectedRows.setValue(flag);
/*      */   }
/*      */   
/*      */   public boolean getUseAffectedRows() {
/* 4545 */     return this.useAffectedRows.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setPasswordCharacterEncoding(String characterSet) {
/* 4549 */     this.passwordCharacterEncoding.setValue(characterSet);
/*      */   }
/*      */   
/*      */   public String getPasswordCharacterEncoding() {
/* 4553 */     return this.passwordCharacterEncoding.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setExceptionInterceptors(String exceptionInterceptors) {
/* 4557 */     this.exceptionInterceptors.setValue(exceptionInterceptors);
/*      */   }
/*      */   
/*      */   public String getExceptionInterceptors() {
/* 4561 */     return this.exceptionInterceptors.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setMaxAllowedPacket(int max) {
/* 4565 */     this.maxAllowedPacket.setValue(max);
/*      */   }
/*      */   
/*      */   public int getMaxAllowedPacket() {
/* 4569 */     return this.maxAllowedPacket.getValueAsInt();
/*      */   }
/*      */   
/*      */   public boolean getQueryTimeoutKillsConnection() {
/* 4573 */     return this.queryTimeoutKillsConnection.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setQueryTimeoutKillsConnection(boolean queryTimeoutKillsConnection) {
/* 4577 */     this.queryTimeoutKillsConnection.setValue(queryTimeoutKillsConnection);
/*      */   }
/*      */   
/*      */   public boolean getLoadBalanceValidateConnectionOnSwapServer() {
/* 4581 */     return this.loadBalanceValidateConnectionOnSwapServer.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setLoadBalanceValidateConnectionOnSwapServer(boolean loadBalanceValidateConnectionOnSwapServer)
/*      */   {
/* 4586 */     this.loadBalanceValidateConnectionOnSwapServer.setValue(loadBalanceValidateConnectionOnSwapServer);
/*      */   }
/*      */   
/*      */   public String getLoadBalanceConnectionGroup()
/*      */   {
/* 4591 */     return this.loadBalanceConnectionGroup.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setLoadBalanceConnectionGroup(String loadBalanceConnectionGroup) {
/* 4595 */     this.loadBalanceConnectionGroup.setValue(loadBalanceConnectionGroup);
/*      */   }
/*      */   
/*      */   public String getLoadBalanceExceptionChecker() {
/* 4599 */     return this.loadBalanceExceptionChecker.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setLoadBalanceExceptionChecker(String loadBalanceExceptionChecker) {
/* 4603 */     this.loadBalanceExceptionChecker.setValue(loadBalanceExceptionChecker);
/*      */   }
/*      */   
/*      */   public String getLoadBalanceSQLStateFailover() {
/* 4607 */     return this.loadBalanceSQLStateFailover.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setLoadBalanceSQLStateFailover(String loadBalanceSQLStateFailover) {
/* 4611 */     this.loadBalanceSQLStateFailover.setValue(loadBalanceSQLStateFailover);
/*      */   }
/*      */   
/*      */   public String getLoadBalanceSQLExceptionSubclassFailover() {
/* 4615 */     return this.loadBalanceSQLExceptionSubclassFailover.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setLoadBalanceSQLExceptionSubclassFailover(String loadBalanceSQLExceptionSubclassFailover) {
/* 4619 */     this.loadBalanceSQLExceptionSubclassFailover.setValue(loadBalanceSQLExceptionSubclassFailover);
/*      */   }
/*      */   
/*      */   public boolean getLoadBalanceEnableJMX() {
/* 4623 */     return this.loadBalanceEnableJMX.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setLoadBalanceEnableJMX(boolean loadBalanceEnableJMX) {
/* 4627 */     this.loadBalanceEnableJMX.setValue(loadBalanceEnableJMX);
/*      */   }
/*      */   
/*      */   public void setLoadBalanceAutoCommitStatementThreshold(int loadBalanceAutoCommitStatementThreshold) {
/* 4631 */     this.loadBalanceAutoCommitStatementThreshold.setValue(loadBalanceAutoCommitStatementThreshold);
/*      */   }
/*      */   
/*      */   public int getLoadBalanceAutoCommitStatementThreshold() {
/* 4635 */     return this.loadBalanceAutoCommitStatementThreshold.getValueAsInt();
/*      */   }
/*      */   
/*      */   public void setLoadBalanceAutoCommitStatementRegex(String loadBalanceAutoCommitStatementRegex) {
/* 4639 */     this.loadBalanceAutoCommitStatementRegex.setValue(loadBalanceAutoCommitStatementRegex);
/*      */   }
/*      */   
/*      */   public String getLoadBalanceAutoCommitStatementRegex() {
/* 4643 */     return this.loadBalanceAutoCommitStatementRegex.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setIncludeThreadDumpInDeadlockExceptions(boolean flag) {
/* 4647 */     this.includeThreadDumpInDeadlockExceptions.setValue(flag);
/*      */   }
/*      */   
/*      */   public boolean getIncludeThreadDumpInDeadlockExceptions() {
/* 4651 */     return this.includeThreadDumpInDeadlockExceptions.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setIncludeThreadNamesAsStatementComment(boolean flag) {
/* 4655 */     this.includeThreadNamesAsStatementComment.setValue(flag);
/*      */   }
/*      */   
/*      */   public boolean getIncludeThreadNamesAsStatementComment() {
/* 4659 */     return this.includeThreadNamesAsStatementComment.getValueAsBoolean();
/*      */   }
/*      */   
/*      */   public void setAuthenticationPlugins(String authenticationPlugins) {
/* 4663 */     this.authenticationPlugins.setValue(authenticationPlugins);
/*      */   }
/*      */   
/*      */   public String getAuthenticationPlugins() {
/* 4667 */     return this.authenticationPlugins.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setDisabledAuthenticationPlugins(String disabledAuthenticationPlugins) {
/* 4671 */     this.disabledAuthenticationPlugins.setValue(disabledAuthenticationPlugins);
/*      */   }
/*      */   
/*      */   public String getDisabledAuthenticationPlugins() {
/* 4675 */     return this.disabledAuthenticationPlugins.getValueAsString();
/*      */   }
/*      */   
/*      */   public void setDefaultAuthenticationPlugin(String defaultAuthenticationPlugin) {
/* 4679 */     this.defaultAuthenticationPlugin.setValue(defaultAuthenticationPlugin);
/*      */   }
/*      */   
/*      */   public String getDefaultAuthenticationPlugin()
/*      */   {
/* 4684 */     return this.defaultAuthenticationPlugin.getValueAsString();
/*      */   }
/*      */ }


/* Location:              C:\Users\Static\Desktop\G10_Prototype_Client.jar!\mysql-connector-java-5.1.19-bin.jar!\com\mysql\jdbc\ConnectionPropertiesImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */