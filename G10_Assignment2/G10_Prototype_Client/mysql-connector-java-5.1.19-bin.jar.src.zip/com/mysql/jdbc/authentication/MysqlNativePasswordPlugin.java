/*     */ package com.mysql.jdbc.authentication;
/*     */ 
/*     */ import com.mysql.jdbc.AuthenticationPlugin;
/*     */ import com.mysql.jdbc.Buffer;
/*     */ import com.mysql.jdbc.Connection;
/*     */ import com.mysql.jdbc.Messages;
/*     */ import com.mysql.jdbc.SQLError;
/*     */ import com.mysql.jdbc.Security;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MysqlNativePasswordPlugin
/*     */   implements AuthenticationPlugin
/*     */ {
/*     */   private Connection connection;
/*     */   private Properties properties;
/*  47 */   private String password = null;
/*     */   
/*     */   public void init(Connection conn, Properties props) throws SQLException {
/*  50 */     this.connection = conn;
/*  51 */     this.properties = props;
/*     */   }
/*     */   
/*     */   public void destroy() {
/*  55 */     this.password = null;
/*     */   }
/*     */   
/*     */   public String getProtocolPluginName() {
/*  59 */     return "mysql_native_password";
/*     */   }
/*     */   
/*     */   public boolean requiresConfidentiality() {
/*  63 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isReusable() {
/*  67 */     return true;
/*     */   }
/*     */   
/*     */   public void setAuthenticationParameters(String user, String password) {
/*  71 */     this.password = password;
/*     */   }
/*     */   
/*     */   public boolean nextAuthenticationStep(Buffer fromServer, List<Buffer> toServer) throws SQLException
/*     */   {
/*     */     try {
/*  77 */       toServer.clear();
/*     */       
/*  79 */       Buffer bresp = null;
/*     */       
/*  81 */       String pwd = this.password;
/*  82 */       if (pwd == null) { pwd = this.properties.getProperty("password");
/*     */       }
/*  84 */       if ((fromServer == null) || (pwd == null) || (pwd.length() == 0)) {
/*  85 */         bresp = new Buffer(new byte[0]);
/*     */       } else {
/*  87 */         bresp = new Buffer(Security.scramble411(pwd, fromServer.readString(), this.connection));
/*     */       }
/*  89 */       toServer.add(bresp);
/*     */     }
/*     */     catch (NoSuchAlgorithmException nse) {
/*  92 */       throw SQLError.createSQLException(Messages.getString("MysqlIO.95") + Messages.getString("MysqlIO.96"), "S1000", null);
/*     */     }
/*     */     catch (UnsupportedEncodingException e)
/*     */     {
/*  96 */       throw SQLError.createSQLException(Messages.getString("MysqlIO.95") + Messages.getString("MysqlIO.96"), "S1000", null);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 101 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Static\Desktop\G10_Prototype_Client.jar!\mysql-connector-java-5.1.19-bin.jar!\com\mysql\jdbc\authentication\MysqlNativePasswordPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */