/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import com.mysql.jdbc.profiler.ProfilerEventHandler;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.Date;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class UpdatableResultSet
/*      */   extends ResultSetImpl
/*      */ {
/*   47 */   static final byte[] STREAM_DATA_MARKER = StringUtils.getBytes("** STREAM DATA **");
/*      */   
/*      */ 
/*      */   protected SingleByteCharsetConverter charConverter;
/*      */   
/*      */ 
/*      */   private String charEncoding;
/*      */   
/*      */   private byte[][] defaultColumnValue;
/*      */   
/*   57 */   private PreparedStatement deleter = null;
/*      */   
/*   59 */   private String deleteSQL = null;
/*      */   
/*   61 */   private boolean initializedCharConverter = false;
/*      */   
/*      */ 
/*   64 */   protected PreparedStatement inserter = null;
/*      */   
/*   66 */   private String insertSQL = null;
/*      */   
/*      */ 
/*   69 */   private boolean isUpdatable = false;
/*      */   
/*      */ 
/*   72 */   private String notUpdatableReason = null;
/*      */   
/*      */ 
/*   75 */   private List primaryKeyIndicies = null;
/*      */   
/*      */   private String qualifiedAndQuotedTableName;
/*      */   
/*   79 */   private String quotedIdChar = null;
/*      */   
/*      */ 
/*      */   private PreparedStatement refresher;
/*      */   
/*   84 */   private String refreshSQL = null;
/*      */   
/*      */ 
/*      */   private ResultSetRow savedCurrentRow;
/*      */   
/*      */ 
/*   90 */   protected PreparedStatement updater = null;
/*      */   
/*      */ 
/*   93 */   private String updateSQL = null;
/*      */   
/*   95 */   private boolean populateInserterWithDefaultValues = false;
/*      */   
/*   97 */   private Map databasesUsedToTablesUsed = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected UpdatableResultSet(String catalog, Field[] fields, RowData tuples, MySQLConnection conn, StatementImpl creatorStmt)
/*      */     throws SQLException
/*      */   {
/*  119 */     super(catalog, fields, tuples, conn, creatorStmt);
/*  120 */     checkUpdatability();
/*  121 */     this.populateInserterWithDefaultValues = this.connection.getPopulateInsertRowWithDefaultValues();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean absolute(int row)
/*      */     throws SQLException
/*      */   {
/*  164 */     return super.absolute(row);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void afterLast()
/*      */     throws SQLException
/*      */   {
/*  180 */     super.afterLast();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void beforeFirst()
/*      */     throws SQLException
/*      */   {
/*  196 */     super.beforeFirst();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void cancelRowUpdates()
/*      */     throws SQLException
/*      */   {
/*  210 */     checkClosed();
/*      */     
/*  212 */     if (this.doingUpdates) {
/*  213 */       this.doingUpdates = false;
/*  214 */       this.updater.clearParameters();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void checkRowPos()
/*      */     throws SQLException
/*      */   {
/*  224 */     checkClosed();
/*      */     
/*  226 */     if (!this.onInsertRow) {
/*  227 */       super.checkRowPos();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void checkUpdatability()
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  239 */       if (this.fields == null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  246 */         return;
/*      */       }
/*      */       
/*  249 */       String singleTableName = null;
/*  250 */       String catalogName = null;
/*      */       
/*  252 */       int primaryKeyCount = 0;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  259 */       if ((this.catalog == null) || (this.catalog.length() == 0)) {
/*  260 */         this.catalog = this.fields[0].getDatabaseName();
/*      */         
/*  262 */         if ((this.catalog == null) || (this.catalog.length() == 0)) {
/*  263 */           throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.43"), "S1009", getExceptionInterceptor());
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  269 */       if (this.fields.length > 0) {
/*  270 */         singleTableName = this.fields[0].getOriginalTableName();
/*  271 */         catalogName = this.fields[0].getDatabaseName();
/*      */         
/*  273 */         if (singleTableName == null) {
/*  274 */           singleTableName = this.fields[0].getTableName();
/*  275 */           catalogName = this.catalog;
/*      */         }
/*      */         
/*  278 */         if ((singleTableName != null) && (singleTableName.length() == 0)) {
/*  279 */           this.isUpdatable = false;
/*  280 */           this.notUpdatableReason = Messages.getString("NotUpdatableReason.3");
/*      */           
/*  282 */           return;
/*      */         }
/*      */         
/*  285 */         if (this.fields[0].isPrimaryKey()) {
/*  286 */           primaryKeyCount++;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  292 */         for (int i = 1; i < this.fields.length; i++) {
/*  293 */           String otherTableName = this.fields[i].getOriginalTableName();
/*  294 */           String otherCatalogName = this.fields[i].getDatabaseName();
/*      */           
/*  296 */           if (otherTableName == null) {
/*  297 */             otherTableName = this.fields[i].getTableName();
/*  298 */             otherCatalogName = this.catalog;
/*      */           }
/*      */           
/*  301 */           if ((otherTableName != null) && (otherTableName.length() == 0)) {
/*  302 */             this.isUpdatable = false;
/*  303 */             this.notUpdatableReason = Messages.getString("NotUpdatableReason.3");
/*      */             
/*  305 */             return;
/*      */           }
/*      */           
/*  308 */           if ((singleTableName == null) || (!otherTableName.equals(singleTableName)))
/*      */           {
/*  310 */             this.isUpdatable = false;
/*  311 */             this.notUpdatableReason = Messages.getString("NotUpdatableReason.0");
/*      */             
/*  313 */             return;
/*      */           }
/*      */           
/*      */ 
/*  317 */           if ((catalogName == null) || (!otherCatalogName.equals(catalogName)))
/*      */           {
/*  319 */             this.isUpdatable = false;
/*  320 */             this.notUpdatableReason = Messages.getString("NotUpdatableReason.1");
/*      */             
/*  322 */             return;
/*      */           }
/*      */           
/*  325 */           if (this.fields[i].isPrimaryKey()) {
/*  326 */             primaryKeyCount++;
/*      */           }
/*      */         }
/*      */         
/*  330 */         if ((singleTableName == null) || (singleTableName.length() == 0)) {
/*  331 */           this.isUpdatable = false;
/*  332 */           this.notUpdatableReason = Messages.getString("NotUpdatableReason.2");
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  337 */         this.isUpdatable = false;
/*  338 */         this.notUpdatableReason = Messages.getString("NotUpdatableReason.3");
/*      */         
/*  340 */         return;
/*      */       }
/*      */       
/*  343 */       if (this.connection.getStrictUpdates()) {
/*  344 */         DatabaseMetaData dbmd = this.connection.getMetaData();
/*      */         
/*  346 */         ResultSet rs = null;
/*  347 */         HashMap primaryKeyNames = new HashMap();
/*      */         try
/*      */         {
/*  350 */           rs = dbmd.getPrimaryKeys(catalogName, null, singleTableName);
/*      */           
/*  352 */           while (rs.next()) {
/*  353 */             String keyName = rs.getString(4);
/*  354 */             keyName = keyName.toUpperCase();
/*  355 */             primaryKeyNames.put(keyName, keyName);
/*      */           }
/*      */         } finally {
/*  358 */           if (rs != null) {
/*      */             try {
/*  360 */               rs.close();
/*      */             } catch (Exception ex) {
/*  362 */               AssertionFailedException.shouldNotHappen(ex);
/*      */             }
/*      */             
/*  365 */             rs = null;
/*      */           }
/*      */         }
/*      */         
/*  369 */         int existingPrimaryKeysCount = primaryKeyNames.size();
/*      */         
/*  371 */         if (existingPrimaryKeysCount == 0) {
/*  372 */           this.isUpdatable = false;
/*  373 */           this.notUpdatableReason = Messages.getString("NotUpdatableReason.5");
/*      */           
/*  375 */           return;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  381 */         for (int i = 0; i < this.fields.length; i++) {
/*  382 */           if (this.fields[i].isPrimaryKey()) {
/*  383 */             String columnNameUC = this.fields[i].getName().toUpperCase();
/*      */             
/*      */ 
/*  386 */             if (primaryKeyNames.remove(columnNameUC) == null)
/*      */             {
/*  388 */               String originalName = this.fields[i].getOriginalName();
/*      */               
/*  390 */               if ((originalName != null) && 
/*  391 */                 (primaryKeyNames.remove(originalName.toUpperCase()) == null))
/*      */               {
/*      */ 
/*  394 */                 this.isUpdatable = false;
/*  395 */                 this.notUpdatableReason = Messages.getString("NotUpdatableReason.6", new Object[] { originalName });
/*      */                 
/*      */ 
/*  398 */                 return;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*  405 */         this.isUpdatable = primaryKeyNames.isEmpty();
/*      */         
/*  407 */         if (!this.isUpdatable) {
/*  408 */           if (existingPrimaryKeysCount > 1) {
/*  409 */             this.notUpdatableReason = Messages.getString("NotUpdatableReason.7");
/*      */           } else {
/*  411 */             this.notUpdatableReason = Messages.getString("NotUpdatableReason.4");
/*      */           }
/*      */           
/*  414 */           return;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  421 */       if (primaryKeyCount == 0) {
/*  422 */         this.isUpdatable = false;
/*  423 */         this.notUpdatableReason = Messages.getString("NotUpdatableReason.4");
/*      */         
/*  425 */         return;
/*      */       }
/*      */       
/*  428 */       this.isUpdatable = true;
/*  429 */       this.notUpdatableReason = null;
/*      */       
/*  431 */       return;
/*      */     } catch (SQLException sqlEx) {
/*  433 */       this.isUpdatable = false;
/*  434 */       this.notUpdatableReason = sqlEx.getMessage();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void deleteRow()
/*      */     throws SQLException
/*      */   {
/*  449 */     checkClosed();
/*      */     
/*  451 */     if (!this.isUpdatable) {
/*  452 */       throw new NotUpdatable(this.notUpdatableReason);
/*      */     }
/*      */     
/*  455 */     if (this.onInsertRow)
/*  456 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.1"), getExceptionInterceptor());
/*  457 */     if (this.rowData.size() == 0)
/*  458 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.2"), getExceptionInterceptor());
/*  459 */     if (isBeforeFirst())
/*  460 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.3"), getExceptionInterceptor());
/*  461 */     if (isAfterLast()) {
/*  462 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.4"), getExceptionInterceptor());
/*      */     }
/*      */     
/*  465 */     if (this.deleter == null) {
/*  466 */       if (this.deleteSQL == null) {
/*  467 */         generateStatements();
/*      */       }
/*      */       
/*  470 */       this.deleter = ((PreparedStatement)this.connection.clientPrepareStatement(this.deleteSQL));
/*      */     }
/*      */     
/*      */ 
/*  474 */     this.deleter.clearParameters();
/*      */     
/*  476 */     int numKeys = this.primaryKeyIndicies.size();
/*      */     
/*  478 */     if (numKeys == 1) {
/*  479 */       int index = ((Integer)this.primaryKeyIndicies.get(0)).intValue();
/*      */       
/*  481 */       setParamValue(this.deleter, 1, this.thisRow, index, this.fields[index].getSQLType());
/*      */     }
/*      */     else {
/*  484 */       for (int i = 0; i < numKeys; i++) {
/*  485 */         int index = ((Integer)this.primaryKeyIndicies.get(i)).intValue();
/*      */         
/*  487 */         setParamValue(this.deleter, i + 1, this.thisRow, index, this.fields[index].getSQLType());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  493 */     this.deleter.executeUpdate();
/*  494 */     this.rowData.removeRow(this.rowData.getCurrentRowNumber());
/*      */     
/*      */ 
/*  497 */     previous();
/*      */   }
/*      */   
/*      */ 
/*      */   private synchronized void setParamValue(PreparedStatement ps, int psIdx, ResultSetRow row, int rsIdx, int sqlType)
/*      */     throws SQLException
/*      */   {
/*  504 */     byte[] val = row.getColumnValue(rsIdx);
/*  505 */     if (val == null) {
/*  506 */       ps.setNull(psIdx, 0);
/*  507 */       return;
/*      */     }
/*  509 */     switch (sqlType) {
/*      */     case 0: 
/*  511 */       ps.setNull(psIdx, 0);
/*  512 */       break;
/*      */     case -6: 
/*      */     case 4: 
/*      */     case 5: 
/*  516 */       ps.setInt(psIdx, row.getInt(rsIdx));
/*  517 */       break;
/*      */     case -5: 
/*  519 */       ps.setLong(psIdx, row.getLong(rsIdx));
/*  520 */       break;
/*      */     case -1: 
/*      */     case 1: 
/*      */     case 2: 
/*      */     case 3: 
/*      */     case 12: 
/*  526 */       ps.setString(psIdx, row.getString(rsIdx, this.charEncoding, this.connection));
/*  527 */       break;
/*      */     case 91: 
/*  529 */       ps.setDate(psIdx, row.getDateFast(rsIdx, this.connection, this, this.fastDateCal), this.fastDateCal);
/*  530 */       break;
/*      */     case 93: 
/*  532 */       ps.setTimestamp(psIdx, row.getTimestampFast(rsIdx, this.fastDateCal, this.defaultTimeZone, false, this.connection, this));
/*  533 */       break;
/*      */     case 92: 
/*  535 */       ps.setTime(psIdx, row.getTimeFast(rsIdx, this.fastDateCal, this.defaultTimeZone, false, this.connection, this));
/*  536 */       break;
/*      */     case 6: 
/*      */     case 7: 
/*      */     case 8: 
/*      */     case 16: 
/*  541 */       ps.setBytesNoEscapeNoQuotes(psIdx, val);
/*  542 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     default: 
/*  548 */       ps.setBytes(psIdx, val);
/*      */     }
/*      */   }
/*      */   
/*      */   private synchronized void extractDefaultValues()
/*      */     throws SQLException
/*      */   {
/*  555 */     DatabaseMetaData dbmd = this.connection.getMetaData();
/*  556 */     this.defaultColumnValue = new byte[this.fields.length][];
/*      */     
/*  558 */     ResultSet columnsResultSet = null;
/*  559 */     Iterator referencedDbs = this.databasesUsedToTablesUsed.entrySet().iterator();
/*      */     
/*  561 */     while (referencedDbs.hasNext()) {
/*  562 */       Map.Entry dbEntry = (Map.Entry)referencedDbs.next();
/*  563 */       String databaseName = dbEntry.getKey().toString();
/*      */       
/*  565 */       Iterator referencedTables = ((Map)dbEntry.getValue()).entrySet().iterator();
/*      */       
/*  567 */       while (referencedTables.hasNext()) {
/*  568 */         Map.Entry tableEntry = (Map.Entry)referencedTables.next();
/*  569 */         String tableName = tableEntry.getKey().toString();
/*  570 */         Map columnNamesToIndices = (Map)tableEntry.getValue();
/*      */         try
/*      */         {
/*  573 */           columnsResultSet = dbmd.getColumns(this.catalog, null, tableName, "%");
/*      */           
/*      */ 
/*  576 */           while (columnsResultSet.next()) {
/*  577 */             String columnName = columnsResultSet.getString("COLUMN_NAME");
/*  578 */             byte[] defaultValue = columnsResultSet.getBytes("COLUMN_DEF");
/*      */             
/*  580 */             if (columnNamesToIndices.containsKey(columnName)) {
/*  581 */               int localColumnIndex = ((Integer)columnNamesToIndices.get(columnName)).intValue();
/*      */               
/*  583 */               this.defaultColumnValue[localColumnIndex] = defaultValue;
/*      */             }
/*      */           }
/*      */         } finally {
/*  587 */           if (columnsResultSet != null) {
/*  588 */             columnsResultSet.close();
/*      */             
/*  590 */             columnsResultSet = null;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean first()
/*      */     throws SQLException
/*      */   {
/*  611 */     return super.first();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void generateStatements()
/*      */     throws SQLException
/*      */   {
/*  624 */     if (!this.isUpdatable) {
/*  625 */       this.doingUpdates = false;
/*  626 */       this.onInsertRow = false;
/*      */       
/*  628 */       throw new NotUpdatable(this.notUpdatableReason);
/*      */     }
/*      */     
/*  631 */     String quotedId = getQuotedIdChar();
/*      */     
/*  633 */     Map tableNamesSoFar = null;
/*      */     
/*  635 */     if (this.connection.lowerCaseTableNames()) {
/*  636 */       tableNamesSoFar = new TreeMap(String.CASE_INSENSITIVE_ORDER);
/*  637 */       this.databasesUsedToTablesUsed = new TreeMap(String.CASE_INSENSITIVE_ORDER);
/*      */     } else {
/*  639 */       tableNamesSoFar = new TreeMap();
/*  640 */       this.databasesUsedToTablesUsed = new TreeMap();
/*      */     }
/*      */     
/*  643 */     this.primaryKeyIndicies = new ArrayList();
/*      */     
/*  645 */     StringBuffer fieldValues = new StringBuffer();
/*  646 */     StringBuffer keyValues = new StringBuffer();
/*  647 */     StringBuffer columnNames = new StringBuffer();
/*  648 */     StringBuffer insertPlaceHolders = new StringBuffer();
/*  649 */     StringBuffer allTablesBuf = new StringBuffer();
/*  650 */     Map columnIndicesToTable = new HashMap();
/*      */     
/*  652 */     boolean firstTime = true;
/*  653 */     boolean keysFirstTime = true;
/*      */     
/*  655 */     String equalsStr = this.connection.versionMeetsMinimum(3, 23, 0) ? "<=>" : "=";
/*      */     
/*      */ 
/*  658 */     for (int i = 0; i < this.fields.length; i++) {
/*  659 */       StringBuffer tableNameBuffer = new StringBuffer();
/*  660 */       Map updColumnNameToIndex = null;
/*      */       
/*      */ 
/*  663 */       if (this.fields[i].getOriginalTableName() != null)
/*      */       {
/*  665 */         String databaseName = this.fields[i].getDatabaseName();
/*      */         
/*  667 */         if ((databaseName != null) && (databaseName.length() > 0)) {
/*  668 */           tableNameBuffer.append(quotedId);
/*  669 */           tableNameBuffer.append(databaseName);
/*  670 */           tableNameBuffer.append(quotedId);
/*  671 */           tableNameBuffer.append('.');
/*      */         }
/*      */         
/*  674 */         String tableOnlyName = this.fields[i].getOriginalTableName();
/*      */         
/*  676 */         tableNameBuffer.append(quotedId);
/*  677 */         tableNameBuffer.append(tableOnlyName);
/*  678 */         tableNameBuffer.append(quotedId);
/*      */         
/*  680 */         String fqTableName = tableNameBuffer.toString();
/*      */         
/*  682 */         if (!tableNamesSoFar.containsKey(fqTableName)) {
/*  683 */           if (!tableNamesSoFar.isEmpty()) {
/*  684 */             allTablesBuf.append(',');
/*      */           }
/*      */           
/*  687 */           allTablesBuf.append(fqTableName);
/*  688 */           tableNamesSoFar.put(fqTableName, fqTableName);
/*      */         }
/*      */         
/*  691 */         columnIndicesToTable.put(Integer.valueOf(i), fqTableName);
/*      */         
/*  693 */         updColumnNameToIndex = getColumnsToIndexMapForTableAndDB(databaseName, tableOnlyName);
/*      */       } else {
/*  695 */         String tableOnlyName = this.fields[i].getTableName();
/*      */         
/*  697 */         if (tableOnlyName != null) {
/*  698 */           tableNameBuffer.append(quotedId);
/*  699 */           tableNameBuffer.append(tableOnlyName);
/*  700 */           tableNameBuffer.append(quotedId);
/*      */           
/*  702 */           String fqTableName = tableNameBuffer.toString();
/*      */           
/*  704 */           if (!tableNamesSoFar.containsKey(fqTableName)) {
/*  705 */             if (!tableNamesSoFar.isEmpty()) {
/*  706 */               allTablesBuf.append(',');
/*      */             }
/*      */             
/*  709 */             allTablesBuf.append(fqTableName);
/*  710 */             tableNamesSoFar.put(fqTableName, fqTableName);
/*      */           }
/*      */           
/*  713 */           columnIndicesToTable.put(Integer.valueOf(i), fqTableName);
/*      */           
/*  715 */           updColumnNameToIndex = getColumnsToIndexMapForTableAndDB(this.catalog, tableOnlyName);
/*      */         }
/*      */       }
/*      */       
/*  719 */       String originalColumnName = this.fields[i].getOriginalName();
/*  720 */       String columnName = null;
/*      */       
/*  722 */       if ((this.connection.getIO().hasLongColumnInfo()) && (originalColumnName != null) && (originalColumnName.length() > 0))
/*      */       {
/*      */ 
/*  725 */         columnName = originalColumnName;
/*      */       } else {
/*  727 */         columnName = this.fields[i].getName();
/*      */       }
/*      */       
/*  730 */       if ((updColumnNameToIndex != null) && (columnName != null)) {
/*  731 */         updColumnNameToIndex.put(columnName, Integer.valueOf(i));
/*      */       }
/*      */       
/*  734 */       String originalTableName = this.fields[i].getOriginalTableName();
/*  735 */       String tableName = null;
/*      */       
/*  737 */       if ((this.connection.getIO().hasLongColumnInfo()) && (originalTableName != null) && (originalTableName.length() > 0))
/*      */       {
/*      */ 
/*  740 */         tableName = originalTableName;
/*      */       } else {
/*  742 */         tableName = this.fields[i].getTableName();
/*      */       }
/*      */       
/*  745 */       StringBuffer fqcnBuf = new StringBuffer();
/*  746 */       String databaseName = this.fields[i].getDatabaseName();
/*      */       
/*  748 */       if ((databaseName != null) && (databaseName.length() > 0)) {
/*  749 */         fqcnBuf.append(quotedId);
/*  750 */         fqcnBuf.append(databaseName);
/*  751 */         fqcnBuf.append(quotedId);
/*  752 */         fqcnBuf.append('.');
/*      */       }
/*      */       
/*  755 */       fqcnBuf.append(quotedId);
/*  756 */       fqcnBuf.append(tableName);
/*  757 */       fqcnBuf.append(quotedId);
/*  758 */       fqcnBuf.append('.');
/*  759 */       fqcnBuf.append(quotedId);
/*  760 */       fqcnBuf.append(columnName);
/*  761 */       fqcnBuf.append(quotedId);
/*      */       
/*  763 */       String qualifiedColumnName = fqcnBuf.toString();
/*      */       
/*  765 */       if (this.fields[i].isPrimaryKey()) {
/*  766 */         this.primaryKeyIndicies.add(Integer.valueOf(i));
/*      */         
/*  768 */         if (!keysFirstTime) {
/*  769 */           keyValues.append(" AND ");
/*      */         } else {
/*  771 */           keysFirstTime = false;
/*      */         }
/*      */         
/*  774 */         keyValues.append(qualifiedColumnName);
/*  775 */         keyValues.append(equalsStr);
/*  776 */         keyValues.append("?");
/*      */       }
/*      */       
/*  779 */       if (firstTime) {
/*  780 */         firstTime = false;
/*  781 */         fieldValues.append("SET ");
/*      */       } else {
/*  783 */         fieldValues.append(",");
/*  784 */         columnNames.append(",");
/*  785 */         insertPlaceHolders.append(",");
/*      */       }
/*      */       
/*  788 */       insertPlaceHolders.append("?");
/*      */       
/*  790 */       columnNames.append(qualifiedColumnName);
/*      */       
/*  792 */       fieldValues.append(qualifiedColumnName);
/*  793 */       fieldValues.append("=?");
/*      */     }
/*      */     
/*  796 */     this.qualifiedAndQuotedTableName = allTablesBuf.toString();
/*      */     
/*  798 */     this.updateSQL = ("UPDATE " + this.qualifiedAndQuotedTableName + " " + fieldValues.toString() + " WHERE " + keyValues.toString());
/*      */     
/*      */ 
/*  801 */     this.insertSQL = ("INSERT INTO " + this.qualifiedAndQuotedTableName + " (" + columnNames.toString() + ") VALUES (" + insertPlaceHolders.toString() + ")");
/*      */     
/*      */ 
/*  804 */     this.refreshSQL = ("SELECT " + columnNames.toString() + " FROM " + this.qualifiedAndQuotedTableName + " WHERE " + keyValues.toString());
/*      */     
/*      */ 
/*  807 */     this.deleteSQL = ("DELETE FROM " + this.qualifiedAndQuotedTableName + " WHERE " + keyValues.toString());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private Map getColumnsToIndexMapForTableAndDB(String databaseName, String tableName)
/*      */   {
/*  814 */     Map tablesUsedToColumnsMap = (Map)this.databasesUsedToTablesUsed.get(databaseName);
/*      */     
/*  816 */     if (tablesUsedToColumnsMap == null) {
/*  817 */       if (this.connection.lowerCaseTableNames()) {
/*  818 */         tablesUsedToColumnsMap = new TreeMap(String.CASE_INSENSITIVE_ORDER);
/*      */       } else {
/*  820 */         tablesUsedToColumnsMap = new TreeMap();
/*      */       }
/*      */       
/*  823 */       this.databasesUsedToTablesUsed.put(databaseName, tablesUsedToColumnsMap);
/*      */     }
/*      */     
/*  826 */     Map nameToIndex = (Map)tablesUsedToColumnsMap.get(tableName);
/*      */     
/*  828 */     if (nameToIndex == null) {
/*  829 */       nameToIndex = new HashMap();
/*  830 */       tablesUsedToColumnsMap.put(tableName, nameToIndex);
/*      */     }
/*      */     
/*  833 */     return nameToIndex;
/*      */   }
/*      */   
/*      */   private synchronized SingleByteCharsetConverter getCharConverter() throws SQLException
/*      */   {
/*  838 */     if (!this.initializedCharConverter) {
/*  839 */       this.initializedCharConverter = true;
/*      */       
/*  841 */       if (this.connection.getUseUnicode()) {
/*  842 */         this.charEncoding = this.connection.getEncoding();
/*  843 */         this.charConverter = this.connection.getCharsetConverter(this.charEncoding);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  848 */     return this.charConverter;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getConcurrency()
/*      */     throws SQLException
/*      */   {
/*  861 */     return this.isUpdatable ? 1008 : 1007;
/*      */   }
/*      */   
/*      */   private synchronized String getQuotedIdChar() throws SQLException {
/*  865 */     if (this.quotedIdChar == null) {
/*  866 */       boolean useQuotedIdentifiers = this.connection.supportsQuotedIdentifiers();
/*      */       
/*      */ 
/*  869 */       if (useQuotedIdentifiers) {
/*  870 */         DatabaseMetaData dbmd = this.connection.getMetaData();
/*  871 */         this.quotedIdChar = dbmd.getIdentifierQuoteString();
/*      */       } else {
/*  873 */         this.quotedIdChar = "";
/*      */       }
/*      */     }
/*      */     
/*  877 */     return this.quotedIdChar;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void insertRow()
/*      */     throws SQLException
/*      */   {
/*  890 */     checkClosed();
/*      */     
/*  892 */     if (!this.onInsertRow) {
/*  893 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.7"), getExceptionInterceptor());
/*      */     }
/*      */     
/*  896 */     this.inserter.executeUpdate();
/*      */     
/*  898 */     long autoIncrementId = this.inserter.getLastInsertID();
/*  899 */     int numFields = this.fields.length;
/*  900 */     byte[][] newRow = new byte[numFields][];
/*      */     
/*  902 */     for (int i = 0; i < numFields; i++) {
/*  903 */       if (this.inserter.isNull(i)) {
/*  904 */         newRow[i] = null;
/*      */       } else {
/*  906 */         newRow[i] = this.inserter.getBytesRepresentation(i);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  913 */       if ((this.fields[i].isAutoIncrement()) && (autoIncrementId > 0L)) {
/*  914 */         newRow[i] = StringUtils.getBytes(String.valueOf(autoIncrementId));
/*  915 */         this.inserter.setBytesNoEscapeNoQuotes(i + 1, newRow[i]);
/*      */       }
/*      */     }
/*      */     
/*  919 */     ResultSetRow resultSetRow = new ByteArrayRow(newRow, getExceptionInterceptor());
/*      */     
/*  921 */     refreshRow(this.inserter, resultSetRow);
/*      */     
/*  923 */     this.rowData.addRow(resultSetRow);
/*  924 */     resetInserter();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean isAfterLast()
/*      */     throws SQLException
/*      */   {
/*  941 */     return super.isAfterLast();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean isBeforeFirst()
/*      */     throws SQLException
/*      */   {
/*  958 */     return super.isBeforeFirst();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean isFirst()
/*      */     throws SQLException
/*      */   {
/*  974 */     return super.isFirst();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean isLast()
/*      */     throws SQLException
/*      */   {
/*  993 */     return super.isLast();
/*      */   }
/*      */   
/*      */   boolean isUpdatable() {
/*  997 */     return this.isUpdatable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean last()
/*      */     throws SQLException
/*      */   {
/* 1014 */     return super.last();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void moveToCurrentRow()
/*      */     throws SQLException
/*      */   {
/* 1028 */     checkClosed();
/*      */     
/* 1030 */     if (!this.isUpdatable) {
/* 1031 */       throw new NotUpdatable(this.notUpdatableReason);
/*      */     }
/*      */     
/* 1034 */     if (this.onInsertRow) {
/* 1035 */       this.onInsertRow = false;
/* 1036 */       this.thisRow = this.savedCurrentRow;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void moveToInsertRow()
/*      */     throws SQLException
/*      */   {
/* 1058 */     checkClosed();
/*      */     
/* 1060 */     if (!this.isUpdatable) {
/* 1061 */       throw new NotUpdatable(this.notUpdatableReason);
/*      */     }
/*      */     
/* 1064 */     if (this.inserter == null) {
/* 1065 */       if (this.insertSQL == null) {
/* 1066 */         generateStatements();
/*      */       }
/*      */       
/* 1069 */       this.inserter = ((PreparedStatement)this.connection.clientPrepareStatement(this.insertSQL));
/*      */       
/* 1071 */       if (this.populateInserterWithDefaultValues) {
/* 1072 */         extractDefaultValues();
/*      */       }
/*      */       
/* 1075 */       resetInserter();
/*      */     } else {
/* 1077 */       resetInserter();
/*      */     }
/*      */     
/* 1080 */     int numFields = this.fields.length;
/*      */     
/* 1082 */     this.onInsertRow = true;
/* 1083 */     this.doingUpdates = false;
/* 1084 */     this.savedCurrentRow = this.thisRow;
/* 1085 */     byte[][] newRowData = new byte[numFields][];
/* 1086 */     this.thisRow = new ByteArrayRow(newRowData, getExceptionInterceptor());
/*      */     
/* 1088 */     for (int i = 0; i < numFields; i++) {
/* 1089 */       if (!this.populateInserterWithDefaultValues) {
/* 1090 */         this.inserter.setBytesNoEscapeNoQuotes(i + 1, StringUtils.getBytes("DEFAULT"));
/*      */         
/* 1092 */         newRowData = (byte[][])null;
/*      */       }
/* 1094 */       else if (this.defaultColumnValue[i] != null) {
/* 1095 */         Field f = this.fields[i];
/*      */         
/* 1097 */         switch (f.getMysqlType())
/*      */         {
/*      */         case 7: 
/*      */         case 10: 
/*      */         case 11: 
/*      */         case 12: 
/*      */         case 14: 
/* 1104 */           if ((this.defaultColumnValue[i].length > 7) && (this.defaultColumnValue[i][0] == 67) && (this.defaultColumnValue[i][1] == 85) && (this.defaultColumnValue[i][2] == 82) && (this.defaultColumnValue[i][3] == 82) && (this.defaultColumnValue[i][4] == 69) && (this.defaultColumnValue[i][5] == 78) && (this.defaultColumnValue[i][6] == 84) && (this.defaultColumnValue[i][7] == 95))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1113 */             this.inserter.setBytesNoEscapeNoQuotes(i + 1, this.defaultColumnValue[i]);
/*      */           }
/*      */           
/* 1116 */           break;
/*      */         }
/*      */         
/* 1119 */         this.inserter.setBytes(i + 1, this.defaultColumnValue[i], false, false);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1125 */         byte[] defaultValueCopy = new byte[this.defaultColumnValue[i].length];
/* 1126 */         System.arraycopy(this.defaultColumnValue[i], 0, defaultValueCopy, 0, defaultValueCopy.length);
/*      */         
/* 1128 */         newRowData[i] = defaultValueCopy;
/*      */       } else {
/* 1130 */         this.inserter.setNull(i + 1, 0);
/* 1131 */         newRowData[i] = null;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean next()
/*      */     throws SQLException
/*      */   {
/* 1157 */     return super.next();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean prev()
/*      */     throws SQLException
/*      */   {
/* 1176 */     return super.prev();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean previous()
/*      */     throws SQLException
/*      */   {
/* 1198 */     return super.previous();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void realClose(boolean calledExplicitly)
/*      */     throws SQLException
/*      */   {
/* 1211 */     if (this.isClosed) {
/* 1212 */       return;
/*      */     }
/*      */     
/* 1215 */     SQLException sqlEx = null;
/*      */     
/* 1217 */     if ((this.useUsageAdvisor) && 
/* 1218 */       (this.deleter == null) && (this.inserter == null) && (this.refresher == null) && (this.updater == null))
/*      */     {
/* 1220 */       this.eventSink = ProfilerEventHandlerFactory.getInstance(this.connection);
/*      */       
/* 1222 */       String message = Messages.getString("UpdatableResultSet.34");
/*      */       
/* 1224 */       this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", this.owningStatement == null ? "N/A" : this.owningStatement.currentCatalog, this.connectionId, this.owningStatement == null ? -1 : this.owningStatement.getId(), this.resultId, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, message));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/* 1238 */       if (this.deleter != null) {
/* 1239 */         this.deleter.close();
/*      */       }
/*      */     } catch (SQLException ex) {
/* 1242 */       sqlEx = ex;
/*      */     }
/*      */     try
/*      */     {
/* 1246 */       if (this.inserter != null) {
/* 1247 */         this.inserter.close();
/*      */       }
/*      */     } catch (SQLException ex) {
/* 1250 */       sqlEx = ex;
/*      */     }
/*      */     try
/*      */     {
/* 1254 */       if (this.refresher != null) {
/* 1255 */         this.refresher.close();
/*      */       }
/*      */     } catch (SQLException ex) {
/* 1258 */       sqlEx = ex;
/*      */     }
/*      */     try
/*      */     {
/* 1262 */       if (this.updater != null) {
/* 1263 */         this.updater.close();
/*      */       }
/*      */     } catch (SQLException ex) {
/* 1266 */       sqlEx = ex;
/*      */     }
/*      */     
/* 1269 */     super.realClose(calledExplicitly);
/*      */     
/* 1271 */     if (sqlEx != null) {
/* 1272 */       throw sqlEx;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void refreshRow()
/*      */     throws SQLException
/*      */   {
/* 1297 */     checkClosed();
/*      */     
/* 1299 */     if (!this.isUpdatable) {
/* 1300 */       throw new NotUpdatable();
/*      */     }
/*      */     
/* 1303 */     if (this.onInsertRow)
/* 1304 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.8"), getExceptionInterceptor());
/* 1305 */     if (this.rowData.size() == 0)
/* 1306 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.9"), getExceptionInterceptor());
/* 1307 */     if (isBeforeFirst())
/* 1308 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.10"), getExceptionInterceptor());
/* 1309 */     if (isAfterLast()) {
/* 1310 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.11"), getExceptionInterceptor());
/*      */     }
/*      */     
/* 1313 */     refreshRow(this.updater, this.thisRow);
/*      */   }
/*      */   
/*      */   private synchronized void refreshRow(PreparedStatement updateInsertStmt, ResultSetRow rowToRefresh) throws SQLException
/*      */   {
/* 1318 */     if (this.refresher == null) {
/* 1319 */       if (this.refreshSQL == null) {
/* 1320 */         generateStatements();
/*      */       }
/*      */       
/* 1323 */       this.refresher = ((PreparedStatement)this.connection.clientPrepareStatement(this.refreshSQL));
/*      */     }
/*      */     
/*      */ 
/* 1327 */     this.refresher.clearParameters();
/*      */     
/* 1329 */     int numKeys = this.primaryKeyIndicies.size();
/*      */     
/* 1331 */     if (numKeys == 1) {
/* 1332 */       byte[] dataFrom = null;
/* 1333 */       int index = ((Integer)this.primaryKeyIndicies.get(0)).intValue();
/*      */       
/* 1335 */       if ((!this.doingUpdates) && (!this.onInsertRow)) {
/* 1336 */         dataFrom = (byte[])rowToRefresh.getColumnValue(index);
/*      */       } else {
/* 1338 */         dataFrom = updateInsertStmt.getBytesRepresentation(index);
/*      */         
/*      */ 
/* 1341 */         if ((updateInsertStmt.isNull(index)) || (dataFrom.length == 0)) {
/* 1342 */           dataFrom = (byte[])rowToRefresh.getColumnValue(index);
/*      */         } else {
/* 1344 */           dataFrom = stripBinaryPrefix(dataFrom);
/*      */         }
/*      */       }
/*      */       
/* 1348 */       if (this.fields[index].getvalueNeedsQuoting()) {
/* 1349 */         this.refresher.setBytesNoEscape(1, dataFrom);
/*      */       } else {
/* 1351 */         this.refresher.setBytesNoEscapeNoQuotes(1, dataFrom);
/*      */       }
/*      */     }
/*      */     else {
/* 1355 */       for (int i = 0; i < numKeys; i++) {
/* 1356 */         byte[] dataFrom = null;
/* 1357 */         int index = ((Integer)this.primaryKeyIndicies.get(i)).intValue();
/*      */         
/*      */ 
/* 1360 */         if ((!this.doingUpdates) && (!this.onInsertRow)) {
/* 1361 */           dataFrom = (byte[])rowToRefresh.getColumnValue(index);
/*      */         } else {
/* 1363 */           dataFrom = updateInsertStmt.getBytesRepresentation(index);
/*      */           
/*      */ 
/* 1366 */           if ((updateInsertStmt.isNull(index)) || (dataFrom.length == 0)) {
/* 1367 */             dataFrom = (byte[])rowToRefresh.getColumnValue(index);
/*      */           } else {
/* 1369 */             dataFrom = stripBinaryPrefix(dataFrom);
/*      */           }
/*      */         }
/*      */         
/* 1373 */         this.refresher.setBytesNoEscape(i + 1, dataFrom);
/*      */       }
/*      */     }
/*      */     
/* 1377 */     ResultSet rs = null;
/*      */     try
/*      */     {
/* 1380 */       rs = this.refresher.executeQuery();
/*      */       
/* 1382 */       int numCols = rs.getMetaData().getColumnCount();
/*      */       
/* 1384 */       if (rs.next()) {
/* 1385 */         for (int i = 0; i < numCols; i++) {
/* 1386 */           byte[] val = rs.getBytes(i + 1);
/*      */           
/* 1388 */           if ((val == null) || (rs.wasNull())) {
/* 1389 */             rowToRefresh.setColumnValue(i, null);
/*      */           } else {
/* 1391 */             rowToRefresh.setColumnValue(i, rs.getBytes(i + 1));
/*      */           }
/*      */         }
/*      */       } else {
/* 1395 */         throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.12"), "S1000", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/* 1400 */       if (rs != null) {
/*      */         try {
/* 1402 */           rs.close();
/*      */         }
/*      */         catch (SQLException ex) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean relative(int rows)
/*      */     throws SQLException
/*      */   {
/* 1437 */     return super.relative(rows);
/*      */   }
/*      */   
/*      */   private void resetInserter() throws SQLException {
/* 1441 */     this.inserter.clearParameters();
/*      */     
/* 1443 */     for (int i = 0; i < this.fields.length; i++) {
/* 1444 */       this.inserter.setNull(i + 1, 0);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean rowDeleted()
/*      */     throws SQLException
/*      */   {
/* 1464 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean rowInserted()
/*      */     throws SQLException
/*      */   {
/* 1482 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean rowUpdated()
/*      */     throws SQLException
/*      */   {
/* 1500 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setResultSetConcurrency(int concurrencyFlag)
/*      */   {
/* 1510 */     super.setResultSetConcurrency(concurrencyFlag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private byte[] stripBinaryPrefix(byte[] dataFrom)
/*      */   {
/* 1524 */     return StringUtils.stripEnclosure(dataFrom, "_binary'", "'");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void syncUpdate()
/*      */     throws SQLException
/*      */   {
/* 1535 */     if (this.updater == null) {
/* 1536 */       if (this.updateSQL == null) {
/* 1537 */         generateStatements();
/*      */       }
/*      */       
/* 1540 */       this.updater = ((PreparedStatement)this.connection.clientPrepareStatement(this.updateSQL));
/*      */     }
/*      */     
/*      */ 
/* 1544 */     int numFields = this.fields.length;
/* 1545 */     this.updater.clearParameters();
/*      */     
/* 1547 */     for (int i = 0; i < numFields; i++) {
/* 1548 */       if (this.thisRow.getColumnValue(i) != null)
/*      */       {
/* 1550 */         if (this.fields[i].getvalueNeedsQuoting()) {
/* 1551 */           this.updater.setBytes(i + 1, (byte[])this.thisRow.getColumnValue(i), this.fields[i].isBinary(), false);
/*      */         }
/*      */         else {
/* 1554 */           this.updater.setBytesNoEscapeNoQuotes(i + 1, (byte[])this.thisRow.getColumnValue(i));
/*      */         }
/*      */       } else {
/* 1557 */         this.updater.setNull(i + 1, 0);
/*      */       }
/*      */     }
/*      */     
/* 1561 */     int numKeys = this.primaryKeyIndicies.size();
/*      */     
/* 1563 */     if (numKeys == 1) {
/* 1564 */       int index = ((Integer)this.primaryKeyIndicies.get(0)).intValue();
/* 1565 */       setParamValue(this.updater, numFields + 1, this.thisRow, index, this.fields[index].getSQLType());
/*      */     }
/*      */     else {
/* 1568 */       for (int i = 0; i < numKeys; i++) {
/* 1569 */         int idx = ((Integer)this.primaryKeyIndicies.get(i)).intValue();
/* 1570 */         setParamValue(this.updater, numFields + i + 1, this.thisRow, idx, this.fields[idx].getSQLType());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateAsciiStream(int columnIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 1595 */     if (!this.onInsertRow) {
/* 1596 */       if (!this.doingUpdates) {
/* 1597 */         this.doingUpdates = true;
/* 1598 */         syncUpdate();
/*      */       }
/*      */       
/* 1601 */       this.updater.setAsciiStream(columnIndex, x, length);
/*      */     } else {
/* 1603 */       this.inserter.setAsciiStream(columnIndex, x, length);
/* 1604 */       this.thisRow.setColumnValue(columnIndex - 1, STREAM_DATA_MARKER);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateAsciiStream(String columnName, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 1627 */     updateAsciiStream(findColumn(columnName), x, length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateBigDecimal(int columnIndex, BigDecimal x)
/*      */     throws SQLException
/*      */   {
/* 1646 */     if (!this.onInsertRow) {
/* 1647 */       if (!this.doingUpdates) {
/* 1648 */         this.doingUpdates = true;
/* 1649 */         syncUpdate();
/*      */       }
/*      */       
/* 1652 */       this.updater.setBigDecimal(columnIndex, x);
/*      */     } else {
/* 1654 */       this.inserter.setBigDecimal(columnIndex, x);
/*      */       
/* 1656 */       if (x == null) {
/* 1657 */         this.thisRow.setColumnValue(columnIndex - 1, null);
/*      */       } else {
/* 1659 */         this.thisRow.setColumnValue(columnIndex - 1, StringUtils.getBytes(x.toString()));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateBigDecimal(String columnName, BigDecimal x)
/*      */     throws SQLException
/*      */   {
/* 1680 */     updateBigDecimal(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateBinaryStream(int columnIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 1702 */     if (!this.onInsertRow) {
/* 1703 */       if (!this.doingUpdates) {
/* 1704 */         this.doingUpdates = true;
/* 1705 */         syncUpdate();
/*      */       }
/*      */       
/* 1708 */       this.updater.setBinaryStream(columnIndex, x, length);
/*      */     } else {
/* 1710 */       this.inserter.setBinaryStream(columnIndex, x, length);
/*      */       
/* 1712 */       if (x == null) {
/* 1713 */         this.thisRow.setColumnValue(columnIndex - 1, null);
/*      */       } else {
/* 1715 */         this.thisRow.setColumnValue(columnIndex - 1, STREAM_DATA_MARKER);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateBinaryStream(String columnName, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 1739 */     updateBinaryStream(findColumn(columnName), x, length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized void updateBlob(int columnIndex, Blob blob)
/*      */     throws SQLException
/*      */   {
/* 1747 */     if (!this.onInsertRow) {
/* 1748 */       if (!this.doingUpdates) {
/* 1749 */         this.doingUpdates = true;
/* 1750 */         syncUpdate();
/*      */       }
/*      */       
/* 1753 */       this.updater.setBlob(columnIndex, blob);
/*      */     } else {
/* 1755 */       this.inserter.setBlob(columnIndex, blob);
/*      */       
/* 1757 */       if (blob == null) {
/* 1758 */         this.thisRow.setColumnValue(columnIndex - 1, null);
/*      */       } else {
/* 1760 */         this.thisRow.setColumnValue(columnIndex - 1, STREAM_DATA_MARKER);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized void updateBlob(String columnName, Blob blob)
/*      */     throws SQLException
/*      */   {
/* 1770 */     updateBlob(findColumn(columnName), blob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateBoolean(int columnIndex, boolean x)
/*      */     throws SQLException
/*      */   {
/* 1789 */     if (!this.onInsertRow) {
/* 1790 */       if (!this.doingUpdates) {
/* 1791 */         this.doingUpdates = true;
/* 1792 */         syncUpdate();
/*      */       }
/*      */       
/* 1795 */       this.updater.setBoolean(columnIndex, x);
/*      */     } else {
/* 1797 */       this.inserter.setBoolean(columnIndex, x);
/*      */       
/* 1799 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateBoolean(String columnName, boolean x)
/*      */     throws SQLException
/*      */   {
/* 1820 */     updateBoolean(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateByte(int columnIndex, byte x)
/*      */     throws SQLException
/*      */   {
/* 1839 */     if (!this.onInsertRow) {
/* 1840 */       if (!this.doingUpdates) {
/* 1841 */         this.doingUpdates = true;
/* 1842 */         syncUpdate();
/*      */       }
/*      */       
/* 1845 */       this.updater.setByte(columnIndex, x);
/*      */     } else {
/* 1847 */       this.inserter.setByte(columnIndex, x);
/*      */       
/* 1849 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateByte(String columnName, byte x)
/*      */     throws SQLException
/*      */   {
/* 1870 */     updateByte(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateBytes(int columnIndex, byte[] x)
/*      */     throws SQLException
/*      */   {
/* 1889 */     if (!this.onInsertRow) {
/* 1890 */       if (!this.doingUpdates) {
/* 1891 */         this.doingUpdates = true;
/* 1892 */         syncUpdate();
/*      */       }
/*      */       
/* 1895 */       this.updater.setBytes(columnIndex, x);
/*      */     } else {
/* 1897 */       this.inserter.setBytes(columnIndex, x);
/*      */       
/* 1899 */       this.thisRow.setColumnValue(columnIndex - 1, x);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateBytes(String columnName, byte[] x)
/*      */     throws SQLException
/*      */   {
/* 1919 */     updateBytes(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateCharacterStream(int columnIndex, Reader x, int length)
/*      */     throws SQLException
/*      */   {
/* 1941 */     if (!this.onInsertRow) {
/* 1942 */       if (!this.doingUpdates) {
/* 1943 */         this.doingUpdates = true;
/* 1944 */         syncUpdate();
/*      */       }
/*      */       
/* 1947 */       this.updater.setCharacterStream(columnIndex, x, length);
/*      */     } else {
/* 1949 */       this.inserter.setCharacterStream(columnIndex, x, length);
/*      */       
/* 1951 */       if (x == null) {
/* 1952 */         this.thisRow.setColumnValue(columnIndex - 1, null);
/*      */       } else {
/* 1954 */         this.thisRow.setColumnValue(columnIndex - 1, STREAM_DATA_MARKER);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateCharacterStream(String columnName, Reader reader, int length)
/*      */     throws SQLException
/*      */   {
/* 1978 */     updateCharacterStream(findColumn(columnName), reader, length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void updateClob(int columnIndex, Clob clob)
/*      */     throws SQLException
/*      */   {
/* 1986 */     if (clob == null) {
/* 1987 */       updateNull(columnIndex);
/*      */     } else {
/* 1989 */       updateCharacterStream(columnIndex, clob.getCharacterStream(), (int)clob.length());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateDate(int columnIndex, Date x)
/*      */     throws SQLException
/*      */   {
/* 2010 */     if (!this.onInsertRow) {
/* 2011 */       if (!this.doingUpdates) {
/* 2012 */         this.doingUpdates = true;
/* 2013 */         syncUpdate();
/*      */       }
/*      */       
/* 2016 */       this.updater.setDate(columnIndex, x);
/*      */     } else {
/* 2018 */       this.inserter.setDate(columnIndex, x);
/*      */       
/* 2020 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateDate(String columnName, Date x)
/*      */     throws SQLException
/*      */   {
/* 2041 */     updateDate(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateDouble(int columnIndex, double x)
/*      */     throws SQLException
/*      */   {
/* 2060 */     if (!this.onInsertRow) {
/* 2061 */       if (!this.doingUpdates) {
/* 2062 */         this.doingUpdates = true;
/* 2063 */         syncUpdate();
/*      */       }
/*      */       
/* 2066 */       this.updater.setDouble(columnIndex, x);
/*      */     } else {
/* 2068 */       this.inserter.setDouble(columnIndex, x);
/*      */       
/* 2070 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateDouble(String columnName, double x)
/*      */     throws SQLException
/*      */   {
/* 2091 */     updateDouble(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateFloat(int columnIndex, float x)
/*      */     throws SQLException
/*      */   {
/* 2110 */     if (!this.onInsertRow) {
/* 2111 */       if (!this.doingUpdates) {
/* 2112 */         this.doingUpdates = true;
/* 2113 */         syncUpdate();
/*      */       }
/*      */       
/* 2116 */       this.updater.setFloat(columnIndex, x);
/*      */     } else {
/* 2118 */       this.inserter.setFloat(columnIndex, x);
/*      */       
/* 2120 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateFloat(String columnName, float x)
/*      */     throws SQLException
/*      */   {
/* 2141 */     updateFloat(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateInt(int columnIndex, int x)
/*      */     throws SQLException
/*      */   {
/* 2160 */     if (!this.onInsertRow) {
/* 2161 */       if (!this.doingUpdates) {
/* 2162 */         this.doingUpdates = true;
/* 2163 */         syncUpdate();
/*      */       }
/*      */       
/* 2166 */       this.updater.setInt(columnIndex, x);
/*      */     } else {
/* 2168 */       this.inserter.setInt(columnIndex, x);
/*      */       
/* 2170 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateInt(String columnName, int x)
/*      */     throws SQLException
/*      */   {
/* 2191 */     updateInt(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateLong(int columnIndex, long x)
/*      */     throws SQLException
/*      */   {
/* 2210 */     if (!this.onInsertRow) {
/* 2211 */       if (!this.doingUpdates) {
/* 2212 */         this.doingUpdates = true;
/* 2213 */         syncUpdate();
/*      */       }
/*      */       
/* 2216 */       this.updater.setLong(columnIndex, x);
/*      */     } else {
/* 2218 */       this.inserter.setLong(columnIndex, x);
/*      */       
/* 2220 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateLong(String columnName, long x)
/*      */     throws SQLException
/*      */   {
/* 2241 */     updateLong(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateNull(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 2257 */     if (!this.onInsertRow) {
/* 2258 */       if (!this.doingUpdates) {
/* 2259 */         this.doingUpdates = true;
/* 2260 */         syncUpdate();
/*      */       }
/*      */       
/* 2263 */       this.updater.setNull(columnIndex, 0);
/*      */     } else {
/* 2265 */       this.inserter.setNull(columnIndex, 0);
/*      */       
/* 2267 */       this.thisRow.setColumnValue(columnIndex - 1, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateNull(String columnName)
/*      */     throws SQLException
/*      */   {
/* 2284 */     updateNull(findColumn(columnName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateObject(int columnIndex, Object x)
/*      */     throws SQLException
/*      */   {
/* 2303 */     if (!this.onInsertRow) {
/* 2304 */       if (!this.doingUpdates) {
/* 2305 */         this.doingUpdates = true;
/* 2306 */         syncUpdate();
/*      */       }
/*      */       
/* 2309 */       this.updater.setObject(columnIndex, x);
/*      */     } else {
/* 2311 */       this.inserter.setObject(columnIndex, x);
/*      */       
/* 2313 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateObject(int columnIndex, Object x, int scale)
/*      */     throws SQLException
/*      */   {
/* 2338 */     if (!this.onInsertRow) {
/* 2339 */       if (!this.doingUpdates) {
/* 2340 */         this.doingUpdates = true;
/* 2341 */         syncUpdate();
/*      */       }
/*      */       
/* 2344 */       this.updater.setObject(columnIndex, x);
/*      */     } else {
/* 2346 */       this.inserter.setObject(columnIndex, x);
/*      */       
/* 2348 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateObject(String columnName, Object x)
/*      */     throws SQLException
/*      */   {
/* 2369 */     updateObject(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateObject(String columnName, Object x, int scale)
/*      */     throws SQLException
/*      */   {
/* 2392 */     updateObject(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateRow()
/*      */     throws SQLException
/*      */   {
/* 2406 */     if (!this.isUpdatable) {
/* 2407 */       throw new NotUpdatable(this.notUpdatableReason);
/*      */     }
/*      */     
/* 2410 */     if (this.doingUpdates) {
/* 2411 */       this.updater.executeUpdate();
/* 2412 */       refreshRow();
/* 2413 */       this.doingUpdates = false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2419 */     syncUpdate();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateShort(int columnIndex, short x)
/*      */     throws SQLException
/*      */   {
/* 2438 */     if (!this.onInsertRow) {
/* 2439 */       if (!this.doingUpdates) {
/* 2440 */         this.doingUpdates = true;
/* 2441 */         syncUpdate();
/*      */       }
/*      */       
/* 2444 */       this.updater.setShort(columnIndex, x);
/*      */     } else {
/* 2446 */       this.inserter.setShort(columnIndex, x);
/*      */       
/* 2448 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateShort(String columnName, short x)
/*      */     throws SQLException
/*      */   {
/* 2469 */     updateShort(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateString(int columnIndex, String x)
/*      */     throws SQLException
/*      */   {
/* 2488 */     checkClosed();
/*      */     
/* 2490 */     if (!this.onInsertRow) {
/* 2491 */       if (!this.doingUpdates) {
/* 2492 */         this.doingUpdates = true;
/* 2493 */         syncUpdate();
/*      */       }
/*      */       
/* 2496 */       this.updater.setString(columnIndex, x);
/*      */     } else {
/* 2498 */       this.inserter.setString(columnIndex, x);
/*      */       
/* 2500 */       if (x == null) {
/* 2501 */         this.thisRow.setColumnValue(columnIndex - 1, null);
/*      */       }
/* 2503 */       else if (getCharConverter() != null) {
/* 2504 */         this.thisRow.setColumnValue(columnIndex - 1, StringUtils.getBytes(x, this.charConverter, this.charEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), getExceptionInterceptor()));
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 2509 */         this.thisRow.setColumnValue(columnIndex - 1, StringUtils.getBytes(x));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateString(String columnName, String x)
/*      */     throws SQLException
/*      */   {
/* 2531 */     updateString(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateTime(int columnIndex, Time x)
/*      */     throws SQLException
/*      */   {
/* 2550 */     if (!this.onInsertRow) {
/* 2551 */       if (!this.doingUpdates) {
/* 2552 */         this.doingUpdates = true;
/* 2553 */         syncUpdate();
/*      */       }
/*      */       
/* 2556 */       this.updater.setTime(columnIndex, x);
/*      */     } else {
/* 2558 */       this.inserter.setTime(columnIndex, x);
/*      */       
/* 2560 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateTime(String columnName, Time x)
/*      */     throws SQLException
/*      */   {
/* 2581 */     updateTime(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateTimestamp(int columnIndex, Timestamp x)
/*      */     throws SQLException
/*      */   {
/* 2600 */     if (!this.onInsertRow) {
/* 2601 */       if (!this.doingUpdates) {
/* 2602 */         this.doingUpdates = true;
/* 2603 */         syncUpdate();
/*      */       }
/*      */       
/* 2606 */       this.updater.setTimestamp(columnIndex, x);
/*      */     } else {
/* 2608 */       this.inserter.setTimestamp(columnIndex, x);
/*      */       
/* 2610 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void updateTimestamp(String columnName, Timestamp x)
/*      */     throws SQLException
/*      */   {
/* 2631 */     updateTimestamp(findColumn(columnName), x);
/*      */   }
/*      */ }


/* Location:              C:\Users\Static\Desktop\G10_Prototype_Client.jar!\mysql-connector-java-5.1.19-bin.jar!\com\mysql\jdbc\UpdatableResultSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */