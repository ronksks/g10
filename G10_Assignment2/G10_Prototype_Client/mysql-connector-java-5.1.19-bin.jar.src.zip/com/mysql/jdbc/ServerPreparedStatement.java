/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.exceptions.MySQLStatementCancelledException;
/*      */ import com.mysql.jdbc.exceptions.MySQLTimeoutException;
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import com.mysql.jdbc.profiler.ProfilerEventHandler;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.BatchUpdateException;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.ParameterMetaData;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.List;
/*      */ import java.util.TimeZone;
/*      */ import java.util.Timer;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ServerPreparedStatement
/*      */   extends PreparedStatement
/*      */ {
/*      */   private static final Constructor JDBC_4_SPS_CTOR;
/*      */   protected static final int BLOB_STREAM_READ_BUF_SIZE = 8192;
/*      */   private static final byte MAX_DATE_REP_LENGTH = 5;
/*      */   private static final byte MAX_DATETIME_REP_LENGTH = 12;
/*      */   private static final byte MAX_TIME_REP_LENGTH = 13;
/*      */   
/*      */   static
/*      */   {
/*   67 */     if (Util.isJdbc4()) {
/*      */       try {
/*   69 */         JDBC_4_SPS_CTOR = Class.forName("com.mysql.jdbc.JDBC4ServerPreparedStatement").getConstructor(new Class[] { MySQLConnection.class, String.class, String.class, Integer.TYPE, Integer.TYPE });
/*      */ 
/*      */       }
/*      */       catch (SecurityException e)
/*      */       {
/*   74 */         throw new RuntimeException(e);
/*      */       } catch (NoSuchMethodException e) {
/*   76 */         throw new RuntimeException(e);
/*      */       } catch (ClassNotFoundException e) {
/*   78 */         throw new RuntimeException(e);
/*      */       }
/*      */     } else {
/*   81 */       JDBC_4_SPS_CTOR = null;
/*      */     }
/*      */   }
/*      */   
/*      */   public static class BatchedBindValues
/*      */   {
/*      */     public ServerPreparedStatement.BindValue[] batchedParameterValues;
/*      */     
/*      */     BatchedBindValues(ServerPreparedStatement.BindValue[] paramVals)
/*      */     {
/*   91 */       int numParams = paramVals.length;
/*      */       
/*   93 */       this.batchedParameterValues = new ServerPreparedStatement.BindValue[numParams];
/*      */       
/*   95 */       for (int i = 0; i < numParams; i++) {
/*   96 */         this.batchedParameterValues[i] = new ServerPreparedStatement.BindValue(paramVals[i]);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public static class BindValue
/*      */   {
/*  103 */     public long boundBeforeExecutionNum = 0L;
/*      */     
/*      */     public long bindLength;
/*      */     
/*      */     public int bufferType;
/*      */     
/*      */     public double doubleBinding;
/*      */     
/*      */     public float floatBinding;
/*      */     
/*      */     public boolean isLongData;
/*      */     
/*      */     public boolean isNull;
/*      */     
/*  117 */     public boolean isSet = false;
/*      */     
/*      */     public long longBinding;
/*      */     
/*      */     public Object value;
/*      */     
/*      */     BindValue() {}
/*      */     
/*      */     BindValue(BindValue copyMe)
/*      */     {
/*  127 */       this.value = copyMe.value;
/*  128 */       this.isSet = copyMe.isSet;
/*  129 */       this.isLongData = copyMe.isLongData;
/*  130 */       this.isNull = copyMe.isNull;
/*  131 */       this.bufferType = copyMe.bufferType;
/*  132 */       this.bindLength = copyMe.bindLength;
/*  133 */       this.longBinding = copyMe.longBinding;
/*  134 */       this.floatBinding = copyMe.floatBinding;
/*  135 */       this.doubleBinding = copyMe.doubleBinding;
/*      */     }
/*      */     
/*      */     void reset() {
/*  139 */       this.isSet = false;
/*  140 */       this.value = null;
/*  141 */       this.isLongData = false;
/*      */       
/*  143 */       this.longBinding = 0L;
/*  144 */       this.floatBinding = 0.0F;
/*  145 */       this.doubleBinding = 0.0D;
/*      */     }
/*      */     
/*      */     public String toString() {
/*  149 */       return toString(false);
/*      */     }
/*      */     
/*      */     public String toString(boolean quoteIfNeeded) {
/*  153 */       if (this.isLongData) {
/*  154 */         return "' STREAM DATA '";
/*      */       }
/*      */       
/*  157 */       switch (this.bufferType) {
/*      */       case 1: 
/*      */       case 2: 
/*      */       case 3: 
/*      */       case 8: 
/*  162 */         return String.valueOf(this.longBinding);
/*      */       case 4: 
/*  164 */         return String.valueOf(this.floatBinding);
/*      */       case 5: 
/*  166 */         return String.valueOf(this.doubleBinding);
/*      */       case 7: 
/*      */       case 10: 
/*      */       case 11: 
/*      */       case 12: 
/*      */       case 15: 
/*      */       case 253: 
/*      */       case 254: 
/*  174 */         if (quoteIfNeeded) {
/*  175 */           return "'" + String.valueOf(this.value) + "'";
/*      */         }
/*  177 */         return String.valueOf(this.value);
/*      */       }
/*      */       
/*  180 */       if ((this.value instanceof byte[])) {
/*  181 */         return "byte data";
/*      */       }
/*      */       
/*  184 */       if (quoteIfNeeded) {
/*  185 */         return "'" + String.valueOf(this.value) + "'";
/*      */       }
/*  187 */       return String.valueOf(this.value);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     long getBoundLength()
/*      */     {
/*  194 */       if (this.isNull) {
/*  195 */         return 0L;
/*      */       }
/*      */       
/*  198 */       if (this.isLongData) {
/*  199 */         return this.bindLength;
/*      */       }
/*      */       
/*  202 */       switch (this.bufferType)
/*      */       {
/*      */       case 1: 
/*  205 */         return 1L;
/*      */       case 2: 
/*  207 */         return 2L;
/*      */       case 3: 
/*  209 */         return 4L;
/*      */       case 8: 
/*  211 */         return 8L;
/*      */       case 4: 
/*  213 */         return 4L;
/*      */       case 5: 
/*  215 */         return 8L;
/*      */       case 11: 
/*  217 */         return 9L;
/*      */       case 10: 
/*  219 */         return 7L;
/*      */       case 7: 
/*      */       case 12: 
/*  222 */         return 11L;
/*      */       case 0: 
/*      */       case 15: 
/*      */       case 246: 
/*      */       case 253: 
/*      */       case 254: 
/*  228 */         if ((this.value instanceof byte[])) {
/*  229 */           return ((byte[])this.value).length;
/*      */         }
/*  231 */         return ((String)this.value).length();
/*      */       }
/*      */       
/*  234 */       return 0L;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  254 */   private boolean hasOnDuplicateKeyUpdate = false;
/*      */   
/*      */   private void storeTime(Buffer intoBuf, Time tm) throws SQLException
/*      */   {
/*  258 */     intoBuf.ensureCapacity(9);
/*  259 */     intoBuf.writeByte((byte)8);
/*  260 */     intoBuf.writeByte((byte)0);
/*  261 */     intoBuf.writeLong(0L);
/*      */     
/*  263 */     Calendar sessionCalendar = getCalendarInstanceForSessionOrNew();
/*      */     
/*  265 */     synchronized (sessionCalendar) {
/*  266 */       java.util.Date oldTime = sessionCalendar.getTime();
/*      */       try {
/*  268 */         sessionCalendar.setTime(tm);
/*  269 */         intoBuf.writeByte((byte)sessionCalendar.get(11));
/*  270 */         intoBuf.writeByte((byte)sessionCalendar.get(12));
/*  271 */         intoBuf.writeByte((byte)sessionCalendar.get(13));
/*      */       }
/*      */       finally
/*      */       {
/*  275 */         sessionCalendar.setTime(oldTime);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  285 */   private boolean detectedLongParameterSwitch = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int fieldCount;
/*      */   
/*      */ 
/*      */ 
/*  294 */   private boolean invalid = false;
/*      */   
/*      */ 
/*      */   private SQLException invalidationException;
/*      */   
/*      */ 
/*      */   private Buffer outByteBuffer;
/*      */   
/*      */ 
/*      */   private BindValue[] parameterBindings;
/*      */   
/*      */ 
/*      */   private Field[] parameterFields;
/*      */   
/*      */ 
/*      */   private Field[] resultFields;
/*      */   
/*  311 */   private boolean sendTypesToServer = false;
/*      */   
/*      */ 
/*      */   private long serverStatementId;
/*      */   
/*      */ 
/*  317 */   private int stringTypeCode = 254;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean serverNeedsResetBeforeEachExecution;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static ServerPreparedStatement getInstance(MySQLConnection conn, String sql, String catalog, int resultSetType, int resultSetConcurrency)
/*      */     throws SQLException
/*      */   {
/*  331 */     if (!Util.isJdbc4()) {
/*  332 */       return new ServerPreparedStatement(conn, sql, catalog, resultSetType, resultSetConcurrency);
/*      */     }
/*      */     
/*      */     try
/*      */     {
/*  337 */       return (ServerPreparedStatement)JDBC_4_SPS_CTOR.newInstance(new Object[] { conn, sql, catalog, Integer.valueOf(resultSetType), Integer.valueOf(resultSetConcurrency) });
/*      */     }
/*      */     catch (IllegalArgumentException e)
/*      */     {
/*  341 */       throw new SQLException(e.toString(), "S1000");
/*      */     } catch (InstantiationException e) {
/*  343 */       throw new SQLException(e.toString(), "S1000");
/*      */     } catch (IllegalAccessException e) {
/*  345 */       throw new SQLException(e.toString(), "S1000");
/*      */     } catch (InvocationTargetException e) {
/*  347 */       Throwable target = e.getTargetException();
/*      */       
/*  349 */       if ((target instanceof SQLException)) {
/*  350 */         throw ((SQLException)target);
/*      */       }
/*      */       
/*  353 */       throw new SQLException(target.toString(), "S1000");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ServerPreparedStatement(MySQLConnection conn, String sql, String catalog, int resultSetType, int resultSetConcurrency)
/*      */     throws SQLException
/*      */   {
/*  373 */     super(conn, catalog);
/*      */     
/*  375 */     checkNullOrEmptyQuery(sql);
/*      */     
/*  377 */     this.hasOnDuplicateKeyUpdate = containsOnDuplicateKeyInString(sql);
/*      */     
/*  379 */     int startOfStatement = findStartOfStatement(sql);
/*      */     
/*  381 */     this.firstCharOfStmt = StringUtils.firstAlphaCharUc(sql, startOfStatement);
/*      */     
/*  383 */     if (this.connection.versionMeetsMinimum(5, 0, 0)) {
/*  384 */       this.serverNeedsResetBeforeEachExecution = (!this.connection.versionMeetsMinimum(5, 0, 3));
/*      */     }
/*      */     else {
/*  387 */       this.serverNeedsResetBeforeEachExecution = (!this.connection.versionMeetsMinimum(4, 1, 10));
/*      */     }
/*      */     
/*      */ 
/*  391 */     this.useAutoSlowLog = this.connection.getAutoSlowLog();
/*  392 */     this.useTrueBoolean = this.connection.versionMeetsMinimum(3, 21, 23);
/*  393 */     this.hasLimitClause = (StringUtils.indexOfIgnoreCase(sql, "LIMIT") != -1);
/*      */     
/*  395 */     String statementComment = this.connection.getStatementComment();
/*      */     
/*  397 */     this.originalSql = ("/* " + statementComment + " */ " + sql);
/*      */     
/*      */ 
/*  400 */     if (this.connection.versionMeetsMinimum(4, 1, 2)) {
/*  401 */       this.stringTypeCode = 253;
/*      */     } else {
/*  403 */       this.stringTypeCode = 254;
/*      */     }
/*      */     try
/*      */     {
/*  407 */       serverPrepare(sql);
/*      */     } catch (SQLException sqlEx) {
/*  409 */       realClose(false, true);
/*      */       
/*  411 */       throw sqlEx;
/*      */     } catch (Exception ex) {
/*  413 */       realClose(false, true);
/*      */       
/*  415 */       SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1000", getExceptionInterceptor());
/*      */       
/*  417 */       sqlEx.initCause(ex);
/*      */       
/*  419 */       throw sqlEx;
/*      */     }
/*      */     
/*  422 */     setResultSetType(resultSetType);
/*  423 */     setResultSetConcurrency(resultSetConcurrency);
/*      */     
/*  425 */     this.parameterTypes = new int[this.parameterCount];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void addBatch()
/*      */     throws SQLException
/*      */   {
/*  437 */     checkClosed();
/*      */     
/*  439 */     if (this.batchedArgs == null) {
/*  440 */       this.batchedArgs = new ArrayList();
/*      */     }
/*      */     
/*  443 */     this.batchedArgs.add(new BatchedBindValues(this.parameterBindings));
/*      */   }
/*      */   
/*      */   protected synchronized String asSql(boolean quoteStreamsAndUnknowns) throws SQLException
/*      */   {
/*  448 */     if (this.isClosed) {
/*  449 */       return "statement has been closed, no further internal information available";
/*      */     }
/*      */     
/*  452 */     PreparedStatement pStmtForSub = null;
/*      */     try
/*      */     {
/*  455 */       pStmtForSub = PreparedStatement.getInstance(this.connection, this.originalSql, this.currentCatalog);
/*      */       
/*      */ 
/*  458 */       int numParameters = pStmtForSub.parameterCount;
/*  459 */       int ourNumParameters = this.parameterCount;
/*      */       
/*  461 */       for (int i = 0; (i < numParameters) && (i < ourNumParameters); i++) {
/*  462 */         if (this.parameterBindings[i] != null) {
/*  463 */           if (this.parameterBindings[i].isNull) {
/*  464 */             pStmtForSub.setNull(i + 1, 0);
/*      */           } else {
/*  466 */             BindValue bindValue = this.parameterBindings[i];
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*  471 */             switch (bindValue.bufferType)
/*      */             {
/*      */             case 1: 
/*  474 */               pStmtForSub.setByte(i + 1, (byte)(int)bindValue.longBinding);
/*  475 */               break;
/*      */             case 2: 
/*  477 */               pStmtForSub.setShort(i + 1, (short)(int)bindValue.longBinding);
/*  478 */               break;
/*      */             case 3: 
/*  480 */               pStmtForSub.setInt(i + 1, (int)bindValue.longBinding);
/*  481 */               break;
/*      */             case 8: 
/*  483 */               pStmtForSub.setLong(i + 1, bindValue.longBinding);
/*  484 */               break;
/*      */             case 4: 
/*  486 */               pStmtForSub.setFloat(i + 1, bindValue.floatBinding);
/*  487 */               break;
/*      */             case 5: 
/*  489 */               pStmtForSub.setDouble(i + 1, bindValue.doubleBinding);
/*      */               
/*  491 */               break;
/*      */             case 6: case 7: default: 
/*  493 */               pStmtForSub.setObject(i + 1, this.parameterBindings[i].value);
/*      */             }
/*      */             
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  501 */       return pStmtForSub.asSql(quoteStreamsAndUnknowns);
/*      */     } finally {
/*  503 */       if (pStmtForSub != null) {
/*      */         try {
/*  505 */           pStmtForSub.close();
/*      */         }
/*      */         catch (SQLException sqlEx) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void checkClosed()
/*      */     throws SQLException
/*      */   {
/*  519 */     if (this.invalid) {
/*  520 */       throw this.invalidationException;
/*      */     }
/*      */     
/*  523 */     super.checkClosed();
/*      */   }
/*      */   
/*      */ 
/*      */   public void clearParameters()
/*      */     throws SQLException
/*      */   {
/*  530 */     checkClosed();
/*  531 */     clearParametersInternal(true);
/*      */   }
/*      */   
/*      */   private synchronized void clearParametersInternal(boolean clearServerParameters) throws SQLException
/*      */   {
/*  536 */     boolean hadLongData = false;
/*      */     
/*  538 */     if (this.parameterBindings != null) {
/*  539 */       for (int i = 0; i < this.parameterCount; i++) {
/*  540 */         if ((this.parameterBindings[i] != null) && (this.parameterBindings[i].isLongData))
/*      */         {
/*  542 */           hadLongData = true;
/*      */         }
/*      */         
/*  545 */         this.parameterBindings[i].reset();
/*      */       }
/*      */     }
/*      */     
/*  549 */     if ((clearServerParameters) && (hadLongData)) {
/*  550 */       serverResetStatement();
/*      */       
/*  552 */       this.detectedLongParameterSwitch = false;
/*      */     }
/*      */   }
/*      */   
/*  556 */   protected boolean isCached = false;
/*      */   
/*      */   private boolean useAutoSlowLog;
/*      */   
/*      */   private Calendar serverTzCalendar;
/*      */   private Calendar defaultTzCalendar;
/*      */   
/*      */   protected synchronized void setClosed(boolean flag)
/*      */   {
/*  565 */     this.isClosed = flag;
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized void close()
/*      */     throws SQLException
/*      */   {
/*  572 */     if ((this.isCached) && (!this.isClosed)) {
/*  573 */       clearParameters();
/*      */       
/*  575 */       this.isClosed = true;
/*      */       
/*  577 */       this.connection.recachePreparedStatement(this);
/*  578 */       return;
/*      */     }
/*      */     
/*  581 */     realClose(true, true);
/*      */   }
/*      */   
/*      */   private synchronized void dumpCloseForTestcase() {
/*  585 */     StringBuffer buf = new StringBuffer();
/*  586 */     this.connection.generateConnectionCommentBlock(buf);
/*  587 */     buf.append("DEALLOCATE PREPARE debug_stmt_");
/*  588 */     buf.append(this.statementId);
/*  589 */     buf.append(";\n");
/*      */     
/*  591 */     this.connection.dumpTestcaseQuery(buf.toString());
/*      */   }
/*      */   
/*      */   private synchronized void dumpExecuteForTestcase() throws SQLException {
/*  595 */     StringBuffer buf = new StringBuffer();
/*      */     
/*  597 */     for (int i = 0; i < this.parameterCount; i++) {
/*  598 */       this.connection.generateConnectionCommentBlock(buf);
/*      */       
/*  600 */       buf.append("SET @debug_stmt_param");
/*  601 */       buf.append(this.statementId);
/*  602 */       buf.append("_");
/*  603 */       buf.append(i);
/*  604 */       buf.append("=");
/*      */       
/*  606 */       if (this.parameterBindings[i].isNull) {
/*  607 */         buf.append("NULL");
/*      */       } else {
/*  609 */         buf.append(this.parameterBindings[i].toString(true));
/*      */       }
/*      */       
/*  612 */       buf.append(";\n");
/*      */     }
/*      */     
/*  615 */     this.connection.generateConnectionCommentBlock(buf);
/*      */     
/*  617 */     buf.append("EXECUTE debug_stmt_");
/*  618 */     buf.append(this.statementId);
/*      */     
/*  620 */     if (this.parameterCount > 0) {
/*  621 */       buf.append(" USING ");
/*  622 */       for (int i = 0; i < this.parameterCount; i++) {
/*  623 */         if (i > 0) {
/*  624 */           buf.append(", ");
/*      */         }
/*      */         
/*  627 */         buf.append("@debug_stmt_param");
/*  628 */         buf.append(this.statementId);
/*  629 */         buf.append("_");
/*  630 */         buf.append(i);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  635 */     buf.append(";\n");
/*      */     
/*  637 */     this.connection.dumpTestcaseQuery(buf.toString());
/*      */   }
/*      */   
/*      */   private synchronized void dumpPrepareForTestcase() throws SQLException
/*      */   {
/*  642 */     StringBuffer buf = new StringBuffer(this.originalSql.length() + 64);
/*      */     
/*  644 */     this.connection.generateConnectionCommentBlock(buf);
/*      */     
/*  646 */     buf.append("PREPARE debug_stmt_");
/*  647 */     buf.append(this.statementId);
/*  648 */     buf.append(" FROM \"");
/*  649 */     buf.append(this.originalSql);
/*  650 */     buf.append("\";\n");
/*      */     
/*  652 */     this.connection.dumpTestcaseQuery(buf.toString());
/*      */   }
/*      */   
/*      */   protected synchronized int[] executeBatchSerially(int batchTimeout) throws SQLException {
/*  656 */     MySQLConnection locallyScopedConn = this.connection;
/*      */     
/*  658 */     if (locallyScopedConn == null) {
/*  659 */       checkClosed();
/*      */     }
/*      */     
/*  662 */     if (locallyScopedConn.isReadOnly()) {
/*  663 */       throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.2") + Messages.getString("ServerPreparedStatement.3"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  669 */     checkClosed();
/*      */     BindValue[] oldBindValues;
/*  671 */     synchronized (locallyScopedConn) {
/*  672 */       clearWarnings();
/*      */       
/*      */ 
/*      */ 
/*  676 */       oldBindValues = this.parameterBindings;
/*      */     }
/*      */     try {
/*  679 */       int[] updateCounts = null;
/*      */       
/*  681 */       if (this.batchedArgs != null) {
/*  682 */         nbrCommands = this.batchedArgs.size();
/*  683 */         updateCounts = new int[nbrCommands];
/*      */         
/*  685 */         if (this.retrieveGeneratedKeys) {
/*  686 */           this.batchedGeneratedKeys = new ArrayList(nbrCommands);
/*      */         }
/*      */         
/*  689 */         for (int i = 0; i < nbrCommands; i++) {
/*  690 */           updateCounts[i] = -3;
/*      */         }
/*      */         
/*  693 */         SQLException sqlEx = null;
/*      */         
/*  695 */         int commandIndex = 0;
/*      */         
/*  697 */         BindValue[] previousBindValuesForBatch = null;
/*      */         
/*  699 */         StatementImpl.CancelTask timeoutTask = null;
/*      */         try
/*      */         {
/*  702 */           if ((locallyScopedConn.getEnableQueryTimeouts()) && (batchTimeout != 0) && (locallyScopedConn.versionMeetsMinimum(5, 0, 0)))
/*      */           {
/*      */ 
/*  705 */             timeoutTask = new StatementImpl.CancelTask(this, this);
/*  706 */             locallyScopedConn.getCancelTimer().schedule(timeoutTask, batchTimeout);
/*      */           }
/*      */           
/*      */ 
/*  710 */           for (commandIndex = 0; commandIndex < nbrCommands; commandIndex++) {
/*  711 */             Object arg = this.batchedArgs.get(commandIndex);
/*      */             
/*  713 */             if ((arg instanceof String)) {
/*  714 */               updateCounts[commandIndex] = executeUpdate((String)arg);
/*      */             } else {
/*  716 */               this.parameterBindings = ((BatchedBindValues)arg).batchedParameterValues;
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */               try
/*      */               {
/*  723 */                 if (previousBindValuesForBatch != null) {
/*  724 */                   for (int j = 0; j < this.parameterBindings.length; j++) {
/*  725 */                     if (this.parameterBindings[j].bufferType != previousBindValuesForBatch[j].bufferType) {
/*  726 */                       this.sendTypesToServer = true;
/*      */                       
/*  728 */                       break;
/*      */                     }
/*      */                   }
/*      */                 }
/*      */                 try
/*      */                 {
/*  734 */                   updateCounts[commandIndex] = executeUpdate(false, true);
/*      */                 } finally {
/*  736 */                   previousBindValuesForBatch = this.parameterBindings;
/*      */                 }
/*      */                 
/*  739 */                 if (this.retrieveGeneratedKeys) {
/*  740 */                   ResultSet rs = null;
/*      */                   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                   try
/*      */                   {
/*  752 */                     rs = getGeneratedKeysInternal();
/*      */                     
/*  754 */                     while (rs.next()) {
/*  755 */                       this.batchedGeneratedKeys.add(new ByteArrayRow(new byte[][] { rs.getBytes(1) }, getExceptionInterceptor()));
/*      */                     }
/*      */                   }
/*      */                   finally
/*      */                   {
/*  760 */                     if (rs != null) {
/*  761 */                       rs.close();
/*      */                     }
/*      */                   }
/*      */                 }
/*      */               } catch (SQLException ex) {
/*  766 */                 updateCounts[commandIndex] = -3;
/*      */                 
/*  768 */                 if ((this.continueBatchOnError) && (!(ex instanceof MySQLTimeoutException)) && (!(ex instanceof MySQLStatementCancelledException)) && (!hasDeadlockOrTimeoutRolledBackTx(ex)))
/*      */                 {
/*      */ 
/*      */ 
/*  772 */                   sqlEx = ex;
/*      */                 } else {
/*  774 */                   int[] newUpdateCounts = new int[commandIndex];
/*  775 */                   System.arraycopy(updateCounts, 0, newUpdateCounts, 0, commandIndex);
/*      */                   
/*      */ 
/*  778 */                   throw new BatchUpdateException(ex.getMessage(), ex.getSQLState(), ex.getErrorCode(), newUpdateCounts);
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */         finally
/*      */         {
/*  786 */           if (timeoutTask != null) {
/*  787 */             timeoutTask.cancel();
/*      */             
/*  789 */             locallyScopedConn.getCancelTimer().purge();
/*      */           }
/*      */           
/*  792 */           resetCancelledState();
/*      */         }
/*      */         
/*  795 */         if (sqlEx != null) {
/*  796 */           throw new BatchUpdateException(sqlEx.getMessage(), sqlEx.getSQLState(), sqlEx.getErrorCode(), updateCounts);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  802 */       int nbrCommands = updateCounts != null ? updateCounts : new int[0];jsr 16;return nbrCommands;
/*      */     } finally {
/*  804 */       jsr 6; } localObject8 = returnAddress;this.parameterBindings = oldBindValues;
/*  805 */     this.sendTypesToServer = true;
/*      */     
/*  807 */     clearBatch();ret;
/*      */     
/*  809 */     localObject9 = finally;throw ((Throwable)localObject9);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized ResultSetInternalMethods executeInternal(int maxRowsToRetrieve, Buffer sendPacket, boolean createStreamingResultSet, boolean queryIsSelectOnly, Field[] metadataFromCache, boolean isBatch)
/*      */     throws SQLException
/*      */   {
/*  821 */     this.numberOfExecutions += 1;
/*      */     
/*      */     try
/*      */     {
/*  825 */       return serverExecute(maxRowsToRetrieve, createStreamingResultSet, metadataFromCache);
/*      */     }
/*      */     catch (SQLException sqlEx)
/*      */     {
/*  829 */       if (this.connection.getEnablePacketDebug()) {
/*  830 */         this.connection.getIO().dumpPacketRingBuffer();
/*      */       }
/*      */       
/*  833 */       if (this.connection.getDumpQueriesOnException()) {
/*  834 */         String extractedSql = toString();
/*  835 */         StringBuffer messageBuf = new StringBuffer(extractedSql.length() + 32);
/*      */         
/*  837 */         messageBuf.append("\n\nQuery being executed when exception was thrown:\n");
/*      */         
/*  839 */         messageBuf.append(extractedSql);
/*  840 */         messageBuf.append("\n\n");
/*      */         
/*  842 */         sqlEx = ConnectionImpl.appendMessageToException(sqlEx, messageBuf.toString(), getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*  846 */       throw sqlEx;
/*      */     } catch (Exception ex) {
/*  848 */       if (this.connection.getEnablePacketDebug()) {
/*  849 */         this.connection.getIO().dumpPacketRingBuffer();
/*      */       }
/*      */       
/*  852 */       SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1000", getExceptionInterceptor());
/*      */       
/*      */ 
/*  855 */       if (this.connection.getDumpQueriesOnException()) {
/*  856 */         String extractedSql = toString();
/*  857 */         StringBuffer messageBuf = new StringBuffer(extractedSql.length() + 32);
/*      */         
/*  859 */         messageBuf.append("\n\nQuery being executed when exception was thrown:\n");
/*      */         
/*  861 */         messageBuf.append(extractedSql);
/*  862 */         messageBuf.append("\n\n");
/*      */         
/*  864 */         sqlEx = ConnectionImpl.appendMessageToException(sqlEx, messageBuf.toString(), getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*  868 */       sqlEx.initCause(ex);
/*      */       
/*  870 */       throw sqlEx;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected Buffer fillSendPacket()
/*      */     throws SQLException
/*      */   {
/*  878 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Buffer fillSendPacket(byte[][] batchedParameterStrings, InputStream[] batchedParameterStreams, boolean[] batchedIsStream, int[] batchedStreamLengths)
/*      */     throws SQLException
/*      */   {
/*  888 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized BindValue getBinding(int parameterIndex, boolean forLongData)
/*      */     throws SQLException
/*      */   {
/*  902 */     checkClosed();
/*      */     
/*  904 */     if (this.parameterBindings.length == 0) {
/*  905 */       throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.8"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  910 */     parameterIndex--;
/*      */     
/*  912 */     if ((parameterIndex < 0) || (parameterIndex >= this.parameterBindings.length))
/*      */     {
/*  914 */       throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.9") + (parameterIndex + 1) + Messages.getString("ServerPreparedStatement.10") + this.parameterBindings.length, "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  922 */     if (this.parameterBindings[parameterIndex] == null) {
/*  923 */       this.parameterBindings[parameterIndex] = new BindValue();
/*      */     }
/*  925 */     else if ((this.parameterBindings[parameterIndex].isLongData) && (!forLongData))
/*      */     {
/*  927 */       this.detectedLongParameterSwitch = true;
/*      */     }
/*      */     
/*      */ 
/*  931 */     this.parameterBindings[parameterIndex].isSet = true;
/*  932 */     this.parameterBindings[parameterIndex].boundBeforeExecutionNum = this.numberOfExecutions;
/*      */     
/*  934 */     return this.parameterBindings[parameterIndex];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BindValue[] getParameterBindValues()
/*      */   {
/*  944 */     return this.parameterBindings;
/*      */   }
/*      */   
/*      */ 
/*      */   synchronized byte[] getBytes(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/*  951 */     BindValue bindValue = getBinding(parameterIndex, false);
/*      */     
/*  953 */     if (bindValue.isNull)
/*  954 */       return null;
/*  955 */     if (bindValue.isLongData) {
/*  956 */       throw SQLError.notImplemented();
/*      */     }
/*  958 */     if (this.outByteBuffer == null) {
/*  959 */       this.outByteBuffer = new Buffer(this.connection.getNetBufferLength());
/*      */     }
/*      */     
/*      */ 
/*  963 */     this.outByteBuffer.clear();
/*      */     
/*  965 */     int originalPosition = this.outByteBuffer.getPosition();
/*      */     
/*  967 */     storeBinding(this.outByteBuffer, bindValue, this.connection.getIO());
/*      */     
/*  969 */     int newPosition = this.outByteBuffer.getPosition();
/*      */     
/*  971 */     int length = newPosition - originalPosition;
/*      */     
/*  973 */     byte[] valueAsBytes = new byte[length];
/*      */     
/*  975 */     System.arraycopy(this.outByteBuffer.getByteBuffer(), originalPosition, valueAsBytes, 0, length);
/*      */     
/*      */ 
/*  978 */     return valueAsBytes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized java.sql.ResultSetMetaData getMetaData()
/*      */     throws SQLException
/*      */   {
/*  986 */     checkClosed();
/*      */     
/*  988 */     if (this.resultFields == null) {
/*  989 */       return null;
/*      */     }
/*      */     
/*  992 */     return new ResultSetMetaData(this.resultFields, this.connection.getUseOldAliasMetadataBehavior(), getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized ParameterMetaData getParameterMetaData()
/*      */     throws SQLException
/*      */   {
/* 1000 */     checkClosed();
/*      */     
/* 1002 */     if (this.parameterMetaData == null) {
/* 1003 */       this.parameterMetaData = new MysqlParameterMetadata(this.parameterFields, this.parameterCount, getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 1007 */     return this.parameterMetaData;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   boolean isNull(int paramIndex)
/*      */   {
/* 1014 */     throw new IllegalArgumentException(Messages.getString("ServerPreparedStatement.7"));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void realClose(boolean calledExplicitly, boolean closeOpenResults)
/*      */     throws SQLException
/*      */   {
/* 1029 */     if (this.isClosed) {
/* 1030 */       return;
/*      */     }
/*      */     
/* 1033 */     if (this.connection != null) {
/* 1034 */       if (this.connection.getAutoGenerateTestcaseScript()) {
/* 1035 */         dumpCloseForTestcase();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1049 */       SQLException exceptionDuringClose = null;
/*      */       
/* 1051 */       if ((calledExplicitly) && (!this.connection.isClosed())) {
/* 1052 */         synchronized (this.connection)
/*      */         {
/*      */           try {
/* 1055 */             MysqlIO mysql = this.connection.getIO();
/*      */             
/* 1057 */             Buffer packet = mysql.getSharedSendPacket();
/*      */             
/* 1059 */             packet.writeByte((byte)25);
/* 1060 */             packet.writeLong(this.serverStatementId);
/*      */             
/* 1062 */             mysql.sendCommand(25, null, packet, true, null, 0);
/*      */           }
/*      */           catch (SQLException sqlEx) {
/* 1065 */             exceptionDuringClose = sqlEx;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 1070 */       super.realClose(calledExplicitly, closeOpenResults);
/*      */       
/* 1072 */       clearParametersInternal(false);
/* 1073 */       this.parameterBindings = null;
/*      */       
/* 1075 */       this.parameterFields = null;
/* 1076 */       this.resultFields = null;
/*      */       
/* 1078 */       if (exceptionDuringClose != null) {
/* 1079 */         throw exceptionDuringClose;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void rePrepare()
/*      */     throws SQLException
/*      */   {
/* 1092 */     this.invalidationException = null;
/*      */     try
/*      */     {
/* 1095 */       serverPrepare(this.originalSql);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/* 1098 */       this.invalidationException = sqlEx;
/*      */     } catch (Exception ex) {
/* 1100 */       this.invalidationException = SQLError.createSQLException(ex.toString(), "S1000", getExceptionInterceptor());
/*      */       
/* 1102 */       this.invalidationException.initCause(ex);
/*      */     }
/*      */     
/* 1105 */     if (this.invalidationException != null) {
/* 1106 */       this.invalid = true;
/*      */       
/* 1108 */       this.parameterBindings = null;
/*      */       
/* 1110 */       this.parameterFields = null;
/* 1111 */       this.resultFields = null;
/*      */       
/* 1113 */       if (this.results != null) {
/*      */         try {
/* 1115 */           this.results.close();
/*      */         }
/*      */         catch (Exception ex) {}
/*      */       }
/*      */       
/*      */ 
/* 1121 */       if (this.connection != null) {
/* 1122 */         if (this.maxRowsChanged) {
/* 1123 */           this.connection.unsetMaxRows(this);
/*      */         }
/*      */         
/* 1126 */         if (!this.connection.getDontTrackOpenResources()) {
/* 1127 */           this.connection.unregisterStatement(this);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private synchronized ResultSetInternalMethods serverExecute(int maxRowsToRetrieve, boolean createStreamingResultSet, Field[] metadataFromCache)
/*      */     throws SQLException
/*      */   {
/* 1169 */     synchronized (this.connection) {
/* 1170 */       MysqlIO mysql = this.connection.getIO();
/*      */       
/* 1172 */       if (mysql.shouldIntercept()) {
/* 1173 */         ResultSetInternalMethods interceptedResults = mysql.invokeStatementInterceptorsPre(this.originalSql, this, true);
/*      */         
/*      */ 
/* 1176 */         if (interceptedResults != null) {
/* 1177 */           return interceptedResults;
/*      */         }
/*      */       }
/*      */       
/* 1181 */       if (this.detectedLongParameterSwitch)
/*      */       {
/* 1183 */         boolean firstFound = false;
/* 1184 */         long boundTimeToCheck = 0L;
/*      */         
/* 1186 */         for (int i = 0; i < this.parameterCount - 1; i++) {
/* 1187 */           if (this.parameterBindings[i].isLongData) {
/* 1188 */             if ((firstFound) && (boundTimeToCheck != this.parameterBindings[i].boundBeforeExecutionNum))
/*      */             {
/* 1190 */               throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.11") + Messages.getString("ServerPreparedStatement.12"), "S1C00", getExceptionInterceptor());
/*      */             }
/*      */             
/*      */ 
/*      */ 
/* 1195 */             firstFound = true;
/* 1196 */             boundTimeToCheck = this.parameterBindings[i].boundBeforeExecutionNum;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1204 */         serverResetStatement();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1209 */       for (int i = 0; i < this.parameterCount; i++) {
/* 1210 */         if (!this.parameterBindings[i].isSet) {
/* 1211 */           throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.13") + (i + 1) + Messages.getString("ServerPreparedStatement.14"), "S1009", getExceptionInterceptor());
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1221 */       for (int i = 0; i < this.parameterCount; i++) {
/* 1222 */         if (this.parameterBindings[i].isLongData) {
/* 1223 */           serverLongData(i, this.parameterBindings[i]);
/*      */         }
/*      */       }
/*      */       
/* 1227 */       if (this.connection.getAutoGenerateTestcaseScript()) {
/* 1228 */         dumpExecuteForTestcase();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1235 */       Buffer packet = mysql.getSharedSendPacket();
/*      */       
/* 1237 */       packet.clear();
/* 1238 */       packet.writeByte((byte)23);
/* 1239 */       packet.writeLong(this.serverStatementId);
/*      */       
/* 1241 */       boolean usingCursor = false;
/*      */       
/* 1243 */       if (this.connection.versionMeetsMinimum(4, 1, 2))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1250 */         if ((this.resultFields != null) && (this.connection.isCursorFetchEnabled()) && (getResultSetType() == 1003) && (getResultSetConcurrency() == 1007) && (getFetchSize() > 0))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/* 1255 */           packet.writeByte((byte)1);
/* 1256 */           usingCursor = true;
/*      */         } else {
/* 1258 */           packet.writeByte((byte)0);
/*      */         }
/*      */         
/* 1261 */         packet.writeLong(1L);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1266 */       int nullCount = (this.parameterCount + 7) / 8;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1271 */       int nullBitsPosition = packet.getPosition();
/*      */       
/* 1273 */       for (int i = 0; i < nullCount; i++) {
/* 1274 */         packet.writeByte((byte)0);
/*      */       }
/*      */       
/* 1277 */       byte[] nullBitsBuffer = new byte[nullCount];
/*      */       
/*      */ 
/* 1280 */       packet.writeByte((byte)(this.sendTypesToServer ? 1 : 0));
/*      */       
/* 1282 */       if (this.sendTypesToServer)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1287 */         for (int i = 0; i < this.parameterCount; i++) {
/* 1288 */           packet.writeInt(this.parameterBindings[i].bufferType);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1295 */       for (int i = 0; i < this.parameterCount; i++) {
/* 1296 */         if (!this.parameterBindings[i].isLongData) {
/* 1297 */           if (!this.parameterBindings[i].isNull) {
/* 1298 */             storeBinding(packet, this.parameterBindings[i], mysql);
/*      */           } else {
/* 1300 */             int tmp590_589 = (i / 8); byte[] tmp590_583 = nullBitsBuffer;tmp590_583[tmp590_589] = ((byte)(tmp590_583[tmp590_589] | 1 << (i & 0x7)));
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1309 */       int endPosition = packet.getPosition();
/* 1310 */       packet.setPosition(nullBitsPosition);
/* 1311 */       packet.writeBytesNoNull(nullBitsBuffer);
/* 1312 */       packet.setPosition(endPosition);
/*      */       
/* 1314 */       long begin = 0L;
/*      */       
/* 1316 */       boolean logSlowQueries = this.connection.getLogSlowQueries();
/* 1317 */       boolean gatherPerformanceMetrics = this.connection.getGatherPerformanceMetrics();
/*      */       
/*      */ 
/* 1320 */       if ((this.profileSQL) || (logSlowQueries) || (gatherPerformanceMetrics)) {
/* 1321 */         begin = mysql.getCurrentTimeNanosOrMillis();
/*      */       }
/*      */       
/* 1324 */       resetCancelledState();
/*      */       
/* 1326 */       StatementImpl.CancelTask timeoutTask = null;
/*      */       try
/*      */       {
/* 1329 */         if ((this.connection.getEnableQueryTimeouts()) && (this.timeoutInMillis != 0) && (this.connection.versionMeetsMinimum(5, 0, 0)))
/*      */         {
/*      */ 
/* 1332 */           timeoutTask = new StatementImpl.CancelTask(this, this);
/* 1333 */           this.connection.getCancelTimer().schedule(timeoutTask, this.timeoutInMillis);
/*      */         }
/*      */         
/*      */ 
/* 1337 */         statementBegins();
/*      */         
/* 1339 */         Buffer resultPacket = mysql.sendCommand(23, null, packet, false, null, 0);
/*      */         
/*      */ 
/* 1342 */         long queryEndTime = 0L;
/*      */         
/* 1344 */         if ((logSlowQueries) || (gatherPerformanceMetrics) || (this.profileSQL)) {
/* 1345 */           queryEndTime = mysql.getCurrentTimeNanosOrMillis();
/*      */         }
/*      */         
/* 1348 */         if (timeoutTask != null) {
/* 1349 */           timeoutTask.cancel();
/*      */           
/* 1351 */           this.connection.getCancelTimer().purge();
/*      */           
/* 1353 */           if (timeoutTask.caughtWhileCancelling != null) {
/* 1354 */             throw timeoutTask.caughtWhileCancelling;
/*      */           }
/*      */           
/* 1357 */           timeoutTask = null;
/*      */         }
/*      */         
/* 1360 */         synchronized (this.cancelTimeoutMutex) {
/* 1361 */           if (this.wasCancelled) {
/* 1362 */             SQLException cause = null;
/*      */             
/* 1364 */             if (this.wasCancelledByTimeout) {
/* 1365 */               cause = new MySQLTimeoutException();
/*      */             } else {
/* 1367 */               cause = new MySQLStatementCancelledException();
/*      */             }
/*      */             
/* 1370 */             resetCancelledState();
/*      */             
/* 1372 */             throw cause;
/*      */           }
/*      */         }
/*      */         
/* 1376 */         boolean queryWasSlow = false;
/*      */         
/* 1378 */         if ((logSlowQueries) || (gatherPerformanceMetrics)) {
/* 1379 */           long elapsedTime = queryEndTime - begin;
/*      */           
/* 1381 */           if (logSlowQueries) {
/* 1382 */             if (this.useAutoSlowLog) {
/* 1383 */               queryWasSlow = elapsedTime > this.connection.getSlowQueryThresholdMillis();
/*      */             } else {
/* 1385 */               queryWasSlow = this.connection.isAbonormallyLongQuery(elapsedTime);
/*      */               
/* 1387 */               this.connection.reportQueryTime(elapsedTime);
/*      */             }
/*      */           }
/*      */           
/* 1391 */           if (queryWasSlow)
/*      */           {
/* 1393 */             StringBuffer mesgBuf = new StringBuffer(48 + this.originalSql.length());
/*      */             
/* 1395 */             mesgBuf.append(Messages.getString("ServerPreparedStatement.15"));
/*      */             
/* 1397 */             mesgBuf.append(mysql.getSlowQueryThreshold());
/* 1398 */             mesgBuf.append(Messages.getString("ServerPreparedStatement.15a"));
/*      */             
/* 1400 */             mesgBuf.append(elapsedTime);
/* 1401 */             mesgBuf.append(Messages.getString("ServerPreparedStatement.16"));
/*      */             
/*      */ 
/* 1404 */             mesgBuf.append("as prepared: ");
/* 1405 */             mesgBuf.append(this.originalSql);
/* 1406 */             mesgBuf.append("\n\n with parameters bound:\n\n");
/* 1407 */             mesgBuf.append(asSql(true));
/*      */             
/* 1409 */             this.eventSink.consumeEvent(new ProfilerEvent((byte)6, "", this.currentCatalog, this.connection.getId(), getId(), 0, System.currentTimeMillis(), elapsedTime, mysql.getQueryTimingUnits(), null, new Throwable(), mesgBuf.toString()));
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1419 */           if (gatherPerformanceMetrics) {
/* 1420 */             this.connection.registerQueryExecutionTime(elapsedTime);
/*      */           }
/*      */         }
/*      */         
/* 1424 */         this.connection.incrementNumberOfPreparedExecutes();
/*      */         
/* 1426 */         if (this.profileSQL) {
/* 1427 */           this.eventSink = ProfilerEventHandlerFactory.getInstance(this.connection);
/*      */           
/*      */ 
/* 1430 */           this.eventSink.consumeEvent(new ProfilerEvent((byte)4, "", this.currentCatalog, this.connectionId, this.statementId, -1, System.currentTimeMillis(), (int)(mysql.getCurrentTimeNanosOrMillis() - begin), mysql.getQueryTimingUnits(), null, new Throwable(), truncateQueryToLog(asSql(true))));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1440 */         ResultSetInternalMethods rs = mysql.readAllResults(this, maxRowsToRetrieve, this.resultSetType, this.resultSetConcurrency, createStreamingResultSet, this.currentCatalog, resultPacket, true, this.fieldCount, metadataFromCache);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1446 */         if (mysql.shouldIntercept()) {
/* 1447 */           ResultSetInternalMethods interceptedResults = mysql.invokeStatementInterceptorsPost(this.originalSql, this, rs, true, null);
/*      */           
/*      */ 
/* 1450 */           if (interceptedResults != null) {
/* 1451 */             rs = interceptedResults;
/*      */           }
/*      */         }
/*      */         
/* 1455 */         if (this.profileSQL) {
/* 1456 */           long fetchEndTime = mysql.getCurrentTimeNanosOrMillis();
/*      */           
/* 1458 */           this.eventSink.consumeEvent(new ProfilerEvent((byte)5, "", this.currentCatalog, this.connection.getId(), getId(), 0, System.currentTimeMillis(), fetchEndTime - queryEndTime, mysql.getQueryTimingUnits(), null, new Throwable(), null));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1467 */         if ((queryWasSlow) && (this.connection.getExplainSlowQueries())) {
/* 1468 */           queryAsString = asSql(true);
/*      */           
/* 1470 */           mysql.explainSlowQuery(StringUtils.getBytes((String)queryAsString), (String)queryAsString);
/*      */         }
/*      */         
/*      */ 
/* 1474 */         if ((!createStreamingResultSet) && (this.serverNeedsResetBeforeEachExecution))
/*      */         {
/* 1476 */           serverResetStatement();
/*      */         }
/*      */         
/*      */ 
/* 1480 */         this.sendTypesToServer = false;
/* 1481 */         this.results = rs;
/*      */         
/* 1483 */         if (mysql.hadWarnings()) {
/* 1484 */           mysql.scanForAndThrowDataTruncation();
/*      */         }
/*      */         
/* 1487 */         Object queryAsString = rs;jsr 45;return (ResultSetInternalMethods)queryAsString;
/*      */       } catch (SQLException sqlEx) {
/* 1489 */         if (mysql.shouldIntercept()) {
/* 1490 */           mysql.invokeStatementInterceptorsPost(this.originalSql, this, null, true, sqlEx);
/*      */         }
/*      */         
/* 1493 */         throw sqlEx;
/*      */       } finally {
/* 1495 */         jsr 6; } localObject3 = returnAddress;this.statementExecuting.set(false);
/*      */       
/* 1497 */       if (timeoutTask != null) {
/* 1498 */         timeoutTask.cancel();
/* 1499 */         this.connection.getCancelTimer().purge(); } ret;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private synchronized void serverLongData(int parameterIndex, BindValue longData)
/*      */     throws SQLException
/*      */   {
/* 1534 */     synchronized (this.connection) {
/* 1535 */       MysqlIO mysql = this.connection.getIO();
/*      */       
/* 1537 */       Buffer packet = mysql.getSharedSendPacket();
/*      */       
/* 1539 */       Object value = longData.value;
/*      */       
/* 1541 */       if ((value instanceof byte[])) {
/* 1542 */         packet.clear();
/* 1543 */         packet.writeByte((byte)24);
/* 1544 */         packet.writeLong(this.serverStatementId);
/* 1545 */         packet.writeInt(parameterIndex);
/*      */         
/* 1547 */         packet.writeBytesNoNull((byte[])longData.value);
/*      */         
/* 1549 */         mysql.sendCommand(24, null, packet, true, null, 0);
/*      */       }
/* 1551 */       else if ((value instanceof InputStream)) {
/* 1552 */         storeStream(mysql, parameterIndex, packet, (InputStream)value);
/* 1553 */       } else if ((value instanceof Blob)) {
/* 1554 */         storeStream(mysql, parameterIndex, packet, ((Blob)value).getBinaryStream());
/*      */       }
/* 1556 */       else if ((value instanceof Reader)) {
/* 1557 */         storeReader(mysql, parameterIndex, packet, (Reader)value);
/*      */       } else {
/* 1559 */         throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.18") + value.getClass().getName() + "'", "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private synchronized void serverPrepare(String sql)
/*      */     throws SQLException
/*      */   {
/* 1568 */     synchronized (this.connection) {
/* 1569 */       MysqlIO mysql = this.connection.getIO();
/*      */       
/* 1571 */       if (this.connection.getAutoGenerateTestcaseScript()) {
/* 1572 */         dumpPrepareForTestcase();
/*      */       }
/*      */       try
/*      */       {
/* 1576 */         long begin = 0L;
/*      */         
/* 1578 */         if (StringUtils.startsWithIgnoreCaseAndWs(sql, "LOAD DATA")) {
/* 1579 */           this.isLoadDataQuery = true;
/*      */         } else {
/* 1581 */           this.isLoadDataQuery = false;
/*      */         }
/*      */         
/* 1584 */         if (this.connection.getProfileSql()) {
/* 1585 */           begin = System.currentTimeMillis();
/*      */         }
/*      */         
/* 1588 */         String characterEncoding = null;
/* 1589 */         String connectionEncoding = this.connection.getEncoding();
/*      */         
/* 1591 */         if ((!this.isLoadDataQuery) && (this.connection.getUseUnicode()) && (connectionEncoding != null))
/*      */         {
/* 1593 */           characterEncoding = connectionEncoding;
/*      */         }
/*      */         
/* 1596 */         Buffer prepareResultPacket = mysql.sendCommand(22, sql, null, false, characterEncoding, 0);
/*      */         
/*      */ 
/*      */ 
/* 1600 */         if (this.connection.versionMeetsMinimum(4, 1, 1))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/* 1605 */           prepareResultPacket.setPosition(1);
/*      */         }
/*      */         else
/*      */         {
/* 1609 */           prepareResultPacket.setPosition(0);
/*      */         }
/*      */         
/* 1612 */         this.serverStatementId = prepareResultPacket.readLong();
/* 1613 */         this.fieldCount = prepareResultPacket.readInt();
/* 1614 */         this.parameterCount = prepareResultPacket.readInt();
/* 1615 */         this.parameterBindings = new BindValue[this.parameterCount];
/*      */         
/* 1617 */         for (int i = 0; i < this.parameterCount; i++) {
/* 1618 */           this.parameterBindings[i] = new BindValue();
/*      */         }
/*      */         
/* 1621 */         this.connection.incrementNumberOfPrepares();
/*      */         
/* 1623 */         if (this.profileSQL) {
/* 1624 */           this.eventSink.consumeEvent(new ProfilerEvent((byte)2, "", this.currentCatalog, this.connectionId, this.statementId, -1, System.currentTimeMillis(), mysql.getCurrentTimeNanosOrMillis() - begin, mysql.getQueryTimingUnits(), null, new Throwable(), truncateQueryToLog(sql)));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1634 */         if ((this.parameterCount > 0) && 
/* 1635 */           (this.connection.versionMeetsMinimum(4, 1, 2)) && (!mysql.isVersion(5, 0, 0)))
/*      */         {
/* 1637 */           this.parameterFields = new Field[this.parameterCount];
/*      */           
/* 1639 */           Buffer metaDataPacket = mysql.readPacket();
/*      */           
/* 1641 */           int i = 0;
/*      */           
/*      */ 
/* 1644 */           while ((!metaDataPacket.isLastDataPacket()) && (i < this.parameterCount)) {
/* 1645 */             this.parameterFields[(i++)] = mysql.unpackField(metaDataPacket, false);
/*      */             
/* 1647 */             metaDataPacket = mysql.readPacket();
/*      */           }
/*      */         }
/*      */         
/*      */ 
/* 1652 */         if (this.fieldCount > 0) {
/* 1653 */           this.resultFields = new Field[this.fieldCount];
/*      */           
/* 1655 */           Buffer fieldPacket = mysql.readPacket();
/*      */           
/* 1657 */           int i = 0;
/*      */           
/*      */ 
/*      */ 
/* 1661 */           while ((!fieldPacket.isLastDataPacket()) && (i < this.fieldCount)) {
/* 1662 */             this.resultFields[(i++)] = mysql.unpackField(fieldPacket, false);
/*      */             
/* 1664 */             fieldPacket = mysql.readPacket();
/*      */           }
/*      */         }
/*      */       } catch (SQLException sqlEx) {
/* 1668 */         if (this.connection.getDumpQueriesOnException()) {
/* 1669 */           StringBuffer messageBuf = new StringBuffer(this.originalSql.length() + 32);
/*      */           
/* 1671 */           messageBuf.append("\n\nQuery being prepared when exception was thrown:\n\n");
/*      */           
/* 1673 */           messageBuf.append(this.originalSql);
/*      */           
/* 1675 */           sqlEx = ConnectionImpl.appendMessageToException(sqlEx, messageBuf.toString(), getExceptionInterceptor());
/*      */         }
/*      */         
/*      */ 
/* 1679 */         throw sqlEx;
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/* 1684 */         this.connection.getIO().clearInputStream();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private synchronized String truncateQueryToLog(String sql) {
/* 1690 */     String query = null;
/*      */     
/* 1692 */     if (sql.length() > this.connection.getMaxQuerySizeToLog()) {
/* 1693 */       StringBuffer queryBuf = new StringBuffer(this.connection.getMaxQuerySizeToLog() + 12);
/*      */       
/* 1695 */       queryBuf.append(sql.substring(0, this.connection.getMaxQuerySizeToLog()));
/* 1696 */       queryBuf.append(Messages.getString("MysqlIO.25"));
/*      */       
/* 1698 */       query = queryBuf.toString();
/*      */     } else {
/* 1700 */       query = sql;
/*      */     }
/*      */     
/* 1703 */     return query;
/*      */   }
/*      */   
/*      */   private synchronized void serverResetStatement() throws SQLException {
/* 1707 */     synchronized (this.connection)
/*      */     {
/* 1709 */       MysqlIO mysql = this.connection.getIO();
/*      */       
/* 1711 */       Buffer packet = mysql.getSharedSendPacket();
/*      */       
/* 1713 */       packet.clear();
/* 1714 */       packet.writeByte((byte)26);
/* 1715 */       packet.writeLong(this.serverStatementId);
/*      */       try
/*      */       {
/* 1718 */         mysql.sendCommand(26, null, packet, !this.connection.versionMeetsMinimum(4, 1, 2), null, 0);
/*      */       }
/*      */       catch (SQLException sqlEx) {
/* 1721 */         throw sqlEx;
/*      */       } catch (Exception ex) {
/* 1723 */         SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1000", getExceptionInterceptor());
/*      */         
/* 1725 */         sqlEx.initCause(ex);
/*      */         
/* 1727 */         throw sqlEx;
/*      */       } finally {
/* 1729 */         mysql.clearInputStream();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setArray(int i, Array x)
/*      */     throws SQLException
/*      */   {
/* 1738 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setAsciiStream(int parameterIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 1747 */     checkClosed();
/*      */     
/* 1749 */     if (x == null) {
/* 1750 */       setNull(parameterIndex, -2);
/*      */     } else {
/* 1752 */       BindValue binding = getBinding(parameterIndex, true);
/* 1753 */       setType(binding, 252);
/*      */       
/* 1755 */       binding.value = x;
/* 1756 */       binding.isNull = false;
/* 1757 */       binding.isLongData = true;
/*      */       
/* 1759 */       if (this.connection.getUseStreamLengthsInPrepStmts()) {
/* 1760 */         binding.bindLength = length;
/*      */       } else {
/* 1762 */         binding.bindLength = -1L;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized void setBigDecimal(int parameterIndex, BigDecimal x)
/*      */     throws SQLException
/*      */   {
/* 1772 */     checkClosed();
/*      */     
/* 1774 */     if (x == null) {
/* 1775 */       setNull(parameterIndex, 3);
/*      */     }
/*      */     else {
/* 1778 */       BindValue binding = getBinding(parameterIndex, false);
/*      */       
/* 1780 */       if (this.connection.versionMeetsMinimum(5, 0, 3)) {
/* 1781 */         setType(binding, 246);
/*      */       } else {
/* 1783 */         setType(binding, this.stringTypeCode);
/*      */       }
/*      */       
/* 1786 */       binding.value = StringUtils.fixDecimalExponent(StringUtils.consistentToString(x));
/*      */       
/* 1788 */       binding.isNull = false;
/* 1789 */       binding.isLongData = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setBinaryStream(int parameterIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 1799 */     checkClosed();
/*      */     
/* 1801 */     if (x == null) {
/* 1802 */       setNull(parameterIndex, -2);
/*      */     } else {
/* 1804 */       BindValue binding = getBinding(parameterIndex, true);
/* 1805 */       setType(binding, 252);
/*      */       
/* 1807 */       binding.value = x;
/* 1808 */       binding.isNull = false;
/* 1809 */       binding.isLongData = true;
/*      */       
/* 1811 */       if (this.connection.getUseStreamLengthsInPrepStmts()) {
/* 1812 */         binding.bindLength = length;
/*      */       } else {
/* 1814 */         binding.bindLength = -1L;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized void setBlob(int parameterIndex, Blob x)
/*      */     throws SQLException
/*      */   {
/* 1823 */     checkClosed();
/*      */     
/* 1825 */     if (x == null) {
/* 1826 */       setNull(parameterIndex, -2);
/*      */     } else {
/* 1828 */       BindValue binding = getBinding(parameterIndex, true);
/* 1829 */       setType(binding, 252);
/*      */       
/* 1831 */       binding.value = x;
/* 1832 */       binding.isNull = false;
/* 1833 */       binding.isLongData = true;
/*      */       
/* 1835 */       if (this.connection.getUseStreamLengthsInPrepStmts()) {
/* 1836 */         binding.bindLength = x.length();
/*      */       } else {
/* 1838 */         binding.bindLength = -1L;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBoolean(int parameterIndex, boolean x)
/*      */     throws SQLException
/*      */   {
/* 1847 */     setByte(parameterIndex, (byte)(x ? 1 : 0));
/*      */   }
/*      */   
/*      */ 
/*      */   public void setByte(int parameterIndex, byte x)
/*      */     throws SQLException
/*      */   {
/* 1854 */     checkClosed();
/*      */     
/* 1856 */     BindValue binding = getBinding(parameterIndex, false);
/* 1857 */     setType(binding, 1);
/*      */     
/* 1859 */     binding.value = null;
/* 1860 */     binding.longBinding = x;
/* 1861 */     binding.isNull = false;
/* 1862 */     binding.isLongData = false;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBytes(int parameterIndex, byte[] x)
/*      */     throws SQLException
/*      */   {
/* 1869 */     checkClosed();
/*      */     
/* 1871 */     if (x == null) {
/* 1872 */       setNull(parameterIndex, -2);
/*      */     } else {
/* 1874 */       BindValue binding = getBinding(parameterIndex, false);
/* 1875 */       setType(binding, 253);
/*      */       
/* 1877 */       binding.value = x;
/* 1878 */       binding.isNull = false;
/* 1879 */       binding.isLongData = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setCharacterStream(int parameterIndex, Reader reader, int length)
/*      */     throws SQLException
/*      */   {
/* 1889 */     checkClosed();
/*      */     
/* 1891 */     if (reader == null) {
/* 1892 */       setNull(parameterIndex, -2);
/*      */     } else {
/* 1894 */       BindValue binding = getBinding(parameterIndex, true);
/* 1895 */       setType(binding, 252);
/*      */       
/* 1897 */       binding.value = reader;
/* 1898 */       binding.isNull = false;
/* 1899 */       binding.isLongData = true;
/*      */       
/* 1901 */       if (this.connection.getUseStreamLengthsInPrepStmts()) {
/* 1902 */         binding.bindLength = length;
/*      */       } else {
/* 1904 */         binding.bindLength = -1L;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized void setClob(int parameterIndex, Clob x)
/*      */     throws SQLException
/*      */   {
/* 1913 */     checkClosed();
/*      */     
/* 1915 */     if (x == null) {
/* 1916 */       setNull(parameterIndex, -2);
/*      */     } else {
/* 1918 */       BindValue binding = getBinding(parameterIndex, true);
/* 1919 */       setType(binding, 252);
/*      */       
/* 1921 */       binding.value = x.getCharacterStream();
/* 1922 */       binding.isNull = false;
/* 1923 */       binding.isLongData = true;
/*      */       
/* 1925 */       if (this.connection.getUseStreamLengthsInPrepStmts()) {
/* 1926 */         binding.bindLength = x.length();
/*      */       } else {
/* 1928 */         binding.bindLength = -1L;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDate(int parameterIndex, java.sql.Date x)
/*      */     throws SQLException
/*      */   {
/* 1946 */     setDate(parameterIndex, x, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDate(int parameterIndex, java.sql.Date x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1965 */     if (x == null) {
/* 1966 */       setNull(parameterIndex, 91);
/*      */     } else {
/* 1968 */       BindValue binding = getBinding(parameterIndex, false);
/* 1969 */       setType(binding, 10);
/*      */       
/* 1971 */       binding.value = x;
/* 1972 */       binding.isNull = false;
/* 1973 */       binding.isLongData = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized void setDouble(int parameterIndex, double x)
/*      */     throws SQLException
/*      */   {
/* 1981 */     checkClosed();
/*      */     
/* 1983 */     if ((!this.connection.getAllowNanAndInf()) && ((x == Double.POSITIVE_INFINITY) || (x == Double.NEGATIVE_INFINITY) || (Double.isNaN(x))))
/*      */     {
/*      */ 
/* 1986 */       throw SQLError.createSQLException("'" + x + "' is not a valid numeric or approximate numeric value", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1992 */     BindValue binding = getBinding(parameterIndex, false);
/* 1993 */     setType(binding, 5);
/*      */     
/* 1995 */     binding.value = null;
/* 1996 */     binding.doubleBinding = x;
/* 1997 */     binding.isNull = false;
/* 1998 */     binding.isLongData = false;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setFloat(int parameterIndex, float x)
/*      */     throws SQLException
/*      */   {
/* 2005 */     checkClosed();
/*      */     
/* 2007 */     BindValue binding = getBinding(parameterIndex, false);
/* 2008 */     setType(binding, 4);
/*      */     
/* 2010 */     binding.value = null;
/* 2011 */     binding.floatBinding = x;
/* 2012 */     binding.isNull = false;
/* 2013 */     binding.isLongData = false;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setInt(int parameterIndex, int x)
/*      */     throws SQLException
/*      */   {
/* 2020 */     checkClosed();
/*      */     
/* 2022 */     BindValue binding = getBinding(parameterIndex, false);
/* 2023 */     setType(binding, 3);
/*      */     
/* 2025 */     binding.value = null;
/* 2026 */     binding.longBinding = x;
/* 2027 */     binding.isNull = false;
/* 2028 */     binding.isLongData = false;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setLong(int parameterIndex, long x)
/*      */     throws SQLException
/*      */   {
/* 2035 */     checkClosed();
/*      */     
/* 2037 */     BindValue binding = getBinding(parameterIndex, false);
/* 2038 */     setType(binding, 8);
/*      */     
/* 2040 */     binding.value = null;
/* 2041 */     binding.longBinding = x;
/* 2042 */     binding.isNull = false;
/* 2043 */     binding.isLongData = false;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setNull(int parameterIndex, int sqlType)
/*      */     throws SQLException
/*      */   {
/* 2050 */     checkClosed();
/*      */     
/* 2052 */     BindValue binding = getBinding(parameterIndex, false);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2058 */     if (binding.bufferType == 0) {
/* 2059 */       setType(binding, 6);
/*      */     }
/*      */     
/* 2062 */     binding.value = null;
/* 2063 */     binding.isNull = true;
/* 2064 */     binding.isLongData = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setNull(int parameterIndex, int sqlType, String typeName)
/*      */     throws SQLException
/*      */   {
/* 2072 */     checkClosed();
/*      */     
/* 2074 */     BindValue binding = getBinding(parameterIndex, false);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2080 */     if (binding.bufferType == 0) {
/* 2081 */       setType(binding, 6);
/*      */     }
/*      */     
/* 2084 */     binding.value = null;
/* 2085 */     binding.isNull = true;
/* 2086 */     binding.isLongData = false;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setRef(int i, Ref x)
/*      */     throws SQLException
/*      */   {
/* 2093 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */   public void setShort(int parameterIndex, short x)
/*      */     throws SQLException
/*      */   {
/* 2100 */     checkClosed();
/*      */     
/* 2102 */     BindValue binding = getBinding(parameterIndex, false);
/* 2103 */     setType(binding, 2);
/*      */     
/* 2105 */     binding.value = null;
/* 2106 */     binding.longBinding = x;
/* 2107 */     binding.isNull = false;
/* 2108 */     binding.isLongData = false;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setString(int parameterIndex, String x)
/*      */     throws SQLException
/*      */   {
/* 2115 */     checkClosed();
/*      */     
/* 2117 */     if (x == null) {
/* 2118 */       setNull(parameterIndex, 1);
/*      */     } else {
/* 2120 */       BindValue binding = getBinding(parameterIndex, false);
/*      */       
/* 2122 */       setType(binding, this.stringTypeCode);
/*      */       
/* 2124 */       binding.value = x;
/* 2125 */       binding.isNull = false;
/* 2126 */       binding.isLongData = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setTime(int parameterIndex, Time x)
/*      */     throws SQLException
/*      */   {
/* 2143 */     setTimeInternal(parameterIndex, x, null, this.connection.getDefaultTimeZone(), false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTime(int parameterIndex, Time x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 2163 */     setTimeInternal(parameterIndex, x, cal, cal.getTimeZone(), true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void setTimeInternal(int parameterIndex, Time x, Calendar targetCalendar, TimeZone tz, boolean rollForward)
/*      */     throws SQLException
/*      */   {
/* 2184 */     if (x == null) {
/* 2185 */       setNull(parameterIndex, 92);
/*      */     } else {
/* 2187 */       BindValue binding = getBinding(parameterIndex, false);
/* 2188 */       setType(binding, 11);
/*      */       
/* 2190 */       if (!this.useLegacyDatetimeCode) {
/* 2191 */         binding.value = x;
/*      */       } else {
/* 2193 */         Calendar sessionCalendar = getCalendarInstanceForSessionOrNew();
/*      */         
/* 2195 */         synchronized (sessionCalendar) {
/* 2196 */           binding.value = TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, x, tz, this.connection.getServerTimezoneTZ(), rollForward);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2205 */       binding.isNull = false;
/* 2206 */       binding.isLongData = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setTimestamp(int parameterIndex, Timestamp x)
/*      */     throws SQLException
/*      */   {
/* 2224 */     setTimestampInternal(parameterIndex, x, null, this.connection.getDefaultTimeZone(), false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 2243 */     setTimestampInternal(parameterIndex, x, cal, cal.getTimeZone(), true);
/*      */   }
/*      */   
/*      */ 
/*      */   protected synchronized void setTimestampInternal(int parameterIndex, Timestamp x, Calendar targetCalendar, TimeZone tz, boolean rollForward)
/*      */     throws SQLException
/*      */   {
/* 2250 */     if (x == null) {
/* 2251 */       setNull(parameterIndex, 93);
/*      */     } else {
/* 2253 */       BindValue binding = getBinding(parameterIndex, false);
/* 2254 */       setType(binding, 12);
/*      */       
/* 2256 */       if (!this.useLegacyDatetimeCode) {
/* 2257 */         binding.value = x;
/*      */       } else {
/* 2259 */         Calendar sessionCalendar = this.connection.getUseJDBCCompliantTimezoneShift() ? this.connection.getUtcCalendar() : getCalendarInstanceForSessionOrNew();
/*      */         
/*      */ 
/*      */ 
/* 2263 */         synchronized (sessionCalendar) {
/* 2264 */           binding.value = TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, x, tz, this.connection.getServerTimezoneTZ(), rollForward);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2272 */         binding.isNull = false;
/* 2273 */         binding.isLongData = false;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected synchronized void setType(BindValue oldValue, int bufferType) {
/* 2279 */     if (oldValue.bufferType != bufferType) {
/* 2280 */       this.sendTypesToServer = true;
/*      */     }
/*      */     
/* 2283 */     oldValue.bufferType = bufferType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void setUnicodeStream(int parameterIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 2307 */     checkClosed();
/*      */     
/* 2309 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */   public void setURL(int parameterIndex, URL x)
/*      */     throws SQLException
/*      */   {
/* 2316 */     checkClosed();
/*      */     
/* 2318 */     setString(parameterIndex, x.toString());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private synchronized void storeBinding(Buffer packet, BindValue bindValue, MysqlIO mysql)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 2335 */       Object value = bindValue.value;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2340 */       switch (bindValue.bufferType)
/*      */       {
/*      */       case 1: 
/* 2343 */         packet.writeByte((byte)(int)bindValue.longBinding);
/* 2344 */         return;
/*      */       case 2: 
/* 2346 */         packet.ensureCapacity(2);
/* 2347 */         packet.writeInt((int)bindValue.longBinding);
/* 2348 */         return;
/*      */       case 3: 
/* 2350 */         packet.ensureCapacity(4);
/* 2351 */         packet.writeLong((int)bindValue.longBinding);
/* 2352 */         return;
/*      */       case 8: 
/* 2354 */         packet.ensureCapacity(8);
/* 2355 */         packet.writeLongLong(bindValue.longBinding);
/* 2356 */         return;
/*      */       case 4: 
/* 2358 */         packet.ensureCapacity(4);
/* 2359 */         packet.writeFloat(bindValue.floatBinding);
/* 2360 */         return;
/*      */       case 5: 
/* 2362 */         packet.ensureCapacity(8);
/* 2363 */         packet.writeDouble(bindValue.doubleBinding);
/* 2364 */         return;
/*      */       case 11: 
/* 2366 */         storeTime(packet, (Time)value);
/* 2367 */         return;
/*      */       case 7: 
/*      */       case 10: 
/*      */       case 12: 
/* 2371 */         storeDateTime(packet, (java.util.Date)value, mysql, bindValue.bufferType);
/* 2372 */         return;
/*      */       case 0: 
/*      */       case 15: 
/*      */       case 246: 
/*      */       case 253: 
/*      */       case 254: 
/* 2378 */         if ((value instanceof byte[])) {
/* 2379 */           packet.writeLenBytes((byte[])value);
/* 2380 */         } else if (!this.isLoadDataQuery) {
/* 2381 */           packet.writeLenString((String)value, this.charEncoding, this.connection.getServerCharacterEncoding(), this.charConverter, this.connection.parserKnowsUnicode(), this.connection);
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/* 2387 */           packet.writeLenBytes(StringUtils.getBytes((String)value));
/*      */         }
/*      */         
/* 2390 */         return;
/*      */       }
/*      */     }
/*      */     catch (UnsupportedEncodingException uEE)
/*      */     {
/* 2395 */       throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.22") + this.connection.getEncoding() + "'", "S1000", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private synchronized void storeDateTime412AndOlder(Buffer intoBuf, java.util.Date dt, int bufferType)
/*      */     throws SQLException
/*      */   {
/* 2405 */     Calendar sessionCalendar = null;
/*      */     
/* 2407 */     if (!this.useLegacyDatetimeCode) {
/* 2408 */       if (bufferType == 10) {
/* 2409 */         sessionCalendar = getDefaultTzCalendar();
/*      */       } else {
/* 2411 */         sessionCalendar = getServerTzCalendar();
/*      */       }
/*      */     } else {
/* 2414 */       sessionCalendar = ((dt instanceof Timestamp)) && (this.connection.getUseJDBCCompliantTimezoneShift()) ? this.connection.getUtcCalendar() : getCalendarInstanceForSessionOrNew();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2419 */     synchronized (sessionCalendar) {
/* 2420 */       java.util.Date oldTime = sessionCalendar.getTime();
/*      */       try
/*      */       {
/* 2423 */         intoBuf.ensureCapacity(8);
/* 2424 */         intoBuf.writeByte((byte)7);
/*      */         
/* 2426 */         sessionCalendar.setTime(dt);
/*      */         
/* 2428 */         int year = sessionCalendar.get(1);
/* 2429 */         int month = sessionCalendar.get(2) + 1;
/* 2430 */         int date = sessionCalendar.get(5);
/*      */         
/* 2432 */         intoBuf.writeInt(year);
/* 2433 */         intoBuf.writeByte((byte)month);
/* 2434 */         intoBuf.writeByte((byte)date);
/*      */         
/* 2436 */         if ((dt instanceof java.sql.Date)) {
/* 2437 */           intoBuf.writeByte((byte)0);
/* 2438 */           intoBuf.writeByte((byte)0);
/* 2439 */           intoBuf.writeByte((byte)0);
/*      */         } else {
/* 2441 */           intoBuf.writeByte((byte)sessionCalendar.get(11));
/*      */           
/* 2443 */           intoBuf.writeByte((byte)sessionCalendar.get(12));
/*      */           
/* 2445 */           intoBuf.writeByte((byte)sessionCalendar.get(13));
/*      */         }
/*      */       }
/*      */       finally {
/* 2449 */         sessionCalendar.setTime(oldTime);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private synchronized void storeDateTime(Buffer intoBuf, java.util.Date dt, MysqlIO mysql, int bufferType) throws SQLException
/*      */   {
/* 2456 */     if (this.connection.versionMeetsMinimum(4, 1, 3)) {
/* 2457 */       storeDateTime413AndNewer(intoBuf, dt, bufferType);
/*      */     } else {
/* 2459 */       storeDateTime412AndOlder(intoBuf, dt, bufferType);
/*      */     }
/*      */   }
/*      */   
/*      */   private synchronized void storeDateTime413AndNewer(Buffer intoBuf, java.util.Date dt, int bufferType) throws SQLException
/*      */   {
/* 2465 */     Calendar sessionCalendar = null;
/*      */     
/* 2467 */     if (!this.useLegacyDatetimeCode) {
/* 2468 */       if (bufferType == 10) {
/* 2469 */         sessionCalendar = getDefaultTzCalendar();
/*      */       } else {
/* 2471 */         sessionCalendar = getServerTzCalendar();
/*      */       }
/*      */     } else {
/* 2474 */       sessionCalendar = ((dt instanceof Timestamp)) && (this.connection.getUseJDBCCompliantTimezoneShift()) ? this.connection.getUtcCalendar() : getCalendarInstanceForSessionOrNew();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2479 */     synchronized (sessionCalendar) {
/* 2480 */       java.util.Date oldTime = sessionCalendar.getTime();
/*      */       try
/*      */       {
/* 2483 */         sessionCalendar.setTime(dt);
/*      */         
/* 2485 */         if ((dt instanceof java.sql.Date)) {
/* 2486 */           sessionCalendar.set(11, 0);
/* 2487 */           sessionCalendar.set(12, 0);
/* 2488 */           sessionCalendar.set(13, 0);
/*      */         }
/*      */         
/* 2491 */         byte length = 7;
/*      */         
/* 2493 */         if ((dt instanceof Timestamp)) {
/* 2494 */           length = 11;
/*      */         }
/*      */         
/* 2497 */         intoBuf.ensureCapacity(length);
/*      */         
/* 2499 */         intoBuf.writeByte(length);
/*      */         
/* 2501 */         int year = sessionCalendar.get(1);
/* 2502 */         int month = sessionCalendar.get(2) + 1;
/* 2503 */         int date = sessionCalendar.get(5);
/*      */         
/* 2505 */         intoBuf.writeInt(year);
/* 2506 */         intoBuf.writeByte((byte)month);
/* 2507 */         intoBuf.writeByte((byte)date);
/*      */         
/* 2509 */         if ((dt instanceof java.sql.Date)) {
/* 2510 */           intoBuf.writeByte((byte)0);
/* 2511 */           intoBuf.writeByte((byte)0);
/* 2512 */           intoBuf.writeByte((byte)0);
/*      */         } else {
/* 2514 */           intoBuf.writeByte((byte)sessionCalendar.get(11));
/*      */           
/* 2516 */           intoBuf.writeByte((byte)sessionCalendar.get(12));
/*      */           
/* 2518 */           intoBuf.writeByte((byte)sessionCalendar.get(13));
/*      */         }
/*      */         
/*      */ 
/* 2522 */         if (length == 11)
/*      */         {
/* 2524 */           intoBuf.writeLong(((Timestamp)dt).getNanos() / 1000);
/*      */         }
/*      */       }
/*      */       finally {
/* 2528 */         sessionCalendar.setTime(oldTime);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private Calendar getServerTzCalendar() {
/* 2534 */     synchronized (this) {
/* 2535 */       if (this.serverTzCalendar == null) {
/* 2536 */         this.serverTzCalendar = new GregorianCalendar(this.connection.getServerTimezoneTZ());
/*      */       }
/*      */       
/* 2539 */       return this.serverTzCalendar;
/*      */     }
/*      */   }
/*      */   
/*      */   private Calendar getDefaultTzCalendar() {
/* 2544 */     synchronized (this) {
/* 2545 */       if (this.defaultTzCalendar == null) {
/* 2546 */         this.defaultTzCalendar = new GregorianCalendar(TimeZone.getDefault());
/*      */       }
/*      */       
/* 2549 */       return this.defaultTzCalendar;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private synchronized void storeReader(MysqlIO mysql, int parameterIndex, Buffer packet, Reader inStream)
/*      */     throws SQLException
/*      */   {
/* 2558 */     String forcedEncoding = this.connection.getClobCharacterEncoding();
/*      */     
/* 2560 */     String clobEncoding = forcedEncoding == null ? this.connection.getEncoding() : forcedEncoding;
/*      */     
/*      */ 
/* 2563 */     int maxBytesChar = 2;
/*      */     
/* 2565 */     if (clobEncoding != null) {
/* 2566 */       if (!clobEncoding.equals("UTF-16")) {
/* 2567 */         maxBytesChar = this.connection.getMaxBytesPerChar(clobEncoding);
/*      */         
/* 2569 */         if (maxBytesChar == 1) {
/* 2570 */           maxBytesChar = 2;
/*      */         }
/*      */       } else {
/* 2573 */         maxBytesChar = 4;
/*      */       }
/*      */     }
/*      */     
/* 2577 */     char[] buf = new char[8192 / maxBytesChar];
/*      */     
/* 2579 */     int numRead = 0;
/*      */     
/* 2581 */     int bytesInPacket = 0;
/* 2582 */     int totalBytesRead = 0;
/* 2583 */     int bytesReadAtLastSend = 0;
/* 2584 */     int packetIsFullAt = this.connection.getBlobSendChunkSize();
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 2589 */       packet.clear();
/* 2590 */       packet.writeByte((byte)24);
/* 2591 */       packet.writeLong(this.serverStatementId);
/* 2592 */       packet.writeInt(parameterIndex);
/*      */       
/* 2594 */       boolean readAny = false;
/*      */       
/* 2596 */       while ((numRead = inStream.read(buf)) != -1) {
/* 2597 */         readAny = true;
/*      */         
/* 2599 */         byte[] valueAsBytes = StringUtils.getBytes(buf, null, clobEncoding, this.connection.getServerCharacterEncoding(), 0, numRead, this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 2604 */         packet.writeBytesNoNull(valueAsBytes, 0, valueAsBytes.length);
/*      */         
/* 2606 */         bytesInPacket += valueAsBytes.length;
/* 2607 */         totalBytesRead += valueAsBytes.length;
/*      */         
/* 2609 */         if (bytesInPacket >= packetIsFullAt) {
/* 2610 */           bytesReadAtLastSend = totalBytesRead;
/*      */           
/* 2612 */           mysql.sendCommand(24, null, packet, true, null, 0);
/*      */           
/*      */ 
/* 2615 */           bytesInPacket = 0;
/* 2616 */           packet.clear();
/* 2617 */           packet.writeByte((byte)24);
/* 2618 */           packet.writeLong(this.serverStatementId);
/* 2619 */           packet.writeInt(parameterIndex);
/*      */         }
/*      */       }
/*      */       
/* 2623 */       if (totalBytesRead != bytesReadAtLastSend) {
/* 2624 */         mysql.sendCommand(24, null, packet, true, null, 0);
/*      */       }
/*      */       
/*      */ 
/* 2628 */       if (!readAny) {
/* 2629 */         mysql.sendCommand(24, null, packet, true, null, 0);
/*      */       }
/*      */     }
/*      */     catch (IOException ioEx) {
/* 2633 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("ServerPreparedStatement.24") + ioEx.toString(), "S1000", getExceptionInterceptor());
/*      */       
/*      */ 
/* 2636 */       sqlEx.initCause(ioEx);
/*      */       
/* 2638 */       throw sqlEx;
/*      */     } finally {
/* 2640 */       if ((this.connection.getAutoClosePStmtStreams()) && 
/* 2641 */         (inStream != null)) {
/*      */         try {
/* 2643 */           inStream.close();
/*      */         }
/*      */         catch (IOException ioEx) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private synchronized void storeStream(MysqlIO mysql, int parameterIndex, Buffer packet, InputStream inStream)
/*      */     throws SQLException
/*      */   {
/* 2654 */     byte[] buf = new byte[' '];
/*      */     
/* 2656 */     int numRead = 0;
/*      */     try
/*      */     {
/* 2659 */       int bytesInPacket = 0;
/* 2660 */       int totalBytesRead = 0;
/* 2661 */       int bytesReadAtLastSend = 0;
/* 2662 */       int packetIsFullAt = this.connection.getBlobSendChunkSize();
/*      */       
/* 2664 */       packet.clear();
/* 2665 */       packet.writeByte((byte)24);
/* 2666 */       packet.writeLong(this.serverStatementId);
/* 2667 */       packet.writeInt(parameterIndex);
/*      */       
/* 2669 */       boolean readAny = false;
/*      */       
/* 2671 */       while ((numRead = inStream.read(buf)) != -1)
/*      */       {
/* 2673 */         readAny = true;
/*      */         
/* 2675 */         packet.writeBytesNoNull(buf, 0, numRead);
/* 2676 */         bytesInPacket += numRead;
/* 2677 */         totalBytesRead += numRead;
/*      */         
/* 2679 */         if (bytesInPacket >= packetIsFullAt) {
/* 2680 */           bytesReadAtLastSend = totalBytesRead;
/*      */           
/* 2682 */           mysql.sendCommand(24, null, packet, true, null, 0);
/*      */           
/*      */ 
/* 2685 */           bytesInPacket = 0;
/* 2686 */           packet.clear();
/* 2687 */           packet.writeByte((byte)24);
/* 2688 */           packet.writeLong(this.serverStatementId);
/* 2689 */           packet.writeInt(parameterIndex);
/*      */         }
/*      */       }
/*      */       
/* 2693 */       if (totalBytesRead != bytesReadAtLastSend) {
/* 2694 */         mysql.sendCommand(24, null, packet, true, null, 0);
/*      */       }
/*      */       
/*      */ 
/* 2698 */       if (!readAny) {
/* 2699 */         mysql.sendCommand(24, null, packet, true, null, 0);
/*      */       }
/*      */     }
/*      */     catch (IOException ioEx) {
/* 2703 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("ServerPreparedStatement.25") + ioEx.toString(), "S1000", getExceptionInterceptor());
/*      */       
/*      */ 
/* 2706 */       sqlEx.initCause(ioEx);
/*      */       
/* 2708 */       throw sqlEx;
/*      */     } finally {
/* 2710 */       if ((this.connection.getAutoClosePStmtStreams()) && 
/* 2711 */         (inStream != null)) {
/*      */         try {
/* 2713 */           inStream.close();
/*      */         }
/*      */         catch (IOException ioEx) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/* 2726 */     StringBuffer toStringBuf = new StringBuffer();
/*      */     
/* 2728 */     toStringBuf.append("com.mysql.jdbc.ServerPreparedStatement[");
/* 2729 */     toStringBuf.append(this.serverStatementId);
/* 2730 */     toStringBuf.append("] - ");
/*      */     try
/*      */     {
/* 2733 */       toStringBuf.append(asSql());
/*      */     } catch (SQLException sqlEx) {
/* 2735 */       toStringBuf.append(Messages.getString("ServerPreparedStatement.6"));
/* 2736 */       toStringBuf.append(sqlEx);
/*      */     }
/*      */     
/* 2739 */     return toStringBuf.toString();
/*      */   }
/*      */   
/*      */   protected long getServerStatementId() {
/* 2743 */     return this.serverStatementId;
/*      */   }
/*      */   
/* 2746 */   private boolean hasCheckedRewrite = false;
/* 2747 */   private boolean canRewrite = false;
/*      */   
/*      */   public synchronized boolean canRewriteAsMultiValueInsertAtSqlLevel() throws SQLException {
/* 2750 */     if (!this.hasCheckedRewrite) {
/* 2751 */       this.hasCheckedRewrite = true;
/* 2752 */       this.canRewrite = canRewrite(this.originalSql, isOnDuplicateKeyUpdate(), getLocationOfOnDuplicateKeyUpdate(), 0);
/*      */       
/* 2754 */       this.parseInfo = new PreparedStatement.ParseInfo(this, this.originalSql, this.connection, this.connection.getMetaData(), this.charEncoding, this.charConverter);
/*      */     }
/*      */     
/* 2757 */     return this.canRewrite;
/*      */   }
/*      */   
/*      */   public synchronized boolean canRewriteAsMultivalueInsertStatement() throws SQLException
/*      */   {
/* 2762 */     if (!canRewriteAsMultiValueInsertAtSqlLevel()) {
/* 2763 */       return false;
/*      */     }
/*      */     
/* 2766 */     BindValue[] currentBindValues = null;
/* 2767 */     BindValue[] previousBindValues = null;
/*      */     
/* 2769 */     int nbrCommands = this.batchedArgs.size();
/*      */     
/*      */ 
/*      */ 
/* 2773 */     for (int commandIndex = 0; commandIndex < nbrCommands; commandIndex++) {
/* 2774 */       Object arg = this.batchedArgs.get(commandIndex);
/*      */       
/* 2776 */       if (!(arg instanceof String))
/*      */       {
/* 2778 */         currentBindValues = ((BatchedBindValues)arg).batchedParameterValues;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2784 */         if (previousBindValues != null) {
/* 2785 */           for (int j = 0; j < this.parameterBindings.length; j++) {
/* 2786 */             if (currentBindValues[j].bufferType != previousBindValues[j].bufferType) {
/* 2787 */               return false;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2796 */     return true;
/*      */   }
/*      */   
/* 2799 */   private int locationOfOnDuplicateKeyUpdate = -2;
/*      */   
/*      */   protected synchronized int getLocationOfOnDuplicateKeyUpdate() {
/* 2802 */     if (this.locationOfOnDuplicateKeyUpdate == -2) {
/* 2803 */       this.locationOfOnDuplicateKeyUpdate = getOnDuplicateKeyLocation(this.originalSql);
/*      */     }
/*      */     
/* 2806 */     return this.locationOfOnDuplicateKeyUpdate;
/*      */   }
/*      */   
/*      */   protected synchronized boolean isOnDuplicateKeyUpdate() {
/* 2810 */     return getLocationOfOnDuplicateKeyUpdate() != -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized long[] computeMaxParameterSetSizeAndBatchSize(int numBatchedArgs)
/*      */   {
/* 2821 */     long sizeOfEntireBatch = 10L;
/* 2822 */     long maxSizeOfParameterSet = 0L;
/*      */     
/* 2824 */     for (int i = 0; i < numBatchedArgs; i++) {
/* 2825 */       BindValue[] paramArg = ((BatchedBindValues)this.batchedArgs.get(i)).batchedParameterValues;
/*      */       
/* 2827 */       long sizeOfParameterSet = 0L;
/*      */       
/* 2829 */       sizeOfParameterSet += (this.parameterCount + 7) / 8;
/*      */       
/* 2831 */       sizeOfParameterSet += this.parameterCount * 2;
/*      */       
/* 2833 */       for (int j = 0; j < this.parameterBindings.length; j++) {
/* 2834 */         if (!paramArg[j].isNull)
/*      */         {
/* 2836 */           long size = paramArg[j].getBoundLength();
/*      */           
/* 2838 */           if (paramArg[j].isLongData) {
/* 2839 */             if (size != -1L) {
/* 2840 */               sizeOfParameterSet += size;
/*      */             }
/*      */           } else {
/* 2843 */             sizeOfParameterSet += size;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 2848 */       sizeOfEntireBatch += sizeOfParameterSet;
/*      */       
/* 2850 */       if (sizeOfParameterSet > maxSizeOfParameterSet) {
/* 2851 */         maxSizeOfParameterSet = sizeOfParameterSet;
/*      */       }
/*      */     }
/*      */     
/* 2855 */     return new long[] { maxSizeOfParameterSet, sizeOfEntireBatch };
/*      */   }
/*      */   
/*      */   protected int setOneBatchedParameterSet(java.sql.PreparedStatement batchedStatement, int batchedParamIndex, Object paramSet)
/*      */     throws SQLException
/*      */   {
/* 2861 */     BindValue[] paramArg = ((BatchedBindValues)paramSet).batchedParameterValues;
/*      */     
/* 2863 */     for (int j = 0; j < paramArg.length; j++) {
/* 2864 */       if (paramArg[j].isNull) {
/* 2865 */         batchedStatement.setNull(batchedParamIndex++, 0);
/*      */       }
/* 2867 */       else if (paramArg[j].isLongData) {
/* 2868 */         Object value = paramArg[j].value;
/*      */         
/* 2870 */         if ((value instanceof InputStream)) {
/* 2871 */           batchedStatement.setBinaryStream(batchedParamIndex++, (InputStream)value, (int)paramArg[j].bindLength);
/*      */         }
/*      */         else
/*      */         {
/* 2875 */           batchedStatement.setCharacterStream(batchedParamIndex++, (Reader)value, (int)paramArg[j].bindLength);
/*      */         }
/*      */         
/*      */       }
/*      */       else
/*      */       {
/* 2881 */         switch (paramArg[j].bufferType)
/*      */         {
/*      */         case 1: 
/* 2884 */           batchedStatement.setByte(batchedParamIndex++, (byte)(int)paramArg[j].longBinding);
/*      */           
/* 2886 */           break;
/*      */         case 2: 
/* 2888 */           batchedStatement.setShort(batchedParamIndex++, (short)(int)paramArg[j].longBinding);
/*      */           
/* 2890 */           break;
/*      */         case 3: 
/* 2892 */           batchedStatement.setInt(batchedParamIndex++, (int)paramArg[j].longBinding);
/*      */           
/* 2894 */           break;
/*      */         case 8: 
/* 2896 */           batchedStatement.setLong(batchedParamIndex++, paramArg[j].longBinding);
/*      */           
/* 2898 */           break;
/*      */         case 4: 
/* 2900 */           batchedStatement.setFloat(batchedParamIndex++, paramArg[j].floatBinding);
/*      */           
/* 2902 */           break;
/*      */         case 5: 
/* 2904 */           batchedStatement.setDouble(batchedParamIndex++, paramArg[j].doubleBinding);
/*      */           
/* 2906 */           break;
/*      */         case 11: 
/* 2908 */           batchedStatement.setTime(batchedParamIndex++, (Time)paramArg[j].value);
/*      */           
/* 2910 */           break;
/*      */         case 10: 
/* 2912 */           batchedStatement.setDate(batchedParamIndex++, (java.sql.Date)paramArg[j].value);
/*      */           
/* 2914 */           break;
/*      */         case 7: 
/*      */         case 12: 
/* 2917 */           batchedStatement.setTimestamp(batchedParamIndex++, (Timestamp)paramArg[j].value);
/*      */           
/* 2919 */           break;
/*      */         case 0: 
/*      */         case 15: 
/*      */         case 246: 
/*      */         case 253: 
/*      */         case 254: 
/* 2925 */           Object value = paramArg[j].value;
/*      */           
/* 2927 */           if ((value instanceof byte[])) {
/* 2928 */             batchedStatement.setBytes(batchedParamIndex, (byte[])value);
/*      */           }
/*      */           else {
/* 2931 */             batchedStatement.setString(batchedParamIndex, (String)value);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 2937 */           if ((batchedStatement instanceof ServerPreparedStatement)) {
/* 2938 */             BindValue asBound = ((ServerPreparedStatement)batchedStatement).getBinding(batchedParamIndex, false);
/*      */             
/*      */ 
/*      */ 
/* 2942 */             asBound.bufferType = paramArg[j].bufferType;
/*      */           }
/*      */           
/* 2945 */           batchedParamIndex++;
/*      */           
/* 2947 */           break;
/*      */         default: 
/* 2949 */           throw new IllegalArgumentException("Unknown type when re-binding parameter into batched statement for parameter index " + batchedParamIndex);
/*      */         }
/*      */         
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2957 */     return batchedParamIndex;
/*      */   }
/*      */   
/*      */   protected boolean containsOnDuplicateKeyUpdateInSQL() {
/* 2961 */     return this.hasOnDuplicateKeyUpdate;
/*      */   }
/*      */   
/*      */   protected synchronized PreparedStatement prepareBatchedInsertSQL(MySQLConnection localConn, int numBatches) throws SQLException {
/*      */     try {
/* 2966 */       PreparedStatement pstmt = new ServerPreparedStatement(localConn, this.parseInfo.getSqlForBatch(numBatches), this.currentCatalog, this.resultSetConcurrency, this.resultSetType);
/* 2967 */       pstmt.setRetrieveGeneratedKeys(this.retrieveGeneratedKeys);
/*      */       
/* 2969 */       return pstmt;
/*      */     } catch (UnsupportedEncodingException e) {
/* 2971 */       SQLException sqlEx = SQLError.createSQLException("Unable to prepare batch statement", "S1000", getExceptionInterceptor());
/* 2972 */       sqlEx.initCause(e);
/*      */       
/* 2974 */       throw sqlEx;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Static\Desktop\G10_Prototype_Client.jar!\mysql-connector-java-5.1.19-bin.jar!\com\mysql\jdbc\ServerPreparedStatement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */