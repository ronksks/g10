/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.StringReader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.math.BigDecimal;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.CharBuffer;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.IllegalCharsetNameException;
/*      */ import java.nio.charset.UnsupportedCharsetException;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StringUtils
/*      */ {
/*      */   private static final int BYTE_RANGE = 256;
/*   55 */   private static byte[] allBytes = new byte['Ā'];
/*      */   
/*   57 */   private static char[] byteToChars = new char['Ā'];
/*      */   
/*      */   private static Method toPlainStringMethod;
/*      */   
/*      */   static final int WILD_COMPARE_MATCH_NO_WILD = 0;
/*      */   
/*      */   static final int WILD_COMPARE_MATCH_WITH_WILD = 1;
/*      */   
/*      */   static final int WILD_COMPARE_NO_MATCH = -1;
/*      */   
/*   67 */   private static final ConcurrentHashMap<String, Charset> charsetsByAlias = new ConcurrentHashMap();
/*      */   
/*      */ 
/*   70 */   private static final String platformEncoding = System.getProperty("file.encoding");
/*      */   
/*      */   static Charset findCharset(String alias) throws UnsupportedEncodingException {
/*      */     try {
/*   74 */       Charset cs = (Charset)charsetsByAlias.get(alias);
/*      */       
/*   76 */       if (cs == null) {
/*   77 */         cs = Charset.forName(alias);
/*   78 */         charsetsByAlias.putIfAbsent(alias, cs);
/*      */       }
/*      */       
/*   81 */       return cs;
/*      */     }
/*      */     catch (UnsupportedCharsetException uce)
/*      */     {
/*   85 */       throw new UnsupportedEncodingException(alias);
/*      */     } catch (IllegalCharsetNameException icne) {
/*   87 */       throw new UnsupportedEncodingException(alias);
/*      */     } catch (IllegalArgumentException iae) {
/*   89 */       throw new UnsupportedEncodingException(alias);
/*      */     }
/*      */   }
/*      */   
/*      */   static {
/*   94 */     for (int i = -128; i <= 127; i++) {
/*   95 */       allBytes[(i - -128)] = ((byte)i);
/*      */     }
/*      */     
/*   98 */     String allBytesString = new String(allBytes, 0, 255);
/*      */     
/*      */ 
/*  101 */     int allBytesStringLen = allBytesString.length();
/*      */     
/*  103 */     for (int i = 0; 
/*  104 */         (i < 255) && (i < allBytesStringLen); i++) {
/*  105 */       byteToChars[i] = allBytesString.charAt(i);
/*      */     }
/*      */     try
/*      */     {
/*  109 */       toPlainStringMethod = BigDecimal.class.getMethod("toPlainString", new Class[0]);
/*      */     }
/*      */     catch (NoSuchMethodException nsme) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String consistentToString(BigDecimal decimal)
/*      */   {
/*  126 */     if (decimal == null) {
/*  127 */       return null;
/*      */     }
/*      */     
/*  130 */     if (toPlainStringMethod != null) {
/*      */       try {
/*  132 */         return (String)toPlainStringMethod.invoke(decimal, (Object[])null);
/*      */       }
/*      */       catch (InvocationTargetException invokeEx) {}catch (IllegalAccessException accessEx) {}
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  140 */     return decimal.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final String dumpAsHex(byte[] byteBuffer, int length)
/*      */   {
/*  154 */     StringBuffer outputBuf = new StringBuffer(length * 4);
/*      */     
/*  156 */     int p = 0;
/*  157 */     int rows = length / 8;
/*      */     
/*  159 */     for (int i = 0; (i < rows) && (p < length); i++) {
/*  160 */       int ptemp = p;
/*      */       
/*  162 */       for (int j = 0; j < 8; j++) {
/*  163 */         String hexVal = Integer.toHexString(byteBuffer[ptemp] & 0xFF);
/*      */         
/*  165 */         if (hexVal.length() == 1) {
/*  166 */           hexVal = "0" + hexVal;
/*      */         }
/*      */         
/*  169 */         outputBuf.append(hexVal + " ");
/*  170 */         ptemp++;
/*      */       }
/*      */       
/*  173 */       outputBuf.append("    ");
/*      */       
/*  175 */       for (int j = 0; j < 8; j++) {
/*  176 */         int b = 0xFF & byteBuffer[p];
/*      */         
/*  178 */         if ((b > 32) && (b < 127)) {
/*  179 */           outputBuf.append((char)b + " ");
/*      */         } else {
/*  181 */           outputBuf.append(". ");
/*      */         }
/*      */         
/*  184 */         p++;
/*      */       }
/*      */       
/*  187 */       outputBuf.append("\n");
/*      */     }
/*      */     
/*  190 */     int n = 0;
/*      */     
/*  192 */     for (int i = p; i < length; i++) {
/*  193 */       String hexVal = Integer.toHexString(byteBuffer[i] & 0xFF);
/*      */       
/*  195 */       if (hexVal.length() == 1) {
/*  196 */         hexVal = "0" + hexVal;
/*      */       }
/*      */       
/*  199 */       outputBuf.append(hexVal + " ");
/*  200 */       n++;
/*      */     }
/*      */     
/*  203 */     for (int i = n; i < 8; i++) {
/*  204 */       outputBuf.append("   ");
/*      */     }
/*      */     
/*  207 */     outputBuf.append("    ");
/*      */     
/*  209 */     for (int i = p; i < length; i++) {
/*  210 */       int b = 0xFF & byteBuffer[i];
/*      */       
/*  212 */       if ((b > 32) && (b < 127)) {
/*  213 */         outputBuf.append((char)b + " ");
/*      */       } else {
/*  215 */         outputBuf.append(". ");
/*      */       }
/*      */     }
/*      */     
/*  219 */     outputBuf.append("\n");
/*      */     
/*  221 */     return outputBuf.toString();
/*      */   }
/*      */   
/*      */   private static boolean endsWith(byte[] dataFrom, String suffix) {
/*  225 */     for (int i = 1; i <= suffix.length(); i++) {
/*  226 */       int dfOffset = dataFrom.length - i;
/*  227 */       int suffixOffset = suffix.length() - i;
/*  228 */       if (dataFrom[dfOffset] != suffix.charAt(suffixOffset)) {
/*  229 */         return false;
/*      */       }
/*      */     }
/*  232 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] escapeEasternUnicodeByteStream(byte[] origBytes, String origString, int offset, int length)
/*      */   {
/*  252 */     if ((origBytes == null) || (origBytes.length == 0)) {
/*  253 */       return origBytes;
/*      */     }
/*      */     
/*  256 */     int bytesLen = origBytes.length;
/*  257 */     int bufIndex = 0;
/*  258 */     int strIndex = 0;
/*      */     
/*  260 */     ByteArrayOutputStream bytesOut = new ByteArrayOutputStream(bytesLen);
/*      */     for (;;)
/*      */     {
/*  263 */       if (origString.charAt(strIndex) == '\\')
/*      */       {
/*  265 */         bytesOut.write(origBytes[(bufIndex++)]);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  270 */         int loByte = origBytes[bufIndex];
/*      */         
/*  272 */         if (loByte < 0) {
/*  273 */           loByte += 256;
/*      */         }
/*      */         
/*      */ 
/*  277 */         bytesOut.write(loByte);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  295 */         if (loByte >= 128) {
/*  296 */           if (bufIndex < bytesLen - 1) {
/*  297 */             int hiByte = origBytes[(bufIndex + 1)];
/*      */             
/*  299 */             if (hiByte < 0) {
/*  300 */               hiByte += 256;
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*  305 */             bytesOut.write(hiByte);
/*  306 */             bufIndex++;
/*      */             
/*      */ 
/*  309 */             if (hiByte == 92) {
/*  310 */               bytesOut.write(hiByte);
/*      */             }
/*      */           }
/*  313 */         } else if ((loByte == 92) && 
/*  314 */           (bufIndex < bytesLen - 1)) {
/*  315 */           int hiByte = origBytes[(bufIndex + 1)];
/*      */           
/*  317 */           if (hiByte < 0) {
/*  318 */             hiByte += 256;
/*      */           }
/*      */           
/*  321 */           if (hiByte == 98)
/*      */           {
/*  323 */             bytesOut.write(92);
/*  324 */             bytesOut.write(98);
/*  325 */             bufIndex++;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*  330 */         bufIndex++;
/*      */       }
/*      */       
/*  333 */       if (bufIndex >= bytesLen) {
/*      */         break;
/*      */       }
/*      */       
/*      */ 
/*  338 */       strIndex++;
/*      */     }
/*      */     
/*  341 */     return bytesOut.toByteArray();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static char firstNonWsCharUc(String searchIn)
/*      */   {
/*  353 */     return firstNonWsCharUc(searchIn, 0);
/*      */   }
/*      */   
/*      */   public static char firstNonWsCharUc(String searchIn, int startAt) {
/*  357 */     if (searchIn == null) {
/*  358 */       return '\000';
/*      */     }
/*      */     
/*  361 */     int length = searchIn.length();
/*      */     
/*  363 */     for (int i = startAt; i < length; i++) {
/*  364 */       char c = searchIn.charAt(i);
/*      */       
/*  366 */       if (!Character.isWhitespace(c)) {
/*  367 */         return Character.toUpperCase(c);
/*      */       }
/*      */     }
/*      */     
/*  371 */     return '\000';
/*      */   }
/*      */   
/*      */   public static char firstAlphaCharUc(String searchIn, int startAt) {
/*  375 */     if (searchIn == null) {
/*  376 */       return '\000';
/*      */     }
/*      */     
/*  379 */     int length = searchIn.length();
/*      */     
/*  381 */     for (int i = startAt; i < length; i++) {
/*  382 */       char c = searchIn.charAt(i);
/*      */       
/*  384 */       if (Character.isLetter(c)) {
/*  385 */         return Character.toUpperCase(c);
/*      */       }
/*      */     }
/*      */     
/*  389 */     return '\000';
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final String fixDecimalExponent(String dString)
/*      */   {
/*  402 */     int ePos = dString.indexOf("E");
/*      */     
/*  404 */     if (ePos == -1) {
/*  405 */       ePos = dString.indexOf("e");
/*      */     }
/*      */     
/*  408 */     if ((ePos != -1) && 
/*  409 */       (dString.length() > ePos + 1)) {
/*  410 */       char maybeMinusChar = dString.charAt(ePos + 1);
/*      */       
/*  412 */       if ((maybeMinusChar != '-') && (maybeMinusChar != '+')) {
/*  413 */         StringBuffer buf = new StringBuffer(dString.length() + 1);
/*  414 */         buf.append(dString.substring(0, ePos + 1));
/*  415 */         buf.append('+');
/*  416 */         buf.append(dString.substring(ePos + 1, dString.length()));
/*  417 */         dString = buf.toString();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  422 */     return dString;
/*      */   }
/*      */   
/*      */   public static final byte[] getBytes(char[] c, SingleByteCharsetConverter converter, String encoding, String serverEncoding, boolean parserKnowsUnicode, ExceptionInterceptor exceptionInterceptor)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  430 */       byte[] b = null;
/*      */       String s;
/*  432 */       if (converter != null) {
/*  433 */         b = converter.toBytes(c);
/*  434 */       } else if (encoding == null) {
/*  435 */         b = new String(c).getBytes();
/*      */       } else {
/*  437 */         s = new String(c);
/*      */         
/*  439 */         b = s.getBytes(encoding);
/*      */         
/*  441 */         if ((!parserKnowsUnicode) && ((encoding.equalsIgnoreCase("SJIS")) || (encoding.equalsIgnoreCase("BIG5")) || (encoding.equalsIgnoreCase("GBK"))))
/*      */         {
/*      */ 
/*      */ 
/*  445 */           if (encoding.equalsIgnoreCase(serverEncoding)) {} } }
/*  446 */       return escapeEasternUnicodeByteStream(b, s, 0, s.length());
/*      */ 
/*      */ 
/*      */     }
/*      */     catch (UnsupportedEncodingException uee)
/*      */     {
/*      */ 
/*  453 */       throw SQLError.createSQLException(Messages.getString("StringUtils.5") + encoding + Messages.getString("StringUtils.6"), "S1009", exceptionInterceptor);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final byte[] getBytes(char[] c, SingleByteCharsetConverter converter, String encoding, String serverEncoding, int offset, int length, boolean parserKnowsUnicode, ExceptionInterceptor exceptionInterceptor)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  464 */       byte[] b = null;
/*      */       String s;
/*  466 */       if (converter != null) {
/*  467 */         b = converter.toBytes(c, offset, length);
/*  468 */       } else if (encoding == null) {
/*  469 */         byte[] temp = new String(c, offset, length).getBytes();
/*      */         
/*  471 */         length = temp.length;
/*      */         
/*  473 */         b = new byte[length];
/*  474 */         System.arraycopy(temp, 0, b, 0, length);
/*      */       } else {
/*  476 */         s = new String(c, offset, length);
/*      */         
/*  478 */         byte[] temp = s.getBytes(encoding);
/*      */         
/*  480 */         length = temp.length;
/*      */         
/*  482 */         b = new byte[length];
/*  483 */         System.arraycopy(temp, 0, b, 0, length);
/*      */         
/*  485 */         if ((!parserKnowsUnicode) && ((encoding.equalsIgnoreCase("SJIS")) || (encoding.equalsIgnoreCase("BIG5")) || (encoding.equalsIgnoreCase("GBK"))))
/*      */         {
/*      */ 
/*      */ 
/*  489 */           if (encoding.equalsIgnoreCase(serverEncoding)) {} } }
/*  490 */       return escapeEasternUnicodeByteStream(b, s, offset, length);
/*      */ 
/*      */ 
/*      */     }
/*      */     catch (UnsupportedEncodingException uee)
/*      */     {
/*      */ 
/*  497 */       throw SQLError.createSQLException(Messages.getString("StringUtils.10") + encoding + Messages.getString("StringUtils.11"), "S1009", exceptionInterceptor);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final byte[] getBytes(char[] c, String encoding, String serverEncoding, boolean parserKnowsUnicode, MySQLConnection conn, ExceptionInterceptor exceptionInterceptor)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  509 */       SingleByteCharsetConverter converter = null;
/*      */       
/*  511 */       if (conn != null) {
/*  512 */         converter = conn.getCharsetConverter(encoding);
/*      */       } else {
/*  514 */         converter = SingleByteCharsetConverter.getInstance(encoding, null);
/*      */       }
/*      */       
/*  517 */       return getBytes(c, converter, encoding, serverEncoding, parserKnowsUnicode, exceptionInterceptor);
/*      */     }
/*      */     catch (UnsupportedEncodingException uee) {
/*  520 */       throw SQLError.createSQLException(Messages.getString("StringUtils.0") + encoding + Messages.getString("StringUtils.1"), "S1009", exceptionInterceptor);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final byte[] getBytes(String s, SingleByteCharsetConverter converter, String encoding, String serverEncoding, boolean parserKnowsUnicode, ExceptionInterceptor exceptionInterceptor)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  551 */       byte[] b = null;
/*      */       
/*  553 */       if (converter != null) {
/*  554 */         b = converter.toBytes(s);
/*  555 */       } else if (encoding == null) {
/*  556 */         b = s.getBytes();
/*      */       } else {
/*  558 */         b = s.getBytes(encoding);
/*      */         
/*  560 */         if ((!parserKnowsUnicode) && ((encoding.equalsIgnoreCase("SJIS")) || (encoding.equalsIgnoreCase("BIG5")) || (encoding.equalsIgnoreCase("GBK"))))
/*      */         {
/*      */ 
/*      */ 
/*  564 */           if (encoding.equalsIgnoreCase(serverEncoding)) {} } }
/*  565 */       return escapeEasternUnicodeByteStream(b, s, 0, s.length());
/*      */ 
/*      */ 
/*      */     }
/*      */     catch (UnsupportedEncodingException uee)
/*      */     {
/*      */ 
/*  572 */       throw SQLError.createSQLException(Messages.getString("StringUtils.5") + encoding + Messages.getString("StringUtils.6"), "S1009", exceptionInterceptor);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final byte[] getBytesWrapped(String s, char beginWrap, char endWrap, SingleByteCharsetConverter converter, String encoding, String serverEncoding, boolean parserKnowsUnicode, ExceptionInterceptor exceptionInterceptor)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  583 */       byte[] b = null;
/*      */       
/*  585 */       if (converter != null) {
/*  586 */         b = converter.toBytesWrapped(s, beginWrap, endWrap);
/*  587 */       } else if (encoding == null) {
/*  588 */         StringBuffer buf = new StringBuffer(s.length() + 2);
/*  589 */         buf.append(beginWrap);
/*  590 */         buf.append(s);
/*  591 */         buf.append(endWrap);
/*      */         
/*  593 */         b = buf.toString().getBytes();
/*      */       } else {
/*  595 */         StringBuffer buf = new StringBuffer(s.length() + 2);
/*  596 */         buf.append(beginWrap);
/*  597 */         buf.append(s);
/*  598 */         buf.append(endWrap);
/*      */         
/*  600 */         b = buf.toString().getBytes(encoding);
/*      */         
/*  602 */         if ((!parserKnowsUnicode) && ((encoding.equalsIgnoreCase("SJIS")) || (encoding.equalsIgnoreCase("BIG5")) || (encoding.equalsIgnoreCase("GBK"))))
/*      */         {
/*      */ 
/*      */ 
/*  606 */           if (encoding.equalsIgnoreCase(serverEncoding)) {} } }
/*  607 */       return escapeEasternUnicodeByteStream(b, s, 0, s.length());
/*      */ 
/*      */ 
/*      */     }
/*      */     catch (UnsupportedEncodingException uee)
/*      */     {
/*      */ 
/*  614 */       throw SQLError.createSQLException(Messages.getString("StringUtils.5") + encoding + Messages.getString("StringUtils.6"), "S1009", exceptionInterceptor);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final byte[] getBytes(String s, SingleByteCharsetConverter converter, String encoding, String serverEncoding, int offset, int length, boolean parserKnowsUnicode, ExceptionInterceptor exceptionInterceptor)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  648 */       byte[] b = null;
/*      */       
/*  650 */       if (converter != null) {
/*  651 */         b = converter.toBytes(s, offset, length);
/*  652 */       } else if (encoding == null) {
/*  653 */         byte[] temp = s.substring(offset, offset + length).getBytes();
/*      */         
/*  655 */         length = temp.length;
/*      */         
/*  657 */         b = new byte[length];
/*  658 */         System.arraycopy(temp, 0, b, 0, length);
/*      */       }
/*      */       else {
/*  661 */         byte[] temp = s.substring(offset, offset + length).getBytes(encoding);
/*      */         
/*      */ 
/*  664 */         length = temp.length;
/*      */         
/*  666 */         b = new byte[length];
/*  667 */         System.arraycopy(temp, 0, b, 0, length);
/*      */         
/*  669 */         if ((!parserKnowsUnicode) && ((encoding.equalsIgnoreCase("SJIS")) || (encoding.equalsIgnoreCase("BIG5")) || (encoding.equalsIgnoreCase("GBK"))))
/*      */         {
/*      */ 
/*      */ 
/*  673 */           if (encoding.equalsIgnoreCase(serverEncoding)) {} } }
/*  674 */       return escapeEasternUnicodeByteStream(b, s, offset, length);
/*      */ 
/*      */ 
/*      */     }
/*      */     catch (UnsupportedEncodingException uee)
/*      */     {
/*      */ 
/*  681 */       throw SQLError.createSQLException(Messages.getString("StringUtils.10") + encoding + Messages.getString("StringUtils.11"), "S1009", exceptionInterceptor);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final byte[] getBytes(String s, String encoding, String serverEncoding, boolean parserKnowsUnicode, MySQLConnection conn, ExceptionInterceptor exceptionInterceptor)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  708 */       SingleByteCharsetConverter converter = null;
/*      */       
/*  710 */       if (conn != null) {
/*  711 */         converter = conn.getCharsetConverter(encoding);
/*      */       } else {
/*  713 */         converter = SingleByteCharsetConverter.getInstance(encoding, null);
/*      */       }
/*      */       
/*  716 */       return getBytes(s, converter, encoding, serverEncoding, parserKnowsUnicode, exceptionInterceptor);
/*      */     }
/*      */     catch (UnsupportedEncodingException uee) {
/*  719 */       throw SQLError.createSQLException(Messages.getString("StringUtils.0") + encoding + Messages.getString("StringUtils.1"), "S1009", exceptionInterceptor);
/*      */     }
/*      */   }
/*      */   
/*      */   public static int getInt(byte[] buf, int offset, int endPos)
/*      */     throws NumberFormatException
/*      */   {
/*  726 */     int base = 10;
/*      */     
/*  728 */     int s = offset;
/*      */     
/*      */ 
/*  731 */     while ((Character.isWhitespace((char)buf[s])) && (s < endPos)) {
/*  732 */       s++;
/*      */     }
/*      */     
/*  735 */     if (s == endPos) {
/*  736 */       throw new NumberFormatException(toString(buf));
/*      */     }
/*      */     
/*      */ 
/*  740 */     boolean negative = false;
/*      */     
/*  742 */     if ((char)buf[s] == '-') {
/*  743 */       negative = true;
/*  744 */       s++;
/*  745 */     } else if ((char)buf[s] == '+') {
/*  746 */       s++;
/*      */     }
/*      */     
/*      */ 
/*  750 */     int save = s;
/*      */     
/*  752 */     int cutoff = Integer.MAX_VALUE / base;
/*  753 */     int cutlim = Integer.MAX_VALUE % base;
/*      */     
/*  755 */     if (negative) {
/*  756 */       cutlim++;
/*      */     }
/*      */     
/*  759 */     boolean overflow = false;
/*      */     
/*  761 */     int i = 0;
/*  763 */     for (; 
/*  763 */         s < endPos; s++) {
/*  764 */       char c = (char)buf[s];
/*      */       
/*  766 */       if (Character.isDigit(c)) {
/*  767 */         c = (char)(c - '0');
/*  768 */       } else { if (!Character.isLetter(c)) break;
/*  769 */         c = (char)(Character.toUpperCase(c) - 'A' + 10);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  774 */       if (c >= base) {
/*      */         break;
/*      */       }
/*      */       
/*      */ 
/*  779 */       if ((i > cutoff) || ((i == cutoff) && (c > cutlim))) {
/*  780 */         overflow = true;
/*      */       } else {
/*  782 */         i *= base;
/*  783 */         i += c;
/*      */       }
/*      */     }
/*      */     
/*  787 */     if (s == save) {
/*  788 */       throw new NumberFormatException(toString(buf));
/*      */     }
/*      */     
/*  791 */     if (overflow) {
/*  792 */       throw new NumberFormatException(toString(buf));
/*      */     }
/*      */     
/*      */ 
/*  796 */     return negative ? -i : i;
/*      */   }
/*      */   
/*      */   public static int getInt(byte[] buf) throws NumberFormatException {
/*  800 */     return getInt(buf, 0, buf.length);
/*      */   }
/*      */   
/*      */   public static long getLong(byte[] buf) throws NumberFormatException {
/*  804 */     return getLong(buf, 0, buf.length);
/*      */   }
/*      */   
/*      */   public static long getLong(byte[] buf, int offset, int endpos) throws NumberFormatException {
/*  808 */     int base = 10;
/*      */     
/*  810 */     int s = offset;
/*      */     
/*      */ 
/*  813 */     while ((Character.isWhitespace((char)buf[s])) && (s < endpos)) {
/*  814 */       s++;
/*      */     }
/*      */     
/*  817 */     if (s == endpos) {
/*  818 */       throw new NumberFormatException(toString(buf));
/*      */     }
/*      */     
/*      */ 
/*  822 */     boolean negative = false;
/*      */     
/*  824 */     if ((char)buf[s] == '-') {
/*  825 */       negative = true;
/*  826 */       s++;
/*  827 */     } else if ((char)buf[s] == '+') {
/*  828 */       s++;
/*      */     }
/*      */     
/*      */ 
/*  832 */     int save = s;
/*      */     
/*  834 */     long cutoff = Long.MAX_VALUE / base;
/*  835 */     long cutlim = (int)(Long.MAX_VALUE % base);
/*      */     
/*  837 */     if (negative) {
/*  838 */       cutlim += 1L;
/*      */     }
/*      */     
/*  841 */     boolean overflow = false;
/*  842 */     long i = 0L;
/*  844 */     for (; 
/*  844 */         s < endpos; s++) {
/*  845 */       char c = (char)buf[s];
/*      */       
/*  847 */       if (Character.isDigit(c)) {
/*  848 */         c = (char)(c - '0');
/*  849 */       } else { if (!Character.isLetter(c)) break;
/*  850 */         c = (char)(Character.toUpperCase(c) - 'A' + 10);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  855 */       if (c >= base) {
/*      */         break;
/*      */       }
/*      */       
/*      */ 
/*  860 */       if ((i > cutoff) || ((i == cutoff) && (c > cutlim))) {
/*  861 */         overflow = true;
/*      */       } else {
/*  863 */         i *= base;
/*  864 */         i += c;
/*      */       }
/*      */     }
/*      */     
/*  868 */     if (s == save) {
/*  869 */       throw new NumberFormatException(toString(buf));
/*      */     }
/*      */     
/*  872 */     if (overflow) {
/*  873 */       throw new NumberFormatException(toString(buf));
/*      */     }
/*      */     
/*      */ 
/*  877 */     return negative ? -i : i;
/*      */   }
/*      */   
/*      */   public static short getShort(byte[] buf) throws NumberFormatException {
/*  881 */     short base = 10;
/*      */     
/*  883 */     int s = 0;
/*      */     
/*      */ 
/*  886 */     while ((Character.isWhitespace((char)buf[s])) && (s < buf.length)) {
/*  887 */       s++;
/*      */     }
/*      */     
/*  890 */     if (s == buf.length) {
/*  891 */       throw new NumberFormatException(toString(buf));
/*      */     }
/*      */     
/*      */ 
/*  895 */     boolean negative = false;
/*      */     
/*  897 */     if ((char)buf[s] == '-') {
/*  898 */       negative = true;
/*  899 */       s++;
/*  900 */     } else if ((char)buf[s] == '+') {
/*  901 */       s++;
/*      */     }
/*      */     
/*      */ 
/*  905 */     int save = s;
/*      */     
/*  907 */     short cutoff = (short)(Short.MAX_VALUE / base);
/*  908 */     short cutlim = (short)(Short.MAX_VALUE % base);
/*      */     
/*  910 */     if (negative) {
/*  911 */       cutlim = (short)(cutlim + 1);
/*      */     }
/*      */     
/*  914 */     boolean overflow = false;
/*  915 */     short i = 0;
/*  917 */     for (; 
/*  917 */         s < buf.length; s++) {
/*  918 */       char c = (char)buf[s];
/*      */       
/*  920 */       if (Character.isDigit(c)) {
/*  921 */         c = (char)(c - '0');
/*  922 */       } else { if (!Character.isLetter(c)) break;
/*  923 */         c = (char)(Character.toUpperCase(c) - 'A' + 10);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  928 */       if (c >= base) {
/*      */         break;
/*      */       }
/*      */       
/*      */ 
/*  933 */       if ((i > cutoff) || ((i == cutoff) && (c > cutlim))) {
/*  934 */         overflow = true;
/*      */       } else {
/*  936 */         i = (short)(i * base);
/*  937 */         i = (short)(i + c);
/*      */       }
/*      */     }
/*      */     
/*  941 */     if (s == save) {
/*  942 */       throw new NumberFormatException(toString(buf));
/*      */     }
/*      */     
/*  945 */     if (overflow) {
/*  946 */       throw new NumberFormatException(toString(buf));
/*      */     }
/*      */     
/*      */ 
/*  950 */     return negative ? (short)-i : i;
/*      */   }
/*      */   
/*      */   public static final int indexOfIgnoreCase(int startingPosition, String searchIn, String searchFor)
/*      */   {
/*  955 */     if ((searchIn == null) || (searchFor == null) || (startingPosition > searchIn.length()))
/*      */     {
/*  957 */       return -1;
/*      */     }
/*      */     
/*  960 */     int patternLength = searchFor.length();
/*  961 */     int stringLength = searchIn.length();
/*  962 */     int stopSearchingAt = stringLength - patternLength;
/*      */     
/*  964 */     if (patternLength == 0) {
/*  965 */       return -1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  970 */     char firstCharOfPatternUc = Character.toUpperCase(searchFor.charAt(0));
/*  971 */     char firstCharOfPatternLc = Character.toLowerCase(searchFor.charAt(0));
/*      */     
/*      */ 
/*  974 */     for (int i = startingPosition; i <= stopSearchingAt; i++) {
/*  975 */       if (isNotEqualIgnoreCharCase(searchIn, firstCharOfPatternUc, firstCharOfPatternLc, i)) {
/*      */         do
/*      */         {
/*  978 */           i++; } while ((i <= stopSearchingAt) && (isNotEqualIgnoreCharCase(searchIn, firstCharOfPatternUc, firstCharOfPatternLc, i)));
/*      */       }
/*      */       
/*      */ 
/*  982 */       if (i <= stopSearchingAt)
/*      */       {
/*      */ 
/*  985 */         int j = i + 1;
/*  986 */         int end = j + patternLength - 1;
/*  987 */         for (int k = 1; (j < end) && ((Character.toLowerCase(searchIn.charAt(j)) == Character.toLowerCase(searchFor.charAt(k))) || (Character.toUpperCase(searchIn.charAt(j)) == Character.toUpperCase(searchFor.charAt(k)))); 
/*      */             
/*  989 */             k++) { j++;
/*      */         }
/*  991 */         if (j == end) {
/*  992 */           return i;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  997 */     return -1;
/*      */   }
/*      */   
/*      */   private static final boolean isNotEqualIgnoreCharCase(String searchIn, char firstCharOfPatternUc, char firstCharOfPatternLc, int i)
/*      */   {
/* 1002 */     return (Character.toLowerCase(searchIn.charAt(i)) != firstCharOfPatternLc) && (Character.toUpperCase(searchIn.charAt(i)) != firstCharOfPatternUc);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int indexOfIgnoreCase(String searchIn, String searchFor)
/*      */   {
/* 1017 */     return indexOfIgnoreCase(0, searchIn, searchFor);
/*      */   }
/*      */   
/*      */ 
/*      */   public static int indexOfIgnoreCaseRespectMarker(int startAt, String src, String target, String marker, String markerCloses, boolean allowBackslashEscapes)
/*      */   {
/* 1023 */     char contextMarker = '\000';
/* 1024 */     boolean escaped = false;
/* 1025 */     int markerTypeFound = 0;
/* 1026 */     int srcLength = src.length();
/* 1027 */     int ind = 0;
/*      */     
/* 1029 */     for (int i = startAt; i < srcLength; i++) {
/* 1030 */       char c = src.charAt(i);
/*      */       
/* 1032 */       if ((allowBackslashEscapes) && (c == '\\')) {
/* 1033 */         escaped = !escaped;
/* 1034 */       } else if ((contextMarker != 0) && (c == markerCloses.charAt(markerTypeFound)) && (!escaped)) {
/* 1035 */         contextMarker = '\000';
/* 1036 */       } else if (((ind = marker.indexOf(c)) != -1) && (!escaped) && (contextMarker == 0))
/*      */       {
/* 1038 */         markerTypeFound = ind;
/* 1039 */         contextMarker = c;
/* 1040 */       } else if (((Character.toUpperCase(c) == Character.toUpperCase(target.charAt(0))) || (Character.toLowerCase(c) == Character.toLowerCase(target.charAt(0)))) && (!escaped) && (contextMarker == 0))
/*      */       {
/*      */ 
/* 1043 */         if (startsWithIgnoreCase(src, i, target)) {
/* 1044 */           return i;
/*      */         }
/*      */       }
/*      */     }
/* 1048 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */   public static int indexOfIgnoreCaseRespectQuotes(int startAt, String src, String target, char quoteChar, boolean allowBackslashEscapes)
/*      */   {
/* 1054 */     char contextMarker = '\000';
/* 1055 */     boolean escaped = false;
/*      */     
/* 1057 */     int srcLength = src.length();
/*      */     
/* 1059 */     for (int i = startAt; i < srcLength; i++) {
/* 1060 */       char c = src.charAt(i);
/*      */       
/* 1062 */       if ((allowBackslashEscapes) && (c == '\\')) {
/* 1063 */         escaped = !escaped;
/* 1064 */       } else if ((c == contextMarker) && (!escaped)) {
/* 1065 */         contextMarker = '\000';
/* 1066 */       } else if ((c == quoteChar) && (!escaped) && (contextMarker == 0))
/*      */       {
/* 1068 */         contextMarker = c;
/*      */ 
/*      */       }
/* 1071 */       else if (((Character.toUpperCase(c) == Character.toUpperCase(target.charAt(0))) || (Character.toLowerCase(c) == Character.toLowerCase(target.charAt(0)))) && (!escaped) && (contextMarker == 0))
/*      */       {
/*      */ 
/* 1074 */         if (startsWithIgnoreCase(src, i, target)) {
/* 1075 */           return i;
/*      */         }
/*      */       }
/*      */     }
/* 1079 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final List<String> split(String stringToSplit, String delimitter, boolean trim)
/*      */   {
/* 1100 */     if (stringToSplit == null) {
/* 1101 */       return new ArrayList();
/*      */     }
/*      */     
/* 1104 */     if (delimitter == null) {
/* 1105 */       throw new IllegalArgumentException();
/*      */     }
/*      */     
/* 1108 */     StringTokenizer tokenizer = new StringTokenizer(stringToSplit, delimitter, false);
/*      */     
/*      */ 
/* 1111 */     List<String> splitTokens = new ArrayList(tokenizer.countTokens());
/*      */     
/* 1113 */     while (tokenizer.hasMoreTokens()) {
/* 1114 */       String token = tokenizer.nextToken();
/*      */       
/* 1116 */       if (trim) {
/* 1117 */         token = token.trim();
/*      */       }
/*      */       
/* 1120 */       splitTokens.add(token);
/*      */     }
/*      */     
/* 1123 */     return splitTokens;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final List<String> split(String stringToSplit, String delimiter, String markers, String markerCloses, boolean trim)
/*      */   {
/* 1143 */     if (stringToSplit == null) {
/* 1144 */       return new ArrayList();
/*      */     }
/*      */     
/* 1147 */     if (delimiter == null) {
/* 1148 */       throw new IllegalArgumentException();
/*      */     }
/*      */     
/* 1151 */     int delimPos = 0;
/* 1152 */     int currentPos = 0;
/*      */     
/* 1154 */     List<String> splitTokens = new ArrayList();
/*      */     
/*      */ 
/* 1157 */     while ((delimPos = indexOfIgnoreCaseRespectMarker(currentPos, stringToSplit, delimiter, markers, markerCloses, false)) != -1) {
/* 1158 */       String token = stringToSplit.substring(currentPos, delimPos);
/*      */       
/* 1160 */       if (trim) {
/* 1161 */         token = token.trim();
/*      */       }
/*      */       
/* 1164 */       splitTokens.add(token);
/* 1165 */       currentPos = delimPos + 1;
/*      */     }
/*      */     
/* 1168 */     if (currentPos < stringToSplit.length()) {
/* 1169 */       String token = stringToSplit.substring(currentPos);
/*      */       
/* 1171 */       if (trim) {
/* 1172 */         token = token.trim();
/*      */       }
/*      */       
/* 1175 */       splitTokens.add(token);
/*      */     }
/*      */     
/* 1178 */     return splitTokens;
/*      */   }
/*      */   
/*      */   private static boolean startsWith(byte[] dataFrom, String chars) {
/* 1182 */     for (int i = 0; i < chars.length(); i++) {
/* 1183 */       if (dataFrom[i] != chars.charAt(i)) {
/* 1184 */         return false;
/*      */       }
/*      */     }
/* 1187 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean startsWithIgnoreCase(String searchIn, int startAt, String searchFor)
/*      */   {
/* 1206 */     return searchIn.regionMatches(true, startAt, searchFor, 0, searchFor.length());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean startsWithIgnoreCase(String searchIn, String searchFor)
/*      */   {
/* 1222 */     return startsWithIgnoreCase(searchIn, 0, searchFor);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean startsWithIgnoreCaseAndNonAlphaNumeric(String searchIn, String searchFor)
/*      */   {
/* 1239 */     if (searchIn == null) {
/* 1240 */       return searchFor == null;
/*      */     }
/*      */     
/* 1243 */     int beginPos = 0;
/*      */     
/* 1245 */     int inLength = searchIn.length();
/*      */     
/* 1247 */     for (beginPos = 0; beginPos < inLength; beginPos++) {
/* 1248 */       char c = searchIn.charAt(beginPos);
/*      */       
/* 1250 */       if (Character.isLetterOrDigit(c)) {
/*      */         break;
/*      */       }
/*      */     }
/*      */     
/* 1255 */     return startsWithIgnoreCase(searchIn, beginPos, searchFor);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean startsWithIgnoreCaseAndWs(String searchIn, String searchFor)
/*      */   {
/* 1271 */     return startsWithIgnoreCaseAndWs(searchIn, searchFor, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean startsWithIgnoreCaseAndWs(String searchIn, String searchFor, int beginPos)
/*      */   {
/* 1290 */     if (searchIn == null) {
/* 1291 */       return searchFor == null;
/*      */     }
/*      */     
/* 1294 */     int inLength = searchIn.length();
/* 1296 */     for (; 
/* 1296 */         beginPos < inLength; beginPos++) {
/* 1297 */       if (!Character.isWhitespace(searchIn.charAt(beginPos))) {
/*      */         break;
/*      */       }
/*      */     }
/*      */     
/* 1302 */     return startsWithIgnoreCase(searchIn, beginPos, searchFor);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static byte[] stripEnclosure(byte[] source, String prefix, String suffix)
/*      */   {
/* 1313 */     if ((source.length >= prefix.length() + suffix.length()) && (startsWith(source, prefix)) && (endsWith(source, suffix)))
/*      */     {
/*      */ 
/* 1316 */       int totalToStrip = prefix.length() + suffix.length();
/* 1317 */       int enclosedLength = source.length - totalToStrip;
/* 1318 */       byte[] enclosed = new byte[enclosedLength];
/*      */       
/* 1320 */       int startPos = prefix.length();
/* 1321 */       int numToCopy = enclosed.length;
/* 1322 */       System.arraycopy(source, startPos, enclosed, 0, numToCopy);
/*      */       
/* 1324 */       return enclosed;
/*      */     }
/* 1326 */     return source;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final String toAsciiString(byte[] buffer)
/*      */   {
/* 1338 */     return toAsciiString(buffer, 0, buffer.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final String toAsciiString(byte[] buffer, int startPos, int length)
/*      */   {
/* 1355 */     char[] charArray = new char[length];
/* 1356 */     int readpoint = startPos;
/*      */     
/* 1358 */     for (int i = 0; i < length; i++) {
/* 1359 */       charArray[i] = ((char)buffer[readpoint]);
/* 1360 */       readpoint++;
/*      */     }
/*      */     
/* 1363 */     return new String(charArray);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int wildCompare(String searchIn, String searchForWildcard)
/*      */   {
/* 1381 */     if ((searchIn == null) || (searchForWildcard == null)) {
/* 1382 */       return -1;
/*      */     }
/*      */     
/* 1385 */     if (searchForWildcard.equals("%"))
/*      */     {
/* 1387 */       return 1;
/*      */     }
/*      */     
/* 1390 */     int result = -1;
/*      */     
/* 1392 */     char wildcardMany = '%';
/* 1393 */     char wildcardOne = '_';
/* 1394 */     char wildcardEscape = '\\';
/*      */     
/* 1396 */     int searchForPos = 0;
/* 1397 */     int searchForEnd = searchForWildcard.length();
/*      */     
/* 1399 */     int searchInPos = 0;
/* 1400 */     int searchInEnd = searchIn.length();
/*      */     
/* 1402 */     while (searchForPos != searchForEnd) {
/* 1403 */       char wildstrChar = searchForWildcard.charAt(searchForPos);
/*      */       
/*      */ 
/* 1406 */       while ((searchForWildcard.charAt(searchForPos) != wildcardMany) && (wildstrChar != wildcardOne)) {
/* 1407 */         if ((searchForWildcard.charAt(searchForPos) == wildcardEscape) && (searchForPos + 1 != searchForEnd))
/*      */         {
/* 1409 */           searchForPos++;
/*      */         }
/*      */         
/* 1412 */         if ((searchInPos == searchInEnd) || (Character.toUpperCase(searchForWildcard.charAt(searchForPos++)) != Character.toUpperCase(searchIn.charAt(searchInPos++))))
/*      */         {
/*      */ 
/*      */ 
/* 1416 */           return 1;
/*      */         }
/*      */         
/* 1419 */         if (searchForPos == searchForEnd) {
/* 1420 */           return searchInPos != searchInEnd ? 1 : 0;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1427 */         result = 1;
/*      */       }
/*      */       
/* 1430 */       if (searchForWildcard.charAt(searchForPos) == wildcardOne) {
/*      */         do {
/* 1432 */           if (searchInPos == searchInEnd)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/* 1437 */             return result;
/*      */           }
/*      */           
/* 1440 */           searchInPos++;
/*      */           
/* 1442 */           searchForPos++; } while ((searchForPos < searchForEnd) && (searchForWildcard.charAt(searchForPos) == wildcardOne));
/*      */         
/* 1444 */         if (searchForPos == searchForEnd) {
/*      */           break;
/*      */         }
/*      */       }
/*      */       
/* 1449 */       if (searchForWildcard.charAt(searchForPos) == wildcardMany)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1456 */         searchForPos++;
/* 1459 */         for (; 
/*      */             
/* 1459 */             searchForPos != searchForEnd; searchForPos++) {
/* 1460 */           if (searchForWildcard.charAt(searchForPos) != wildcardMany)
/*      */           {
/*      */ 
/*      */ 
/* 1464 */             if (searchForWildcard.charAt(searchForPos) != wildcardOne) break;
/* 1465 */             if (searchInPos == searchInEnd) {
/* 1466 */               return -1;
/*      */             }
/*      */             
/* 1469 */             searchInPos++;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1477 */         if (searchForPos == searchForEnd) {
/* 1478 */           return 0;
/*      */         }
/*      */         
/* 1481 */         if (searchInPos == searchInEnd) {
/* 1482 */           return -1;
/*      */         }
/*      */         char cmp;
/* 1485 */         if (((cmp = searchForWildcard.charAt(searchForPos)) == wildcardEscape) && (searchForPos + 1 != searchForEnd))
/*      */         {
/* 1487 */           cmp = searchForWildcard.charAt(++searchForPos);
/*      */         }
/*      */         
/* 1490 */         searchForPos++;
/*      */         
/*      */         do
/*      */         {
/* 1494 */           while ((searchInPos != searchInEnd) && (Character.toUpperCase(searchIn.charAt(searchInPos)) != Character.toUpperCase(cmp)))
/*      */           {
/*      */ 
/* 1497 */             searchInPos++;
/*      */           }
/* 1499 */           if (searchInPos++ == searchInEnd) {
/* 1500 */             return -1;
/*      */           }
/*      */           
/*      */ 
/* 1504 */           int tmp = wildCompare(searchIn, searchForWildcard);
/*      */           
/* 1506 */           if (tmp <= 0) {
/* 1507 */             return tmp;
/*      */           }
/*      */           
/*      */         }
/* 1511 */         while ((searchInPos != searchInEnd) && (searchForWildcard.charAt(0) != wildcardMany));
/*      */         
/* 1513 */         return -1;
/*      */       }
/*      */     }
/*      */     
/* 1517 */     return searchInPos != searchInEnd ? 1 : 0;
/*      */   }
/*      */   
/*      */   static byte[] s2b(String s, MySQLConnection conn) throws SQLException
/*      */   {
/* 1522 */     if (s == null) {
/* 1523 */       return null;
/*      */     }
/*      */     
/* 1526 */     if ((conn != null) && (conn.getUseUnicode())) {
/*      */       try {
/* 1528 */         String encoding = conn.getEncoding();
/*      */         
/* 1530 */         if (encoding == null) {
/* 1531 */           return s.getBytes();
/*      */         }
/*      */         
/* 1534 */         SingleByteCharsetConverter converter = conn.getCharsetConverter(encoding);
/*      */         
/*      */ 
/* 1537 */         if (converter != null) {
/* 1538 */           return converter.toBytes(s);
/*      */         }
/*      */         
/* 1541 */         return s.getBytes(encoding);
/*      */       } catch (UnsupportedEncodingException E) {
/* 1543 */         return s.getBytes();
/*      */       }
/*      */     }
/*      */     
/* 1547 */     return s.getBytes();
/*      */   }
/*      */   
/*      */   public static int lastIndexOf(byte[] s, char c) {
/* 1551 */     if (s == null) {
/* 1552 */       return -1;
/*      */     }
/*      */     
/* 1555 */     for (int i = s.length - 1; i >= 0; i--) {
/* 1556 */       if (s[i] == c) {
/* 1557 */         return i;
/*      */       }
/*      */     }
/*      */     
/* 1561 */     return -1;
/*      */   }
/*      */   
/*      */   public static int indexOf(byte[] s, char c) {
/* 1565 */     if (s == null) {
/* 1566 */       return -1;
/*      */     }
/*      */     
/* 1569 */     int length = s.length;
/*      */     
/* 1571 */     for (int i = 0; i < length; i++) {
/* 1572 */       if (s[i] == c) {
/* 1573 */         return i;
/*      */       }
/*      */     }
/*      */     
/* 1577 */     return -1;
/*      */   }
/*      */   
/*      */   public static boolean isNullOrEmpty(String toTest) {
/* 1581 */     return (toTest == null) || (toTest.length() == 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String stripComments(String src, String stringOpens, String stringCloses, boolean slashStarComments, boolean slashSlashComments, boolean hashComments, boolean dashDashComments)
/*      */   {
/* 1608 */     if (src == null) {
/* 1609 */       return null;
/*      */     }
/*      */     
/* 1612 */     StringBuffer buf = new StringBuffer(src.length());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1621 */     StringReader sourceReader = new StringReader(src);
/*      */     
/* 1623 */     int contextMarker = 0;
/* 1624 */     boolean escaped = false;
/* 1625 */     int markerTypeFound = -1;
/*      */     
/* 1627 */     int ind = 0;
/*      */     
/* 1629 */     int currentChar = 0;
/*      */     try
/*      */     {
/* 1632 */       while ((currentChar = sourceReader.read()) != -1)
/*      */       {
/*      */ 
/*      */ 
/* 1636 */         if ((markerTypeFound != -1) && (currentChar == stringCloses.charAt(markerTypeFound)) && (!escaped))
/*      */         {
/* 1638 */           contextMarker = 0;
/* 1639 */           markerTypeFound = -1;
/* 1640 */         } else if (((ind = stringOpens.indexOf(currentChar)) != -1) && (!escaped) && (contextMarker == 0))
/*      */         {
/* 1642 */           markerTypeFound = ind;
/* 1643 */           contextMarker = currentChar;
/*      */         }
/*      */         
/* 1646 */         if ((contextMarker == 0) && (currentChar == 47) && ((slashSlashComments) || (slashStarComments)))
/*      */         {
/* 1648 */           currentChar = sourceReader.read();
/* 1649 */           if ((currentChar == 42) && (slashStarComments)) {
/* 1650 */             int prevChar = 0;
/*      */             
/* 1652 */             while (((currentChar = sourceReader.read()) != 47) || (prevChar != 42)) {
/* 1653 */               if (currentChar == 13)
/*      */               {
/* 1655 */                 currentChar = sourceReader.read();
/* 1656 */                 if (currentChar == 10) {
/* 1657 */                   currentChar = sourceReader.read();
/*      */                 }
/*      */               }
/* 1660 */               else if (currentChar == 10)
/*      */               {
/* 1662 */                 currentChar = sourceReader.read();
/*      */               }
/*      */               
/* 1665 */               if (currentChar < 0)
/*      */                 break;
/* 1667 */               prevChar = currentChar;
/*      */             }
/*      */           }
/* 1670 */           if ((currentChar != 47) || (!slashSlashComments)) {}
/*      */         } else {
/* 1672 */           while (((currentChar = sourceReader.read()) != 10) && (currentChar != 13) && (currentChar >= 0))
/*      */           {
/*      */             continue;
/* 1675 */             if ((contextMarker == 0) && (currentChar == 35) && (hashComments)) {}
/*      */             
/*      */             for (;;)
/*      */             {
/* 1679 */               if (((currentChar = sourceReader.read()) != 10) && (currentChar != 13) && (currentChar >= 0)) {
/*      */                 continue;
/* 1681 */                 if ((contextMarker == 0) && (currentChar == 45) && (dashDashComments))
/*      */                 {
/* 1683 */                   currentChar = sourceReader.read();
/*      */                   
/* 1685 */                   if ((currentChar == -1) || (currentChar != 45)) {
/* 1686 */                     buf.append('-');
/*      */                     
/* 1688 */                     if (currentChar == -1) break;
/* 1689 */                     buf.append(currentChar); break;
/*      */                   }
/*      */                   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1698 */                   while (((currentChar = sourceReader.read()) != 10) && (currentChar != 13) && (currentChar >= 0)) {}
/*      */                 }
/*      */               }
/*      */             } } }
/* 1702 */         if (currentChar != -1) {
/* 1703 */           buf.append((char)currentChar);
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (IOException ioEx) {}
/*      */     
/*      */ 
/* 1710 */     return buf.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String sanitizeProcOrFuncName(String src)
/*      */   {
/* 1726 */     if ((src == null) || (src.equals("%"))) {
/* 1727 */       return null;
/*      */     }
/*      */     
/* 1730 */     return src;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static List splitDBdotName(String src, String cat, String quotId, boolean isNoBslashEscSet)
/*      */   {
/* 1750 */     if ((src == null) || (src.equals("%"))) {
/* 1751 */       return new ArrayList();
/*      */     }
/*      */     
/* 1754 */     boolean isQuoted = indexOfIgnoreCase(0, src, quotId) > -1;
/*      */     
/*      */ 
/* 1757 */     String retval = src;
/* 1758 */     String tmpCat = cat;
/*      */     
/* 1760 */     int trueDotIndex = -1;
/* 1761 */     if (!" ".equals(quotId))
/*      */     {
/*      */ 
/* 1764 */       if (isQuoted) {
/* 1765 */         trueDotIndex = indexOfIgnoreCase(0, retval, quotId + "." + quotId);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 1770 */         trueDotIndex = indexOfIgnoreCase(0, retval, ".");
/*      */       }
/*      */     }
/*      */     else {
/* 1774 */       trueDotIndex = retval.indexOf(".");
/*      */     }
/*      */     
/* 1777 */     List retTokens = new ArrayList(2);
/*      */     
/* 1779 */     if (trueDotIndex != -1)
/*      */     {
/* 1781 */       if (isQuoted) {
/* 1782 */         tmpCat = toString(stripEnclosure(retval.substring(0, trueDotIndex + 1).getBytes(), quotId, quotId));
/*      */         
/* 1784 */         if (startsWithIgnoreCaseAndWs(tmpCat, quotId)) {
/* 1785 */           tmpCat = tmpCat.substring(1, tmpCat.length() - 1);
/*      */         }
/*      */         
/* 1788 */         retval = retval.substring(trueDotIndex + 2);
/* 1789 */         retval = toString(stripEnclosure(retval.getBytes(), quotId, quotId));
/*      */       }
/*      */       else
/*      */       {
/* 1793 */         tmpCat = retval.substring(0, trueDotIndex);
/* 1794 */         retval = retval.substring(trueDotIndex + 1);
/*      */       }
/*      */     }
/*      */     else {
/* 1798 */       retval = toString(stripEnclosure(retval.getBytes(), quotId, quotId));
/*      */     }
/*      */     
/*      */ 
/* 1802 */     retTokens.add(tmpCat);
/* 1803 */     retTokens.add(retval);
/* 1804 */     return retTokens;
/*      */   }
/*      */   
/*      */   public static final boolean isEmptyOrWhitespaceOnly(String str) {
/* 1808 */     if ((str == null) || (str.length() == 0)) {
/* 1809 */       return true;
/*      */     }
/*      */     
/* 1812 */     int length = str.length();
/*      */     
/* 1814 */     for (int i = 0; i < length; i++) {
/* 1815 */       if (!Character.isWhitespace(str.charAt(i))) {
/* 1816 */         return false;
/*      */       }
/*      */     }
/*      */     
/* 1820 */     return true;
/*      */   }
/*      */   
/*      */   public static String escapeQuote(String src, String quotChar) {
/* 1824 */     if (src == null) {
/* 1825 */       return null;
/*      */     }
/*      */     
/* 1828 */     src = toString(stripEnclosure(src.getBytes(), quotChar, quotChar));
/*      */     
/* 1830 */     int lastNdx = src.indexOf(quotChar);
/*      */     
/*      */ 
/*      */ 
/* 1834 */     String tmpSrc = src.substring(0, lastNdx);
/* 1835 */     tmpSrc = tmpSrc + quotChar + quotChar;
/*      */     
/* 1837 */     String tmpRest = src.substring(lastNdx + 1, src.length());
/*      */     
/* 1839 */     lastNdx = tmpRest.indexOf(quotChar);
/* 1840 */     while (lastNdx > -1)
/*      */     {
/* 1842 */       tmpSrc = tmpSrc + tmpRest.substring(0, lastNdx);
/* 1843 */       tmpSrc = tmpSrc + quotChar + quotChar;
/* 1844 */       tmpRest = tmpRest.substring(lastNdx + 1, tmpRest.length());
/*      */       
/* 1846 */       lastNdx = tmpRest.indexOf(quotChar);
/*      */     }
/*      */     
/* 1849 */     tmpSrc = tmpSrc + tmpRest;
/* 1850 */     src = tmpSrc;
/*      */     
/* 1852 */     return src;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String toString(byte[] value, int offset, int length, String encoding)
/*      */     throws UnsupportedEncodingException
/*      */   {
/* 1866 */     Charset cs = findCharset(encoding);
/*      */     
/* 1868 */     return cs.decode(ByteBuffer.wrap(value, offset, length)).toString();
/*      */   }
/*      */   
/*      */   public static String toString(byte[] value, String encoding) throws UnsupportedEncodingException
/*      */   {
/* 1873 */     Charset cs = findCharset(encoding);
/*      */     
/* 1875 */     return cs.decode(ByteBuffer.wrap(value)).toString();
/*      */   }
/*      */   
/*      */   public static String toString(byte[] value, int offset, int length) {
/*      */     try {
/* 1880 */       Charset cs = findCharset(platformEncoding);
/*      */       
/* 1882 */       return cs.decode(ByteBuffer.wrap(value, offset, length)).toString();
/*      */     }
/*      */     catch (UnsupportedEncodingException e) {}
/*      */     
/*      */ 
/* 1887 */     return null;
/*      */   }
/*      */   
/*      */   public static String toString(byte[] value) {
/*      */     try {
/* 1892 */       Charset cs = findCharset(platformEncoding);
/*      */       
/* 1894 */       return cs.decode(ByteBuffer.wrap(value)).toString();
/*      */     }
/*      */     catch (UnsupportedEncodingException e) {}
/*      */     
/*      */ 
/* 1899 */     return null;
/*      */   }
/*      */   
/*      */   public static byte[] getBytes(String value, String encoding) throws UnsupportedEncodingException
/*      */   {
/* 1904 */     Charset cs = findCharset(encoding);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1909 */     ByteBuffer buf = cs.encode(value);
/*      */     
/* 1911 */     int encodedLen = buf.limit();
/* 1912 */     byte[] asBytes = new byte[encodedLen];
/* 1913 */     buf.get(asBytes, 0, encodedLen);
/*      */     
/* 1915 */     return asBytes;
/*      */   }
/*      */   
/*      */   public static byte[] getBytes(String value) {
/*      */     try {
/* 1920 */       Charset cs = findCharset(platformEncoding);
/*      */       
/* 1922 */       ByteBuffer buf = cs.encode(value);
/*      */       
/* 1924 */       int encodedLen = buf.limit();
/* 1925 */       byte[] asBytes = new byte[encodedLen];
/* 1926 */       buf.get(asBytes, 0, encodedLen);
/*      */       
/* 1928 */       return asBytes;
/*      */     }
/*      */     catch (UnsupportedEncodingException e) {}
/*      */     
/*      */ 
/* 1933 */     return null;
/*      */   }
/*      */ }


/* Location:              C:\Users\Static\Desktop\G10_Prototype_Client.jar!\mysql-connector-java-5.1.19-bin.jar!\com\mysql\jdbc\StringUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */