/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DatabaseMetaData
/*      */   implements java.sql.DatabaseMetaData
/*      */ {
/*      */   private static String mysqlKeywordsThatArentSQL92;
/*      */   protected static final int MAX_IDENTIFIER_LENGTH = 64;
/*      */   private static final int DEFERRABILITY = 13;
/*      */   private static final int DELETE_RULE = 10;
/*      */   private static final int FK_NAME = 11;
/*      */   private static final int FKCOLUMN_NAME = 7;
/*      */   private static final int FKTABLE_CAT = 4;
/*      */   private static final int FKTABLE_NAME = 6;
/*      */   private static final int FKTABLE_SCHEM = 5;
/*      */   private static final int KEY_SEQ = 8;
/*      */   private static final int PK_NAME = 12;
/*      */   private static final int PKCOLUMN_NAME = 3;
/*      */   private static final int PKTABLE_CAT = 0;
/*      */   private static final int PKTABLE_NAME = 2;
/*      */   private static final int PKTABLE_SCHEM = 1;
/*      */   private static final String SUPPORTS_FK = "SUPPORTS_FK";
/*      */   
/*      */   protected abstract class IteratorWithCleanup
/*      */   {
/*      */     protected IteratorWithCleanup() {}
/*      */     
/*      */     abstract void close()
/*      */       throws SQLException;
/*      */     
/*      */     abstract boolean hasNext()
/*      */       throws SQLException;
/*      */     
/*      */     abstract Object next()
/*      */       throws SQLException;
/*      */   }
/*      */   
/*      */   class LocalAndReferencedColumns
/*      */   {
/*      */     String constraintName;
/*      */     List localColumnsList;
/*      */     String referencedCatalog;
/*      */     List referencedColumnsList;
/*      */     String referencedTable;
/*      */     
/*      */     LocalAndReferencedColumns(List localColumns, List refColumns, String constName, String refCatalog, String refTable)
/*      */     {
/*   87 */       this.localColumnsList = localColumns;
/*   88 */       this.referencedColumnsList = refColumns;
/*   89 */       this.constraintName = constName;
/*   90 */       this.referencedTable = refTable;
/*   91 */       this.referencedCatalog = refCatalog;
/*      */     }
/*      */   }
/*      */   
/*      */   protected class ResultSetIterator extends DatabaseMetaData.IteratorWithCleanup {
/*      */     int colIndex;
/*      */     ResultSet resultSet;
/*      */     
/*      */     ResultSetIterator(ResultSet rs, int index) {
/*  100 */       super();
/*  101 */       this.resultSet = rs;
/*  102 */       this.colIndex = index;
/*      */     }
/*      */     
/*      */     void close() throws SQLException {
/*  106 */       this.resultSet.close();
/*      */     }
/*      */     
/*      */     boolean hasNext() throws SQLException {
/*  110 */       return this.resultSet.next();
/*      */     }
/*      */     
/*      */     Object next() throws SQLException {
/*  114 */       return this.resultSet.getObject(this.colIndex);
/*      */     }
/*      */   }
/*      */   
/*      */   protected class SingleStringIterator extends DatabaseMetaData.IteratorWithCleanup {
/*  119 */     boolean onFirst = true;
/*      */     String value;
/*      */     
/*      */     SingleStringIterator(String s) {
/*  123 */       super();
/*  124 */       this.value = s;
/*      */     }
/*      */     
/*      */     void close()
/*      */       throws SQLException
/*      */     {}
/*      */     
/*      */     boolean hasNext() throws SQLException
/*      */     {
/*  133 */       return this.onFirst;
/*      */     }
/*      */     
/*      */     Object next() throws SQLException {
/*  137 */       this.onFirst = false;
/*  138 */       return this.value;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   class TypeDescriptor
/*      */   {
/*      */     int bufferLength;
/*      */     
/*      */ 
/*      */     int charOctetLength;
/*      */     
/*      */     Integer columnSize;
/*      */     
/*      */     short dataType;
/*      */     
/*      */     Integer decimalDigits;
/*      */     
/*      */     String isNullable;
/*      */     
/*      */     int nullability;
/*      */     
/*  161 */     int numPrecRadix = 10;
/*      */     String typeName;
/*      */     
/*      */     TypeDescriptor(String typeInfo, String nullabilityInfo)
/*      */       throws SQLException
/*      */     {
/*  167 */       if (typeInfo == null) {
/*  168 */         throw SQLError.createSQLException("NULL typeinfo not supported.", "S1009", DatabaseMetaData.this.getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*  172 */       String mysqlType = "";
/*  173 */       String fullMysqlType = null;
/*      */       
/*  175 */       if (typeInfo.indexOf("(") != -1) {
/*  176 */         mysqlType = typeInfo.substring(0, typeInfo.indexOf("("));
/*      */       } else {
/*  178 */         mysqlType = typeInfo;
/*      */       }
/*      */       
/*  181 */       int indexOfUnsignedInMysqlType = StringUtils.indexOfIgnoreCase(mysqlType, "unsigned");
/*      */       
/*      */ 
/*  184 */       if (indexOfUnsignedInMysqlType != -1) {
/*  185 */         mysqlType = mysqlType.substring(0, indexOfUnsignedInMysqlType - 1);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  192 */       boolean isUnsigned = false;
/*      */       
/*  194 */       if ((StringUtils.indexOfIgnoreCase(typeInfo, "unsigned") != -1) && (StringUtils.indexOfIgnoreCase(typeInfo, "set") != 0) && (StringUtils.indexOfIgnoreCase(typeInfo, "enum") != 0))
/*      */       {
/*      */ 
/*  197 */         fullMysqlType = mysqlType + " unsigned";
/*  198 */         isUnsigned = true;
/*      */       } else {
/*  200 */         fullMysqlType = mysqlType;
/*      */       }
/*      */       
/*  203 */       if (DatabaseMetaData.this.conn.getCapitalizeTypeNames()) {
/*  204 */         fullMysqlType = fullMysqlType.toUpperCase(Locale.ENGLISH);
/*      */       }
/*      */       
/*  207 */       this.dataType = ((short)MysqlDefs.mysqlToJavaType(mysqlType));
/*      */       
/*  209 */       this.typeName = fullMysqlType;
/*      */       
/*      */ 
/*      */ 
/*  213 */       if (StringUtils.startsWithIgnoreCase(typeInfo, "enum")) {
/*  214 */         String temp = typeInfo.substring(typeInfo.indexOf("("), typeInfo.lastIndexOf(")"));
/*      */         
/*  216 */         StringTokenizer tokenizer = new StringTokenizer(temp, ",");
/*      */         
/*  218 */         int maxLength = 0;
/*      */         
/*  220 */         while (tokenizer.hasMoreTokens()) {
/*  221 */           maxLength = Math.max(maxLength, tokenizer.nextToken().length() - 2);
/*      */         }
/*      */         
/*      */ 
/*  225 */         this.columnSize = Integer.valueOf(maxLength);
/*  226 */         this.decimalDigits = null;
/*  227 */       } else if (StringUtils.startsWithIgnoreCase(typeInfo, "set")) {
/*  228 */         String temp = typeInfo.substring(typeInfo.indexOf("(") + 1, typeInfo.lastIndexOf(")"));
/*      */         
/*  230 */         StringTokenizer tokenizer = new StringTokenizer(temp, ",");
/*      */         
/*  232 */         int maxLength = 0;
/*      */         
/*  234 */         int numElements = tokenizer.countTokens();
/*      */         
/*  236 */         if (numElements > 0) {
/*  237 */           maxLength += numElements - 1;
/*      */         }
/*      */         
/*  240 */         while (tokenizer.hasMoreTokens()) {
/*  241 */           String setMember = tokenizer.nextToken().trim();
/*      */           
/*  243 */           if ((setMember.startsWith("'")) && (setMember.endsWith("'")))
/*      */           {
/*  245 */             maxLength += setMember.length() - 2;
/*      */           } else {
/*  247 */             maxLength += setMember.length();
/*      */           }
/*      */         }
/*      */         
/*  251 */         this.columnSize = Integer.valueOf(maxLength);
/*  252 */         this.decimalDigits = null;
/*  253 */       } else if (typeInfo.indexOf(",") != -1)
/*      */       {
/*  255 */         this.columnSize = Integer.valueOf(typeInfo.substring(typeInfo.indexOf("(") + 1, typeInfo.indexOf(",")).trim());
/*      */         
/*  257 */         this.decimalDigits = Integer.valueOf(typeInfo.substring(typeInfo.indexOf(",") + 1, typeInfo.indexOf(")")).trim());
/*      */       }
/*      */       else
/*      */       {
/*  261 */         this.columnSize = null;
/*  262 */         this.decimalDigits = null;
/*      */         
/*      */ 
/*  265 */         if (((StringUtils.indexOfIgnoreCase(typeInfo, "char") != -1) || (StringUtils.indexOfIgnoreCase(typeInfo, "text") != -1) || (StringUtils.indexOfIgnoreCase(typeInfo, "blob") != -1) || (StringUtils.indexOfIgnoreCase(typeInfo, "binary") != -1) || (StringUtils.indexOfIgnoreCase(typeInfo, "bit") != -1)) && (typeInfo.indexOf("(") != -1))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  272 */           int endParenIndex = typeInfo.indexOf(")");
/*      */           
/*  274 */           if (endParenIndex == -1) {
/*  275 */             endParenIndex = typeInfo.length();
/*      */           }
/*      */           
/*  278 */           this.columnSize = Integer.valueOf(typeInfo.substring(typeInfo.indexOf("(") + 1, endParenIndex).trim());
/*      */           
/*      */ 
/*      */ 
/*  282 */           if ((DatabaseMetaData.this.conn.getTinyInt1isBit()) && (this.columnSize.intValue() == 1) && (StringUtils.startsWithIgnoreCase(typeInfo, 0, "tinyint")))
/*      */           {
/*      */ 
/*      */ 
/*  286 */             if (DatabaseMetaData.this.conn.getTransformedBitIsBoolean()) {
/*  287 */               this.dataType = 16;
/*  288 */               this.typeName = "BOOLEAN";
/*      */             } else {
/*  290 */               this.dataType = -7;
/*  291 */               this.typeName = "BIT";
/*      */             }
/*      */           }
/*  294 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "tinyint"))
/*      */         {
/*  296 */           if ((DatabaseMetaData.this.conn.getTinyInt1isBit()) && (typeInfo.indexOf("(1)") != -1)) {
/*  297 */             if (DatabaseMetaData.this.conn.getTransformedBitIsBoolean()) {
/*  298 */               this.dataType = 16;
/*  299 */               this.typeName = "BOOLEAN";
/*      */             } else {
/*  301 */               this.dataType = -7;
/*  302 */               this.typeName = "BIT";
/*      */             }
/*      */           } else {
/*  305 */             this.columnSize = Integer.valueOf(3);
/*  306 */             this.decimalDigits = Integer.valueOf(0);
/*      */           }
/*  308 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "smallint"))
/*      */         {
/*  310 */           this.columnSize = Integer.valueOf(5);
/*  311 */           this.decimalDigits = Integer.valueOf(0);
/*  312 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "mediumint"))
/*      */         {
/*  314 */           this.columnSize = Integer.valueOf(isUnsigned ? 8 : 7);
/*  315 */           this.decimalDigits = Integer.valueOf(0);
/*  316 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "int"))
/*      */         {
/*  318 */           this.columnSize = Integer.valueOf(10);
/*  319 */           this.decimalDigits = Integer.valueOf(0);
/*  320 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "integer"))
/*      */         {
/*  322 */           this.columnSize = Integer.valueOf(10);
/*  323 */           this.decimalDigits = Integer.valueOf(0);
/*  324 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "bigint"))
/*      */         {
/*  326 */           this.columnSize = Integer.valueOf(isUnsigned ? 20 : 19);
/*  327 */           this.decimalDigits = Integer.valueOf(0);
/*  328 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "int24"))
/*      */         {
/*  330 */           this.columnSize = Integer.valueOf(19);
/*  331 */           this.decimalDigits = Integer.valueOf(0);
/*  332 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "real"))
/*      */         {
/*  334 */           this.columnSize = Integer.valueOf(12);
/*  335 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "float"))
/*      */         {
/*  337 */           this.columnSize = Integer.valueOf(12);
/*  338 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "decimal"))
/*      */         {
/*  340 */           this.columnSize = Integer.valueOf(12);
/*  341 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "numeric"))
/*      */         {
/*  343 */           this.columnSize = Integer.valueOf(12);
/*  344 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "double"))
/*      */         {
/*  346 */           this.columnSize = Integer.valueOf(22);
/*  347 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "char"))
/*      */         {
/*  349 */           this.columnSize = Integer.valueOf(1);
/*  350 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "varchar"))
/*      */         {
/*  352 */           this.columnSize = Integer.valueOf(255);
/*  353 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "timestamp"))
/*      */         {
/*  355 */           this.columnSize = Integer.valueOf(19);
/*  356 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "datetime"))
/*      */         {
/*  358 */           this.columnSize = Integer.valueOf(19);
/*  359 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "date"))
/*      */         {
/*  361 */           this.columnSize = Integer.valueOf(10);
/*  362 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "time"))
/*      */         {
/*  364 */           this.columnSize = Integer.valueOf(8);
/*      */         }
/*  366 */         else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "tinyblob"))
/*      */         {
/*  368 */           this.columnSize = Integer.valueOf(255);
/*  369 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "blob"))
/*      */         {
/*  371 */           this.columnSize = Integer.valueOf(65535);
/*  372 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "mediumblob"))
/*      */         {
/*  374 */           this.columnSize = Integer.valueOf(16777215);
/*  375 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "longblob"))
/*      */         {
/*  377 */           this.columnSize = Integer.valueOf(Integer.MAX_VALUE);
/*  378 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "tinytext"))
/*      */         {
/*  380 */           this.columnSize = Integer.valueOf(255);
/*  381 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "text"))
/*      */         {
/*  383 */           this.columnSize = Integer.valueOf(65535);
/*  384 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "mediumtext"))
/*      */         {
/*  386 */           this.columnSize = Integer.valueOf(16777215);
/*  387 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "longtext"))
/*      */         {
/*  389 */           this.columnSize = Integer.valueOf(Integer.MAX_VALUE);
/*  390 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "enum"))
/*      */         {
/*  392 */           this.columnSize = Integer.valueOf(255);
/*  393 */         } else if (StringUtils.startsWithIgnoreCaseAndWs(typeInfo, "set"))
/*      */         {
/*  395 */           this.columnSize = Integer.valueOf(255);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  401 */       this.bufferLength = MysqlIO.getMaxBuf();
/*      */       
/*      */ 
/*  404 */       this.numPrecRadix = 10;
/*      */       
/*      */ 
/*  407 */       if (nullabilityInfo != null) {
/*  408 */         if (nullabilityInfo.equals("YES")) {
/*  409 */           this.nullability = 1;
/*  410 */           this.isNullable = "YES";
/*      */         }
/*      */         else
/*      */         {
/*  414 */           this.nullability = 0;
/*  415 */           this.isNullable = "NO";
/*      */         }
/*      */       } else {
/*  418 */         this.nullability = 0;
/*  419 */         this.isNullable = "NO";
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  461 */   private static final byte[] TABLE_AS_BYTES = "TABLE".getBytes();
/*      */   
/*  463 */   private static final byte[] SYSTEM_TABLE_AS_BYTES = "SYSTEM TABLE".getBytes();
/*      */   
/*      */   private static final int UPDATE_RULE = 9;
/*      */   
/*  467 */   private static final byte[] VIEW_AS_BYTES = "VIEW".getBytes();
/*      */   private static final Constructor JDBC_4_DBMD_SHOW_CTOR;
/*      */   private static final Constructor JDBC_4_DBMD_IS_CTOR;
/*      */   protected MySQLConnection conn;
/*      */   
/*      */   static
/*      */   {
/*  474 */     if (Util.isJdbc4()) {
/*      */       try {
/*  476 */         JDBC_4_DBMD_SHOW_CTOR = Class.forName("com.mysql.jdbc.JDBC4DatabaseMetaData").getConstructor(new Class[] { MySQLConnection.class, String.class });
/*      */         
/*      */ 
/*      */ 
/*  480 */         JDBC_4_DBMD_IS_CTOR = Class.forName("com.mysql.jdbc.JDBC4DatabaseMetaDataUsingInfoSchema").getConstructor(new Class[] { MySQLConnection.class, String.class });
/*      */ 
/*      */       }
/*      */       catch (SecurityException e)
/*      */       {
/*      */ 
/*  486 */         throw new RuntimeException(e);
/*      */       } catch (NoSuchMethodException e) {
/*  488 */         throw new RuntimeException(e);
/*      */       } catch (ClassNotFoundException e) {
/*  490 */         throw new RuntimeException(e);
/*      */       }
/*      */     } else {
/*  493 */       JDBC_4_DBMD_IS_CTOR = null;
/*  494 */       JDBC_4_DBMD_SHOW_CTOR = null;
/*      */     }
/*      */     
/*      */ 
/*  498 */     String[] allMySQLKeywords = { "ACCESSIBLE", "ADD", "ALL", "ALTER", "ANALYZE", "AND", "AS", "ASC", "ASENSITIVE", "BEFORE", "BETWEEN", "BIGINT", "BINARY", "BLOB", "BOTH", "BY", "CALL", "CASCADE", "CASE", "CHANGE", "CHAR", "CHARACTER", "CHECK", "COLLATE", "COLUMN", "CONDITION", "CONNECTION", "CONSTRAINT", "CONTINUE", "CONVERT", "CREATE", "CROSS", "CURRENT_DATE", "CURRENT_TIME", "CURRENT_TIMESTAMP", "CURRENT_USER", "CURSOR", "DATABASE", "DATABASES", "DAY_HOUR", "DAY_MICROSECOND", "DAY_MINUTE", "DAY_SECOND", "DEC", "DECIMAL", "DECLARE", "DEFAULT", "DELAYED", "DELETE", "DESC", "DESCRIBE", "DETERMINISTIC", "DISTINCT", "DISTINCTROW", "DIV", "DOUBLE", "DROP", "DUAL", "EACH", "ELSE", "ELSEIF", "ENCLOSED", "ESCAPED", "EXISTS", "EXIT", "EXPLAIN", "FALSE", "FETCH", "FLOAT", "FLOAT4", "FLOAT8", "FOR", "FORCE", "FOREIGN", "FROM", "FULLTEXT", "GRANT", "GROUP", "HAVING", "HIGH_PRIORITY", "HOUR_MICROSECOND", "HOUR_MINUTE", "HOUR_SECOND", "IF", "IGNORE", "IN", "INDEX", "INFILE", "INNER", "INOUT", "INSENSITIVE", "INSERT", "INT", "INT1", "INT2", "INT3", "INT4", "INT8", "INTEGER", "INTERVAL", "INTO", "IS", "ITERATE", "JOIN", "KEY", "KEYS", "KILL", "LEADING", "LEAVE", "LEFT", "LIKE", "LIMIT", "LINEAR", "LINES", "LOAD", "LOCALTIME", "LOCALTIMESTAMP", "LOCK", "LONG", "LONGBLOB", "LONGTEXT", "LOOP", "LOW_PRIORITY", "MATCH", "MEDIUMBLOB", "MEDIUMINT", "MEDIUMTEXT", "MIDDLEINT", "MINUTE_MICROSECOND", "MINUTE_SECOND", "MOD", "MODIFIES", "NATURAL", "NOT", "NO_WRITE_TO_BINLOG", "NULL", "NUMERIC", "ON", "OPTIMIZE", "OPTION", "OPTIONALLY", "OR", "ORDER", "OUT", "OUTER", "OUTFILE", "PRECISION", "PRIMARY", "PROCEDURE", "PURGE", "RANGE", "READ", "READS", "READ_ONLY", "READ_WRITE", "REAL", "REFERENCES", "REGEXP", "RELEASE", "RENAME", "REPEAT", "REPLACE", "REQUIRE", "RESTRICT", "RETURN", "REVOKE", "RIGHT", "RLIKE", "SCHEMA", "SCHEMAS", "SECOND_MICROSECOND", "SELECT", "SENSITIVE", "SEPARATOR", "SET", "SHOW", "SMALLINT", "SPATIAL", "SPECIFIC", "SQL", "SQLEXCEPTION", "SQLSTATE", "SQLWARNING", "SQL_BIG_RESULT", "SQL_CALC_FOUND_ROWS", "SQL_SMALL_RESULT", "SSL", "STARTING", "STRAIGHT_JOIN", "TABLE", "TERMINATED", "THEN", "TINYBLOB", "TINYINT", "TINYTEXT", "TO", "TRAILING", "TRIGGER", "TRUE", "UNDO", "UNION", "UNIQUE", "UNLOCK", "UNSIGNED", "UPDATE", "USAGE", "USE", "USING", "UTC_DATE", "UTC_TIME", "UTC_TIMESTAMP", "VALUES", "VARBINARY", "VARCHAR", "VARCHARACTER", "VARYING", "WHEN", "WHERE", "WHILE", "WITH", "WRITE", "X509", "XOR", "YEAR_MONTH", "ZEROFILL", "GENERAL", "IGNORE_SERVER_IDS", "MASTER_HEARTBEAT_PERIOD", "MAXVALUE", "RESIGNAL", "SIGNAL", "SLOW" };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  546 */     String[] sql92Keywords = { "ABSOLUTE", "EXEC", "OVERLAPS", "ACTION", "EXECUTE", "PAD", "ADA", "EXISTS", "PARTIAL", "ADD", "EXTERNAL", "PASCAL", "ALL", "EXTRACT", "POSITION", "ALLOCATE", "FALSE", "PRECISION", "ALTER", "FETCH", "PREPARE", "AND", "FIRST", "PRESERVE", "ANY", "FLOAT", "PRIMARY", "ARE", "FOR", "PRIOR", "AS", "FOREIGN", "PRIVILEGES", "ASC", "FORTRAN", "PROCEDURE", "ASSERTION", "FOUND", "PUBLIC", "AT", "FROM", "READ", "AUTHORIZATION", "FULL", "REAL", "AVG", "GET", "REFERENCES", "BEGIN", "GLOBAL", "RELATIVE", "BETWEEN", "GO", "RESTRICT", "BIT", "GOTO", "REVOKE", "BIT_LENGTH", "GRANT", "RIGHT", "BOTH", "GROUP", "ROLLBACK", "BY", "HAVING", "ROWS", "CASCADE", "HOUR", "SCHEMA", "CASCADED", "IDENTITY", "SCROLL", "CASE", "IMMEDIATE", "SECOND", "CAST", "IN", "SECTION", "CATALOG", "INCLUDE", "SELECT", "CHAR", "INDEX", "SESSION", "CHAR_LENGTH", "INDICATOR", "SESSION_USER", "CHARACTER", "INITIALLY", "SET", "CHARACTER_LENGTH", "INNER", "SIZE", "CHECK", "INPUT", "SMALLINT", "CLOSE", "INSENSITIVE", "SOME", "COALESCE", "INSERT", "SPACE", "COLLATE", "INT", "SQL", "COLLATION", "INTEGER", "SQLCA", "COLUMN", "INTERSECT", "SQLCODE", "COMMIT", "INTERVAL", "SQLERROR", "CONNECT", "INTO", "SQLSTATE", "CONNECTION", "IS", "SQLWARNING", "CONSTRAINT", "ISOLATION", "SUBSTRING", "CONSTRAINTS", "JOIN", "SUM", "CONTINUE", "KEY", "SYSTEM_USER", "CONVERT", "LANGUAGE", "TABLE", "CORRESPONDING", "LAST", "TEMPORARY", "COUNT", "LEADING", "THEN", "CREATE", "LEFT", "TIME", "CROSS", "LEVEL", "TIMESTAMP", "CURRENT", "LIKE", "TIMEZONE_HOUR", "CURRENT_DATE", "LOCAL", "TIMEZONE_MINUTE", "CURRENT_TIME", "LOWER", "TO", "CURRENT_TIMESTAMP", "MATCH", "TRAILING", "CURRENT_USER", "MAX", "TRANSACTION", "CURSOR", "MIN", "TRANSLATE", "DATE", "MINUTE", "TRANSLATION", "DAY", "MODULE", "TRIM", "DEALLOCATE", "MONTH", "TRUE", "DEC", "NAMES", "UNION", "DECIMAL", "NATIONAL", "UNIQUE", "DECLARE", "NATURAL", "UNKNOWN", "DEFAULT", "NCHAR", "UPDATE", "DEFERRABLE", "NEXT", "UPPER", "DEFERRED", "NO", "USAGE", "DELETE", "NONE", "USER", "DESC", "NOT", "USING", "DESCRIBE", "NULL", "VALUE", "DESCRIPTOR", "NULLIF", "VALUES", "DIAGNOSTICS", "NUMERIC", "VARCHAR", "DISCONNECT", "OCTET_LENGTH", "VARYING", "DISTINCT", "OF", "VIEW", "DOMAIN", "ON", "WHEN", "DOUBLE", "ONLY", "WHENEVER", "DROP", "OPEN", "WHERE", "ELSE", "OPTION", "WITH", "END", "OR", "WORK", "END-EXEC", "ORDER", "WRITE", "ESCAPE", "OUTER", "YEAR", "EXCEPT", "OUTPUT", "ZONE", "EXCEPTION" };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  588 */     TreeMap mySQLKeywordMap = new TreeMap();
/*      */     
/*  590 */     for (int i = 0; i < allMySQLKeywords.length; i++) {
/*  591 */       mySQLKeywordMap.put(allMySQLKeywords[i], null);
/*      */     }
/*      */     
/*  594 */     HashMap sql92KeywordMap = new HashMap(sql92Keywords.length);
/*      */     
/*  596 */     for (int i = 0; i < sql92Keywords.length; i++) {
/*  597 */       sql92KeywordMap.put(sql92Keywords[i], null);
/*      */     }
/*      */     
/*  600 */     Iterator it = sql92KeywordMap.keySet().iterator();
/*      */     
/*  602 */     while (it.hasNext()) {
/*  603 */       mySQLKeywordMap.remove(it.next());
/*      */     }
/*      */     
/*  606 */     StringBuffer keywordBuf = new StringBuffer();
/*      */     
/*  608 */     it = mySQLKeywordMap.keySet().iterator();
/*      */     
/*  610 */     if (it.hasNext()) {
/*  611 */       keywordBuf.append(it.next().toString());
/*      */     }
/*      */     
/*  614 */     while (it.hasNext()) {
/*  615 */       keywordBuf.append(",");
/*  616 */       keywordBuf.append(it.next().toString());
/*      */     }
/*      */     
/*  619 */     mysqlKeywordsThatArentSQL92 = keywordBuf.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  626 */   protected String database = null;
/*      */   
/*      */ 
/*  629 */   protected String quotedId = null;
/*      */   
/*      */   private ExceptionInterceptor exceptionInterceptor;
/*      */   
/*      */ 
/*      */   protected static DatabaseMetaData getInstance(MySQLConnection connToSet, String databaseToSet, boolean checkForInfoSchema)
/*      */     throws SQLException
/*      */   {
/*  637 */     if (!Util.isJdbc4()) {
/*  638 */       if ((checkForInfoSchema) && (connToSet != null) && (connToSet.getUseInformationSchema()) && (connToSet.versionMeetsMinimum(5, 0, 7)))
/*      */       {
/*      */ 
/*  641 */         return new DatabaseMetaDataUsingInfoSchema(connToSet, databaseToSet);
/*      */       }
/*      */       
/*      */ 
/*  645 */       return new DatabaseMetaData(connToSet, databaseToSet);
/*      */     }
/*      */     
/*  648 */     if ((checkForInfoSchema) && (connToSet != null) && (connToSet.getUseInformationSchema()) && (connToSet.versionMeetsMinimum(5, 0, 7)))
/*      */     {
/*      */ 
/*      */ 
/*  652 */       return (DatabaseMetaData)Util.handleNewInstance(JDBC_4_DBMD_IS_CTOR, new Object[] { connToSet, databaseToSet }, connToSet.getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  657 */     return (DatabaseMetaData)Util.handleNewInstance(JDBC_4_DBMD_SHOW_CTOR, new Object[] { connToSet, databaseToSet }, connToSet.getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected DatabaseMetaData(MySQLConnection connToSet, String databaseToSet)
/*      */   {
/*  670 */     this.conn = connToSet;
/*  671 */     this.database = databaseToSet;
/*  672 */     this.exceptionInterceptor = this.conn.getExceptionInterceptor();
/*      */     try
/*      */     {
/*  675 */       this.quotedId = (this.conn.supportsQuotedIdentifiers() ? getIdentifierQuoteString() : "");
/*      */ 
/*      */     }
/*      */     catch (SQLException sqlEx)
/*      */     {
/*      */ 
/*  681 */       AssertionFailedException.shouldNotHappen(sqlEx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean allProceduresAreCallable()
/*      */     throws SQLException
/*      */   {
/*  694 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean allTablesAreSelectable()
/*      */     throws SQLException
/*      */   {
/*  705 */     return false;
/*      */   }
/*      */   
/*      */   private ResultSet buildResultSet(Field[] fields, ArrayList rows) throws SQLException
/*      */   {
/*  710 */     return buildResultSet(fields, rows, this.conn);
/*      */   }
/*      */   
/*      */   static ResultSet buildResultSet(Field[] fields, ArrayList rows, MySQLConnection c) throws SQLException
/*      */   {
/*  715 */     int fieldsLength = fields.length;
/*      */     
/*  717 */     for (int i = 0; i < fieldsLength; i++) {
/*  718 */       int jdbcType = fields[i].getSQLType();
/*      */       
/*  720 */       switch (jdbcType) {
/*      */       case -1: 
/*      */       case 1: 
/*      */       case 12: 
/*  724 */         fields[i].setCharacterSet(c.getCharacterSetMetadata());
/*  725 */         break;
/*      */       }
/*      */       
/*      */       
/*      */ 
/*  730 */       fields[i].setConnection(c);
/*  731 */       fields[i].setUseOldNameMetadata(true);
/*      */     }
/*      */     
/*  734 */     return ResultSetImpl.getInstance(c.getCatalog(), fields, new RowDataStatic(rows), c, null, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void convertToJdbcFunctionList(String catalog, ResultSet proceduresRs, boolean needsClientFiltering, String db, Map procedureRowsOrderedByName, int nameIndex, Field[] fields)
/*      */     throws SQLException
/*      */   {
/*  742 */     while (proceduresRs.next()) {
/*  743 */       boolean shouldAdd = true;
/*      */       
/*  745 */       if (needsClientFiltering) {
/*  746 */         shouldAdd = false;
/*      */         
/*  748 */         String procDb = proceduresRs.getString(1);
/*      */         
/*  750 */         if ((db == null) && (procDb == null)) {
/*  751 */           shouldAdd = true;
/*  752 */         } else if ((db != null) && (db.equals(procDb))) {
/*  753 */           shouldAdd = true;
/*      */         }
/*      */       }
/*      */       
/*  757 */       if (shouldAdd) {
/*  758 */         String functionName = proceduresRs.getString(nameIndex);
/*      */         
/*  760 */         byte[][] rowData = (byte[][])null;
/*      */         
/*  762 */         if ((fields != null) && (fields.length == 9))
/*      */         {
/*  764 */           rowData = new byte[9][];
/*  765 */           rowData[0] = (catalog == null ? null : s2b(catalog));
/*  766 */           rowData[1] = null;
/*  767 */           rowData[2] = s2b(functionName);
/*  768 */           rowData[3] = null;
/*  769 */           rowData[4] = null;
/*  770 */           rowData[5] = null;
/*  771 */           rowData[6] = s2b(proceduresRs.getString("comment"));
/*  772 */           rowData[7] = s2b(Integer.toString(2));
/*  773 */           rowData[8] = s2b(functionName);
/*      */         }
/*      */         else {
/*  776 */           rowData = new byte[6][];
/*      */           
/*  778 */           rowData[0] = (catalog == null ? null : s2b(catalog));
/*  779 */           rowData[1] = null;
/*  780 */           rowData[2] = s2b(functionName);
/*  781 */           rowData[3] = s2b(proceduresRs.getString("comment"));
/*  782 */           rowData[4] = s2b(Integer.toString(getJDBC4FunctionNoTableConstant()));
/*  783 */           rowData[5] = s2b(functionName);
/*      */         }
/*      */         
/*  786 */         procedureRowsOrderedByName.put(functionName, new ByteArrayRow(rowData, getExceptionInterceptor()));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected int getJDBC4FunctionNoTableConstant() {
/*  792 */     return 0;
/*      */   }
/*      */   
/*      */   private void convertToJdbcProcedureList(boolean fromSelect, String catalog, ResultSet proceduresRs, boolean needsClientFiltering, String db, Map procedureRowsOrderedByName, int nameIndex)
/*      */     throws SQLException
/*      */   {
/*  798 */     while (proceduresRs.next()) {
/*  799 */       boolean shouldAdd = true;
/*      */       
/*  801 */       if (needsClientFiltering) {
/*  802 */         shouldAdd = false;
/*      */         
/*  804 */         String procDb = proceduresRs.getString(1);
/*      */         
/*  806 */         if ((db == null) && (procDb == null)) {
/*  807 */           shouldAdd = true;
/*  808 */         } else if ((db != null) && (db.equals(procDb))) {
/*  809 */           shouldAdd = true;
/*      */         }
/*      */       }
/*      */       
/*  813 */       if (shouldAdd) {
/*  814 */         String procedureName = proceduresRs.getString(nameIndex);
/*  815 */         byte[][] rowData = new byte[9][];
/*  816 */         rowData[0] = (catalog == null ? null : s2b(catalog));
/*  817 */         rowData[1] = null;
/*  818 */         rowData[2] = s2b(procedureName);
/*  819 */         rowData[3] = null;
/*  820 */         rowData[4] = null;
/*  821 */         rowData[5] = null;
/*  822 */         rowData[6] = null;
/*      */         
/*  824 */         boolean isFunction = fromSelect ? "FUNCTION".equalsIgnoreCase(proceduresRs.getString("type")) : false;
/*      */         
/*      */ 
/*  827 */         rowData[7] = s2b(isFunction ? Integer.toString(2) : Integer.toString(0));
/*      */         
/*      */ 
/*      */ 
/*  831 */         rowData[8] = s2b(procedureName);
/*      */         
/*  833 */         procedureRowsOrderedByName.put(procedureName, new ByteArrayRow(rowData, getExceptionInterceptor()));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ResultSetRow convertTypeDescriptorToProcedureRow(byte[] procNameAsBytes, byte[] procCatAsBytes, String paramName, boolean isOutParam, boolean isInParam, boolean isReturnParam, TypeDescriptor typeDesc, boolean forGetFunctionColumns, int ordinal)
/*      */     throws SQLException
/*      */   {
/*  844 */     byte[][] row = forGetFunctionColumns ? new byte[17][] : new byte[14][];
/*  845 */     row[0] = procCatAsBytes;
/*  846 */     row[1] = null;
/*  847 */     row[2] = procNameAsBytes;
/*  848 */     row[3] = s2b(paramName);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  855 */     if ((isInParam) && (isOutParam)) {
/*  856 */       row[4] = s2b(String.valueOf(2));
/*  857 */     } else if (isInParam) {
/*  858 */       row[4] = s2b(String.valueOf(1));
/*  859 */     } else if (isOutParam) {
/*  860 */       row[4] = s2b(String.valueOf(4));
/*  861 */     } else if (isReturnParam) {
/*  862 */       row[4] = s2b(String.valueOf(5));
/*      */     } else {
/*  864 */       row[4] = s2b(String.valueOf(0));
/*      */     }
/*  866 */     row[5] = s2b(Short.toString(typeDesc.dataType));
/*  867 */     row[6] = s2b(typeDesc.typeName);
/*  868 */     row[7] = (typeDesc.columnSize == null ? null : s2b(typeDesc.columnSize.toString()));
/*  869 */     row[8] = row[7];
/*  870 */     row[9] = (typeDesc.decimalDigits == null ? null : s2b(typeDesc.decimalDigits.toString()));
/*  871 */     row[10] = s2b(Integer.toString(typeDesc.numPrecRadix));
/*      */     
/*  873 */     switch (typeDesc.nullability) {
/*      */     case 0: 
/*  875 */       row[11] = s2b(String.valueOf(0));
/*      */       
/*  877 */       break;
/*      */     
/*      */     case 1: 
/*  880 */       row[11] = s2b(String.valueOf(1));
/*      */       
/*  882 */       break;
/*      */     
/*      */     case 2: 
/*  885 */       row[11] = s2b(String.valueOf(2));
/*      */       
/*  887 */       break;
/*      */     
/*      */     default: 
/*  890 */       throw SQLError.createSQLException("Internal error while parsing callable statement metadata (unknown nullability value fount)", "S1000", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */     
/*      */ 
/*  895 */     row[12] = null;
/*      */     
/*  897 */     if (forGetFunctionColumns)
/*      */     {
/*  899 */       row[13] = null;
/*      */       
/*      */ 
/*  902 */       row[14] = s2b(String.valueOf(ordinal));
/*      */       
/*      */ 
/*  905 */       row[15] = Constants.EMPTY_BYTE_ARRAY;
/*      */       
/*  907 */       row[16] = s2b(paramName);
/*      */     }
/*      */     
/*  910 */     return new ByteArrayRow(row, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */   protected ExceptionInterceptor getExceptionInterceptor()
/*      */   {
/*  916 */     return this.exceptionInterceptor;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean dataDefinitionCausesTransactionCommit()
/*      */     throws SQLException
/*      */   {
/*  928 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean dataDefinitionIgnoredInTransactions()
/*      */     throws SQLException
/*      */   {
/*  939 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean deletesAreDetected(int type)
/*      */     throws SQLException
/*      */   {
/*  954 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean doesMaxRowSizeIncludeBlobs()
/*      */     throws SQLException
/*      */   {
/*  967 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List extractForeignKeyForTable(ArrayList rows, ResultSet rs, String catalog)
/*      */     throws SQLException
/*      */   {
/*  985 */     byte[][] row = new byte[3][];
/*  986 */     row[0] = rs.getBytes(1);
/*  987 */     row[1] = s2b("SUPPORTS_FK");
/*      */     
/*  989 */     String createTableString = rs.getString(2);
/*  990 */     StringTokenizer lineTokenizer = new StringTokenizer(createTableString, "\n");
/*      */     
/*  992 */     StringBuffer commentBuf = new StringBuffer("comment; ");
/*  993 */     boolean firstTime = true;
/*      */     
/*  995 */     String quoteChar = getIdentifierQuoteString();
/*      */     
/*  997 */     if (quoteChar == null) {
/*  998 */       quoteChar = "`";
/*      */     }
/*      */     
/* 1001 */     while (lineTokenizer.hasMoreTokens()) {
/* 1002 */       String line = lineTokenizer.nextToken().trim();
/*      */       
/* 1004 */       String constraintName = null;
/*      */       
/* 1006 */       if (StringUtils.startsWithIgnoreCase(line, "CONSTRAINT")) {
/* 1007 */         boolean usingBackTicks = true;
/* 1008 */         int beginPos = line.indexOf(quoteChar);
/*      */         
/* 1010 */         if (beginPos == -1) {
/* 1011 */           beginPos = line.indexOf("\"");
/* 1012 */           usingBackTicks = false;
/*      */         }
/*      */         
/* 1015 */         if (beginPos != -1) {
/* 1016 */           int endPos = -1;
/*      */           
/* 1018 */           if (usingBackTicks) {
/* 1019 */             endPos = line.indexOf(quoteChar, beginPos + 1);
/*      */           } else {
/* 1021 */             endPos = line.indexOf("\"", beginPos + 1);
/*      */           }
/*      */           
/* 1024 */           if (endPos != -1) {
/* 1025 */             constraintName = line.substring(beginPos + 1, endPos);
/* 1026 */             line = line.substring(endPos + 1, line.length()).trim();
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1032 */       if (line.startsWith("FOREIGN KEY")) {
/* 1033 */         if (line.endsWith(",")) {
/* 1034 */           line = line.substring(0, line.length() - 1);
/*      */         }
/*      */         
/* 1037 */         char quote = this.quotedId.charAt(0);
/*      */         
/* 1039 */         int indexOfFK = line.indexOf("FOREIGN KEY");
/*      */         
/* 1041 */         String localColumnName = null;
/* 1042 */         String referencedCatalogName = this.quotedId + catalog + this.quotedId;
/* 1043 */         String referencedTableName = null;
/* 1044 */         String referencedColumnName = null;
/*      */         
/*      */ 
/* 1047 */         if (indexOfFK != -1) {
/* 1048 */           int afterFk = indexOfFK + "FOREIGN KEY".length();
/*      */           
/* 1050 */           int indexOfRef = StringUtils.indexOfIgnoreCaseRespectQuotes(afterFk, line, "REFERENCES", quote, true);
/*      */           
/* 1052 */           if (indexOfRef != -1)
/*      */           {
/* 1054 */             int indexOfParenOpen = line.indexOf('(', afterFk);
/* 1055 */             int indexOfParenClose = StringUtils.indexOfIgnoreCaseRespectQuotes(indexOfParenOpen, line, ")", quote, true);
/*      */             
/* 1057 */             if ((indexOfParenOpen != -1) && (indexOfParenClose == -1)) {}
/*      */             
/*      */ 
/*      */ 
/* 1061 */             localColumnName = line.substring(indexOfParenOpen + 1, indexOfParenClose);
/*      */             
/* 1063 */             int afterRef = indexOfRef + "REFERENCES".length();
/*      */             
/* 1065 */             int referencedColumnBegin = StringUtils.indexOfIgnoreCaseRespectQuotes(afterRef, line, "(", quote, true);
/*      */             
/* 1067 */             if (referencedColumnBegin != -1) {
/* 1068 */               referencedTableName = line.substring(afterRef, referencedColumnBegin);
/*      */               
/* 1070 */               int referencedColumnEnd = StringUtils.indexOfIgnoreCaseRespectQuotes(referencedColumnBegin + 1, line, ")", quote, true);
/*      */               
/* 1072 */               if (referencedColumnEnd != -1) {
/* 1073 */                 referencedColumnName = line.substring(referencedColumnBegin + 1, referencedColumnEnd);
/*      */               }
/*      */               
/* 1076 */               int indexOfCatalogSep = StringUtils.indexOfIgnoreCaseRespectQuotes(0, referencedTableName, ".", quote, true);
/*      */               
/* 1078 */               if (indexOfCatalogSep != -1) {
/* 1079 */                 referencedCatalogName = referencedTableName.substring(0, indexOfCatalogSep);
/* 1080 */                 referencedTableName = referencedTableName.substring(indexOfCatalogSep + 1);
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/* 1087 */         if (!firstTime) {
/* 1088 */           commentBuf.append("; ");
/*      */         } else {
/* 1090 */           firstTime = false;
/*      */         }
/*      */         
/* 1093 */         if (constraintName != null) {
/* 1094 */           commentBuf.append(constraintName);
/*      */         } else {
/* 1096 */           commentBuf.append("not_available");
/*      */         }
/*      */         
/* 1099 */         commentBuf.append("(");
/* 1100 */         commentBuf.append(localColumnName);
/* 1101 */         commentBuf.append(") REFER ");
/* 1102 */         commentBuf.append(referencedCatalogName);
/* 1103 */         commentBuf.append("/");
/* 1104 */         commentBuf.append(referencedTableName);
/* 1105 */         commentBuf.append("(");
/* 1106 */         commentBuf.append(referencedColumnName);
/* 1107 */         commentBuf.append(")");
/*      */         
/* 1109 */         int lastParenIndex = line.lastIndexOf(")");
/*      */         
/* 1111 */         if (lastParenIndex != line.length() - 1) {
/* 1112 */           String cascadeOptions = line.substring(lastParenIndex + 1);
/*      */           
/* 1114 */           commentBuf.append(" ");
/* 1115 */           commentBuf.append(cascadeOptions);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1120 */     row[2] = s2b(commentBuf.toString());
/* 1121 */     rows.add(new ByteArrayRow(row, getExceptionInterceptor()));
/*      */     
/* 1123 */     return rows;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet extractForeignKeyFromCreateTable(String catalog, String tableName)
/*      */     throws SQLException
/*      */   {
/* 1144 */     ArrayList tableList = new ArrayList();
/* 1145 */     ResultSet rs = null;
/* 1146 */     java.sql.Statement stmt = null;
/*      */     
/* 1148 */     if (tableName != null) {
/* 1149 */       tableList.add(tableName);
/*      */     } else {
/*      */       try {
/* 1152 */         rs = getTables(catalog, "", "%", new String[] { "TABLE" });
/*      */         
/* 1154 */         while (rs.next()) {
/* 1155 */           tableList.add(rs.getString("TABLE_NAME"));
/*      */         }
/*      */       } finally {
/* 1158 */         if (rs != null) {
/* 1159 */           rs.close();
/*      */         }
/*      */         
/* 1162 */         rs = null;
/*      */       }
/*      */     }
/*      */     
/* 1166 */     ArrayList rows = new ArrayList();
/* 1167 */     Field[] fields = new Field[3];
/* 1168 */     fields[0] = new Field("", "Name", 1, Integer.MAX_VALUE);
/* 1169 */     fields[1] = new Field("", "Type", 1, 255);
/* 1170 */     fields[2] = new Field("", "Comment", 1, Integer.MAX_VALUE);
/*      */     
/* 1172 */     int numTables = tableList.size();
/* 1173 */     stmt = this.conn.getMetadataSafeStatement();
/*      */     
/* 1175 */     String quoteChar = getIdentifierQuoteString();
/*      */     
/* 1177 */     if (quoteChar == null) {
/* 1178 */       quoteChar = "`";
/*      */     }
/*      */     try
/*      */     {
/* 1182 */       for (int i = 0; i < numTables; i++) {
/* 1183 */         String tableToExtract = (String)tableList.get(i);
/* 1184 */         if (tableToExtract.indexOf(quoteChar) > 0) {
/* 1185 */           tableToExtract = StringUtils.escapeQuote(tableToExtract, quoteChar);
/*      */         }
/*      */         
/* 1188 */         String query = "SHOW CREATE TABLE " + quoteChar + catalog + quoteChar + "." + quoteChar + tableToExtract + quoteChar;
/*      */         
/*      */ 
/*      */ 
/*      */         try
/*      */         {
/* 1194 */           rs = stmt.executeQuery(query);
/*      */         }
/*      */         catch (SQLException sqlEx) {
/* 1197 */           String sqlState = sqlEx.getSQLState();
/*      */           
/* 1199 */           if ((!"42S02".equals(sqlState)) && (sqlEx.getErrorCode() != 1146))
/*      */           {
/* 1201 */             throw sqlEx;
/*      */           }
/*      */           
/* 1204 */           continue;
/*      */         }
/*      */         
/* 1207 */         while (rs.next()) {
/* 1208 */           extractForeignKeyForTable(rows, rs, catalog);
/*      */         }
/*      */       }
/*      */     } finally {
/* 1212 */       if (rs != null) {
/* 1213 */         rs.close();
/*      */       }
/*      */       
/* 1216 */       rs = null;
/*      */       
/* 1218 */       if (stmt != null) {
/* 1219 */         stmt.close();
/*      */       }
/*      */       
/* 1222 */       stmt = null;
/*      */     }
/*      */     
/* 1225 */     return buildResultSet(fields, rows);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ResultSet getAttributes(String arg0, String arg1, String arg2, String arg3)
/*      */     throws SQLException
/*      */   {
/* 1233 */     Field[] fields = new Field[21];
/* 1234 */     fields[0] = new Field("", "TYPE_CAT", 1, 32);
/* 1235 */     fields[1] = new Field("", "TYPE_SCHEM", 1, 32);
/* 1236 */     fields[2] = new Field("", "TYPE_NAME", 1, 32);
/* 1237 */     fields[3] = new Field("", "ATTR_NAME", 1, 32);
/* 1238 */     fields[4] = new Field("", "DATA_TYPE", 5, 32);
/* 1239 */     fields[5] = new Field("", "ATTR_TYPE_NAME", 1, 32);
/* 1240 */     fields[6] = new Field("", "ATTR_SIZE", 4, 32);
/* 1241 */     fields[7] = new Field("", "DECIMAL_DIGITS", 4, 32);
/* 1242 */     fields[8] = new Field("", "NUM_PREC_RADIX", 4, 32);
/* 1243 */     fields[9] = new Field("", "NULLABLE ", 4, 32);
/* 1244 */     fields[10] = new Field("", "REMARKS", 1, 32);
/* 1245 */     fields[11] = new Field("", "ATTR_DEF", 1, 32);
/* 1246 */     fields[12] = new Field("", "SQL_DATA_TYPE", 4, 32);
/* 1247 */     fields[13] = new Field("", "SQL_DATETIME_SUB", 4, 32);
/* 1248 */     fields[14] = new Field("", "CHAR_OCTET_LENGTH", 4, 32);
/* 1249 */     fields[15] = new Field("", "ORDINAL_POSITION", 4, 32);
/* 1250 */     fields[16] = new Field("", "IS_NULLABLE", 1, 32);
/* 1251 */     fields[17] = new Field("", "SCOPE_CATALOG", 1, 32);
/* 1252 */     fields[18] = new Field("", "SCOPE_SCHEMA", 1, 32);
/* 1253 */     fields[19] = new Field("", "SCOPE_TABLE", 1, 32);
/* 1254 */     fields[20] = new Field("", "SOURCE_DATA_TYPE", 5, 32);
/*      */     
/* 1256 */     return buildResultSet(fields, new ArrayList());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getBestRowIdentifier(String catalog, String schema, final String table, int scope, boolean nullable)
/*      */     throws SQLException
/*      */   {
/* 1307 */     if (table == null) {
/* 1308 */       throw SQLError.createSQLException("Table not specified.", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 1312 */     Field[] fields = new Field[8];
/* 1313 */     fields[0] = new Field("", "SCOPE", 5, 5);
/* 1314 */     fields[1] = new Field("", "COLUMN_NAME", 1, 32);
/* 1315 */     fields[2] = new Field("", "DATA_TYPE", 4, 32);
/* 1316 */     fields[3] = new Field("", "TYPE_NAME", 1, 32);
/* 1317 */     fields[4] = new Field("", "COLUMN_SIZE", 4, 10);
/* 1318 */     fields[5] = new Field("", "BUFFER_LENGTH", 4, 10);
/* 1319 */     fields[6] = new Field("", "DECIMAL_DIGITS", 5, 10);
/* 1320 */     fields[7] = new Field("", "PSEUDO_COLUMN", 5, 5);
/*      */     
/* 1322 */     final ArrayList rows = new ArrayList();
/* 1323 */     final java.sql.Statement stmt = this.conn.getMetadataSafeStatement();
/*      */     
/*      */     try
/*      */     {
/* 1327 */       new IterateBlock(getCatalogIterator(catalog)) {
/*      */         void forEach(Object catalogStr) throws SQLException {
/* 1329 */           ResultSet results = null;
/*      */           try
/*      */           {
/* 1332 */             StringBuffer queryBuf = new StringBuffer("SHOW COLUMNS FROM ");
/*      */             
/* 1334 */             queryBuf.append(DatabaseMetaData.this.quotedId);
/* 1335 */             queryBuf.append(table);
/* 1336 */             queryBuf.append(DatabaseMetaData.this.quotedId);
/* 1337 */             queryBuf.append(" FROM ");
/* 1338 */             queryBuf.append(DatabaseMetaData.this.quotedId);
/* 1339 */             queryBuf.append(catalogStr.toString());
/* 1340 */             queryBuf.append(DatabaseMetaData.this.quotedId);
/*      */             
/* 1342 */             results = stmt.executeQuery(queryBuf.toString());
/*      */             
/* 1344 */             while (results.next()) {
/* 1345 */               String keyType = results.getString("Key");
/*      */               
/* 1347 */               if ((keyType != null) && 
/* 1348 */                 (StringUtils.startsWithIgnoreCase(keyType, "PRI")))
/*      */               {
/* 1350 */                 byte[][] rowVal = new byte[8][];
/* 1351 */                 rowVal[0] = Integer.toString(2).getBytes();
/*      */                 
/*      */ 
/*      */ 
/* 1355 */                 rowVal[1] = results.getBytes("Field");
/*      */                 
/* 1357 */                 String type = results.getString("Type");
/* 1358 */                 int size = MysqlIO.getMaxBuf();
/* 1359 */                 int decimals = 0;
/*      */                 
/*      */ 
/*      */ 
/*      */ 
/* 1364 */                 if (type.indexOf("enum") != -1) {
/* 1365 */                   String temp = type.substring(type.indexOf("("), type.indexOf(")"));
/*      */                   
/*      */ 
/* 1368 */                   StringTokenizer tokenizer = new StringTokenizer(temp, ",");
/*      */                   
/* 1370 */                   int maxLength = 0;
/*      */                   
/* 1372 */                   while (tokenizer.hasMoreTokens()) {
/* 1373 */                     maxLength = Math.max(maxLength, tokenizer.nextToken().length() - 2);
/*      */                   }
/*      */                   
/*      */ 
/*      */ 
/* 1378 */                   size = maxLength;
/* 1379 */                   decimals = 0;
/* 1380 */                   type = "enum";
/* 1381 */                 } else if (type.indexOf("(") != -1) {
/* 1382 */                   if (type.indexOf(",") != -1) {
/* 1383 */                     size = Integer.parseInt(type.substring(type.indexOf("(") + 1, type.indexOf(",")));
/*      */                     
/*      */ 
/*      */ 
/* 1387 */                     decimals = Integer.parseInt(type.substring(type.indexOf(",") + 1, type.indexOf(")")));
/*      */ 
/*      */                   }
/*      */                   else
/*      */                   {
/* 1392 */                     size = Integer.parseInt(type.substring(type.indexOf("(") + 1, type.indexOf(")")));
/*      */                   }
/*      */                   
/*      */ 
/*      */ 
/*      */ 
/* 1398 */                   type = type.substring(0, type.indexOf("("));
/*      */                 }
/*      */                 
/*      */ 
/* 1402 */                 rowVal[2] = DatabaseMetaData.this.s2b(String.valueOf(MysqlDefs.mysqlToJavaType(type)));
/*      */                 
/* 1404 */                 rowVal[3] = DatabaseMetaData.this.s2b(type);
/* 1405 */                 rowVal[4] = Integer.toString(size + decimals).getBytes();
/*      */                 
/* 1407 */                 rowVal[5] = Integer.toString(size + decimals).getBytes();
/*      */                 
/* 1409 */                 rowVal[6] = Integer.toString(decimals).getBytes();
/*      */                 
/* 1411 */                 rowVal[7] = Integer.toString(1).getBytes();
/*      */                 
/*      */ 
/*      */ 
/*      */ 
/* 1416 */                 rows.add(new ByteArrayRow(rowVal, DatabaseMetaData.this.getExceptionInterceptor()));
/*      */               }
/*      */             }
/*      */           }
/*      */           catch (SQLException sqlEx) {
/* 1421 */             if (!"42S02".equals(sqlEx.getSQLState())) {
/* 1422 */               throw sqlEx;
/*      */             }
/*      */           } finally {
/* 1425 */             if (results != null) {
/*      */               try {
/* 1427 */                 results.close();
/*      */               }
/*      */               catch (Exception ex) {}
/*      */               
/*      */ 
/* 1432 */               results = null;
/*      */             }
/*      */           }
/*      */         }
/*      */       }.doForAll();
/*      */     } finally {
/* 1438 */       if (stmt != null) {
/* 1439 */         stmt.close();
/*      */       }
/*      */     }
/*      */     
/* 1443 */     ResultSet results = buildResultSet(fields, rows);
/*      */     
/* 1445 */     return results;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void getCallStmtParameterTypes(String catalog, String procName, String parameterNamePattern, List resultRows)
/*      */     throws SQLException
/*      */   {
/* 1483 */     getCallStmtParameterTypes(catalog, procName, parameterNamePattern, resultRows, false);
/*      */   }
/*      */   
/*      */ 
/*      */   private void getCallStmtParameterTypes(String catalog, String procName, String parameterNamePattern, List resultRows, boolean forGetFunctionColumns)
/*      */     throws SQLException
/*      */   {
/* 1490 */     java.sql.Statement paramRetrievalStmt = null;
/* 1491 */     ResultSet paramRetrievalRs = null;
/*      */     
/* 1493 */     if (parameterNamePattern == null) {
/* 1494 */       if (this.conn.getNullNamePatternMatchesAll()) {
/* 1495 */         parameterNamePattern = "%";
/*      */       } else {
/* 1497 */         throw SQLError.createSQLException("Parameter/Column name pattern can not be NULL or empty.", "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1503 */     String quoteChar = getIdentifierQuoteString();
/*      */     
/* 1505 */     String parameterDef = null;
/*      */     
/* 1507 */     byte[] procNameAsBytes = null;
/* 1508 */     byte[] procCatAsBytes = null;
/*      */     
/* 1510 */     boolean isProcedureInAnsiMode = false;
/* 1511 */     String storageDefnDelims = null;
/* 1512 */     String storageDefnClosures = null;
/*      */     try
/*      */     {
/* 1515 */       paramRetrievalStmt = this.conn.getMetadataSafeStatement();
/*      */       
/* 1517 */       String oldCatalog = this.conn.getCatalog();
/* 1518 */       if ((this.conn.lowerCaseTableNames()) && (catalog != null) && (catalog.length() != 0) && (oldCatalog != null) && (oldCatalog.length() != 0))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1525 */         ResultSet rs = null;
/*      */         try
/*      */         {
/* 1528 */           this.conn.setCatalog(catalog.replaceAll(quoteChar, ""));
/* 1529 */           rs = paramRetrievalStmt.executeQuery("SELECT DATABASE()");
/* 1530 */           rs.next();
/*      */           
/* 1532 */           catalog = rs.getString(1);
/*      */         }
/*      */         finally
/*      */         {
/* 1536 */           this.conn.setCatalog(oldCatalog);
/*      */           
/* 1538 */           if (rs != null) {
/* 1539 */             rs.close();
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 1544 */       if (paramRetrievalStmt.getMaxRows() != 0) {
/* 1545 */         paramRetrievalStmt.setMaxRows(0);
/*      */       }
/*      */       
/* 1548 */       int dotIndex = -1;
/*      */       
/* 1550 */       if (!" ".equals(quoteChar)) {
/* 1551 */         dotIndex = StringUtils.indexOfIgnoreCaseRespectQuotes(0, procName, ".", quoteChar.charAt(0), !this.conn.isNoBackslashEscapesSet());
/*      */       }
/*      */       else
/*      */       {
/* 1555 */         dotIndex = procName.indexOf(".");
/*      */       }
/*      */       
/* 1558 */       String dbName = null;
/*      */       
/* 1560 */       if ((dotIndex != -1) && (dotIndex + 1 < procName.length())) {
/* 1561 */         dbName = procName.substring(0, dotIndex);
/* 1562 */         procName = procName.substring(dotIndex + 1);
/*      */       } else {
/* 1564 */         dbName = catalog;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1570 */       String tmpProcName = procName;
/* 1571 */       tmpProcName = tmpProcName.replaceAll(quoteChar, "");
/*      */       try {
/* 1573 */         procNameAsBytes = StringUtils.getBytes(tmpProcName, "UTF-8");
/*      */       } catch (UnsupportedEncodingException ueEx) {
/* 1575 */         procNameAsBytes = s2b(tmpProcName);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1580 */       tmpProcName = dbName;
/* 1581 */       tmpProcName = tmpProcName.replaceAll(quoteChar, "");
/*      */       try {
/* 1583 */         procCatAsBytes = StringUtils.getBytes(tmpProcName, "UTF-8");
/*      */       } catch (UnsupportedEncodingException ueEx) {
/* 1585 */         procCatAsBytes = s2b(tmpProcName);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1590 */       StringBuffer procNameBuf = new StringBuffer();
/*      */       
/* 1592 */       if (dbName != null) {
/* 1593 */         if ((!" ".equals(quoteChar)) && (!dbName.startsWith(quoteChar))) {
/* 1594 */           procNameBuf.append(quoteChar);
/*      */         }
/*      */         
/* 1597 */         procNameBuf.append(dbName);
/*      */         
/* 1599 */         if ((!" ".equals(quoteChar)) && (!dbName.startsWith(quoteChar))) {
/* 1600 */           procNameBuf.append(quoteChar);
/*      */         }
/*      */         
/* 1603 */         procNameBuf.append(".");
/*      */       }
/*      */       
/* 1606 */       boolean procNameIsNotQuoted = !procName.startsWith(quoteChar);
/*      */       
/* 1608 */       if ((!" ".equals(quoteChar)) && (procNameIsNotQuoted)) {
/* 1609 */         procNameBuf.append(quoteChar);
/*      */       }
/*      */       
/* 1612 */       procNameBuf.append(procName);
/*      */       
/* 1614 */       if ((!" ".equals(quoteChar)) && (procNameIsNotQuoted)) {
/* 1615 */         procNameBuf.append(quoteChar);
/*      */       }
/*      */       
/* 1618 */       boolean parsingFunction = false;
/*      */       try
/*      */       {
/* 1621 */         paramRetrievalRs = paramRetrievalStmt.executeQuery("SHOW CREATE PROCEDURE " + procNameBuf.toString());
/*      */         
/*      */ 
/* 1624 */         parsingFunction = false;
/*      */       } catch (SQLException sqlEx) {
/* 1626 */         paramRetrievalRs = paramRetrievalStmt.executeQuery("SHOW CREATE FUNCTION " + procNameBuf.toString());
/*      */         
/*      */ 
/* 1629 */         parsingFunction = true;
/*      */       }
/*      */       
/* 1632 */       if (paramRetrievalRs.next()) {
/* 1633 */         String procedureDef = parsingFunction ? paramRetrievalRs.getString("Create Function") : paramRetrievalRs.getString("Create Procedure");
/*      */         
/*      */ 
/*      */ 
/* 1637 */         if ((!this.conn.getNoAccessToProcedureBodies()) && ((procedureDef == null) || (procedureDef.length() == 0)))
/*      */         {
/* 1639 */           throw SQLError.createSQLException("User does not have access to metadata required to determine stored procedure parameter types. If rights can not be granted, configure connection with \"noAccessToProcedureBodies=true\" to have driver generate parameters that represent INOUT strings irregardless of actual parameter types.", "S1000", getExceptionInterceptor());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */         try
/*      */         {
/* 1646 */           String sqlMode = paramRetrievalRs.getString("sql_mode");
/*      */           
/* 1648 */           if (StringUtils.indexOfIgnoreCase(sqlMode, "ANSI") != -1) {
/* 1649 */             isProcedureInAnsiMode = true;
/*      */           }
/*      */         }
/*      */         catch (SQLException sqlEx) {}
/*      */         
/*      */ 
/* 1655 */         String identifierMarkers = isProcedureInAnsiMode ? "`\"" : "`";
/* 1656 */         String identifierAndStringMarkers = "'" + identifierMarkers;
/* 1657 */         storageDefnDelims = "(" + identifierMarkers;
/* 1658 */         storageDefnClosures = ")" + identifierMarkers;
/*      */         
/* 1660 */         if ((procedureDef != null) && (procedureDef.length() != 0))
/*      */         {
/* 1662 */           procedureDef = StringUtils.stripComments(procedureDef, identifierAndStringMarkers, identifierAndStringMarkers, true, false, true, true);
/*      */           
/*      */ 
/* 1665 */           int openParenIndex = StringUtils.indexOfIgnoreCaseRespectQuotes(0, procedureDef, "(", quoteChar.charAt(0), !this.conn.isNoBackslashEscapesSet());
/*      */           
/*      */ 
/*      */ 
/* 1669 */           int endOfParamDeclarationIndex = 0;
/*      */           
/* 1671 */           endOfParamDeclarationIndex = endPositionOfParameterDeclaration(openParenIndex, procedureDef, quoteChar);
/*      */           
/*      */ 
/* 1674 */           if (parsingFunction)
/*      */           {
/*      */ 
/*      */ 
/* 1678 */             int returnsIndex = StringUtils.indexOfIgnoreCaseRespectQuotes(0, procedureDef, " RETURNS ", quoteChar.charAt(0), !this.conn.isNoBackslashEscapesSet());
/*      */             
/*      */ 
/*      */ 
/*      */ 
/* 1683 */             int endReturnsDef = findEndOfReturnsClause(procedureDef, quoteChar, returnsIndex);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/* 1688 */             int declarationStart = returnsIndex + "RETURNS ".length();
/*      */             
/* 1690 */             while ((declarationStart < procedureDef.length()) && 
/* 1691 */               (Character.isWhitespace(procedureDef.charAt(declarationStart)))) {
/* 1692 */               declarationStart++;
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/* 1698 */             String returnsDefn = procedureDef.substring(declarationStart, endReturnsDef).trim();
/* 1699 */             TypeDescriptor returnDescriptor = new TypeDescriptor(returnsDefn, "YES");
/*      */             
/*      */ 
/* 1702 */             resultRows.add(convertTypeDescriptorToProcedureRow(procNameAsBytes, procCatAsBytes, "", false, false, true, returnDescriptor, forGetFunctionColumns, 0));
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 1707 */           if ((openParenIndex == -1) || (endOfParamDeclarationIndex == -1))
/*      */           {
/*      */ 
/* 1710 */             throw SQLError.createSQLException("Internal error when parsing callable statement metadata", "S1000", getExceptionInterceptor());
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 1716 */           parameterDef = procedureDef.substring(openParenIndex + 1, endOfParamDeclarationIndex);
/*      */         }
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/* 1722 */       SQLException sqlExRethrow = null;
/*      */       
/* 1724 */       if (paramRetrievalRs != null) {
/*      */         try {
/* 1726 */           paramRetrievalRs.close();
/*      */         } catch (SQLException sqlEx) {
/* 1728 */           sqlExRethrow = sqlEx;
/*      */         }
/*      */         
/* 1731 */         paramRetrievalRs = null;
/*      */       }
/*      */       
/* 1734 */       if (paramRetrievalStmt != null) {
/*      */         try {
/* 1736 */           paramRetrievalStmt.close();
/*      */         } catch (SQLException sqlEx) {
/* 1738 */           sqlExRethrow = sqlEx;
/*      */         }
/*      */         
/* 1741 */         paramRetrievalStmt = null;
/*      */       }
/*      */       
/* 1744 */       if (sqlExRethrow != null) {
/* 1745 */         throw sqlExRethrow;
/*      */       }
/*      */     }
/*      */     
/* 1749 */     if (parameterDef != null) {
/* 1750 */       int ordinal = 1;
/*      */       
/* 1752 */       List parseList = StringUtils.split(parameterDef, ",", storageDefnDelims, storageDefnClosures, true);
/*      */       
/*      */ 
/* 1755 */       int parseListLen = parseList.size();
/*      */       
/* 1757 */       for (int i = 0; i < parseListLen; i++) {
/* 1758 */         String declaration = (String)parseList.get(i);
/*      */         
/* 1760 */         if (declaration.trim().length() == 0) {
/*      */           break;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1766 */         declaration = declaration.replaceAll("[\\t\\n\\x0B\\f\\r]", " ");
/* 1767 */         StringTokenizer declarationTok = new StringTokenizer(declaration, " \t");
/*      */         
/*      */ 
/* 1770 */         String paramName = null;
/* 1771 */         boolean isOutParam = false;
/* 1772 */         boolean isInParam = false;
/*      */         
/* 1774 */         if (declarationTok.hasMoreTokens()) {
/* 1775 */           String possibleParamName = declarationTok.nextToken();
/*      */           
/* 1777 */           if (possibleParamName.equalsIgnoreCase("OUT")) {
/* 1778 */             isOutParam = true;
/*      */             
/* 1780 */             if (declarationTok.hasMoreTokens()) {
/* 1781 */               paramName = declarationTok.nextToken();
/*      */             } else {
/* 1783 */               throw SQLError.createSQLException("Internal error when parsing callable statement metadata (missing parameter name)", "S1000", getExceptionInterceptor());
/*      */             }
/*      */             
/*      */           }
/* 1787 */           else if (possibleParamName.equalsIgnoreCase("INOUT")) {
/* 1788 */             isOutParam = true;
/* 1789 */             isInParam = true;
/*      */             
/* 1791 */             if (declarationTok.hasMoreTokens()) {
/* 1792 */               paramName = declarationTok.nextToken();
/*      */             } else {
/* 1794 */               throw SQLError.createSQLException("Internal error when parsing callable statement metadata (missing parameter name)", "S1000", getExceptionInterceptor());
/*      */             }
/*      */             
/*      */           }
/* 1798 */           else if (possibleParamName.equalsIgnoreCase("IN")) {
/* 1799 */             isOutParam = false;
/* 1800 */             isInParam = true;
/*      */             
/* 1802 */             if (declarationTok.hasMoreTokens()) {
/* 1803 */               paramName = declarationTok.nextToken();
/*      */             } else {
/* 1805 */               throw SQLError.createSQLException("Internal error when parsing callable statement metadata (missing parameter name)", "S1000", getExceptionInterceptor());
/*      */             }
/*      */           }
/*      */           else
/*      */           {
/* 1810 */             isOutParam = false;
/* 1811 */             isInParam = true;
/*      */             
/* 1813 */             paramName = possibleParamName;
/*      */           }
/*      */           
/* 1816 */           TypeDescriptor typeDesc = null;
/*      */           
/* 1818 */           if (declarationTok.hasMoreTokens()) {
/* 1819 */             StringBuffer typeInfoBuf = new StringBuffer(declarationTok.nextToken());
/*      */             
/*      */ 
/* 1822 */             while (declarationTok.hasMoreTokens()) {
/* 1823 */               typeInfoBuf.append(" ");
/* 1824 */               typeInfoBuf.append(declarationTok.nextToken());
/*      */             }
/*      */             
/* 1827 */             String typeInfo = typeInfoBuf.toString();
/*      */             
/* 1829 */             typeDesc = new TypeDescriptor(typeInfo, "YES");
/*      */           } else {
/* 1831 */             throw SQLError.createSQLException("Internal error when parsing callable statement metadata (missing parameter type)", "S1000", getExceptionInterceptor());
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 1836 */           if (((paramName.startsWith("`")) && (paramName.endsWith("`"))) || ((isProcedureInAnsiMode) && (paramName.startsWith("\"")) && (paramName.endsWith("\""))))
/*      */           {
/* 1838 */             paramName = paramName.substring(1, paramName.length() - 1);
/*      */           }
/*      */           
/* 1841 */           int wildCompareRes = StringUtils.wildCompare(paramName, parameterNamePattern);
/*      */           
/*      */ 
/* 1844 */           if (wildCompareRes != -1) {
/* 1845 */             ResultSetRow row = convertTypeDescriptorToProcedureRow(procNameAsBytes, procCatAsBytes, paramName, isOutParam, isInParam, false, typeDesc, forGetFunctionColumns, ordinal++);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/* 1850 */             resultRows.add(row);
/*      */           }
/*      */         } else {
/* 1853 */           throw SQLError.createSQLException("Internal error when parsing callable statement metadata (unknown output from 'SHOW CREATE PROCEDURE')", "S1000", getExceptionInterceptor());
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int endPositionOfParameterDeclaration(int beginIndex, String procedureDef, String quoteChar)
/*      */     throws SQLException
/*      */   {
/* 1882 */     int currentPos = beginIndex + 1;
/* 1883 */     int parenDepth = 1;
/*      */     
/* 1885 */     while ((parenDepth > 0) && (currentPos < procedureDef.length())) {
/* 1886 */       int closedParenIndex = StringUtils.indexOfIgnoreCaseRespectQuotes(currentPos, procedureDef, ")", quoteChar.charAt(0), !this.conn.isNoBackslashEscapesSet());
/*      */       
/*      */ 
/*      */ 
/* 1890 */       if (closedParenIndex != -1) {
/* 1891 */         int nextOpenParenIndex = StringUtils.indexOfIgnoreCaseRespectQuotes(currentPos, procedureDef, "(", quoteChar.charAt(0), !this.conn.isNoBackslashEscapesSet());
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1896 */         if ((nextOpenParenIndex != -1) && (nextOpenParenIndex < closedParenIndex))
/*      */         {
/* 1898 */           parenDepth++;
/* 1899 */           currentPos = closedParenIndex + 1;
/*      */         }
/*      */         else
/*      */         {
/* 1903 */           parenDepth--;
/* 1904 */           currentPos = closedParenIndex;
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1909 */         throw SQLError.createSQLException("Internal error when parsing callable statement metadata", "S1000", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1916 */     return currentPos;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int findEndOfReturnsClause(String procedureDefn, String quoteChar, int positionOfReturnKeyword)
/*      */     throws SQLException
/*      */   {
/* 1941 */     String[] tokens = { "LANGUAGE", "NOT", "DETERMINISTIC", "CONTAINS", "NO", "READ", "MODIFIES", "SQL", "COMMENT", "BEGIN", "RETURN" };
/*      */     
/*      */ 
/*      */ 
/* 1945 */     int startLookingAt = positionOfReturnKeyword + "RETURNS".length() + 1;
/*      */     
/* 1947 */     int endOfReturn = -1;
/*      */     
/* 1949 */     for (int i = 0; i < tokens.length; i++) {
/* 1950 */       int nextEndOfReturn = StringUtils.indexOfIgnoreCaseRespectQuotes(startLookingAt, procedureDefn, tokens[i], quoteChar.charAt(0), !this.conn.isNoBackslashEscapesSet());
/*      */       
/*      */ 
/*      */ 
/* 1954 */       if ((nextEndOfReturn != -1) && (
/* 1955 */         (endOfReturn == -1) || (nextEndOfReturn < endOfReturn))) {
/* 1956 */         endOfReturn = nextEndOfReturn;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1961 */     if (endOfReturn != -1) {
/* 1962 */       return endOfReturn;
/*      */     }
/*      */     
/*      */ 
/* 1966 */     endOfReturn = StringUtils.indexOfIgnoreCaseRespectQuotes(startLookingAt, procedureDefn, ":", quoteChar.charAt(0), !this.conn.isNoBackslashEscapesSet());
/*      */     
/*      */ 
/*      */ 
/* 1970 */     if (endOfReturn != -1)
/*      */     {
/* 1972 */       for (int i = endOfReturn; i > 0; i--) {
/* 1973 */         if (Character.isWhitespace(procedureDefn.charAt(i))) {
/* 1974 */           return i;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1981 */     throw SQLError.createSQLException("Internal error when parsing callable statement metadata", "S1000", getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getCascadeDeleteOption(String cascadeOptions)
/*      */   {
/* 1995 */     int onDeletePos = cascadeOptions.indexOf("ON DELETE");
/*      */     
/* 1997 */     if (onDeletePos != -1) {
/* 1998 */       String deleteOptions = cascadeOptions.substring(onDeletePos, cascadeOptions.length());
/*      */       
/*      */ 
/* 2001 */       if (deleteOptions.startsWith("ON DELETE CASCADE"))
/* 2002 */         return 0;
/* 2003 */       if (deleteOptions.startsWith("ON DELETE SET NULL"))
/* 2004 */         return 2;
/* 2005 */       if (deleteOptions.startsWith("ON DELETE RESTRICT"))
/* 2006 */         return 1;
/* 2007 */       if (deleteOptions.startsWith("ON DELETE NO ACTION")) {
/* 2008 */         return 3;
/*      */       }
/*      */     }
/*      */     
/* 2012 */     return 3;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getCascadeUpdateOption(String cascadeOptions)
/*      */   {
/* 2024 */     int onUpdatePos = cascadeOptions.indexOf("ON UPDATE");
/*      */     
/* 2026 */     if (onUpdatePos != -1) {
/* 2027 */       String updateOptions = cascadeOptions.substring(onUpdatePos, cascadeOptions.length());
/*      */       
/*      */ 
/* 2030 */       if (updateOptions.startsWith("ON UPDATE CASCADE"))
/* 2031 */         return 0;
/* 2032 */       if (updateOptions.startsWith("ON UPDATE SET NULL"))
/* 2033 */         return 2;
/* 2034 */       if (updateOptions.startsWith("ON UPDATE RESTRICT"))
/* 2035 */         return 1;
/* 2036 */       if (updateOptions.startsWith("ON UPDATE NO ACTION")) {
/* 2037 */         return 3;
/*      */       }
/*      */     }
/*      */     
/* 2041 */     return 3;
/*      */   }
/*      */   
/*      */   protected IteratorWithCleanup getCatalogIterator(String catalogSpec) throws SQLException {
/*      */     IteratorWithCleanup allCatalogsIter;
/*      */     IteratorWithCleanup allCatalogsIter;
/* 2047 */     if (catalogSpec != null) { IteratorWithCleanup allCatalogsIter;
/* 2048 */       if (!catalogSpec.equals("")) {
/* 2049 */         allCatalogsIter = new SingleStringIterator(unQuoteQuotedIdentifier(catalogSpec));
/*      */       }
/*      */       else
/* 2052 */         allCatalogsIter = new SingleStringIterator(this.database);
/*      */     } else { IteratorWithCleanup allCatalogsIter;
/* 2054 */       if (this.conn.getNullCatalogMeansCurrent())
/*      */       {
/* 2056 */         allCatalogsIter = new SingleStringIterator(this.database);
/*      */       } else {
/* 2058 */         allCatalogsIter = new ResultSetIterator(getCatalogs(), 1);
/*      */       }
/*      */     }
/* 2061 */     return allCatalogsIter;
/*      */   }
/*      */   
/*      */   protected String unQuoteQuotedIdentifier(String identifier) {
/* 2065 */     boolean trimQuotes = false;
/*      */     
/* 2067 */     if (identifier != null)
/*      */     {
/*      */ 
/* 2070 */       if ((identifier.startsWith("`")) && (identifier.endsWith("`"))) {
/* 2071 */         trimQuotes = true;
/*      */       }
/*      */       
/* 2074 */       if ((this.conn.useAnsiQuotedIdentifiers()) && 
/* 2075 */         (identifier.startsWith("\"")) && (identifier.endsWith("\""))) {
/* 2076 */         trimQuotes = true;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2081 */     if (trimQuotes) {
/* 2082 */       return identifier.substring(1, identifier.length() - 1);
/*      */     }
/*      */     
/* 2085 */     return identifier;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getCatalogs()
/*      */     throws SQLException
/*      */   {
/* 2104 */     ResultSet results = null;
/* 2105 */     java.sql.Statement stmt = null;
/*      */     try
/*      */     {
/* 2108 */       stmt = this.conn.createStatement();
/* 2109 */       stmt.setEscapeProcessing(false);
/* 2110 */       results = stmt.executeQuery("SHOW DATABASES");
/*      */       
/* 2112 */       ResultSetMetaData resultsMD = results.getMetaData();
/* 2113 */       Field[] fields = new Field[1];
/* 2114 */       fields[0] = new Field("", "TABLE_CAT", 12, resultsMD.getColumnDisplaySize(1));
/*      */       
/*      */ 
/* 2117 */       ArrayList tuples = new ArrayList();
/*      */       byte[][] rowVal;
/* 2119 */       while (results.next()) {
/* 2120 */         rowVal = new byte[1][];
/* 2121 */         rowVal[0] = results.getBytes(1);
/* 2122 */         tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */       }
/*      */       
/* 2125 */       return buildResultSet(fields, tuples);
/*      */     } finally {
/* 2127 */       if (results != null) {
/*      */         try {
/* 2129 */           results.close();
/*      */         } catch (SQLException sqlEx) {
/* 2131 */           AssertionFailedException.shouldNotHappen(sqlEx);
/*      */         }
/*      */         
/* 2134 */         results = null;
/*      */       }
/*      */       
/* 2137 */       if (stmt != null) {
/*      */         try {
/* 2139 */           stmt.close();
/*      */         } catch (SQLException sqlEx) {
/* 2141 */           AssertionFailedException.shouldNotHappen(sqlEx);
/*      */         }
/*      */         
/* 2144 */         stmt = null;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCatalogSeparator()
/*      */     throws SQLException
/*      */   {
/* 2157 */     return ".";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCatalogTerm()
/*      */     throws SQLException
/*      */   {
/* 2174 */     return "database";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getColumnPrivileges(String catalog, String schema, String table, String columnNamePattern)
/*      */     throws SQLException
/*      */   {
/* 2215 */     Field[] fields = new Field[8];
/* 2216 */     fields[0] = new Field("", "TABLE_CAT", 1, 64);
/* 2217 */     fields[1] = new Field("", "TABLE_SCHEM", 1, 1);
/* 2218 */     fields[2] = new Field("", "TABLE_NAME", 1, 64);
/* 2219 */     fields[3] = new Field("", "COLUMN_NAME", 1, 64);
/* 2220 */     fields[4] = new Field("", "GRANTOR", 1, 77);
/* 2221 */     fields[5] = new Field("", "GRANTEE", 1, 77);
/* 2222 */     fields[6] = new Field("", "PRIVILEGE", 1, 64);
/* 2223 */     fields[7] = new Field("", "IS_GRANTABLE", 1, 3);
/*      */     
/* 2225 */     StringBuffer grantQuery = new StringBuffer("SELECT c.host, c.db, t.grantor, c.user, c.table_name, c.column_name, c.column_priv from mysql.columns_priv c, mysql.tables_priv t where c.host = t.host and c.db = t.db and c.table_name = t.table_name ");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2232 */     if ((catalog != null) && (catalog.length() != 0)) {
/* 2233 */       grantQuery.append(" AND c.db='");
/* 2234 */       grantQuery.append(catalog);
/* 2235 */       grantQuery.append("' ");
/*      */     }
/*      */     
/*      */ 
/* 2239 */     grantQuery.append(" AND c.table_name ='");
/* 2240 */     grantQuery.append(table);
/* 2241 */     grantQuery.append("' AND c.column_name like '");
/* 2242 */     grantQuery.append(columnNamePattern);
/* 2243 */     grantQuery.append("'");
/*      */     
/* 2245 */     java.sql.Statement stmt = null;
/* 2246 */     ResultSet results = null;
/* 2247 */     ArrayList grantRows = new ArrayList();
/*      */     try
/*      */     {
/* 2250 */       stmt = this.conn.createStatement();
/* 2251 */       stmt.setEscapeProcessing(false);
/* 2252 */       results = stmt.executeQuery(grantQuery.toString());
/*      */       
/* 2254 */       while (results.next()) {
/* 2255 */         String host = results.getString(1);
/* 2256 */         String db = results.getString(2);
/* 2257 */         String grantor = results.getString(3);
/* 2258 */         String user = results.getString(4);
/*      */         
/* 2260 */         if ((user == null) || (user.length() == 0)) {
/* 2261 */           user = "%";
/*      */         }
/*      */         
/* 2264 */         StringBuffer fullUser = new StringBuffer(user);
/*      */         
/* 2266 */         if ((host != null) && (this.conn.getUseHostsInPrivileges())) {
/* 2267 */           fullUser.append("@");
/* 2268 */           fullUser.append(host);
/*      */         }
/*      */         
/* 2271 */         String columnName = results.getString(6);
/* 2272 */         String allPrivileges = results.getString(7);
/*      */         
/* 2274 */         if (allPrivileges != null) {
/* 2275 */           allPrivileges = allPrivileges.toUpperCase(Locale.ENGLISH);
/*      */           
/* 2277 */           StringTokenizer st = new StringTokenizer(allPrivileges, ",");
/*      */           
/* 2279 */           while (st.hasMoreTokens()) {
/* 2280 */             String privilege = st.nextToken().trim();
/* 2281 */             byte[][] tuple = new byte[8][];
/* 2282 */             tuple[0] = s2b(db);
/* 2283 */             tuple[1] = null;
/* 2284 */             tuple[2] = s2b(table);
/* 2285 */             tuple[3] = s2b(columnName);
/*      */             
/* 2287 */             if (grantor != null) {
/* 2288 */               tuple[4] = s2b(grantor);
/*      */             } else {
/* 2290 */               tuple[4] = null;
/*      */             }
/*      */             
/* 2293 */             tuple[5] = s2b(fullUser.toString());
/* 2294 */             tuple[6] = s2b(privilege);
/* 2295 */             tuple[7] = null;
/* 2296 */             grantRows.add(new ByteArrayRow(tuple, getExceptionInterceptor()));
/*      */           }
/*      */         }
/*      */       }
/*      */     } finally {
/* 2301 */       if (results != null) {
/*      */         try {
/* 2303 */           results.close();
/*      */         }
/*      */         catch (Exception ex) {}
/*      */         
/*      */ 
/* 2308 */         results = null;
/*      */       }
/*      */       
/* 2311 */       if (stmt != null) {
/*      */         try {
/* 2313 */           stmt.close();
/*      */         }
/*      */         catch (Exception ex) {}
/*      */         
/*      */ 
/* 2318 */         stmt = null;
/*      */       }
/*      */     }
/*      */     
/* 2322 */     return buildResultSet(fields, grantRows);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getColumns(String catalog, final String schemaPattern, final String tableNamePattern, String columnNamePattern)
/*      */     throws SQLException
/*      */   {
/* 2386 */     if (columnNamePattern == null) {
/* 2387 */       if (this.conn.getNullNamePatternMatchesAll()) {
/* 2388 */         columnNamePattern = "%";
/*      */       } else {
/* 2390 */         throw SQLError.createSQLException("Column name pattern can not be NULL or empty.", "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2396 */     final String colPattern = columnNamePattern;
/*      */     
/* 2398 */     Field[] fields = createColumnsFields();
/*      */     
/* 2400 */     final ArrayList rows = new ArrayList();
/* 2401 */     final java.sql.Statement stmt = this.conn.getMetadataSafeStatement();
/*      */     
/*      */     try
/*      */     {
/* 2405 */       new IterateBlock(getCatalogIterator(catalog))
/*      */       {
/*      */         void forEach(Object catalogStr) throws SQLException {
/* 2408 */           ArrayList tableNameList = new ArrayList();
/*      */           
/* 2410 */           if (tableNamePattern == null)
/*      */           {
/* 2412 */             ResultSet tables = null;
/*      */             try
/*      */             {
/* 2415 */               tables = DatabaseMetaData.this.getTables((String)catalogStr, schemaPattern, "%", new String[0]);
/*      */               
/*      */ 
/* 2418 */               while (tables.next()) {
/* 2419 */                 String tableNameFromList = tables.getString("TABLE_NAME");
/*      */                 
/* 2421 */                 tableNameList.add(tableNameFromList);
/*      */               }
/*      */             } finally {
/* 2424 */               if (tables != null) {
/*      */                 try {
/* 2426 */                   tables.close();
/*      */                 } catch (Exception sqlEx) {
/* 2428 */                   AssertionFailedException.shouldNotHappen(sqlEx);
/*      */                 }
/*      */                 
/*      */ 
/* 2432 */                 tables = null;
/*      */               }
/*      */             }
/*      */           } else {
/* 2436 */             ResultSet tables = null;
/*      */             try
/*      */             {
/* 2439 */               tables = DatabaseMetaData.this.getTables((String)catalogStr, schemaPattern, tableNamePattern, new String[0]);
/*      */               
/*      */ 
/* 2442 */               while (tables.next()) {
/* 2443 */                 String tableNameFromList = tables.getString("TABLE_NAME");
/*      */                 
/* 2445 */                 tableNameList.add(tableNameFromList);
/*      */               }
/*      */             } finally {
/* 2448 */               if (tables != null) {
/*      */                 try {
/* 2450 */                   tables.close();
/*      */                 } catch (SQLException sqlEx) {
/* 2452 */                   AssertionFailedException.shouldNotHappen(sqlEx);
/*      */                 }
/*      */                 
/*      */ 
/* 2456 */                 tables = null;
/*      */               }
/*      */             }
/*      */           }
/*      */           
/* 2461 */           Iterator tableNames = tableNameList.iterator();
/*      */           
/* 2463 */           while (tableNames.hasNext()) {
/* 2464 */             String tableName = (String)tableNames.next();
/*      */             
/* 2466 */             ResultSet results = null;
/*      */             try
/*      */             {
/* 2469 */               StringBuffer queryBuf = new StringBuffer("SHOW ");
/*      */               
/* 2471 */               if (DatabaseMetaData.this.conn.versionMeetsMinimum(4, 1, 0)) {
/* 2472 */                 queryBuf.append("FULL ");
/*      */               }
/*      */               
/* 2475 */               queryBuf.append("COLUMNS FROM ");
/* 2476 */               queryBuf.append(DatabaseMetaData.this.quotedId);
/* 2477 */               queryBuf.append(tableName);
/* 2478 */               queryBuf.append(DatabaseMetaData.this.quotedId);
/* 2479 */               queryBuf.append(" FROM ");
/* 2480 */               queryBuf.append(DatabaseMetaData.this.quotedId);
/* 2481 */               queryBuf.append((String)catalogStr);
/* 2482 */               queryBuf.append(DatabaseMetaData.this.quotedId);
/* 2483 */               queryBuf.append(" LIKE '");
/* 2484 */               queryBuf.append(colPattern);
/* 2485 */               queryBuf.append("'");
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2492 */               boolean fixUpOrdinalsRequired = false;
/* 2493 */               Object ordinalFixUpMap = null;
/*      */               
/* 2495 */               if (!colPattern.equals("%")) {
/* 2496 */                 fixUpOrdinalsRequired = true;
/*      */                 
/* 2498 */                 StringBuffer fullColumnQueryBuf = new StringBuffer("SHOW ");
/*      */                 
/*      */ 
/* 2501 */                 if (DatabaseMetaData.this.conn.versionMeetsMinimum(4, 1, 0)) {
/* 2502 */                   fullColumnQueryBuf.append("FULL ");
/*      */                 }
/*      */                 
/* 2505 */                 fullColumnQueryBuf.append("COLUMNS FROM ");
/* 2506 */                 fullColumnQueryBuf.append(DatabaseMetaData.this.quotedId);
/* 2507 */                 fullColumnQueryBuf.append(tableName);
/* 2508 */                 fullColumnQueryBuf.append(DatabaseMetaData.this.quotedId);
/* 2509 */                 fullColumnQueryBuf.append(" FROM ");
/* 2510 */                 fullColumnQueryBuf.append(DatabaseMetaData.this.quotedId);
/* 2511 */                 fullColumnQueryBuf.append((String)catalogStr);
/*      */                 
/* 2513 */                 fullColumnQueryBuf.append(DatabaseMetaData.this.quotedId);
/*      */                 
/* 2515 */                 results = stmt.executeQuery(fullColumnQueryBuf.toString());
/*      */                 
/*      */ 
/* 2518 */                 ordinalFixUpMap = new HashMap();
/*      */                 
/* 2520 */                 int fullOrdinalPos = 1;
/*      */                 
/* 2522 */                 while (results.next()) {
/* 2523 */                   String fullOrdColName = results.getString("Field");
/*      */                   
/*      */ 
/* 2526 */                   ((Map)ordinalFixUpMap).put(fullOrdColName, Integer.valueOf(fullOrdinalPos++));
/*      */                 }
/*      */               }
/*      */               
/*      */ 
/* 2531 */               results = stmt.executeQuery(queryBuf.toString());
/*      */               
/* 2533 */               int ordPos = 1;
/*      */               
/* 2535 */               while (results.next()) {
/* 2536 */                 byte[][] rowVal = new byte[23][];
/* 2537 */                 rowVal[0] = DatabaseMetaData.this.s2b((String)catalogStr);
/* 2538 */                 rowVal[1] = null;
/*      */                 
/*      */ 
/* 2541 */                 rowVal[2] = DatabaseMetaData.this.s2b(tableName);
/* 2542 */                 rowVal[3] = results.getBytes("Field");
/*      */                 
/* 2544 */                 DatabaseMetaData.TypeDescriptor typeDesc = new DatabaseMetaData.TypeDescriptor(DatabaseMetaData.this, results.getString("Type"), results.getString("Null"));
/*      */                 
/*      */ 
/*      */ 
/* 2548 */                 rowVal[4] = Short.toString(typeDesc.dataType).getBytes();
/*      */                 
/*      */ 
/*      */ 
/* 2552 */                 rowVal[5] = DatabaseMetaData.this.s2b(typeDesc.typeName);
/*      */                 
/* 2554 */                 rowVal[6] = (typeDesc.columnSize == null ? null : DatabaseMetaData.this.s2b(typeDesc.columnSize.toString()));
/* 2555 */                 rowVal[7] = DatabaseMetaData.this.s2b(Integer.toString(typeDesc.bufferLength));
/* 2556 */                 rowVal[8] = (typeDesc.decimalDigits == null ? null : DatabaseMetaData.this.s2b(typeDesc.decimalDigits.toString()));
/* 2557 */                 rowVal[9] = DatabaseMetaData.this.s2b(Integer.toString(typeDesc.numPrecRadix));
/*      */                 
/* 2559 */                 rowVal[10] = DatabaseMetaData.this.s2b(Integer.toString(typeDesc.nullability));
/*      */                 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 try
/*      */                 {
/* 2570 */                   if (DatabaseMetaData.this.conn.versionMeetsMinimum(4, 1, 0)) {
/* 2571 */                     rowVal[11] = results.getBytes("Comment");
/*      */                   }
/*      */                   else {
/* 2574 */                     rowVal[11] = results.getBytes("Extra");
/*      */                   }
/*      */                 } catch (Exception E) {
/* 2577 */                   rowVal[11] = new byte[0];
/*      */                 }
/*      */                 
/*      */ 
/* 2581 */                 rowVal[12] = results.getBytes("Default");
/*      */                 
/* 2583 */                 rowVal[13] = { 48 };
/* 2584 */                 rowVal[14] = { 48 };
/*      */                 
/* 2586 */                 if ((StringUtils.indexOfIgnoreCase(typeDesc.typeName, "CHAR") != -1) || (StringUtils.indexOfIgnoreCase(typeDesc.typeName, "BLOB") != -1) || (StringUtils.indexOfIgnoreCase(typeDesc.typeName, "TEXT") != -1) || (StringUtils.indexOfIgnoreCase(typeDesc.typeName, "BINARY") != -1))
/*      */                 {
/*      */ 
/*      */ 
/* 2590 */                   rowVal[15] = rowVal[6];
/*      */                 } else {
/* 2592 */                   rowVal[15] = null;
/*      */                 }
/*      */                 
/*      */ 
/* 2596 */                 if (!fixUpOrdinalsRequired) {
/* 2597 */                   rowVal[16] = Integer.toString(ordPos++).getBytes();
/*      */                 }
/*      */                 else {
/* 2600 */                   String origColName = results.getString("Field");
/*      */                   
/* 2602 */                   Integer realOrdinal = (Integer)((Map)ordinalFixUpMap).get(origColName);
/*      */                   
/*      */ 
/* 2605 */                   if (realOrdinal != null) {
/* 2606 */                     rowVal[16] = realOrdinal.toString().getBytes();
/*      */                   }
/*      */                   else {
/* 2609 */                     throw SQLError.createSQLException("Can not find column in full column list to determine true ordinal position.", "S1000", DatabaseMetaData.this.getExceptionInterceptor());
/*      */                   }
/*      */                 }
/*      */                 
/*      */ 
/*      */ 
/* 2615 */                 rowVal[17] = DatabaseMetaData.this.s2b(typeDesc.isNullable);
/*      */                 
/*      */ 
/* 2618 */                 rowVal[18] = null;
/* 2619 */                 rowVal[19] = null;
/* 2620 */                 rowVal[20] = null;
/* 2621 */                 rowVal[21] = null;
/*      */                 
/* 2623 */                 rowVal[22] = DatabaseMetaData.this.s2b("");
/*      */                 
/* 2625 */                 String extra = results.getString("Extra");
/*      */                 
/* 2627 */                 if (extra != null) {
/* 2628 */                   rowVal[22] = DatabaseMetaData.this.s2b(StringUtils.indexOfIgnoreCase(extra, "auto_increment") != -1 ? "YES" : "NO");
/*      */                 }
/*      */                 
/*      */ 
/*      */ 
/*      */ 
/* 2634 */                 rows.add(new ByteArrayRow(rowVal, DatabaseMetaData.this.getExceptionInterceptor()));
/*      */               }
/*      */             } finally {
/* 2637 */               if (results != null) {
/*      */                 try {
/* 2639 */                   results.close();
/*      */                 }
/*      */                 catch (Exception ex) {}
/*      */                 
/*      */ 
/* 2644 */                 results = null;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }.doForAll();
/*      */     } finally {
/* 2651 */       if (stmt != null) {
/* 2652 */         stmt.close();
/*      */       }
/*      */     }
/*      */     
/* 2656 */     ResultSet results = buildResultSet(fields, rows);
/*      */     
/* 2658 */     return results;
/*      */   }
/*      */   
/*      */   protected Field[] createColumnsFields() {
/* 2662 */     Field[] fields = new Field[23];
/* 2663 */     fields[0] = new Field("", "TABLE_CAT", 1, 255);
/* 2664 */     fields[1] = new Field("", "TABLE_SCHEM", 1, 0);
/* 2665 */     fields[2] = new Field("", "TABLE_NAME", 1, 255);
/* 2666 */     fields[3] = new Field("", "COLUMN_NAME", 1, 32);
/* 2667 */     fields[4] = new Field("", "DATA_TYPE", 4, 5);
/* 2668 */     fields[5] = new Field("", "TYPE_NAME", 1, 16);
/* 2669 */     fields[6] = new Field("", "COLUMN_SIZE", 4, Integer.toString(Integer.MAX_VALUE).length());
/*      */     
/* 2671 */     fields[7] = new Field("", "BUFFER_LENGTH", 4, 10);
/* 2672 */     fields[8] = new Field("", "DECIMAL_DIGITS", 4, 10);
/* 2673 */     fields[9] = new Field("", "NUM_PREC_RADIX", 4, 10);
/* 2674 */     fields[10] = new Field("", "NULLABLE", 4, 10);
/* 2675 */     fields[11] = new Field("", "REMARKS", 1, 0);
/* 2676 */     fields[12] = new Field("", "COLUMN_DEF", 1, 0);
/* 2677 */     fields[13] = new Field("", "SQL_DATA_TYPE", 4, 10);
/* 2678 */     fields[14] = new Field("", "SQL_DATETIME_SUB", 4, 10);
/* 2679 */     fields[15] = new Field("", "CHAR_OCTET_LENGTH", 4, Integer.toString(Integer.MAX_VALUE).length());
/*      */     
/* 2681 */     fields[16] = new Field("", "ORDINAL_POSITION", 4, 10);
/* 2682 */     fields[17] = new Field("", "IS_NULLABLE", 1, 3);
/* 2683 */     fields[18] = new Field("", "SCOPE_CATALOG", 1, 255);
/* 2684 */     fields[19] = new Field("", "SCOPE_SCHEMA", 1, 255);
/* 2685 */     fields[20] = new Field("", "SCOPE_TABLE", 1, 255);
/* 2686 */     fields[21] = new Field("", "SOURCE_DATA_TYPE", 5, 10);
/* 2687 */     fields[22] = new Field("", "IS_AUTOINCREMENT", 1, 3);
/* 2688 */     return fields;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Connection getConnection()
/*      */     throws SQLException
/*      */   {
/* 2699 */     return this.conn;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getCrossReference(final String primaryCatalog, final String primarySchema, final String primaryTable, final String foreignCatalog, final String foreignSchema, final String foreignTable)
/*      */     throws SQLException
/*      */   {
/* 2773 */     if (primaryTable == null) {
/* 2774 */       throw SQLError.createSQLException("Table not specified.", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 2778 */     Field[] fields = createFkMetadataFields();
/*      */     
/* 2780 */     final ArrayList tuples = new ArrayList();
/*      */     
/* 2782 */     if (this.conn.versionMeetsMinimum(3, 23, 0))
/*      */     {
/* 2784 */       final java.sql.Statement stmt = this.conn.getMetadataSafeStatement();
/*      */       
/*      */       try
/*      */       {
/* 2788 */         new IterateBlock(getCatalogIterator(foreignCatalog))
/*      */         {
/*      */           void forEach(Object catalogStr) throws SQLException {
/* 2791 */             ResultSet fkresults = null;
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */             try
/*      */             {
/* 2798 */               if (DatabaseMetaData.this.conn.versionMeetsMinimum(3, 23, 50)) {
/* 2799 */                 fkresults = DatabaseMetaData.this.extractForeignKeyFromCreateTable(catalogStr.toString(), null);
/*      */               }
/*      */               else {
/* 2802 */                 StringBuffer queryBuf = new StringBuffer("SHOW TABLE STATUS FROM ");
/*      */                 
/* 2804 */                 queryBuf.append(DatabaseMetaData.this.quotedId);
/* 2805 */                 queryBuf.append(catalogStr.toString());
/* 2806 */                 queryBuf.append(DatabaseMetaData.this.quotedId);
/*      */                 
/* 2808 */                 fkresults = stmt.executeQuery(queryBuf.toString());
/*      */               }
/*      */               
/*      */ 
/* 2812 */               String foreignTableWithCase = DatabaseMetaData.this.getTableNameWithCase(foreignTable);
/* 2813 */               String primaryTableWithCase = DatabaseMetaData.this.getTableNameWithCase(primaryTable);
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2821 */               while (fkresults.next()) {
/* 2822 */                 String tableType = fkresults.getString("Type");
/*      */                 
/* 2824 */                 if ((tableType != null) && ((tableType.equalsIgnoreCase("innodb")) || (tableType.equalsIgnoreCase("SUPPORTS_FK"))))
/*      */                 {
/*      */ 
/*      */ 
/* 2828 */                   String comment = fkresults.getString("Comment").trim();
/*      */                   
/*      */ 
/* 2831 */                   if (comment != null) {
/* 2832 */                     StringTokenizer commentTokens = new StringTokenizer(comment, ";", false);
/*      */                     
/*      */ 
/* 2835 */                     if (commentTokens.hasMoreTokens()) {
/* 2836 */                       String str1 = commentTokens.nextToken();
/*      */                     }
/*      */                     
/*      */ 
/*      */ 
/* 2841 */                     while (commentTokens.hasMoreTokens()) {
/* 2842 */                       String keys = commentTokens.nextToken();
/*      */                       
/* 2844 */                       DatabaseMetaData.LocalAndReferencedColumns parsedInfo = DatabaseMetaData.this.parseTableStatusIntoLocalAndReferencedColumns(keys);
/*      */                       
/* 2846 */                       int keySeq = 0;
/*      */                       
/* 2848 */                       Iterator referencingColumns = parsedInfo.localColumnsList.iterator();
/*      */                       
/* 2850 */                       Iterator referencedColumns = parsedInfo.referencedColumnsList.iterator();
/*      */                       
/*      */ 
/* 2853 */                       while (referencingColumns.hasNext()) {
/* 2854 */                         String referencingColumn = DatabaseMetaData.this.removeQuotedId(referencingColumns.next().toString());
/*      */                         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2860 */                         byte[][] tuple = new byte[14][];
/* 2861 */                         tuple[4] = (foreignCatalog == null ? null : DatabaseMetaData.this.s2b(foreignCatalog));
/*      */                         
/* 2863 */                         tuple[5] = (foreignSchema == null ? null : DatabaseMetaData.this.s2b(foreignSchema));
/*      */                         
/* 2865 */                         String dummy = fkresults.getString("Name");
/*      */                         
/*      */ 
/* 2868 */                         if (dummy.compareTo(foreignTableWithCase) == 0)
/*      */                         {
/*      */ 
/*      */ 
/*      */ 
/* 2873 */                           tuple[6] = DatabaseMetaData.this.s2b(dummy);
/*      */                           
/* 2875 */                           tuple[7] = DatabaseMetaData.this.s2b(referencingColumn);
/* 2876 */                           tuple[0] = (primaryCatalog == null ? null : DatabaseMetaData.this.s2b(primaryCatalog));
/*      */                           
/* 2878 */                           tuple[1] = (primarySchema == null ? null : DatabaseMetaData.this.s2b(primarySchema));
/*      */                           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2884 */                           if (parsedInfo.referencedTable.compareTo(primaryTableWithCase) == 0)
/*      */                           {
/*      */ 
/*      */ 
/*      */ 
/* 2889 */                             tuple[2] = DatabaseMetaData.this.s2b(parsedInfo.referencedTable);
/* 2890 */                             tuple[3] = DatabaseMetaData.this.s2b(DatabaseMetaData.this.removeQuotedId(referencedColumns.next().toString()));
/*      */                             
/* 2892 */                             tuple[8] = Integer.toString(keySeq).getBytes();
/*      */                             
/*      */ 
/* 2895 */                             int[] actions = DatabaseMetaData.this.getForeignKeyActions(keys);
/*      */                             
/* 2897 */                             tuple[9] = Integer.toString(actions[1]).getBytes();
/*      */                             
/* 2899 */                             tuple[10] = Integer.toString(actions[0]).getBytes();
/*      */                             
/* 2901 */                             tuple[11] = null;
/* 2902 */                             tuple[12] = null;
/* 2903 */                             tuple[13] = Integer.toString(7).getBytes();
/*      */                             
/*      */ 
/*      */ 
/* 2907 */                             tuples.add(new ByteArrayRow(tuple, DatabaseMetaData.this.getExceptionInterceptor()));
/* 2908 */                             keySeq++;
/*      */                           }
/*      */                         }
/*      */                       }
/*      */                     }
/*      */                   }
/*      */                 }
/*      */               }
/* 2916 */             } finally { if (fkresults != null) {
/*      */                 try {
/* 2918 */                   fkresults.close();
/*      */                 } catch (Exception sqlEx) {
/* 2920 */                   AssertionFailedException.shouldNotHappen(sqlEx);
/*      */                 }
/*      */                 
/*      */ 
/* 2924 */                 fkresults = null;
/*      */               }
/*      */             }
/*      */           }
/*      */         }.doForAll();
/*      */       } finally {
/* 2930 */         if (stmt != null) {
/* 2931 */           stmt.close();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2936 */     ResultSet results = buildResultSet(fields, tuples);
/*      */     
/* 2938 */     return results;
/*      */   }
/*      */   
/*      */   protected Field[] createFkMetadataFields() {
/* 2942 */     Field[] fields = new Field[14];
/* 2943 */     fields[0] = new Field("", "PKTABLE_CAT", 1, 255);
/* 2944 */     fields[1] = new Field("", "PKTABLE_SCHEM", 1, 0);
/* 2945 */     fields[2] = new Field("", "PKTABLE_NAME", 1, 255);
/* 2946 */     fields[3] = new Field("", "PKCOLUMN_NAME", 1, 32);
/* 2947 */     fields[4] = new Field("", "FKTABLE_CAT", 1, 255);
/* 2948 */     fields[5] = new Field("", "FKTABLE_SCHEM", 1, 0);
/* 2949 */     fields[6] = new Field("", "FKTABLE_NAME", 1, 255);
/* 2950 */     fields[7] = new Field("", "FKCOLUMN_NAME", 1, 32);
/* 2951 */     fields[8] = new Field("", "KEY_SEQ", 5, 2);
/* 2952 */     fields[9] = new Field("", "UPDATE_RULE", 5, 2);
/* 2953 */     fields[10] = new Field("", "DELETE_RULE", 5, 2);
/* 2954 */     fields[11] = new Field("", "FK_NAME", 1, 0);
/* 2955 */     fields[12] = new Field("", "PK_NAME", 1, 0);
/* 2956 */     fields[13] = new Field("", "DEFERRABILITY", 5, 2);
/* 2957 */     return fields;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getDatabaseMajorVersion()
/*      */     throws SQLException
/*      */   {
/* 2964 */     return this.conn.getServerMajorVersion();
/*      */   }
/*      */   
/*      */ 
/*      */   public int getDatabaseMinorVersion()
/*      */     throws SQLException
/*      */   {
/* 2971 */     return this.conn.getServerMinorVersion();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDatabaseProductName()
/*      */     throws SQLException
/*      */   {
/* 2982 */     return "MySQL";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDatabaseProductVersion()
/*      */     throws SQLException
/*      */   {
/* 2993 */     return this.conn.getServerVersion();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getDefaultTransactionIsolation()
/*      */     throws SQLException
/*      */   {
/* 3006 */     if (this.conn.supportsIsolationLevel()) {
/* 3007 */       return 2;
/*      */     }
/*      */     
/* 3010 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getDriverMajorVersion()
/*      */   {
/* 3019 */     return NonRegisteringDriver.getMajorVersionInternal();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getDriverMinorVersion()
/*      */   {
/* 3028 */     return NonRegisteringDriver.getMinorVersionInternal();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDriverName()
/*      */     throws SQLException
/*      */   {
/* 3039 */     return "MySQL-AB JDBC Driver";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDriverVersion()
/*      */     throws SQLException
/*      */   {
/* 3050 */     return "mysql-connector-java-5.1.19 ( Revision: tonci.grgin@oracle.com-20111003110438-qfydx066wsbydkbw )";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getExportedKeys(String catalog, String schema, final String table)
/*      */     throws SQLException
/*      */   {
/* 3114 */     if (table == null) {
/* 3115 */       throw SQLError.createSQLException("Table not specified.", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 3119 */     Field[] fields = createFkMetadataFields();
/*      */     
/* 3121 */     final ArrayList rows = new ArrayList();
/*      */     
/* 3123 */     if (this.conn.versionMeetsMinimum(3, 23, 0))
/*      */     {
/* 3125 */       final java.sql.Statement stmt = this.conn.getMetadataSafeStatement();
/*      */       
/*      */       try
/*      */       {
/* 3129 */         new IterateBlock(getCatalogIterator(catalog)) {
/*      */           void forEach(Object catalogStr) throws SQLException {
/* 3131 */             ResultSet fkresults = null;
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */             try
/*      */             {
/* 3138 */               if (DatabaseMetaData.this.conn.versionMeetsMinimum(3, 23, 50))
/*      */               {
/*      */ 
/* 3141 */                 fkresults = DatabaseMetaData.this.extractForeignKeyFromCreateTable(catalogStr.toString(), null);
/*      */               }
/*      */               else {
/* 3144 */                 StringBuffer queryBuf = new StringBuffer("SHOW TABLE STATUS FROM ");
/*      */                 
/* 3146 */                 queryBuf.append(DatabaseMetaData.this.quotedId);
/* 3147 */                 queryBuf.append(catalogStr.toString());
/* 3148 */                 queryBuf.append(DatabaseMetaData.this.quotedId);
/*      */                 
/* 3150 */                 fkresults = stmt.executeQuery(queryBuf.toString());
/*      */               }
/*      */               
/*      */ 
/*      */ 
/* 3155 */               String tableNameWithCase = DatabaseMetaData.this.getTableNameWithCase(table);
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3161 */               while (fkresults.next()) {
/* 3162 */                 String tableType = fkresults.getString("Type");
/*      */                 
/* 3164 */                 if ((tableType != null) && ((tableType.equalsIgnoreCase("innodb")) || (tableType.equalsIgnoreCase("SUPPORTS_FK"))))
/*      */                 {
/*      */ 
/*      */ 
/* 3168 */                   String comment = fkresults.getString("Comment").trim();
/*      */                   
/*      */ 
/* 3171 */                   if (comment != null) {
/* 3172 */                     StringTokenizer commentTokens = new StringTokenizer(comment, ";", false);
/*      */                     
/*      */ 
/* 3175 */                     if (commentTokens.hasMoreTokens()) {
/* 3176 */                       commentTokens.nextToken();
/*      */                       
/*      */ 
/*      */ 
/*      */ 
/* 3181 */                       while (commentTokens.hasMoreTokens()) {
/* 3182 */                         String keys = commentTokens.nextToken();
/*      */                         
/* 3184 */                         DatabaseMetaData.this.getExportKeyResults(catalogStr.toString(), tableNameWithCase, keys, rows, fkresults.getString("Name"));
/*      */                       }
/*      */                       
/*      */                     }
/*      */                     
/*      */                   }
/*      */                   
/*      */                 }
/*      */                 
/*      */               }
/*      */               
/*      */             }
/*      */             finally
/*      */             {
/* 3198 */               if (fkresults != null) {
/*      */                 try {
/* 3200 */                   fkresults.close();
/*      */                 } catch (SQLException sqlEx) {
/* 3202 */                   AssertionFailedException.shouldNotHappen(sqlEx);
/*      */                 }
/*      */                 
/*      */ 
/* 3206 */                 fkresults = null;
/*      */               }
/*      */             }
/*      */           }
/*      */         }.doForAll();
/*      */       } finally {
/* 3212 */         if (stmt != null) {
/* 3213 */           stmt.close();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 3218 */     ResultSet results = buildResultSet(fields, rows);
/*      */     
/* 3220 */     return results;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void getExportKeyResults(String catalog, String exportingTable, String keysComment, List tuples, String fkTableName)
/*      */     throws SQLException
/*      */   {
/* 3244 */     getResultsImpl(catalog, exportingTable, keysComment, tuples, fkTableName, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getExtraNameCharacters()
/*      */     throws SQLException
/*      */   {
/* 3257 */     return "#@";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int[] getForeignKeyActions(String commentString)
/*      */   {
/* 3270 */     int[] actions = { 3, 3 };
/*      */     
/*      */ 
/*      */ 
/* 3274 */     int lastParenIndex = commentString.lastIndexOf(")");
/*      */     
/* 3276 */     if (lastParenIndex != commentString.length() - 1) {
/* 3277 */       String cascadeOptions = commentString.substring(lastParenIndex + 1).trim().toUpperCase(Locale.ENGLISH);
/*      */       
/*      */ 
/* 3280 */       actions[0] = getCascadeDeleteOption(cascadeOptions);
/* 3281 */       actions[1] = getCascadeUpdateOption(cascadeOptions);
/*      */     }
/*      */     
/* 3284 */     return actions;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getIdentifierQuoteString()
/*      */     throws SQLException
/*      */   {
/* 3297 */     if (this.conn.supportsQuotedIdentifiers()) {
/* 3298 */       if (!this.conn.useAnsiQuotedIdentifiers()) {
/* 3299 */         return "`";
/*      */       }
/*      */       
/* 3302 */       return "\"";
/*      */     }
/*      */     
/* 3305 */     return " ";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getImportedKeys(String catalog, String schema, final String table)
/*      */     throws SQLException
/*      */   {
/* 3369 */     if (table == null) {
/* 3370 */       throw SQLError.createSQLException("Table not specified.", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 3374 */     Field[] fields = createFkMetadataFields();
/*      */     
/* 3376 */     final ArrayList rows = new ArrayList();
/*      */     
/* 3378 */     if (this.conn.versionMeetsMinimum(3, 23, 0))
/*      */     {
/* 3380 */       final java.sql.Statement stmt = this.conn.getMetadataSafeStatement();
/*      */       
/*      */       try
/*      */       {
/* 3384 */         new IterateBlock(getCatalogIterator(catalog)) {
/*      */           void forEach(Object catalogStr) throws SQLException {
/* 3386 */             ResultSet fkresults = null;
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */             try
/*      */             {
/* 3393 */               if (DatabaseMetaData.this.conn.versionMeetsMinimum(3, 23, 50))
/*      */               {
/*      */ 
/* 3396 */                 fkresults = DatabaseMetaData.this.extractForeignKeyFromCreateTable(catalogStr.toString(), table);
/*      */               }
/*      */               else {
/* 3399 */                 StringBuffer queryBuf = new StringBuffer("SHOW TABLE STATUS ");
/*      */                 
/* 3401 */                 queryBuf.append(" FROM ");
/* 3402 */                 queryBuf.append(DatabaseMetaData.this.quotedId);
/* 3403 */                 queryBuf.append(catalogStr.toString());
/* 3404 */                 queryBuf.append(DatabaseMetaData.this.quotedId);
/* 3405 */                 queryBuf.append(" LIKE '");
/* 3406 */                 queryBuf.append(table);
/* 3407 */                 queryBuf.append("'");
/*      */                 
/* 3409 */                 fkresults = stmt.executeQuery(queryBuf.toString());
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3417 */               while (fkresults.next()) {
/* 3418 */                 String tableType = fkresults.getString("Type");
/*      */                 
/* 3420 */                 if ((tableType != null) && ((tableType.equalsIgnoreCase("innodb")) || (tableType.equalsIgnoreCase("SUPPORTS_FK"))))
/*      */                 {
/*      */ 
/*      */ 
/* 3424 */                   String comment = fkresults.getString("Comment").trim();
/*      */                   
/*      */ 
/* 3427 */                   if (comment != null) {
/* 3428 */                     StringTokenizer commentTokens = new StringTokenizer(comment, ";", false);
/*      */                     
/*      */ 
/* 3431 */                     if (commentTokens.hasMoreTokens()) {
/* 3432 */                       commentTokens.nextToken();
/*      */                       
/*      */ 
/*      */ 
/*      */ 
/* 3437 */                       while (commentTokens.hasMoreTokens()) {
/* 3438 */                         String keys = commentTokens.nextToken();
/*      */                         
/* 3440 */                         DatabaseMetaData.this.getImportKeyResults(catalogStr.toString(), table, keys, rows);
/*      */                       }
/*      */                     }
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*      */             finally
/*      */             {
/* 3449 */               if (fkresults != null) {
/*      */                 try {
/* 3451 */                   fkresults.close();
/*      */                 } catch (SQLException sqlEx) {
/* 3453 */                   AssertionFailedException.shouldNotHappen(sqlEx);
/*      */                 }
/*      */                 
/*      */ 
/* 3457 */                 fkresults = null;
/*      */               }
/*      */             }
/*      */           }
/*      */         }.doForAll();
/*      */       } finally {
/* 3463 */         if (stmt != null) {
/* 3464 */           stmt.close();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 3469 */     ResultSet results = buildResultSet(fields, rows);
/*      */     
/* 3471 */     return results;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void getImportKeyResults(String catalog, String importingTable, String keysComment, List tuples)
/*      */     throws SQLException
/*      */   {
/* 3493 */     getResultsImpl(catalog, importingTable, keysComment, tuples, null, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getIndexInfo(String catalog, String schema, final String table, final boolean unique, boolean approximate)
/*      */     throws SQLException
/*      */   {
/* 3564 */     Field[] fields = createIndexInfoFields();
/*      */     
/* 3566 */     final ArrayList rows = new ArrayList();
/* 3567 */     final java.sql.Statement stmt = this.conn.getMetadataSafeStatement();
/*      */     
/*      */     try
/*      */     {
/* 3571 */       new IterateBlock(getCatalogIterator(catalog))
/*      */       {
/*      */         void forEach(Object catalogStr) throws SQLException {
/* 3574 */           ResultSet results = null;
/*      */           try
/*      */           {
/* 3577 */             StringBuffer queryBuf = new StringBuffer("SHOW INDEX FROM ");
/*      */             
/* 3579 */             queryBuf.append(DatabaseMetaData.this.quotedId);
/* 3580 */             queryBuf.append(table);
/* 3581 */             queryBuf.append(DatabaseMetaData.this.quotedId);
/* 3582 */             queryBuf.append(" FROM ");
/* 3583 */             queryBuf.append(DatabaseMetaData.this.quotedId);
/* 3584 */             queryBuf.append(catalogStr.toString());
/* 3585 */             queryBuf.append(DatabaseMetaData.this.quotedId);
/*      */             try
/*      */             {
/* 3588 */               results = stmt.executeQuery(queryBuf.toString());
/*      */             } catch (SQLException sqlEx) {
/* 3590 */               int errorCode = sqlEx.getErrorCode();
/*      */               
/*      */ 
/*      */ 
/* 3594 */               if (!"42S02".equals(sqlEx.getSQLState()))
/*      */               {
/*      */ 
/* 3597 */                 if (errorCode != 1146) {
/* 3598 */                   throw sqlEx;
/*      */                 }
/*      */               }
/*      */             }
/*      */             
/* 3603 */             while ((results != null) && (results.next())) {
/* 3604 */               byte[][] row = new byte[14][];
/* 3605 */               row[0] = (catalogStr.toString() == null ? new byte[0] : DatabaseMetaData.this.s2b(catalogStr.toString()));
/*      */               
/*      */ 
/* 3608 */               row[1] = null;
/* 3609 */               row[2] = results.getBytes("Table");
/*      */               
/* 3611 */               boolean indexIsUnique = results.getInt("Non_unique") == 0;
/*      */               
/*      */ 
/* 3614 */               row[3] = (!indexIsUnique ? DatabaseMetaData.this.s2b("true") : DatabaseMetaData.this.s2b("false"));
/*      */               
/* 3616 */               row[4] = new byte[0];
/* 3617 */               row[5] = results.getBytes("Key_name");
/* 3618 */               row[6] = Integer.toString(3).getBytes();
/*      */               
/*      */ 
/* 3621 */               row[7] = results.getBytes("Seq_in_index");
/* 3622 */               row[8] = results.getBytes("Column_name");
/* 3623 */               row[9] = results.getBytes("Collation");
/*      */               
/*      */ 
/*      */ 
/* 3627 */               long cardinality = results.getLong("Cardinality");
/*      */               
/* 3629 */               if (cardinality > 2147483647L) {
/* 3630 */                 cardinality = 2147483647L;
/*      */               }
/*      */               
/* 3633 */               row[10] = DatabaseMetaData.this.s2b(String.valueOf(cardinality));
/* 3634 */               row[11] = DatabaseMetaData.this.s2b("0");
/* 3635 */               row[12] = null;
/*      */               
/* 3637 */               if (unique) {
/* 3638 */                 if (indexIsUnique) {
/* 3639 */                   rows.add(new ByteArrayRow(row, DatabaseMetaData.this.getExceptionInterceptor()));
/*      */                 }
/*      */               }
/*      */               else {
/* 3643 */                 rows.add(new ByteArrayRow(row, DatabaseMetaData.this.getExceptionInterceptor()));
/*      */               }
/*      */             }
/*      */           } finally {
/* 3647 */             if (results != null) {
/*      */               try {
/* 3649 */                 results.close();
/*      */               }
/*      */               catch (Exception ex) {}
/*      */               
/*      */ 
/* 3654 */               results = null;
/*      */             }
/*      */             
/*      */           }
/*      */         }
/* 3659 */       }.doForAll();
/* 3660 */       ResultSet indexInfo = buildResultSet(fields, rows);
/*      */       
/* 3662 */       return indexInfo;
/*      */     } finally {
/* 3664 */       if (stmt != null) {
/* 3665 */         stmt.close();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected Field[] createIndexInfoFields() {
/* 3671 */     Field[] fields = new Field[13];
/* 3672 */     fields[0] = new Field("", "TABLE_CAT", 1, 255);
/* 3673 */     fields[1] = new Field("", "TABLE_SCHEM", 1, 0);
/* 3674 */     fields[2] = new Field("", "TABLE_NAME", 1, 255);
/* 3675 */     fields[3] = new Field("", "NON_UNIQUE", 16, 4);
/* 3676 */     fields[4] = new Field("", "INDEX_QUALIFIER", 1, 1);
/* 3677 */     fields[5] = new Field("", "INDEX_NAME", 1, 32);
/* 3678 */     fields[6] = new Field("", "TYPE", 5, 32);
/* 3679 */     fields[7] = new Field("", "ORDINAL_POSITION", 5, 5);
/* 3680 */     fields[8] = new Field("", "COLUMN_NAME", 1, 32);
/* 3681 */     fields[9] = new Field("", "ASC_OR_DESC", 1, 1);
/* 3682 */     fields[10] = new Field("", "CARDINALITY", 4, 20);
/* 3683 */     fields[11] = new Field("", "PAGES", 4, 10);
/* 3684 */     fields[12] = new Field("", "FILTER_CONDITION", 1, 32);
/* 3685 */     return fields;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getJDBCMajorVersion()
/*      */     throws SQLException
/*      */   {
/* 3692 */     return 4;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getJDBCMinorVersion()
/*      */     throws SQLException
/*      */   {
/* 3699 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxBinaryLiteralLength()
/*      */     throws SQLException
/*      */   {
/* 3710 */     return 16777208;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxCatalogNameLength()
/*      */     throws SQLException
/*      */   {
/* 3721 */     return 32;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxCharLiteralLength()
/*      */     throws SQLException
/*      */   {
/* 3732 */     return 16777208;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxColumnNameLength()
/*      */     throws SQLException
/*      */   {
/* 3743 */     return 64;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxColumnsInGroupBy()
/*      */     throws SQLException
/*      */   {
/* 3754 */     return 64;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxColumnsInIndex()
/*      */     throws SQLException
/*      */   {
/* 3765 */     return 16;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxColumnsInOrderBy()
/*      */     throws SQLException
/*      */   {
/* 3776 */     return 64;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxColumnsInSelect()
/*      */     throws SQLException
/*      */   {
/* 3787 */     return 256;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxColumnsInTable()
/*      */     throws SQLException
/*      */   {
/* 3798 */     return 512;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxConnections()
/*      */     throws SQLException
/*      */   {
/* 3809 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxCursorNameLength()
/*      */     throws SQLException
/*      */   {
/* 3820 */     return 64;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxIndexLength()
/*      */     throws SQLException
/*      */   {
/* 3831 */     return 256;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxProcedureNameLength()
/*      */     throws SQLException
/*      */   {
/* 3842 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxRowSize()
/*      */     throws SQLException
/*      */   {
/* 3853 */     return 2147483639;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxSchemaNameLength()
/*      */     throws SQLException
/*      */   {
/* 3864 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxStatementLength()
/*      */     throws SQLException
/*      */   {
/* 3875 */     return MysqlIO.getMaxBuf() - 4;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxStatements()
/*      */     throws SQLException
/*      */   {
/* 3886 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxTableNameLength()
/*      */     throws SQLException
/*      */   {
/* 3897 */     return 64;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxTablesInSelect()
/*      */     throws SQLException
/*      */   {
/* 3908 */     return 256;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxUserNameLength()
/*      */     throws SQLException
/*      */   {
/* 3919 */     return 16;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getNumericFunctions()
/*      */     throws SQLException
/*      */   {
/* 3930 */     return "ABS,ACOS,ASIN,ATAN,ATAN2,BIT_COUNT,CEILING,COS,COT,DEGREES,EXP,FLOOR,LOG,LOG10,MAX,MIN,MOD,PI,POW,POWER,RADIANS,RAND,ROUND,SIN,SQRT,TAN,TRUNCATE";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getPrimaryKeys(String catalog, String schema, final String table)
/*      */     throws SQLException
/*      */   {
/* 3962 */     Field[] fields = new Field[6];
/* 3963 */     fields[0] = new Field("", "TABLE_CAT", 1, 255);
/* 3964 */     fields[1] = new Field("", "TABLE_SCHEM", 1, 0);
/* 3965 */     fields[2] = new Field("", "TABLE_NAME", 1, 255);
/* 3966 */     fields[3] = new Field("", "COLUMN_NAME", 1, 32);
/* 3967 */     fields[4] = new Field("", "KEY_SEQ", 5, 5);
/* 3968 */     fields[5] = new Field("", "PK_NAME", 1, 32);
/*      */     
/* 3970 */     if (table == null) {
/* 3971 */       throw SQLError.createSQLException("Table not specified.", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 3975 */     final ArrayList rows = new ArrayList();
/* 3976 */     final java.sql.Statement stmt = this.conn.getMetadataSafeStatement();
/*      */     
/*      */     try
/*      */     {
/* 3980 */       new IterateBlock(getCatalogIterator(catalog)) {
/*      */         void forEach(Object catalogStr) throws SQLException {
/* 3982 */           ResultSet rs = null;
/*      */           
/*      */           try
/*      */           {
/* 3986 */             StringBuffer queryBuf = new StringBuffer("SHOW KEYS FROM ");
/*      */             
/* 3988 */             queryBuf.append(DatabaseMetaData.this.quotedId);
/* 3989 */             queryBuf.append(table);
/* 3990 */             queryBuf.append(DatabaseMetaData.this.quotedId);
/* 3991 */             queryBuf.append(" FROM ");
/* 3992 */             queryBuf.append(DatabaseMetaData.this.quotedId);
/* 3993 */             queryBuf.append(catalogStr.toString());
/* 3994 */             queryBuf.append(DatabaseMetaData.this.quotedId);
/*      */             
/* 3996 */             rs = stmt.executeQuery(queryBuf.toString());
/*      */             
/* 3998 */             TreeMap sortMap = new TreeMap();
/*      */             
/* 4000 */             while (rs.next()) {
/* 4001 */               String keyType = rs.getString("Key_name");
/*      */               
/* 4003 */               if ((keyType != null) && (
/* 4004 */                 (keyType.equalsIgnoreCase("PRIMARY")) || (keyType.equalsIgnoreCase("PRI"))))
/*      */               {
/* 4006 */                 byte[][] tuple = new byte[6][];
/* 4007 */                 tuple[0] = (catalogStr.toString() == null ? new byte[0] : DatabaseMetaData.this.s2b(catalogStr.toString()));
/*      */                 
/* 4009 */                 tuple[1] = null;
/* 4010 */                 tuple[2] = DatabaseMetaData.this.s2b(table);
/*      */                 
/* 4012 */                 String columnName = rs.getString("Column_name");
/*      */                 
/* 4014 */                 tuple[3] = DatabaseMetaData.this.s2b(columnName);
/* 4015 */                 tuple[4] = DatabaseMetaData.this.s2b(rs.getString("Seq_in_index"));
/* 4016 */                 tuple[5] = DatabaseMetaData.this.s2b(keyType);
/* 4017 */                 sortMap.put(columnName, tuple);
/*      */               }
/*      */             }
/*      */             
/*      */ 
/*      */ 
/* 4023 */             Iterator sortedIterator = sortMap.values().iterator();
/*      */             
/* 4025 */             while (sortedIterator.hasNext()) {
/* 4026 */               rows.add(new ByteArrayRow((byte[][])sortedIterator.next(), DatabaseMetaData.this.getExceptionInterceptor()));
/*      */             }
/*      */           }
/*      */           finally {
/* 4030 */             if (rs != null) {
/*      */               try {
/* 4032 */                 rs.close();
/*      */               }
/*      */               catch (Exception ex) {}
/*      */               
/*      */ 
/* 4037 */               rs = null;
/*      */             }
/*      */           }
/*      */         }
/*      */       }.doForAll();
/*      */     } finally {
/* 4043 */       if (stmt != null) {
/* 4044 */         stmt.close();
/*      */       }
/*      */     }
/*      */     
/* 4048 */     ResultSet results = buildResultSet(fields, rows);
/*      */     
/* 4050 */     return results;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getProcedureColumns(String catalog, String schemaPattern, String procedureNamePattern, String columnNamePattern)
/*      */     throws SQLException
/*      */   {
/* 4122 */     Field[] fields = createProcedureColumnsFields();
/*      */     
/* 4124 */     return getProcedureOrFunctionColumns(fields, catalog, schemaPattern, procedureNamePattern, columnNamePattern, true, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected Field[] createProcedureColumnsFields()
/*      */   {
/* 4131 */     Field[] fields = new Field[13];
/*      */     
/* 4133 */     fields[0] = new Field("", "PROCEDURE_CAT", 1, 512);
/* 4134 */     fields[1] = new Field("", "PROCEDURE_SCHEM", 1, 512);
/* 4135 */     fields[2] = new Field("", "PROCEDURE_NAME", 1, 512);
/* 4136 */     fields[3] = new Field("", "COLUMN_NAME", 1, 512);
/* 4137 */     fields[4] = new Field("", "COLUMN_TYPE", 1, 64);
/* 4138 */     fields[5] = new Field("", "DATA_TYPE", 5, 6);
/* 4139 */     fields[6] = new Field("", "TYPE_NAME", 1, 64);
/* 4140 */     fields[7] = new Field("", "PRECISION", 4, 12);
/* 4141 */     fields[8] = new Field("", "LENGTH", 4, 12);
/* 4142 */     fields[9] = new Field("", "SCALE", 5, 12);
/* 4143 */     fields[10] = new Field("", "RADIX", 5, 6);
/* 4144 */     fields[11] = new Field("", "NULLABLE", 5, 6);
/* 4145 */     fields[12] = new Field("", "REMARKS", 1, 512);
/* 4146 */     return fields;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ResultSet getProcedureOrFunctionColumns(Field[] fields, String catalog, String schemaPattern, String procedureOrFunctionNamePattern, String columnNamePattern, boolean returnProcedures, boolean returnFunctions)
/*      */     throws SQLException
/*      */   {
/* 4155 */     List proceduresToExtractList = new ArrayList();
/*      */     
/* 4157 */     ResultSet procedureNameRs = null;
/*      */     
/* 4159 */     if (supportsStoredProcedures())
/*      */     {
/*      */       try
/*      */       {
/* 4163 */         String tmpProcedureOrFunctionNamePattern = null;
/*      */         
/* 4165 */         if ((procedureOrFunctionNamePattern != null) && (procedureOrFunctionNamePattern != "%")) {
/* 4166 */           tmpProcedureOrFunctionNamePattern = StringUtils.sanitizeProcOrFuncName(procedureOrFunctionNamePattern);
/*      */         }
/*      */         
/*      */ 
/* 4170 */         if (tmpProcedureOrFunctionNamePattern == null) {
/* 4171 */           tmpProcedureOrFunctionNamePattern = procedureOrFunctionNamePattern;
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 4176 */           String tmpCatalog = catalog;
/* 4177 */           List parseList = StringUtils.splitDBdotName(tmpProcedureOrFunctionNamePattern, tmpCatalog, this.quotedId, this.conn.isNoBackslashEscapesSet());
/*      */           
/*      */ 
/*      */ 
/* 4181 */           if (parseList.size() == 2) {
/* 4182 */             tmpCatalog = (String)parseList.get(0);
/* 4183 */             tmpProcedureOrFunctionNamePattern = (String)parseList.get(1);
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 4189 */         procedureNameRs = getProceduresAndOrFunctions(createFieldMetadataForGetProcedures(), catalog, schemaPattern, tmpProcedureOrFunctionNamePattern, returnProcedures, returnFunctions);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4201 */         String tmpstrPNameRs = null;
/* 4202 */         String tmpstrCatNameRs = null;
/*      */         
/* 4204 */         boolean hasResults = false;
/* 4205 */         while (procedureNameRs.next()) {
/* 4206 */           tmpstrCatNameRs = procedureNameRs.getString(1);
/* 4207 */           tmpstrPNameRs = procedureNameRs.getString(3);
/*      */           
/* 4209 */           if (((!tmpstrCatNameRs.startsWith(this.quotedId)) || (!tmpstrCatNameRs.endsWith(this.quotedId))) && ((!tmpstrCatNameRs.startsWith("\"")) || (!tmpstrCatNameRs.endsWith("\""))))
/*      */           {
/* 4211 */             tmpstrCatNameRs = this.quotedId + tmpstrCatNameRs + this.quotedId;
/*      */           }
/* 4213 */           if (((!tmpstrPNameRs.startsWith(this.quotedId)) || (!tmpstrPNameRs.endsWith(this.quotedId))) && ((!tmpstrPNameRs.startsWith("\"")) || (!tmpstrPNameRs.endsWith("\""))))
/*      */           {
/* 4215 */             tmpstrPNameRs = this.quotedId + tmpstrPNameRs + this.quotedId;
/*      */           }
/*      */           
/* 4218 */           if (proceduresToExtractList.indexOf(tmpstrCatNameRs + "." + tmpstrPNameRs) < 0) {
/* 4219 */             proceduresToExtractList.add(tmpstrCatNameRs + "." + tmpstrPNameRs);
/*      */           }
/* 4221 */           hasResults = true;
/*      */         }
/*      */         
/*      */ 
/* 4225 */         if (hasResults)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4232 */           Collections.sort(proceduresToExtractList);
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/*      */ 
/* 4241 */         SQLException rethrowSqlEx = null;
/*      */         
/* 4243 */         if (procedureNameRs != null) {
/*      */           try {
/* 4245 */             procedureNameRs.close();
/*      */           } catch (SQLException sqlEx) {
/* 4247 */             rethrowSqlEx = sqlEx;
/*      */           }
/*      */         }
/*      */         
/* 4251 */         if (rethrowSqlEx != null) {
/* 4252 */           throw rethrowSqlEx;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 4257 */     ArrayList resultRows = new ArrayList();
/* 4258 */     int idx = 0;
/* 4259 */     String procNameToCall = "";
/*      */     
/* 4261 */     for (Iterator iter = proceduresToExtractList.iterator(); iter.hasNext();) {
/* 4262 */       String procName = (String)iter.next();
/*      */       
/*      */ 
/* 4265 */       if (!" ".equals(this.quotedId)) {
/* 4266 */         idx = StringUtils.indexOfIgnoreCaseRespectQuotes(0, procName, ".", this.quotedId.charAt(0), !this.conn.isNoBackslashEscapesSet());
/*      */       }
/*      */       else
/*      */       {
/* 4270 */         idx = procName.indexOf(".");
/*      */       }
/*      */       
/* 4273 */       if (idx > 0) {
/* 4274 */         catalog = procName.substring(0, idx);
/* 4275 */         if ((this.quotedId != " ") && (catalog.startsWith(this.quotedId)) && (catalog.endsWith(this.quotedId))) {
/* 4276 */           catalog = procName.substring(1, catalog.length() - 1);
/*      */         }
/* 4278 */         procNameToCall = procName;
/*      */       }
/*      */       else {
/* 4281 */         procNameToCall = procName;
/*      */       }
/* 4283 */       getCallStmtParameterTypes(catalog, procNameToCall, columnNamePattern, resultRows, fields.length == 17);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 4288 */     return buildResultSet(fields, resultRows);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getProcedures(String catalog, String schemaPattern, String procedureNamePattern)
/*      */     throws SQLException
/*      */   {
/* 4334 */     Field[] fields = createFieldMetadataForGetProcedures();
/*      */     
/* 4336 */     return getProceduresAndOrFunctions(fields, catalog, schemaPattern, procedureNamePattern, true, true);
/*      */   }
/*      */   
/*      */   private Field[] createFieldMetadataForGetProcedures()
/*      */   {
/* 4341 */     Field[] fields = new Field[9];
/* 4342 */     fields[0] = new Field("", "PROCEDURE_CAT", 1, 255);
/* 4343 */     fields[1] = new Field("", "PROCEDURE_SCHEM", 1, 255);
/* 4344 */     fields[2] = new Field("", "PROCEDURE_NAME", 1, 255);
/* 4345 */     fields[3] = new Field("", "reserved1", 1, 0);
/* 4346 */     fields[4] = new Field("", "reserved2", 1, 0);
/* 4347 */     fields[5] = new Field("", "reserved3", 1, 0);
/* 4348 */     fields[6] = new Field("", "REMARKS", 1, 255);
/* 4349 */     fields[7] = new Field("", "PROCEDURE_TYPE", 5, 6);
/* 4350 */     fields[8] = new Field("", "SPECIFIC_NAME", 1, 255);
/*      */     
/* 4352 */     return fields;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ResultSet getProceduresAndOrFunctions(final Field[] fields, String catalog, String schemaPattern, String procedureNamePattern, final boolean returnProcedures, final boolean returnFunctions)
/*      */     throws SQLException
/*      */   {
/* 4362 */     if ((procedureNamePattern == null) || (procedureNamePattern.length() == 0))
/*      */     {
/* 4364 */       if (this.conn.getNullNamePatternMatchesAll()) {
/* 4365 */         procedureNamePattern = "%";
/*      */       } else {
/* 4367 */         throw SQLError.createSQLException("Procedure name pattern can not be NULL or empty.", "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 4373 */     final ArrayList procedureRows = new ArrayList();
/*      */     
/* 4375 */     if (supportsStoredProcedures()) {
/* 4376 */       final String procNamePattern = procedureNamePattern;
/*      */       
/* 4378 */       final Map procedureRowsOrderedByName = new TreeMap();
/*      */       
/* 4380 */       new IterateBlock(getCatalogIterator(catalog)) {
/*      */         void forEach(Object catalogStr) throws SQLException {
/* 4382 */           String db = catalogStr.toString();
/*      */           
/* 4384 */           boolean fromSelect = false;
/* 4385 */           ResultSet proceduresRs = null;
/* 4386 */           boolean needsClientFiltering = true;
/* 4387 */           PreparedStatement proceduresStmt = DatabaseMetaData.this.conn.clientPrepareStatement("SELECT name, type, comment FROM mysql.proc WHERE name like ? and db <=> ? ORDER BY name");
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           try
/*      */           {
/* 4396 */             boolean hasTypeColumn = false;
/*      */             
/* 4398 */             if (db != null) {
/* 4399 */               if (DatabaseMetaData.this.conn.lowerCaseTableNames()) {
/* 4400 */                 db = db.toLowerCase();
/*      */               }
/* 4402 */               proceduresStmt.setString(2, db);
/*      */             } else {
/* 4404 */               proceduresStmt.setNull(2, 12);
/*      */             }
/*      */             
/* 4407 */             int nameIndex = 1;
/*      */             
/* 4409 */             if (proceduresStmt.getMaxRows() != 0) {
/* 4410 */               proceduresStmt.setMaxRows(0);
/*      */             }
/*      */             
/* 4413 */             proceduresStmt.setString(1, procNamePattern);
/*      */             try
/*      */             {
/* 4416 */               proceduresRs = proceduresStmt.executeQuery();
/* 4417 */               fromSelect = true;
/* 4418 */               needsClientFiltering = false;
/* 4419 */               hasTypeColumn = true;
/*      */ 
/*      */ 
/*      */             }
/*      */             catch (SQLException sqlEx)
/*      */             {
/*      */ 
/*      */ 
/* 4427 */               proceduresStmt.close();
/*      */               
/* 4429 */               fromSelect = false;
/*      */               
/* 4431 */               if (DatabaseMetaData.this.conn.versionMeetsMinimum(5, 0, 1)) {
/* 4432 */                 nameIndex = 2;
/*      */               } else {
/* 4434 */                 nameIndex = 1;
/*      */               }
/*      */               
/* 4437 */               proceduresStmt = DatabaseMetaData.this.conn.clientPrepareStatement("SHOW PROCEDURE STATUS LIKE ?");
/*      */               
/*      */ 
/* 4440 */               if (proceduresStmt.getMaxRows() != 0) {
/* 4441 */                 proceduresStmt.setMaxRows(0);
/*      */               }
/*      */               
/* 4444 */               proceduresStmt.setString(1, procNamePattern);
/*      */               
/* 4446 */               proceduresRs = proceduresStmt.executeQuery();
/*      */             }
/*      */             
/* 4449 */             if (returnProcedures) {
/* 4450 */               DatabaseMetaData.this.convertToJdbcProcedureList(fromSelect, db, proceduresRs, needsClientFiltering, db, procedureRowsOrderedByName, nameIndex);
/*      */             }
/*      */             
/*      */ 
/*      */ 
/* 4455 */             if (!hasTypeColumn)
/*      */             {
/* 4457 */               if (proceduresStmt != null) {
/* 4458 */                 proceduresStmt.close();
/*      */               }
/*      */               
/* 4461 */               proceduresStmt = DatabaseMetaData.this.conn.clientPrepareStatement("SHOW FUNCTION STATUS LIKE ?");
/*      */               
/*      */ 
/* 4464 */               if (proceduresStmt.getMaxRows() != 0) {
/* 4465 */                 proceduresStmt.setMaxRows(0);
/*      */               }
/*      */               
/* 4468 */               proceduresStmt.setString(1, procNamePattern);
/*      */               
/* 4470 */               proceduresRs = proceduresStmt.executeQuery();
/*      */             }
/*      */             
/*      */ 
/* 4474 */             if (returnFunctions) {
/* 4475 */               DatabaseMetaData.this.convertToJdbcFunctionList(db, proceduresRs, needsClientFiltering, db, procedureRowsOrderedByName, nameIndex, fields);
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4483 */             Iterator proceduresIter = procedureRowsOrderedByName.values().iterator();
/*      */             
/*      */ 
/* 4486 */             while (proceduresIter.hasNext()) {
/* 4487 */               procedureRows.add(proceduresIter.next());
/*      */             }
/*      */           } finally {
/* 4490 */             SQLException rethrowSqlEx = null;
/*      */             
/* 4492 */             if (proceduresRs != null) {
/*      */               try {
/* 4494 */                 proceduresRs.close();
/*      */               } catch (SQLException sqlEx) {
/* 4496 */                 rethrowSqlEx = sqlEx;
/*      */               }
/*      */             }
/*      */             
/* 4500 */             if (proceduresStmt != null) {
/*      */               try {
/* 4502 */                 proceduresStmt.close();
/*      */               } catch (SQLException sqlEx) {
/* 4504 */                 rethrowSqlEx = sqlEx;
/*      */               }
/*      */             }
/*      */             
/* 4508 */             if (rethrowSqlEx != null) {
/* 4509 */               throw rethrowSqlEx;
/*      */             }
/*      */           }
/*      */         }
/*      */       }.doForAll();
/*      */     }
/*      */     
/* 4516 */     return buildResultSet(fields, procedureRows);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getProcedureTerm()
/*      */     throws SQLException
/*      */   {
/* 4528 */     return "PROCEDURE";
/*      */   }
/*      */   
/*      */ 
/*      */   public int getResultSetHoldability()
/*      */     throws SQLException
/*      */   {
/* 4535 */     return 1;
/*      */   }
/*      */   
/*      */ 
/*      */   private void getResultsImpl(String catalog, String table, String keysComment, List tuples, String fkTableName, boolean isExport)
/*      */     throws SQLException
/*      */   {
/* 4542 */     LocalAndReferencedColumns parsedInfo = parseTableStatusIntoLocalAndReferencedColumns(keysComment);
/*      */     
/* 4544 */     if ((isExport) && (!parsedInfo.referencedTable.equals(table))) {
/* 4545 */       return;
/*      */     }
/*      */     
/* 4548 */     if (parsedInfo.localColumnsList.size() != parsedInfo.referencedColumnsList.size())
/*      */     {
/* 4550 */       throw SQLError.createSQLException("Error parsing foreign keys definition,number of local and referenced columns is not the same.", "S1000", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4556 */     Iterator localColumnNames = parsedInfo.localColumnsList.iterator();
/* 4557 */     Iterator referColumnNames = parsedInfo.referencedColumnsList.iterator();
/*      */     
/* 4559 */     int keySeqIndex = 1;
/*      */     
/* 4561 */     while (localColumnNames.hasNext()) {
/* 4562 */       byte[][] tuple = new byte[14][];
/* 4563 */       String lColumnName = removeQuotedId(localColumnNames.next().toString());
/*      */       
/* 4565 */       String rColumnName = removeQuotedId(referColumnNames.next().toString());
/*      */       
/* 4567 */       tuple[4] = (catalog == null ? new byte[0] : s2b(catalog));
/*      */       
/* 4569 */       tuple[5] = null;
/* 4570 */       tuple[6] = s2b(isExport ? fkTableName : table);
/* 4571 */       tuple[7] = s2b(lColumnName);
/* 4572 */       tuple[0] = s2b(parsedInfo.referencedCatalog);
/* 4573 */       tuple[1] = null;
/* 4574 */       tuple[2] = s2b(isExport ? table : parsedInfo.referencedTable);
/*      */       
/* 4576 */       tuple[3] = s2b(rColumnName);
/* 4577 */       tuple[8] = s2b(Integer.toString(keySeqIndex++));
/*      */       
/* 4579 */       int[] actions = getForeignKeyActions(keysComment);
/*      */       
/* 4581 */       tuple[9] = s2b(Integer.toString(actions[1]));
/* 4582 */       tuple[10] = s2b(Integer.toString(actions[0]));
/* 4583 */       tuple[11] = s2b(parsedInfo.constraintName);
/* 4584 */       tuple[12] = null;
/* 4585 */       tuple[13] = s2b(Integer.toString(7));
/*      */       
/* 4587 */       tuples.add(new ByteArrayRow(tuple, getExceptionInterceptor()));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getSchemas()
/*      */     throws SQLException
/*      */   {
/* 4607 */     Field[] fields = new Field[2];
/* 4608 */     fields[0] = new Field("", "TABLE_SCHEM", 1, 0);
/* 4609 */     fields[1] = new Field("", "TABLE_CATALOG", 1, 0);
/*      */     
/* 4611 */     ArrayList tuples = new ArrayList();
/* 4612 */     ResultSet results = buildResultSet(fields, tuples);
/*      */     
/* 4614 */     return results;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSchemaTerm()
/*      */     throws SQLException
/*      */   {
/* 4625 */     return "";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSearchStringEscape()
/*      */     throws SQLException
/*      */   {
/* 4643 */     return "\\";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSQLKeywords()
/*      */     throws SQLException
/*      */   {
/* 4655 */     return mysqlKeywordsThatArentSQL92;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getSQLStateType()
/*      */     throws SQLException
/*      */   {
/* 4662 */     if (this.conn.versionMeetsMinimum(4, 1, 0)) {
/* 4663 */       return 2;
/*      */     }
/*      */     
/* 4666 */     if (this.conn.getUseSqlStateCodes()) {
/* 4667 */       return 2;
/*      */     }
/*      */     
/* 4670 */     return 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getStringFunctions()
/*      */     throws SQLException
/*      */   {
/* 4681 */     return "ASCII,BIN,BIT_LENGTH,CHAR,CHARACTER_LENGTH,CHAR_LENGTH,CONCAT,CONCAT_WS,CONV,ELT,EXPORT_SET,FIELD,FIND_IN_SET,HEX,INSERT,INSTR,LCASE,LEFT,LENGTH,LOAD_FILE,LOCATE,LOCATE,LOWER,LPAD,LTRIM,MAKE_SET,MATCH,MID,OCT,OCTET_LENGTH,ORD,POSITION,QUOTE,REPEAT,REPLACE,REVERSE,RIGHT,RPAD,RTRIM,SOUNDEX,SPACE,STRCMP,SUBSTRING,SUBSTRING,SUBSTRING,SUBSTRING,SUBSTRING_INDEX,TRIM,UCASE,UPPER";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getSuperTables(String arg0, String arg1, String arg2)
/*      */     throws SQLException
/*      */   {
/* 4695 */     Field[] fields = new Field[4];
/* 4696 */     fields[0] = new Field("", "TABLE_CAT", 1, 32);
/* 4697 */     fields[1] = new Field("", "TABLE_SCHEM", 1, 32);
/* 4698 */     fields[2] = new Field("", "TABLE_NAME", 1, 32);
/* 4699 */     fields[3] = new Field("", "SUPERTABLE_NAME", 1, 32);
/*      */     
/* 4701 */     return buildResultSet(fields, new ArrayList());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ResultSet getSuperTypes(String arg0, String arg1, String arg2)
/*      */     throws SQLException
/*      */   {
/* 4709 */     Field[] fields = new Field[6];
/* 4710 */     fields[0] = new Field("", "TYPE_CAT", 1, 32);
/* 4711 */     fields[1] = new Field("", "TYPE_SCHEM", 1, 32);
/* 4712 */     fields[2] = new Field("", "TYPE_NAME", 1, 32);
/* 4713 */     fields[3] = new Field("", "SUPERTYPE_CAT", 1, 32);
/* 4714 */     fields[4] = new Field("", "SUPERTYPE_SCHEM", 1, 32);
/* 4715 */     fields[5] = new Field("", "SUPERTYPE_NAME", 1, 32);
/*      */     
/* 4717 */     return buildResultSet(fields, new ArrayList());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSystemFunctions()
/*      */     throws SQLException
/*      */   {
/* 4728 */     return "DATABASE,USER,SYSTEM_USER,SESSION_USER,PASSWORD,ENCRYPT,LAST_INSERT_ID,VERSION";
/*      */   }
/*      */   
/*      */   private String getTableNameWithCase(String table) {
/* 4732 */     String tableNameWithCase = this.conn.lowerCaseTableNames() ? table.toLowerCase() : table;
/*      */     
/*      */ 
/* 4735 */     return tableNameWithCase;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getTablePrivileges(String catalog, String schemaPattern, String tableNamePattern)
/*      */     throws SQLException
/*      */   {
/* 4775 */     if (tableNamePattern == null) {
/* 4776 */       if (this.conn.getNullNamePatternMatchesAll()) {
/* 4777 */         tableNamePattern = "%";
/*      */       } else {
/* 4779 */         throw SQLError.createSQLException("Table name pattern can not be NULL or empty.", "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 4785 */     Field[] fields = new Field[7];
/* 4786 */     fields[0] = new Field("", "TABLE_CAT", 1, 64);
/* 4787 */     fields[1] = new Field("", "TABLE_SCHEM", 1, 1);
/* 4788 */     fields[2] = new Field("", "TABLE_NAME", 1, 64);
/* 4789 */     fields[3] = new Field("", "GRANTOR", 1, 77);
/* 4790 */     fields[4] = new Field("", "GRANTEE", 1, 77);
/* 4791 */     fields[5] = new Field("", "PRIVILEGE", 1, 64);
/* 4792 */     fields[6] = new Field("", "IS_GRANTABLE", 1, 3);
/*      */     
/* 4794 */     StringBuffer grantQuery = new StringBuffer("SELECT host,db,table_name,grantor,user,table_priv from mysql.tables_priv ");
/*      */     
/* 4796 */     grantQuery.append(" WHERE ");
/*      */     
/* 4798 */     if ((catalog != null) && (catalog.length() != 0)) {
/* 4799 */       grantQuery.append(" db='");
/* 4800 */       grantQuery.append(catalog);
/* 4801 */       grantQuery.append("' AND ");
/*      */     }
/*      */     
/* 4804 */     grantQuery.append("table_name like '");
/* 4805 */     grantQuery.append(tableNamePattern);
/* 4806 */     grantQuery.append("'");
/*      */     
/* 4808 */     ResultSet results = null;
/* 4809 */     ArrayList grantRows = new ArrayList();
/* 4810 */     java.sql.Statement stmt = null;
/*      */     try
/*      */     {
/* 4813 */       stmt = this.conn.createStatement();
/* 4814 */       stmt.setEscapeProcessing(false);
/*      */       
/* 4816 */       results = stmt.executeQuery(grantQuery.toString());
/*      */       
/* 4818 */       while (results.next()) {
/* 4819 */         String host = results.getString(1);
/* 4820 */         String db = results.getString(2);
/* 4821 */         String table = results.getString(3);
/* 4822 */         String grantor = results.getString(4);
/* 4823 */         String user = results.getString(5);
/*      */         
/* 4825 */         if ((user == null) || (user.length() == 0)) {
/* 4826 */           user = "%";
/*      */         }
/*      */         
/* 4829 */         StringBuffer fullUser = new StringBuffer(user);
/*      */         
/* 4831 */         if ((host != null) && (this.conn.getUseHostsInPrivileges())) {
/* 4832 */           fullUser.append("@");
/* 4833 */           fullUser.append(host);
/*      */         }
/*      */         
/* 4836 */         String allPrivileges = results.getString(6);
/*      */         
/* 4838 */         if (allPrivileges != null) {
/* 4839 */           allPrivileges = allPrivileges.toUpperCase(Locale.ENGLISH);
/*      */           
/* 4841 */           StringTokenizer st = new StringTokenizer(allPrivileges, ",");
/*      */           
/* 4843 */           while (st.hasMoreTokens()) {
/* 4844 */             String privilege = st.nextToken().trim();
/*      */             
/*      */ 
/* 4847 */             ResultSet columnResults = null;
/*      */             try
/*      */             {
/* 4850 */               columnResults = getColumns(catalog, schemaPattern, table, "%");
/*      */               
/*      */ 
/* 4853 */               while (columnResults.next()) {
/* 4854 */                 byte[][] tuple = new byte[8][];
/* 4855 */                 tuple[0] = s2b(db);
/* 4856 */                 tuple[1] = null;
/* 4857 */                 tuple[2] = s2b(table);
/*      */                 
/* 4859 */                 if (grantor != null) {
/* 4860 */                   tuple[3] = s2b(grantor);
/*      */                 } else {
/* 4862 */                   tuple[3] = null;
/*      */                 }
/*      */                 
/* 4865 */                 tuple[4] = s2b(fullUser.toString());
/* 4866 */                 tuple[5] = s2b(privilege);
/* 4867 */                 tuple[6] = null;
/* 4868 */                 grantRows.add(new ByteArrayRow(tuple, getExceptionInterceptor()));
/*      */               }
/*      */             } finally {
/* 4871 */               if (columnResults != null) {
/*      */                 try {
/* 4873 */                   columnResults.close();
/*      */                 }
/*      */                 catch (Exception ex) {}
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     finally {
/* 4883 */       if (results != null) {
/*      */         try {
/* 4885 */           results.close();
/*      */         }
/*      */         catch (Exception ex) {}
/*      */         
/*      */ 
/* 4890 */         results = null;
/*      */       }
/*      */       
/* 4893 */       if (stmt != null) {
/*      */         try {
/* 4895 */           stmt.close();
/*      */         }
/*      */         catch (Exception ex) {}
/*      */         
/*      */ 
/* 4900 */         stmt = null;
/*      */       }
/*      */     }
/*      */     
/* 4904 */     return buildResultSet(fields, grantRows);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getTables(String catalog, String schemaPattern, String tableNamePattern, final String[] types)
/*      */     throws SQLException
/*      */   {
/* 4946 */     if (tableNamePattern == null) {
/* 4947 */       if (this.conn.getNullNamePatternMatchesAll()) {
/* 4948 */         tableNamePattern = "%";
/*      */       } else {
/* 4950 */         throw SQLError.createSQLException("Table name pattern can not be NULL or empty.", "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 4956 */     Field[] fields = new Field[5];
/* 4957 */     fields[0] = new Field("", "TABLE_CAT", 12, 255);
/* 4958 */     fields[1] = new Field("", "TABLE_SCHEM", 12, 0);
/* 4959 */     fields[2] = new Field("", "TABLE_NAME", 12, 255);
/* 4960 */     fields[3] = new Field("", "TABLE_TYPE", 12, 5);
/* 4961 */     fields[4] = new Field("", "REMARKS", 12, 0);
/*      */     
/* 4963 */     final ArrayList tuples = new ArrayList();
/*      */     
/* 4965 */     final java.sql.Statement stmt = this.conn.getMetadataSafeStatement();
/*      */     
/*      */ 
/* 4968 */     String tmpCat = "";
/*      */     
/* 4970 */     if ((catalog == null) || (catalog.length() == 0)) {
/* 4971 */       if (this.conn.getNullCatalogMeansCurrent()) {
/* 4972 */         tmpCat = this.database;
/*      */       }
/*      */     } else {
/* 4975 */       tmpCat = catalog;
/*      */     }
/*      */     
/* 4978 */     List parseList = StringUtils.splitDBdotName(tableNamePattern, tmpCat, this.quotedId, this.conn.isNoBackslashEscapesSet());
/*      */     String tableNamePat;
/*      */     final String tableNamePat;
/* 4981 */     if (parseList.size() == 2) {
/* 4982 */       tableNamePat = (String)parseList.get(1);
/*      */     } else {
/* 4984 */       tableNamePat = tableNamePattern;
/*      */     }
/*      */     
/* 4987 */     final boolean operatingOnInformationSchema = "information_schema".equalsIgnoreCase(catalog);
/*      */     
/*      */     try
/*      */     {
/* 4991 */       new IterateBlock(getCatalogIterator(catalog)) {
/*      */         void forEach(Object catalogStr) throws SQLException {
/* 4993 */           ResultSet results = null;
/*      */           
/*      */           try
/*      */           {
/* 4997 */             if (!DatabaseMetaData.this.conn.versionMeetsMinimum(5, 0, 2)) {
/*      */               try {
/* 4999 */                 results = stmt.executeQuery("SHOW TABLES FROM " + DatabaseMetaData.this.quotedId + catalogStr.toString() + DatabaseMetaData.this.quotedId + " LIKE '" + tableNamePat + "'");
/*      */ 
/*      */               }
/*      */               catch (SQLException sqlEx)
/*      */               {
/*      */ 
/* 5005 */                 if ("08S01".equals(sqlEx.getSQLState())) {
/* 5006 */                   throw sqlEx;
/*      */                 }
/*      */                 
/* 5009 */                 return;
/*      */               }
/*      */             } else {
/*      */               try {
/* 5013 */                 results = stmt.executeQuery("SHOW FULL TABLES FROM " + DatabaseMetaData.this.quotedId + catalogStr.toString() + DatabaseMetaData.this.quotedId + " LIKE '" + tableNamePat + "'");
/*      */ 
/*      */               }
/*      */               catch (SQLException sqlEx)
/*      */               {
/*      */ 
/* 5019 */                 if ("08S01".equals(sqlEx.getSQLState())) {
/* 5020 */                   throw sqlEx;
/*      */                 }
/*      */                 
/* 5023 */                 return;
/*      */               }
/*      */             }
/*      */             
/* 5027 */             boolean shouldReportTables = false;
/* 5028 */             boolean shouldReportViews = false;
/* 5029 */             boolean shouldReportSystemTables = false;
/*      */             
/* 5031 */             if ((types == null) || (types.length == 0)) {
/* 5032 */               shouldReportTables = true;
/* 5033 */               shouldReportViews = true;
/* 5034 */               shouldReportSystemTables = true;
/*      */             } else {
/* 5036 */               for (int i = 0; i < types.length; i++) {
/* 5037 */                 if ("TABLE".equalsIgnoreCase(types[i])) {
/* 5038 */                   shouldReportTables = true;
/*      */                 }
/*      */                 
/* 5041 */                 if ("VIEW".equalsIgnoreCase(types[i])) {
/* 5042 */                   shouldReportViews = true;
/*      */                 }
/*      */                 
/* 5045 */                 if ("SYSTEM TABLE".equalsIgnoreCase(types[i])) {
/* 5046 */                   shouldReportSystemTables = true;
/*      */                 }
/*      */               }
/*      */             }
/*      */             
/* 5051 */             int typeColumnIndex = 0;
/* 5052 */             boolean hasTableTypes = false;
/*      */             
/* 5054 */             if (DatabaseMetaData.this.conn.versionMeetsMinimum(5, 0, 2))
/*      */             {
/*      */               try
/*      */               {
/*      */ 
/* 5059 */                 typeColumnIndex = results.findColumn("table_type");
/*      */                 
/* 5061 */                 hasTableTypes = true;
/*      */ 
/*      */ 
/*      */               }
/*      */               catch (SQLException sqlEx)
/*      */               {
/*      */ 
/*      */ 
/*      */                 try
/*      */                 {
/*      */ 
/*      */ 
/* 5073 */                   typeColumnIndex = results.findColumn("Type");
/*      */                   
/* 5075 */                   hasTableTypes = true;
/*      */                 } catch (SQLException sqlEx2) {
/* 5077 */                   hasTableTypes = false;
/*      */                 }
/*      */               }
/*      */             }
/*      */             
/* 5082 */             TreeMap tablesOrderedByName = null;
/* 5083 */             TreeMap viewsOrderedByName = null;
/*      */             
/* 5085 */             while (results.next()) {
/* 5086 */               byte[][] row = new byte[5][];
/* 5087 */               row[0] = (catalogStr.toString() == null ? null : DatabaseMetaData.this.s2b(catalogStr.toString()));
/*      */               
/* 5089 */               row[1] = null;
/* 5090 */               row[2] = results.getBytes(1);
/* 5091 */               row[4] = new byte[0];
/*      */               
/* 5093 */               if (hasTableTypes) {
/* 5094 */                 String tableType = results.getString(typeColumnIndex);
/*      */                 
/*      */ 
/* 5097 */                 if ((("table".equalsIgnoreCase(tableType)) || ("base table".equalsIgnoreCase(tableType))) && (shouldReportTables))
/*      */                 {
/*      */ 
/* 5100 */                   boolean reportTable = false;
/*      */                   
/* 5102 */                   if ((!operatingOnInformationSchema) && (shouldReportTables)) {
/* 5103 */                     row[3] = DatabaseMetaData.TABLE_AS_BYTES;
/* 5104 */                     reportTable = true;
/* 5105 */                   } else if ((operatingOnInformationSchema) && (shouldReportSystemTables)) {
/* 5106 */                     row[3] = DatabaseMetaData.SYSTEM_TABLE_AS_BYTES;
/* 5107 */                     reportTable = true;
/*      */                   }
/*      */                   
/* 5110 */                   if (reportTable) {
/* 5111 */                     if (tablesOrderedByName == null) {
/* 5112 */                       tablesOrderedByName = new TreeMap();
/*      */                     }
/*      */                     
/* 5115 */                     tablesOrderedByName.put(results.getString(1), row);
/*      */                   }
/*      */                 }
/* 5118 */                 else if (("system view".equalsIgnoreCase(tableType)) && (shouldReportSystemTables)) {
/* 5119 */                   row[3] = DatabaseMetaData.SYSTEM_TABLE_AS_BYTES;
/*      */                   
/* 5121 */                   if (tablesOrderedByName == null) {
/* 5122 */                     tablesOrderedByName = new TreeMap();
/*      */                   }
/*      */                   
/* 5125 */                   tablesOrderedByName.put(results.getString(1), row);
/*      */                 }
/* 5127 */                 else if (("view".equalsIgnoreCase(tableType)) && (shouldReportViews))
/*      */                 {
/* 5129 */                   row[3] = DatabaseMetaData.VIEW_AS_BYTES;
/*      */                   
/* 5131 */                   if (viewsOrderedByName == null) {
/* 5132 */                     viewsOrderedByName = new TreeMap();
/*      */                   }
/*      */                   
/* 5135 */                   viewsOrderedByName.put(results.getString(1), row);
/*      */                 }
/* 5137 */                 else if (!hasTableTypes)
/*      */                 {
/* 5139 */                   row[3] = DatabaseMetaData.TABLE_AS_BYTES;
/*      */                   
/* 5141 */                   if (tablesOrderedByName == null) {
/* 5142 */                     tablesOrderedByName = new TreeMap();
/*      */                   }
/*      */                   
/* 5145 */                   tablesOrderedByName.put(results.getString(1), row);
/*      */                 }
/*      */                 
/*      */               }
/* 5149 */               else if (shouldReportTables)
/*      */               {
/* 5151 */                 row[3] = DatabaseMetaData.TABLE_AS_BYTES;
/*      */                 
/* 5153 */                 if (tablesOrderedByName == null) {
/* 5154 */                   tablesOrderedByName = new TreeMap();
/*      */                 }
/*      */                 
/* 5157 */                 tablesOrderedByName.put(results.getString(1), row);
/*      */               }
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5166 */             if (tablesOrderedByName != null) {
/* 5167 */               Iterator tablesIter = tablesOrderedByName.values().iterator();
/*      */               
/*      */ 
/* 5170 */               while (tablesIter.hasNext()) {
/* 5171 */                 tuples.add(new ByteArrayRow((byte[][])tablesIter.next(), DatabaseMetaData.this.getExceptionInterceptor()));
/*      */               }
/*      */             }
/*      */             
/* 5175 */             if (viewsOrderedByName != null) {
/* 5176 */               Iterator viewsIter = viewsOrderedByName.values().iterator();
/*      */               
/*      */ 
/* 5179 */               while (viewsIter.hasNext()) {
/* 5180 */                 tuples.add(new ByteArrayRow((byte[][])viewsIter.next(), DatabaseMetaData.this.getExceptionInterceptor()));
/*      */               }
/*      */             }
/*      */           }
/*      */           finally {
/* 5185 */             if (results != null) {
/*      */               try {
/* 5187 */                 results.close();
/*      */               }
/*      */               catch (Exception ex) {}
/*      */               
/*      */ 
/* 5192 */               results = null;
/*      */             }
/*      */           }
/*      */         }
/*      */       }.doForAll();
/*      */     }
/*      */     finally {
/* 5199 */       if (stmt != null) {
/* 5200 */         stmt.close();
/*      */       }
/*      */     }
/*      */     
/* 5204 */     ResultSet tables = buildResultSet(fields, tuples);
/*      */     
/* 5206 */     return tables;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getTableTypes()
/*      */     throws SQLException
/*      */   {
/* 5227 */     ArrayList tuples = new ArrayList();
/* 5228 */     Field[] fields = new Field[1];
/* 5229 */     fields[0] = new Field("", "TABLE_TYPE", 12, 5);
/*      */     
/* 5231 */     byte[][] tableTypeRow = new byte[1][];
/* 5232 */     tableTypeRow[0] = TABLE_AS_BYTES;
/* 5233 */     tuples.add(new ByteArrayRow(tableTypeRow, getExceptionInterceptor()));
/*      */     
/* 5235 */     if (this.conn.versionMeetsMinimum(5, 0, 1)) {
/* 5236 */       byte[][] viewTypeRow = new byte[1][];
/* 5237 */       viewTypeRow[0] = VIEW_AS_BYTES;
/* 5238 */       tuples.add(new ByteArrayRow(viewTypeRow, getExceptionInterceptor()));
/*      */     }
/*      */     
/* 5241 */     byte[][] tempTypeRow = new byte[1][];
/* 5242 */     tempTypeRow[0] = s2b("LOCAL TEMPORARY");
/* 5243 */     tuples.add(new ByteArrayRow(tempTypeRow, getExceptionInterceptor()));
/*      */     
/* 5245 */     return buildResultSet(fields, tuples);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getTimeDateFunctions()
/*      */     throws SQLException
/*      */   {
/* 5256 */     return "DAYOFWEEK,WEEKDAY,DAYOFMONTH,DAYOFYEAR,MONTH,DAYNAME,MONTHNAME,QUARTER,WEEK,YEAR,HOUR,MINUTE,SECOND,PERIOD_ADD,PERIOD_DIFF,TO_DAYS,FROM_DAYS,DATE_FORMAT,TIME_FORMAT,CURDATE,CURRENT_DATE,CURTIME,CURRENT_TIME,NOW,SYSDATE,CURRENT_TIMESTAMP,UNIX_TIMESTAMP,FROM_UNIXTIME,SEC_TO_TIME,TIME_TO_SEC";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getTypeInfo()
/*      */     throws SQLException
/*      */   {
/* 5365 */     Field[] fields = new Field[18];
/* 5366 */     fields[0] = new Field("", "TYPE_NAME", 1, 32);
/* 5367 */     fields[1] = new Field("", "DATA_TYPE", 4, 5);
/* 5368 */     fields[2] = new Field("", "PRECISION", 4, 10);
/* 5369 */     fields[3] = new Field("", "LITERAL_PREFIX", 1, 4);
/* 5370 */     fields[4] = new Field("", "LITERAL_SUFFIX", 1, 4);
/* 5371 */     fields[5] = new Field("", "CREATE_PARAMS", 1, 32);
/* 5372 */     fields[6] = new Field("", "NULLABLE", 5, 5);
/* 5373 */     fields[7] = new Field("", "CASE_SENSITIVE", 16, 3);
/* 5374 */     fields[8] = new Field("", "SEARCHABLE", 5, 3);
/* 5375 */     fields[9] = new Field("", "UNSIGNED_ATTRIBUTE", 16, 3);
/* 5376 */     fields[10] = new Field("", "FIXED_PREC_SCALE", 16, 3);
/* 5377 */     fields[11] = new Field("", "AUTO_INCREMENT", 16, 3);
/* 5378 */     fields[12] = new Field("", "LOCAL_TYPE_NAME", 1, 32);
/* 5379 */     fields[13] = new Field("", "MINIMUM_SCALE", 5, 5);
/* 5380 */     fields[14] = new Field("", "MAXIMUM_SCALE", 5, 5);
/* 5381 */     fields[15] = new Field("", "SQL_DATA_TYPE", 4, 10);
/* 5382 */     fields[16] = new Field("", "SQL_DATETIME_SUB", 4, 10);
/* 5383 */     fields[17] = new Field("", "NUM_PREC_RADIX", 4, 10);
/*      */     
/* 5385 */     byte[][] rowVal = (byte[][])null;
/* 5386 */     ArrayList tuples = new ArrayList();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5395 */     rowVal = new byte[18][];
/* 5396 */     rowVal[0] = s2b("BIT");
/* 5397 */     rowVal[1] = Integer.toString(-7).getBytes();
/*      */     
/*      */ 
/* 5400 */     rowVal[2] = s2b("1");
/* 5401 */     rowVal[3] = s2b("");
/* 5402 */     rowVal[4] = s2b("");
/* 5403 */     rowVal[5] = s2b("");
/* 5404 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5408 */     rowVal[7] = s2b("true");
/* 5409 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5413 */     rowVal[9] = s2b("false");
/* 5414 */     rowVal[10] = s2b("false");
/* 5415 */     rowVal[11] = s2b("false");
/* 5416 */     rowVal[12] = s2b("BIT");
/* 5417 */     rowVal[13] = s2b("0");
/* 5418 */     rowVal[14] = s2b("0");
/* 5419 */     rowVal[15] = s2b("0");
/* 5420 */     rowVal[16] = s2b("0");
/* 5421 */     rowVal[17] = s2b("10");
/* 5422 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5427 */     rowVal = new byte[18][];
/* 5428 */     rowVal[0] = s2b("BOOL");
/* 5429 */     rowVal[1] = Integer.toString(-7).getBytes();
/*      */     
/*      */ 
/* 5432 */     rowVal[2] = s2b("1");
/* 5433 */     rowVal[3] = s2b("");
/* 5434 */     rowVal[4] = s2b("");
/* 5435 */     rowVal[5] = s2b("");
/* 5436 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5440 */     rowVal[7] = s2b("true");
/* 5441 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5445 */     rowVal[9] = s2b("false");
/* 5446 */     rowVal[10] = s2b("false");
/* 5447 */     rowVal[11] = s2b("false");
/* 5448 */     rowVal[12] = s2b("BOOL");
/* 5449 */     rowVal[13] = s2b("0");
/* 5450 */     rowVal[14] = s2b("0");
/* 5451 */     rowVal[15] = s2b("0");
/* 5452 */     rowVal[16] = s2b("0");
/* 5453 */     rowVal[17] = s2b("10");
/* 5454 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5459 */     rowVal = new byte[18][];
/* 5460 */     rowVal[0] = s2b("TINYINT");
/* 5461 */     rowVal[1] = Integer.toString(-6).getBytes();
/*      */     
/*      */ 
/* 5464 */     rowVal[2] = s2b("3");
/* 5465 */     rowVal[3] = s2b("");
/* 5466 */     rowVal[4] = s2b("");
/* 5467 */     rowVal[5] = s2b("[(M)] [UNSIGNED] [ZEROFILL]");
/* 5468 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5472 */     rowVal[7] = s2b("false");
/* 5473 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5477 */     rowVal[9] = s2b("true");
/* 5478 */     rowVal[10] = s2b("false");
/* 5479 */     rowVal[11] = s2b("true");
/* 5480 */     rowVal[12] = s2b("TINYINT");
/* 5481 */     rowVal[13] = s2b("0");
/* 5482 */     rowVal[14] = s2b("0");
/* 5483 */     rowVal[15] = s2b("0");
/* 5484 */     rowVal[16] = s2b("0");
/* 5485 */     rowVal[17] = s2b("10");
/* 5486 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/* 5488 */     rowVal = new byte[18][];
/* 5489 */     rowVal[0] = s2b("TINYINT UNSIGNED");
/* 5490 */     rowVal[1] = Integer.toString(-6).getBytes();
/*      */     
/*      */ 
/* 5493 */     rowVal[2] = s2b("3");
/* 5494 */     rowVal[3] = s2b("");
/* 5495 */     rowVal[4] = s2b("");
/* 5496 */     rowVal[5] = s2b("[(M)] [UNSIGNED] [ZEROFILL]");
/* 5497 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5501 */     rowVal[7] = s2b("false");
/* 5502 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5506 */     rowVal[9] = s2b("true");
/* 5507 */     rowVal[10] = s2b("false");
/* 5508 */     rowVal[11] = s2b("true");
/* 5509 */     rowVal[12] = s2b("TINYINT UNSIGNED");
/* 5510 */     rowVal[13] = s2b("0");
/* 5511 */     rowVal[14] = s2b("0");
/* 5512 */     rowVal[15] = s2b("0");
/* 5513 */     rowVal[16] = s2b("0");
/* 5514 */     rowVal[17] = s2b("10");
/* 5515 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5520 */     rowVal = new byte[18][];
/* 5521 */     rowVal[0] = s2b("BIGINT");
/* 5522 */     rowVal[1] = Integer.toString(-5).getBytes();
/*      */     
/*      */ 
/* 5525 */     rowVal[2] = s2b("19");
/* 5526 */     rowVal[3] = s2b("");
/* 5527 */     rowVal[4] = s2b("");
/* 5528 */     rowVal[5] = s2b("[(M)] [UNSIGNED] [ZEROFILL]");
/* 5529 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5533 */     rowVal[7] = s2b("false");
/* 5534 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5538 */     rowVal[9] = s2b("true");
/* 5539 */     rowVal[10] = s2b("false");
/* 5540 */     rowVal[11] = s2b("true");
/* 5541 */     rowVal[12] = s2b("BIGINT");
/* 5542 */     rowVal[13] = s2b("0");
/* 5543 */     rowVal[14] = s2b("0");
/* 5544 */     rowVal[15] = s2b("0");
/* 5545 */     rowVal[16] = s2b("0");
/* 5546 */     rowVal[17] = s2b("10");
/* 5547 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/* 5549 */     rowVal = new byte[18][];
/* 5550 */     rowVal[0] = s2b("BIGINT UNSIGNED");
/* 5551 */     rowVal[1] = Integer.toString(-5).getBytes();
/*      */     
/*      */ 
/* 5554 */     rowVal[2] = s2b("20");
/* 5555 */     rowVal[3] = s2b("");
/* 5556 */     rowVal[4] = s2b("");
/* 5557 */     rowVal[5] = s2b("[(M)] [ZEROFILL]");
/* 5558 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5562 */     rowVal[7] = s2b("false");
/* 5563 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5567 */     rowVal[9] = s2b("true");
/* 5568 */     rowVal[10] = s2b("false");
/* 5569 */     rowVal[11] = s2b("true");
/* 5570 */     rowVal[12] = s2b("BIGINT UNSIGNED");
/* 5571 */     rowVal[13] = s2b("0");
/* 5572 */     rowVal[14] = s2b("0");
/* 5573 */     rowVal[15] = s2b("0");
/* 5574 */     rowVal[16] = s2b("0");
/* 5575 */     rowVal[17] = s2b("10");
/* 5576 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5581 */     rowVal = new byte[18][];
/* 5582 */     rowVal[0] = s2b("LONG VARBINARY");
/* 5583 */     rowVal[1] = Integer.toString(-4).getBytes();
/*      */     
/*      */ 
/* 5586 */     rowVal[2] = s2b("16777215");
/* 5587 */     rowVal[3] = s2b("'");
/* 5588 */     rowVal[4] = s2b("'");
/* 5589 */     rowVal[5] = s2b("");
/* 5590 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5594 */     rowVal[7] = s2b("true");
/* 5595 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5599 */     rowVal[9] = s2b("false");
/* 5600 */     rowVal[10] = s2b("false");
/* 5601 */     rowVal[11] = s2b("false");
/* 5602 */     rowVal[12] = s2b("LONG VARBINARY");
/* 5603 */     rowVal[13] = s2b("0");
/* 5604 */     rowVal[14] = s2b("0");
/* 5605 */     rowVal[15] = s2b("0");
/* 5606 */     rowVal[16] = s2b("0");
/* 5607 */     rowVal[17] = s2b("10");
/* 5608 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5613 */     rowVal = new byte[18][];
/* 5614 */     rowVal[0] = s2b("MEDIUMBLOB");
/* 5615 */     rowVal[1] = Integer.toString(-4).getBytes();
/*      */     
/*      */ 
/* 5618 */     rowVal[2] = s2b("16777215");
/* 5619 */     rowVal[3] = s2b("'");
/* 5620 */     rowVal[4] = s2b("'");
/* 5621 */     rowVal[5] = s2b("");
/* 5622 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5626 */     rowVal[7] = s2b("true");
/* 5627 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5631 */     rowVal[9] = s2b("false");
/* 5632 */     rowVal[10] = s2b("false");
/* 5633 */     rowVal[11] = s2b("false");
/* 5634 */     rowVal[12] = s2b("MEDIUMBLOB");
/* 5635 */     rowVal[13] = s2b("0");
/* 5636 */     rowVal[14] = s2b("0");
/* 5637 */     rowVal[15] = s2b("0");
/* 5638 */     rowVal[16] = s2b("0");
/* 5639 */     rowVal[17] = s2b("10");
/* 5640 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5645 */     rowVal = new byte[18][];
/* 5646 */     rowVal[0] = s2b("LONGBLOB");
/* 5647 */     rowVal[1] = Integer.toString(-4).getBytes();
/*      */     
/*      */ 
/* 5650 */     rowVal[2] = Integer.toString(Integer.MAX_VALUE).getBytes();
/*      */     
/*      */ 
/* 5653 */     rowVal[3] = s2b("'");
/* 5654 */     rowVal[4] = s2b("'");
/* 5655 */     rowVal[5] = s2b("");
/* 5656 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5660 */     rowVal[7] = s2b("true");
/* 5661 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5665 */     rowVal[9] = s2b("false");
/* 5666 */     rowVal[10] = s2b("false");
/* 5667 */     rowVal[11] = s2b("false");
/* 5668 */     rowVal[12] = s2b("LONGBLOB");
/* 5669 */     rowVal[13] = s2b("0");
/* 5670 */     rowVal[14] = s2b("0");
/* 5671 */     rowVal[15] = s2b("0");
/* 5672 */     rowVal[16] = s2b("0");
/* 5673 */     rowVal[17] = s2b("10");
/* 5674 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5679 */     rowVal = new byte[18][];
/* 5680 */     rowVal[0] = s2b("BLOB");
/* 5681 */     rowVal[1] = Integer.toString(-4).getBytes();
/*      */     
/*      */ 
/* 5684 */     rowVal[2] = s2b("65535");
/* 5685 */     rowVal[3] = s2b("'");
/* 5686 */     rowVal[4] = s2b("'");
/* 5687 */     rowVal[5] = s2b("");
/* 5688 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5692 */     rowVal[7] = s2b("true");
/* 5693 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5697 */     rowVal[9] = s2b("false");
/* 5698 */     rowVal[10] = s2b("false");
/* 5699 */     rowVal[11] = s2b("false");
/* 5700 */     rowVal[12] = s2b("BLOB");
/* 5701 */     rowVal[13] = s2b("0");
/* 5702 */     rowVal[14] = s2b("0");
/* 5703 */     rowVal[15] = s2b("0");
/* 5704 */     rowVal[16] = s2b("0");
/* 5705 */     rowVal[17] = s2b("10");
/* 5706 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5711 */     rowVal = new byte[18][];
/* 5712 */     rowVal[0] = s2b("TINYBLOB");
/* 5713 */     rowVal[1] = Integer.toString(-4).getBytes();
/*      */     
/*      */ 
/* 5716 */     rowVal[2] = s2b("255");
/* 5717 */     rowVal[3] = s2b("'");
/* 5718 */     rowVal[4] = s2b("'");
/* 5719 */     rowVal[5] = s2b("");
/* 5720 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5724 */     rowVal[7] = s2b("true");
/* 5725 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5729 */     rowVal[9] = s2b("false");
/* 5730 */     rowVal[10] = s2b("false");
/* 5731 */     rowVal[11] = s2b("false");
/* 5732 */     rowVal[12] = s2b("TINYBLOB");
/* 5733 */     rowVal[13] = s2b("0");
/* 5734 */     rowVal[14] = s2b("0");
/* 5735 */     rowVal[15] = s2b("0");
/* 5736 */     rowVal[16] = s2b("0");
/* 5737 */     rowVal[17] = s2b("10");
/* 5738 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5744 */     rowVal = new byte[18][];
/* 5745 */     rowVal[0] = s2b("VARBINARY");
/* 5746 */     rowVal[1] = Integer.toString(-3).getBytes();
/*      */     
/*      */ 
/* 5749 */     rowVal[2] = s2b("255");
/* 5750 */     rowVal[3] = s2b("'");
/* 5751 */     rowVal[4] = s2b("'");
/* 5752 */     rowVal[5] = s2b("(M)");
/* 5753 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5757 */     rowVal[7] = s2b("true");
/* 5758 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5762 */     rowVal[9] = s2b("false");
/* 5763 */     rowVal[10] = s2b("false");
/* 5764 */     rowVal[11] = s2b("false");
/* 5765 */     rowVal[12] = s2b("VARBINARY");
/* 5766 */     rowVal[13] = s2b("0");
/* 5767 */     rowVal[14] = s2b("0");
/* 5768 */     rowVal[15] = s2b("0");
/* 5769 */     rowVal[16] = s2b("0");
/* 5770 */     rowVal[17] = s2b("10");
/* 5771 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5777 */     rowVal = new byte[18][];
/* 5778 */     rowVal[0] = s2b("BINARY");
/* 5779 */     rowVal[1] = Integer.toString(-2).getBytes();
/*      */     
/*      */ 
/* 5782 */     rowVal[2] = s2b("255");
/* 5783 */     rowVal[3] = s2b("'");
/* 5784 */     rowVal[4] = s2b("'");
/* 5785 */     rowVal[5] = s2b("(M)");
/* 5786 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5790 */     rowVal[7] = s2b("true");
/* 5791 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5795 */     rowVal[9] = s2b("false");
/* 5796 */     rowVal[10] = s2b("false");
/* 5797 */     rowVal[11] = s2b("false");
/* 5798 */     rowVal[12] = s2b("BINARY");
/* 5799 */     rowVal[13] = s2b("0");
/* 5800 */     rowVal[14] = s2b("0");
/* 5801 */     rowVal[15] = s2b("0");
/* 5802 */     rowVal[16] = s2b("0");
/* 5803 */     rowVal[17] = s2b("10");
/* 5804 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5809 */     rowVal = new byte[18][];
/* 5810 */     rowVal[0] = s2b("LONG VARCHAR");
/* 5811 */     rowVal[1] = Integer.toString(-1).getBytes();
/*      */     
/*      */ 
/* 5814 */     rowVal[2] = s2b("16777215");
/* 5815 */     rowVal[3] = s2b("'");
/* 5816 */     rowVal[4] = s2b("'");
/* 5817 */     rowVal[5] = s2b("");
/* 5818 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5822 */     rowVal[7] = s2b("false");
/* 5823 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5827 */     rowVal[9] = s2b("false");
/* 5828 */     rowVal[10] = s2b("false");
/* 5829 */     rowVal[11] = s2b("false");
/* 5830 */     rowVal[12] = s2b("LONG VARCHAR");
/* 5831 */     rowVal[13] = s2b("0");
/* 5832 */     rowVal[14] = s2b("0");
/* 5833 */     rowVal[15] = s2b("0");
/* 5834 */     rowVal[16] = s2b("0");
/* 5835 */     rowVal[17] = s2b("10");
/* 5836 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5841 */     rowVal = new byte[18][];
/* 5842 */     rowVal[0] = s2b("MEDIUMTEXT");
/* 5843 */     rowVal[1] = Integer.toString(-1).getBytes();
/*      */     
/*      */ 
/* 5846 */     rowVal[2] = s2b("16777215");
/* 5847 */     rowVal[3] = s2b("'");
/* 5848 */     rowVal[4] = s2b("'");
/* 5849 */     rowVal[5] = s2b("");
/* 5850 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5854 */     rowVal[7] = s2b("false");
/* 5855 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5859 */     rowVal[9] = s2b("false");
/* 5860 */     rowVal[10] = s2b("false");
/* 5861 */     rowVal[11] = s2b("false");
/* 5862 */     rowVal[12] = s2b("MEDIUMTEXT");
/* 5863 */     rowVal[13] = s2b("0");
/* 5864 */     rowVal[14] = s2b("0");
/* 5865 */     rowVal[15] = s2b("0");
/* 5866 */     rowVal[16] = s2b("0");
/* 5867 */     rowVal[17] = s2b("10");
/* 5868 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5873 */     rowVal = new byte[18][];
/* 5874 */     rowVal[0] = s2b("LONGTEXT");
/* 5875 */     rowVal[1] = Integer.toString(-1).getBytes();
/*      */     
/*      */ 
/* 5878 */     rowVal[2] = Integer.toString(Integer.MAX_VALUE).getBytes();
/*      */     
/*      */ 
/* 5881 */     rowVal[3] = s2b("'");
/* 5882 */     rowVal[4] = s2b("'");
/* 5883 */     rowVal[5] = s2b("");
/* 5884 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5888 */     rowVal[7] = s2b("false");
/* 5889 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5893 */     rowVal[9] = s2b("false");
/* 5894 */     rowVal[10] = s2b("false");
/* 5895 */     rowVal[11] = s2b("false");
/* 5896 */     rowVal[12] = s2b("LONGTEXT");
/* 5897 */     rowVal[13] = s2b("0");
/* 5898 */     rowVal[14] = s2b("0");
/* 5899 */     rowVal[15] = s2b("0");
/* 5900 */     rowVal[16] = s2b("0");
/* 5901 */     rowVal[17] = s2b("10");
/* 5902 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5907 */     rowVal = new byte[18][];
/* 5908 */     rowVal[0] = s2b("TEXT");
/* 5909 */     rowVal[1] = Integer.toString(-1).getBytes();
/*      */     
/*      */ 
/* 5912 */     rowVal[2] = s2b("65535");
/* 5913 */     rowVal[3] = s2b("'");
/* 5914 */     rowVal[4] = s2b("'");
/* 5915 */     rowVal[5] = s2b("");
/* 5916 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5920 */     rowVal[7] = s2b("false");
/* 5921 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5925 */     rowVal[9] = s2b("false");
/* 5926 */     rowVal[10] = s2b("false");
/* 5927 */     rowVal[11] = s2b("false");
/* 5928 */     rowVal[12] = s2b("TEXT");
/* 5929 */     rowVal[13] = s2b("0");
/* 5930 */     rowVal[14] = s2b("0");
/* 5931 */     rowVal[15] = s2b("0");
/* 5932 */     rowVal[16] = s2b("0");
/* 5933 */     rowVal[17] = s2b("10");
/* 5934 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5939 */     rowVal = new byte[18][];
/* 5940 */     rowVal[0] = s2b("TINYTEXT");
/* 5941 */     rowVal[1] = Integer.toString(-1).getBytes();
/*      */     
/*      */ 
/* 5944 */     rowVal[2] = s2b("255");
/* 5945 */     rowVal[3] = s2b("'");
/* 5946 */     rowVal[4] = s2b("'");
/* 5947 */     rowVal[5] = s2b("");
/* 5948 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5952 */     rowVal[7] = s2b("false");
/* 5953 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5957 */     rowVal[9] = s2b("false");
/* 5958 */     rowVal[10] = s2b("false");
/* 5959 */     rowVal[11] = s2b("false");
/* 5960 */     rowVal[12] = s2b("TINYTEXT");
/* 5961 */     rowVal[13] = s2b("0");
/* 5962 */     rowVal[14] = s2b("0");
/* 5963 */     rowVal[15] = s2b("0");
/* 5964 */     rowVal[16] = s2b("0");
/* 5965 */     rowVal[17] = s2b("10");
/* 5966 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5971 */     rowVal = new byte[18][];
/* 5972 */     rowVal[0] = s2b("CHAR");
/* 5973 */     rowVal[1] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/* 5976 */     rowVal[2] = s2b("255");
/* 5977 */     rowVal[3] = s2b("'");
/* 5978 */     rowVal[4] = s2b("'");
/* 5979 */     rowVal[5] = s2b("(M)");
/* 5980 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5984 */     rowVal[7] = s2b("false");
/* 5985 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 5989 */     rowVal[9] = s2b("false");
/* 5990 */     rowVal[10] = s2b("false");
/* 5991 */     rowVal[11] = s2b("false");
/* 5992 */     rowVal[12] = s2b("CHAR");
/* 5993 */     rowVal[13] = s2b("0");
/* 5994 */     rowVal[14] = s2b("0");
/* 5995 */     rowVal[15] = s2b("0");
/* 5996 */     rowVal[16] = s2b("0");
/* 5997 */     rowVal[17] = s2b("10");
/* 5998 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/* 6002 */     int decimalPrecision = 254;
/*      */     
/* 6004 */     if (this.conn.versionMeetsMinimum(5, 0, 3)) {
/* 6005 */       if (this.conn.versionMeetsMinimum(5, 0, 6)) {
/* 6006 */         decimalPrecision = 65;
/*      */       } else {
/* 6008 */         decimalPrecision = 64;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6016 */     rowVal = new byte[18][];
/* 6017 */     rowVal[0] = s2b("NUMERIC");
/* 6018 */     rowVal[1] = Integer.toString(2).getBytes();
/*      */     
/*      */ 
/* 6021 */     rowVal[2] = s2b(String.valueOf(decimalPrecision));
/* 6022 */     rowVal[3] = s2b("");
/* 6023 */     rowVal[4] = s2b("");
/* 6024 */     rowVal[5] = s2b("[(M[,D])] [ZEROFILL]");
/* 6025 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6029 */     rowVal[7] = s2b("false");
/* 6030 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6034 */     rowVal[9] = s2b("false");
/* 6035 */     rowVal[10] = s2b("false");
/* 6036 */     rowVal[11] = s2b("true");
/* 6037 */     rowVal[12] = s2b("NUMERIC");
/* 6038 */     rowVal[13] = s2b("-308");
/* 6039 */     rowVal[14] = s2b("308");
/* 6040 */     rowVal[15] = s2b("0");
/* 6041 */     rowVal[16] = s2b("0");
/* 6042 */     rowVal[17] = s2b("10");
/* 6043 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 6048 */     rowVal = new byte[18][];
/* 6049 */     rowVal[0] = s2b("DECIMAL");
/* 6050 */     rowVal[1] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/* 6053 */     rowVal[2] = s2b(String.valueOf(decimalPrecision));
/* 6054 */     rowVal[3] = s2b("");
/* 6055 */     rowVal[4] = s2b("");
/* 6056 */     rowVal[5] = s2b("[(M[,D])] [ZEROFILL]");
/* 6057 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6061 */     rowVal[7] = s2b("false");
/* 6062 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6066 */     rowVal[9] = s2b("false");
/* 6067 */     rowVal[10] = s2b("false");
/* 6068 */     rowVal[11] = s2b("true");
/* 6069 */     rowVal[12] = s2b("DECIMAL");
/* 6070 */     rowVal[13] = s2b("-308");
/* 6071 */     rowVal[14] = s2b("308");
/* 6072 */     rowVal[15] = s2b("0");
/* 6073 */     rowVal[16] = s2b("0");
/* 6074 */     rowVal[17] = s2b("10");
/* 6075 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 6080 */     rowVal = new byte[18][];
/* 6081 */     rowVal[0] = s2b("INTEGER");
/* 6082 */     rowVal[1] = Integer.toString(4).getBytes();
/*      */     
/*      */ 
/* 6085 */     rowVal[2] = s2b("10");
/* 6086 */     rowVal[3] = s2b("");
/* 6087 */     rowVal[4] = s2b("");
/* 6088 */     rowVal[5] = s2b("[(M)] [UNSIGNED] [ZEROFILL]");
/* 6089 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6093 */     rowVal[7] = s2b("false");
/* 6094 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6098 */     rowVal[9] = s2b("true");
/* 6099 */     rowVal[10] = s2b("false");
/* 6100 */     rowVal[11] = s2b("true");
/* 6101 */     rowVal[12] = s2b("INTEGER");
/* 6102 */     rowVal[13] = s2b("0");
/* 6103 */     rowVal[14] = s2b("0");
/* 6104 */     rowVal[15] = s2b("0");
/* 6105 */     rowVal[16] = s2b("0");
/* 6106 */     rowVal[17] = s2b("10");
/* 6107 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/* 6109 */     rowVal = new byte[18][];
/* 6110 */     rowVal[0] = s2b("INTEGER UNSIGNED");
/* 6111 */     rowVal[1] = Integer.toString(4).getBytes();
/*      */     
/*      */ 
/* 6114 */     rowVal[2] = s2b("10");
/* 6115 */     rowVal[3] = s2b("");
/* 6116 */     rowVal[4] = s2b("");
/* 6117 */     rowVal[5] = s2b("[(M)] [ZEROFILL]");
/* 6118 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6122 */     rowVal[7] = s2b("false");
/* 6123 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6127 */     rowVal[9] = s2b("true");
/* 6128 */     rowVal[10] = s2b("false");
/* 6129 */     rowVal[11] = s2b("true");
/* 6130 */     rowVal[12] = s2b("INTEGER UNSIGNED");
/* 6131 */     rowVal[13] = s2b("0");
/* 6132 */     rowVal[14] = s2b("0");
/* 6133 */     rowVal[15] = s2b("0");
/* 6134 */     rowVal[16] = s2b("0");
/* 6135 */     rowVal[17] = s2b("10");
/* 6136 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 6141 */     rowVal = new byte[18][];
/* 6142 */     rowVal[0] = s2b("INT");
/* 6143 */     rowVal[1] = Integer.toString(4).getBytes();
/*      */     
/*      */ 
/* 6146 */     rowVal[2] = s2b("10");
/* 6147 */     rowVal[3] = s2b("");
/* 6148 */     rowVal[4] = s2b("");
/* 6149 */     rowVal[5] = s2b("[(M)] [UNSIGNED] [ZEROFILL]");
/* 6150 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6154 */     rowVal[7] = s2b("false");
/* 6155 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6159 */     rowVal[9] = s2b("true");
/* 6160 */     rowVal[10] = s2b("false");
/* 6161 */     rowVal[11] = s2b("true");
/* 6162 */     rowVal[12] = s2b("INT");
/* 6163 */     rowVal[13] = s2b("0");
/* 6164 */     rowVal[14] = s2b("0");
/* 6165 */     rowVal[15] = s2b("0");
/* 6166 */     rowVal[16] = s2b("0");
/* 6167 */     rowVal[17] = s2b("10");
/* 6168 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/* 6170 */     rowVal = new byte[18][];
/* 6171 */     rowVal[0] = s2b("INT UNSIGNED");
/* 6172 */     rowVal[1] = Integer.toString(4).getBytes();
/*      */     
/*      */ 
/* 6175 */     rowVal[2] = s2b("10");
/* 6176 */     rowVal[3] = s2b("");
/* 6177 */     rowVal[4] = s2b("");
/* 6178 */     rowVal[5] = s2b("[(M)] [ZEROFILL]");
/* 6179 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6183 */     rowVal[7] = s2b("false");
/* 6184 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6188 */     rowVal[9] = s2b("true");
/* 6189 */     rowVal[10] = s2b("false");
/* 6190 */     rowVal[11] = s2b("true");
/* 6191 */     rowVal[12] = s2b("INT UNSIGNED");
/* 6192 */     rowVal[13] = s2b("0");
/* 6193 */     rowVal[14] = s2b("0");
/* 6194 */     rowVal[15] = s2b("0");
/* 6195 */     rowVal[16] = s2b("0");
/* 6196 */     rowVal[17] = s2b("10");
/* 6197 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 6202 */     rowVal = new byte[18][];
/* 6203 */     rowVal[0] = s2b("MEDIUMINT");
/* 6204 */     rowVal[1] = Integer.toString(4).getBytes();
/*      */     
/*      */ 
/* 6207 */     rowVal[2] = s2b("7");
/* 6208 */     rowVal[3] = s2b("");
/* 6209 */     rowVal[4] = s2b("");
/* 6210 */     rowVal[5] = s2b("[(M)] [UNSIGNED] [ZEROFILL]");
/* 6211 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6215 */     rowVal[7] = s2b("false");
/* 6216 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6220 */     rowVal[9] = s2b("true");
/* 6221 */     rowVal[10] = s2b("false");
/* 6222 */     rowVal[11] = s2b("true");
/* 6223 */     rowVal[12] = s2b("MEDIUMINT");
/* 6224 */     rowVal[13] = s2b("0");
/* 6225 */     rowVal[14] = s2b("0");
/* 6226 */     rowVal[15] = s2b("0");
/* 6227 */     rowVal[16] = s2b("0");
/* 6228 */     rowVal[17] = s2b("10");
/* 6229 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/* 6231 */     rowVal = new byte[18][];
/* 6232 */     rowVal[0] = s2b("MEDIUMINT UNSIGNED");
/* 6233 */     rowVal[1] = Integer.toString(4).getBytes();
/*      */     
/*      */ 
/* 6236 */     rowVal[2] = s2b("8");
/* 6237 */     rowVal[3] = s2b("");
/* 6238 */     rowVal[4] = s2b("");
/* 6239 */     rowVal[5] = s2b("[(M)] [ZEROFILL]");
/* 6240 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6244 */     rowVal[7] = s2b("false");
/* 6245 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6249 */     rowVal[9] = s2b("true");
/* 6250 */     rowVal[10] = s2b("false");
/* 6251 */     rowVal[11] = s2b("true");
/* 6252 */     rowVal[12] = s2b("MEDIUMINT UNSIGNED");
/* 6253 */     rowVal[13] = s2b("0");
/* 6254 */     rowVal[14] = s2b("0");
/* 6255 */     rowVal[15] = s2b("0");
/* 6256 */     rowVal[16] = s2b("0");
/* 6257 */     rowVal[17] = s2b("10");
/* 6258 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 6263 */     rowVal = new byte[18][];
/* 6264 */     rowVal[0] = s2b("SMALLINT");
/* 6265 */     rowVal[1] = Integer.toString(5).getBytes();
/*      */     
/*      */ 
/* 6268 */     rowVal[2] = s2b("5");
/* 6269 */     rowVal[3] = s2b("");
/* 6270 */     rowVal[4] = s2b("");
/* 6271 */     rowVal[5] = s2b("[(M)] [UNSIGNED] [ZEROFILL]");
/* 6272 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6276 */     rowVal[7] = s2b("false");
/* 6277 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6281 */     rowVal[9] = s2b("true");
/* 6282 */     rowVal[10] = s2b("false");
/* 6283 */     rowVal[11] = s2b("true");
/* 6284 */     rowVal[12] = s2b("SMALLINT");
/* 6285 */     rowVal[13] = s2b("0");
/* 6286 */     rowVal[14] = s2b("0");
/* 6287 */     rowVal[15] = s2b("0");
/* 6288 */     rowVal[16] = s2b("0");
/* 6289 */     rowVal[17] = s2b("10");
/* 6290 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/* 6292 */     rowVal = new byte[18][];
/* 6293 */     rowVal[0] = s2b("SMALLINT UNSIGNED");
/* 6294 */     rowVal[1] = Integer.toString(5).getBytes();
/*      */     
/*      */ 
/* 6297 */     rowVal[2] = s2b("5");
/* 6298 */     rowVal[3] = s2b("");
/* 6299 */     rowVal[4] = s2b("");
/* 6300 */     rowVal[5] = s2b("[(M)] [ZEROFILL]");
/* 6301 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6305 */     rowVal[7] = s2b("false");
/* 6306 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6310 */     rowVal[9] = s2b("true");
/* 6311 */     rowVal[10] = s2b("false");
/* 6312 */     rowVal[11] = s2b("true");
/* 6313 */     rowVal[12] = s2b("SMALLINT UNSIGNED");
/* 6314 */     rowVal[13] = s2b("0");
/* 6315 */     rowVal[14] = s2b("0");
/* 6316 */     rowVal[15] = s2b("0");
/* 6317 */     rowVal[16] = s2b("0");
/* 6318 */     rowVal[17] = s2b("10");
/* 6319 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6325 */     rowVal = new byte[18][];
/* 6326 */     rowVal[0] = s2b("FLOAT");
/* 6327 */     rowVal[1] = Integer.toString(7).getBytes();
/*      */     
/*      */ 
/* 6330 */     rowVal[2] = s2b("10");
/* 6331 */     rowVal[3] = s2b("");
/* 6332 */     rowVal[4] = s2b("");
/* 6333 */     rowVal[5] = s2b("[(M,D)] [ZEROFILL]");
/* 6334 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6338 */     rowVal[7] = s2b("false");
/* 6339 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6343 */     rowVal[9] = s2b("false");
/* 6344 */     rowVal[10] = s2b("false");
/* 6345 */     rowVal[11] = s2b("true");
/* 6346 */     rowVal[12] = s2b("FLOAT");
/* 6347 */     rowVal[13] = s2b("-38");
/* 6348 */     rowVal[14] = s2b("38");
/* 6349 */     rowVal[15] = s2b("0");
/* 6350 */     rowVal[16] = s2b("0");
/* 6351 */     rowVal[17] = s2b("10");
/* 6352 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 6357 */     rowVal = new byte[18][];
/* 6358 */     rowVal[0] = s2b("DOUBLE");
/* 6359 */     rowVal[1] = Integer.toString(8).getBytes();
/*      */     
/*      */ 
/* 6362 */     rowVal[2] = s2b("17");
/* 6363 */     rowVal[3] = s2b("");
/* 6364 */     rowVal[4] = s2b("");
/* 6365 */     rowVal[5] = s2b("[(M,D)] [ZEROFILL]");
/* 6366 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6370 */     rowVal[7] = s2b("false");
/* 6371 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6375 */     rowVal[9] = s2b("false");
/* 6376 */     rowVal[10] = s2b("false");
/* 6377 */     rowVal[11] = s2b("true");
/* 6378 */     rowVal[12] = s2b("DOUBLE");
/* 6379 */     rowVal[13] = s2b("-308");
/* 6380 */     rowVal[14] = s2b("308");
/* 6381 */     rowVal[15] = s2b("0");
/* 6382 */     rowVal[16] = s2b("0");
/* 6383 */     rowVal[17] = s2b("10");
/* 6384 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 6389 */     rowVal = new byte[18][];
/* 6390 */     rowVal[0] = s2b("DOUBLE PRECISION");
/* 6391 */     rowVal[1] = Integer.toString(8).getBytes();
/*      */     
/*      */ 
/* 6394 */     rowVal[2] = s2b("17");
/* 6395 */     rowVal[3] = s2b("");
/* 6396 */     rowVal[4] = s2b("");
/* 6397 */     rowVal[5] = s2b("[(M,D)] [ZEROFILL]");
/* 6398 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6402 */     rowVal[7] = s2b("false");
/* 6403 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6407 */     rowVal[9] = s2b("false");
/* 6408 */     rowVal[10] = s2b("false");
/* 6409 */     rowVal[11] = s2b("true");
/* 6410 */     rowVal[12] = s2b("DOUBLE PRECISION");
/* 6411 */     rowVal[13] = s2b("-308");
/* 6412 */     rowVal[14] = s2b("308");
/* 6413 */     rowVal[15] = s2b("0");
/* 6414 */     rowVal[16] = s2b("0");
/* 6415 */     rowVal[17] = s2b("10");
/* 6416 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 6421 */     rowVal = new byte[18][];
/* 6422 */     rowVal[0] = s2b("REAL");
/* 6423 */     rowVal[1] = Integer.toString(8).getBytes();
/*      */     
/*      */ 
/* 6426 */     rowVal[2] = s2b("17");
/* 6427 */     rowVal[3] = s2b("");
/* 6428 */     rowVal[4] = s2b("");
/* 6429 */     rowVal[5] = s2b("[(M,D)] [ZEROFILL]");
/* 6430 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6434 */     rowVal[7] = s2b("false");
/* 6435 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6439 */     rowVal[9] = s2b("false");
/* 6440 */     rowVal[10] = s2b("false");
/* 6441 */     rowVal[11] = s2b("true");
/* 6442 */     rowVal[12] = s2b("REAL");
/* 6443 */     rowVal[13] = s2b("-308");
/* 6444 */     rowVal[14] = s2b("308");
/* 6445 */     rowVal[15] = s2b("0");
/* 6446 */     rowVal[16] = s2b("0");
/* 6447 */     rowVal[17] = s2b("10");
/* 6448 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 6453 */     rowVal = new byte[18][];
/* 6454 */     rowVal[0] = s2b("VARCHAR");
/* 6455 */     rowVal[1] = Integer.toString(12).getBytes();
/*      */     
/*      */ 
/* 6458 */     rowVal[2] = s2b("255");
/* 6459 */     rowVal[3] = s2b("'");
/* 6460 */     rowVal[4] = s2b("'");
/* 6461 */     rowVal[5] = s2b("(M)");
/* 6462 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6466 */     rowVal[7] = s2b("false");
/* 6467 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6471 */     rowVal[9] = s2b("false");
/* 6472 */     rowVal[10] = s2b("false");
/* 6473 */     rowVal[11] = s2b("false");
/* 6474 */     rowVal[12] = s2b("VARCHAR");
/* 6475 */     rowVal[13] = s2b("0");
/* 6476 */     rowVal[14] = s2b("0");
/* 6477 */     rowVal[15] = s2b("0");
/* 6478 */     rowVal[16] = s2b("0");
/* 6479 */     rowVal[17] = s2b("10");
/* 6480 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 6485 */     rowVal = new byte[18][];
/* 6486 */     rowVal[0] = s2b("ENUM");
/* 6487 */     rowVal[1] = Integer.toString(12).getBytes();
/*      */     
/*      */ 
/* 6490 */     rowVal[2] = s2b("65535");
/* 6491 */     rowVal[3] = s2b("'");
/* 6492 */     rowVal[4] = s2b("'");
/* 6493 */     rowVal[5] = s2b("");
/* 6494 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6498 */     rowVal[7] = s2b("false");
/* 6499 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6503 */     rowVal[9] = s2b("false");
/* 6504 */     rowVal[10] = s2b("false");
/* 6505 */     rowVal[11] = s2b("false");
/* 6506 */     rowVal[12] = s2b("ENUM");
/* 6507 */     rowVal[13] = s2b("0");
/* 6508 */     rowVal[14] = s2b("0");
/* 6509 */     rowVal[15] = s2b("0");
/* 6510 */     rowVal[16] = s2b("0");
/* 6511 */     rowVal[17] = s2b("10");
/* 6512 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 6517 */     rowVal = new byte[18][];
/* 6518 */     rowVal[0] = s2b("SET");
/* 6519 */     rowVal[1] = Integer.toString(12).getBytes();
/*      */     
/*      */ 
/* 6522 */     rowVal[2] = s2b("64");
/* 6523 */     rowVal[3] = s2b("'");
/* 6524 */     rowVal[4] = s2b("'");
/* 6525 */     rowVal[5] = s2b("");
/* 6526 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6530 */     rowVal[7] = s2b("false");
/* 6531 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6535 */     rowVal[9] = s2b("false");
/* 6536 */     rowVal[10] = s2b("false");
/* 6537 */     rowVal[11] = s2b("false");
/* 6538 */     rowVal[12] = s2b("SET");
/* 6539 */     rowVal[13] = s2b("0");
/* 6540 */     rowVal[14] = s2b("0");
/* 6541 */     rowVal[15] = s2b("0");
/* 6542 */     rowVal[16] = s2b("0");
/* 6543 */     rowVal[17] = s2b("10");
/* 6544 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 6549 */     rowVal = new byte[18][];
/* 6550 */     rowVal[0] = s2b("DATE");
/* 6551 */     rowVal[1] = Integer.toString(91).getBytes();
/*      */     
/*      */ 
/* 6554 */     rowVal[2] = s2b("0");
/* 6555 */     rowVal[3] = s2b("'");
/* 6556 */     rowVal[4] = s2b("'");
/* 6557 */     rowVal[5] = s2b("");
/* 6558 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6562 */     rowVal[7] = s2b("false");
/* 6563 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6567 */     rowVal[9] = s2b("false");
/* 6568 */     rowVal[10] = s2b("false");
/* 6569 */     rowVal[11] = s2b("false");
/* 6570 */     rowVal[12] = s2b("DATE");
/* 6571 */     rowVal[13] = s2b("0");
/* 6572 */     rowVal[14] = s2b("0");
/* 6573 */     rowVal[15] = s2b("0");
/* 6574 */     rowVal[16] = s2b("0");
/* 6575 */     rowVal[17] = s2b("10");
/* 6576 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 6581 */     rowVal = new byte[18][];
/* 6582 */     rowVal[0] = s2b("TIME");
/* 6583 */     rowVal[1] = Integer.toString(92).getBytes();
/*      */     
/*      */ 
/* 6586 */     rowVal[2] = s2b("0");
/* 6587 */     rowVal[3] = s2b("'");
/* 6588 */     rowVal[4] = s2b("'");
/* 6589 */     rowVal[5] = s2b("");
/* 6590 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6594 */     rowVal[7] = s2b("false");
/* 6595 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6599 */     rowVal[9] = s2b("false");
/* 6600 */     rowVal[10] = s2b("false");
/* 6601 */     rowVal[11] = s2b("false");
/* 6602 */     rowVal[12] = s2b("TIME");
/* 6603 */     rowVal[13] = s2b("0");
/* 6604 */     rowVal[14] = s2b("0");
/* 6605 */     rowVal[15] = s2b("0");
/* 6606 */     rowVal[16] = s2b("0");
/* 6607 */     rowVal[17] = s2b("10");
/* 6608 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 6613 */     rowVal = new byte[18][];
/* 6614 */     rowVal[0] = s2b("DATETIME");
/* 6615 */     rowVal[1] = Integer.toString(93).getBytes();
/*      */     
/*      */ 
/* 6618 */     rowVal[2] = s2b("0");
/* 6619 */     rowVal[3] = s2b("'");
/* 6620 */     rowVal[4] = s2b("'");
/* 6621 */     rowVal[5] = s2b("");
/* 6622 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6626 */     rowVal[7] = s2b("false");
/* 6627 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6631 */     rowVal[9] = s2b("false");
/* 6632 */     rowVal[10] = s2b("false");
/* 6633 */     rowVal[11] = s2b("false");
/* 6634 */     rowVal[12] = s2b("DATETIME");
/* 6635 */     rowVal[13] = s2b("0");
/* 6636 */     rowVal[14] = s2b("0");
/* 6637 */     rowVal[15] = s2b("0");
/* 6638 */     rowVal[16] = s2b("0");
/* 6639 */     rowVal[17] = s2b("10");
/* 6640 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 6645 */     rowVal = new byte[18][];
/* 6646 */     rowVal[0] = s2b("TIMESTAMP");
/* 6647 */     rowVal[1] = Integer.toString(93).getBytes();
/*      */     
/*      */ 
/* 6650 */     rowVal[2] = s2b("0");
/* 6651 */     rowVal[3] = s2b("'");
/* 6652 */     rowVal[4] = s2b("'");
/* 6653 */     rowVal[5] = s2b("[(M)]");
/* 6654 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6658 */     rowVal[7] = s2b("false");
/* 6659 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */     
/*      */ 
/*      */ 
/* 6663 */     rowVal[9] = s2b("false");
/* 6664 */     rowVal[10] = s2b("false");
/* 6665 */     rowVal[11] = s2b("false");
/* 6666 */     rowVal[12] = s2b("TIMESTAMP");
/* 6667 */     rowVal[13] = s2b("0");
/* 6668 */     rowVal[14] = s2b("0");
/* 6669 */     rowVal[15] = s2b("0");
/* 6670 */     rowVal[16] = s2b("0");
/* 6671 */     rowVal[17] = s2b("10");
/* 6672 */     tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
/*      */     
/* 6674 */     return buildResultSet(fields, tuples);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getUDTs(String catalog, String schemaPattern, String typeNamePattern, int[] types)
/*      */     throws SQLException
/*      */   {
/* 6720 */     Field[] fields = new Field[6];
/* 6721 */     fields[0] = new Field("", "TYPE_CAT", 12, 32);
/* 6722 */     fields[1] = new Field("", "TYPE_SCHEM", 12, 32);
/* 6723 */     fields[2] = new Field("", "TYPE_NAME", 12, 32);
/* 6724 */     fields[3] = new Field("", "CLASS_NAME", 12, 32);
/* 6725 */     fields[4] = new Field("", "DATA_TYPE", 12, 32);
/* 6726 */     fields[5] = new Field("", "REMARKS", 12, 32);
/*      */     
/* 6728 */     ArrayList tuples = new ArrayList();
/*      */     
/* 6730 */     return buildResultSet(fields, tuples);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getURL()
/*      */     throws SQLException
/*      */   {
/* 6741 */     return this.conn.getURL();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getUserName()
/*      */     throws SQLException
/*      */   {
/* 6752 */     if (this.conn.getUseHostsInPrivileges()) {
/* 6753 */       java.sql.Statement stmt = null;
/* 6754 */       ResultSet rs = null;
/*      */       try
/*      */       {
/* 6757 */         stmt = this.conn.createStatement();
/* 6758 */         stmt.setEscapeProcessing(false);
/*      */         
/* 6760 */         rs = stmt.executeQuery("SELECT USER()");
/* 6761 */         rs.next();
/*      */         
/* 6763 */         return rs.getString(1);
/*      */       } finally {
/* 6765 */         if (rs != null) {
/*      */           try {
/* 6767 */             rs.close();
/*      */           } catch (Exception ex) {
/* 6769 */             AssertionFailedException.shouldNotHappen(ex);
/*      */           }
/*      */           
/* 6772 */           rs = null;
/*      */         }
/*      */         
/* 6775 */         if (stmt != null) {
/*      */           try {
/* 6777 */             stmt.close();
/*      */           } catch (Exception ex) {
/* 6779 */             AssertionFailedException.shouldNotHappen(ex);
/*      */           }
/*      */           
/* 6782 */           stmt = null;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 6787 */     return this.conn.getUser();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getVersionColumns(String catalog, String schema, String table)
/*      */     throws SQLException
/*      */   {
/* 6826 */     Field[] fields = new Field[8];
/* 6827 */     fields[0] = new Field("", "SCOPE", 5, 5);
/* 6828 */     fields[1] = new Field("", "COLUMN_NAME", 1, 32);
/* 6829 */     fields[2] = new Field("", "DATA_TYPE", 4, 5);
/* 6830 */     fields[3] = new Field("", "TYPE_NAME", 1, 16);
/* 6831 */     fields[4] = new Field("", "COLUMN_SIZE", 4, 16);
/* 6832 */     fields[5] = new Field("", "BUFFER_LENGTH", 4, 16);
/* 6833 */     fields[6] = new Field("", "DECIMAL_DIGITS", 5, 16);
/* 6834 */     fields[7] = new Field("", "PSEUDO_COLUMN", 5, 5);
/*      */     
/* 6836 */     return buildResultSet(fields, new ArrayList());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean insertsAreDetected(int type)
/*      */     throws SQLException
/*      */   {
/* 6852 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isCatalogAtStart()
/*      */     throws SQLException
/*      */   {
/* 6864 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isReadOnly()
/*      */     throws SQLException
/*      */   {
/* 6875 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean locatorsUpdateCopy()
/*      */     throws SQLException
/*      */   {
/* 6882 */     return !this.conn.getEmulateLocators();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean nullPlusNonNullIsNull()
/*      */     throws SQLException
/*      */   {
/* 6894 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean nullsAreSortedAtEnd()
/*      */     throws SQLException
/*      */   {
/* 6905 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean nullsAreSortedAtStart()
/*      */     throws SQLException
/*      */   {
/* 6916 */     return (this.conn.versionMeetsMinimum(4, 0, 2)) && (!this.conn.versionMeetsMinimum(4, 0, 11));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean nullsAreSortedHigh()
/*      */     throws SQLException
/*      */   {
/* 6928 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean nullsAreSortedLow()
/*      */     throws SQLException
/*      */   {
/* 6939 */     return !nullsAreSortedHigh();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean othersDeletesAreVisible(int type)
/*      */     throws SQLException
/*      */   {
/* 6952 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean othersInsertsAreVisible(int type)
/*      */     throws SQLException
/*      */   {
/* 6965 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean othersUpdatesAreVisible(int type)
/*      */     throws SQLException
/*      */   {
/* 6978 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean ownDeletesAreVisible(int type)
/*      */     throws SQLException
/*      */   {
/* 6991 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean ownInsertsAreVisible(int type)
/*      */     throws SQLException
/*      */   {
/* 7004 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean ownUpdatesAreVisible(int type)
/*      */     throws SQLException
/*      */   {
/* 7017 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private LocalAndReferencedColumns parseTableStatusIntoLocalAndReferencedColumns(String keysComment)
/*      */     throws SQLException
/*      */   {
/* 7038 */     String columnsDelimitter = ",";
/*      */     
/* 7040 */     char quoteChar = this.quotedId.length() == 0 ? '\000' : this.quotedId.charAt(0);
/*      */     
/*      */ 
/* 7043 */     int indexOfOpenParenLocalColumns = StringUtils.indexOfIgnoreCaseRespectQuotes(0, keysComment, "(", quoteChar, true);
/*      */     
/*      */ 
/*      */ 
/* 7047 */     if (indexOfOpenParenLocalColumns == -1) {
/* 7048 */       throw SQLError.createSQLException("Error parsing foreign keys definition, couldn't find start of local columns list.", "S1000", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 7053 */     String constraintName = removeQuotedId(keysComment.substring(0, indexOfOpenParenLocalColumns).trim());
/*      */     
/* 7055 */     keysComment = keysComment.substring(indexOfOpenParenLocalColumns, keysComment.length());
/*      */     
/*      */ 
/* 7058 */     String keysCommentTrimmed = keysComment.trim();
/*      */     
/* 7060 */     int indexOfCloseParenLocalColumns = StringUtils.indexOfIgnoreCaseRespectQuotes(0, keysCommentTrimmed, ")", quoteChar, true);
/*      */     
/*      */ 
/*      */ 
/* 7064 */     if (indexOfCloseParenLocalColumns == -1) {
/* 7065 */       throw SQLError.createSQLException("Error parsing foreign keys definition, couldn't find end of local columns list.", "S1000", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 7070 */     String localColumnNamesString = keysCommentTrimmed.substring(1, indexOfCloseParenLocalColumns);
/*      */     
/*      */ 
/* 7073 */     int indexOfRefer = StringUtils.indexOfIgnoreCaseRespectQuotes(0, keysCommentTrimmed, "REFER ", this.quotedId.charAt(0), true);
/*      */     
/*      */ 
/* 7076 */     if (indexOfRefer == -1) {
/* 7077 */       throw SQLError.createSQLException("Error parsing foreign keys definition, couldn't find start of referenced tables list.", "S1000", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 7082 */     int indexOfOpenParenReferCol = StringUtils.indexOfIgnoreCaseRespectQuotes(indexOfRefer, keysCommentTrimmed, "(", quoteChar, false);
/*      */     
/*      */ 
/*      */ 
/* 7086 */     if (indexOfOpenParenReferCol == -1) {
/* 7087 */       throw SQLError.createSQLException("Error parsing foreign keys definition, couldn't find start of referenced columns list.", "S1000", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 7092 */     String referCatalogTableString = keysCommentTrimmed.substring(indexOfRefer + "REFER ".length(), indexOfOpenParenReferCol);
/*      */     
/*      */ 
/* 7095 */     int indexOfSlash = StringUtils.indexOfIgnoreCaseRespectQuotes(0, referCatalogTableString, "/", this.quotedId.charAt(0), false);
/*      */     
/*      */ 
/* 7098 */     if (indexOfSlash == -1) {
/* 7099 */       throw SQLError.createSQLException("Error parsing foreign keys definition, couldn't find name of referenced catalog.", "S1000", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 7104 */     String referCatalog = removeQuotedId(referCatalogTableString.substring(0, indexOfSlash));
/*      */     
/* 7106 */     String referTable = removeQuotedId(referCatalogTableString.substring(indexOfSlash + 1).trim());
/*      */     
/*      */ 
/* 7109 */     int indexOfCloseParenRefer = StringUtils.indexOfIgnoreCaseRespectQuotes(indexOfOpenParenReferCol, keysCommentTrimmed, ")", quoteChar, true);
/*      */     
/*      */ 
/*      */ 
/* 7113 */     if (indexOfCloseParenRefer == -1) {
/* 7114 */       throw SQLError.createSQLException("Error parsing foreign keys definition, couldn't find end of referenced columns list.", "S1000", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 7119 */     String referColumnNamesString = keysCommentTrimmed.substring(indexOfOpenParenReferCol + 1, indexOfCloseParenRefer);
/*      */     
/*      */ 
/* 7122 */     List referColumnsList = StringUtils.split(referColumnNamesString, columnsDelimitter, this.quotedId, this.quotedId, false);
/*      */     
/* 7124 */     List localColumnsList = StringUtils.split(localColumnNamesString, columnsDelimitter, this.quotedId, this.quotedId, false);
/*      */     
/*      */ 
/* 7127 */     return new LocalAndReferencedColumns(localColumnsList, referColumnsList, constraintName, referCatalog, referTable);
/*      */   }
/*      */   
/*      */   private String removeQuotedId(String s)
/*      */   {
/* 7132 */     if (s == null) {
/* 7133 */       return null;
/*      */     }
/*      */     
/* 7136 */     if (this.quotedId.equals("")) {
/* 7137 */       return s;
/*      */     }
/*      */     
/* 7140 */     s = s.trim();
/*      */     
/* 7142 */     int frontOffset = 0;
/* 7143 */     int backOffset = s.length();
/* 7144 */     int quoteLength = this.quotedId.length();
/*      */     
/* 7146 */     if (s.startsWith(this.quotedId)) {
/* 7147 */       frontOffset = quoteLength;
/*      */     }
/*      */     
/* 7150 */     if (s.endsWith(this.quotedId)) {
/* 7151 */       backOffset -= quoteLength;
/*      */     }
/*      */     
/* 7154 */     return s.substring(frontOffset, backOffset);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected byte[] s2b(String s)
/*      */     throws SQLException
/*      */   {
/* 7166 */     if (s == null) {
/* 7167 */       return null;
/*      */     }
/*      */     
/* 7170 */     return StringUtils.getBytes(s, this.conn.getCharacterSetMetadata(), this.conn.getServerCharacterEncoding(), this.conn.parserKnowsUnicode(), this.conn, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean storesLowerCaseIdentifiers()
/*      */     throws SQLException
/*      */   {
/* 7184 */     return this.conn.storesLowerCaseTableName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean storesLowerCaseQuotedIdentifiers()
/*      */     throws SQLException
/*      */   {
/* 7196 */     return this.conn.storesLowerCaseTableName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean storesMixedCaseIdentifiers()
/*      */     throws SQLException
/*      */   {
/* 7208 */     return !this.conn.storesLowerCaseTableName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean storesMixedCaseQuotedIdentifiers()
/*      */     throws SQLException
/*      */   {
/* 7219 */     return !this.conn.storesLowerCaseTableName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean storesUpperCaseIdentifiers()
/*      */     throws SQLException
/*      */   {
/* 7231 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean storesUpperCaseQuotedIdentifiers()
/*      */     throws SQLException
/*      */   {
/* 7243 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsAlterTableWithAddColumn()
/*      */     throws SQLException
/*      */   {
/* 7254 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsAlterTableWithDropColumn()
/*      */     throws SQLException
/*      */   {
/* 7265 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsANSI92EntryLevelSQL()
/*      */     throws SQLException
/*      */   {
/* 7277 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsANSI92FullSQL()
/*      */     throws SQLException
/*      */   {
/* 7288 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsANSI92IntermediateSQL()
/*      */     throws SQLException
/*      */   {
/* 7299 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsBatchUpdates()
/*      */     throws SQLException
/*      */   {
/* 7311 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsCatalogsInDataManipulation()
/*      */     throws SQLException
/*      */   {
/* 7323 */     return this.conn.versionMeetsMinimum(3, 22, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsCatalogsInIndexDefinitions()
/*      */     throws SQLException
/*      */   {
/* 7335 */     return this.conn.versionMeetsMinimum(3, 22, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsCatalogsInPrivilegeDefinitions()
/*      */     throws SQLException
/*      */   {
/* 7347 */     return this.conn.versionMeetsMinimum(3, 22, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsCatalogsInProcedureCalls()
/*      */     throws SQLException
/*      */   {
/* 7359 */     return this.conn.versionMeetsMinimum(3, 22, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsCatalogsInTableDefinitions()
/*      */     throws SQLException
/*      */   {
/* 7371 */     return this.conn.versionMeetsMinimum(3, 22, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsColumnAliasing()
/*      */     throws SQLException
/*      */   {
/* 7387 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsConvert()
/*      */     throws SQLException
/*      */   {
/* 7398 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsConvert(int fromType, int toType)
/*      */     throws SQLException
/*      */   {
/* 7415 */     switch (fromType)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */     case -4: 
/*      */     case -3: 
/*      */     case -2: 
/*      */     case -1: 
/*      */     case 1: 
/*      */     case 12: 
/* 7426 */       switch (toType) {
/*      */       case -6: 
/*      */       case -5: 
/*      */       case -4: 
/*      */       case -3: 
/*      */       case -2: 
/*      */       case -1: 
/*      */       case 1: 
/*      */       case 2: 
/*      */       case 3: 
/*      */       case 4: 
/*      */       case 5: 
/*      */       case 6: 
/*      */       case 7: 
/*      */       case 8: 
/*      */       case 12: 
/*      */       case 91: 
/*      */       case 92: 
/*      */       case 93: 
/*      */       case 1111: 
/* 7446 */         return true;
/*      */       }
/*      */       
/* 7449 */       return false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case -7: 
/* 7456 */       return false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case -6: 
/*      */     case -5: 
/*      */     case 2: 
/*      */     case 3: 
/*      */     case 4: 
/*      */     case 5: 
/*      */     case 6: 
/*      */     case 7: 
/*      */     case 8: 
/* 7472 */       switch (toType) {
/*      */       case -6: 
/*      */       case -5: 
/*      */       case -4: 
/*      */       case -3: 
/*      */       case -2: 
/*      */       case -1: 
/*      */       case 1: 
/*      */       case 2: 
/*      */       case 3: 
/*      */       case 4: 
/*      */       case 5: 
/*      */       case 6: 
/*      */       case 7: 
/*      */       case 8: 
/*      */       case 12: 
/* 7488 */         return true;
/*      */       }
/*      */       
/* 7491 */       return false;
/*      */     
/*      */ 
/*      */ 
/*      */     case 0: 
/* 7496 */       return false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 1111: 
/* 7504 */       switch (toType) {
/*      */       case -4: 
/*      */       case -3: 
/*      */       case -2: 
/*      */       case -1: 
/*      */       case 1: 
/*      */       case 12: 
/* 7511 */         return true;
/*      */       }
/*      */       
/* 7514 */       return false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 91: 
/* 7520 */       switch (toType) {
/*      */       case -4: 
/*      */       case -3: 
/*      */       case -2: 
/*      */       case -1: 
/*      */       case 1: 
/*      */       case 12: 
/* 7527 */         return true;
/*      */       }
/*      */       
/* 7530 */       return false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 92: 
/* 7536 */       switch (toType) {
/*      */       case -4: 
/*      */       case -3: 
/*      */       case -2: 
/*      */       case -1: 
/*      */       case 1: 
/*      */       case 12: 
/* 7543 */         return true;
/*      */       }
/*      */       
/* 7546 */       return false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 93: 
/* 7555 */       switch (toType) {
/*      */       case -4: 
/*      */       case -3: 
/*      */       case -2: 
/*      */       case -1: 
/*      */       case 1: 
/*      */       case 12: 
/*      */       case 91: 
/*      */       case 92: 
/* 7564 */         return true;
/*      */       }
/*      */       
/* 7567 */       return false;
/*      */     }
/*      */     
/*      */     
/*      */ 
/* 7572 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsCoreSQLGrammar()
/*      */     throws SQLException
/*      */   {
/* 7584 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsCorrelatedSubqueries()
/*      */     throws SQLException
/*      */   {
/* 7596 */     return this.conn.versionMeetsMinimum(4, 1, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsDataDefinitionAndDataManipulationTransactions()
/*      */     throws SQLException
/*      */   {
/* 7609 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsDataManipulationTransactionsOnly()
/*      */     throws SQLException
/*      */   {
/* 7621 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsDifferentTableCorrelationNames()
/*      */     throws SQLException
/*      */   {
/* 7634 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsExpressionsInOrderBy()
/*      */     throws SQLException
/*      */   {
/* 7645 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsExtendedSQLGrammar()
/*      */     throws SQLException
/*      */   {
/* 7656 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsFullOuterJoins()
/*      */     throws SQLException
/*      */   {
/* 7667 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsGetGeneratedKeys()
/*      */   {
/* 7676 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsGroupBy()
/*      */     throws SQLException
/*      */   {
/* 7687 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsGroupByBeyondSelect()
/*      */     throws SQLException
/*      */   {
/* 7699 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsGroupByUnrelated()
/*      */     throws SQLException
/*      */   {
/* 7710 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsIntegrityEnhancementFacility()
/*      */     throws SQLException
/*      */   {
/* 7721 */     if (!this.conn.getOverrideSupportsIntegrityEnhancementFacility()) {
/* 7722 */       return false;
/*      */     }
/*      */     
/* 7725 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsLikeEscapeClause()
/*      */     throws SQLException
/*      */   {
/* 7737 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsLimitedOuterJoins()
/*      */     throws SQLException
/*      */   {
/* 7749 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsMinimumSQLGrammar()
/*      */     throws SQLException
/*      */   {
/* 7761 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsMixedCaseIdentifiers()
/*      */     throws SQLException
/*      */   {
/* 7772 */     return !this.conn.lowerCaseTableNames();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsMixedCaseQuotedIdentifiers()
/*      */     throws SQLException
/*      */   {
/* 7784 */     return !this.conn.lowerCaseTableNames();
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean supportsMultipleOpenResults()
/*      */     throws SQLException
/*      */   {
/* 7791 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsMultipleResultSets()
/*      */     throws SQLException
/*      */   {
/* 7802 */     return this.conn.versionMeetsMinimum(4, 1, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsMultipleTransactions()
/*      */     throws SQLException
/*      */   {
/* 7814 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean supportsNamedParameters()
/*      */     throws SQLException
/*      */   {
/* 7821 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsNonNullableColumns()
/*      */     throws SQLException
/*      */   {
/* 7833 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsOpenCursorsAcrossCommit()
/*      */     throws SQLException
/*      */   {
/* 7845 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsOpenCursorsAcrossRollback()
/*      */     throws SQLException
/*      */   {
/* 7857 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsOpenStatementsAcrossCommit()
/*      */     throws SQLException
/*      */   {
/* 7869 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsOpenStatementsAcrossRollback()
/*      */     throws SQLException
/*      */   {
/* 7881 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsOrderByUnrelated()
/*      */     throws SQLException
/*      */   {
/* 7892 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsOuterJoins()
/*      */     throws SQLException
/*      */   {
/* 7903 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsPositionedDelete()
/*      */     throws SQLException
/*      */   {
/* 7914 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsPositionedUpdate()
/*      */     throws SQLException
/*      */   {
/* 7925 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsResultSetConcurrency(int type, int concurrency)
/*      */     throws SQLException
/*      */   {
/* 7943 */     switch (type) {
/*      */     case 1004: 
/* 7945 */       if ((concurrency == 1007) || (concurrency == 1008))
/*      */       {
/* 7947 */         return true;
/*      */       }
/* 7949 */       throw SQLError.createSQLException("Illegal arguments to supportsResultSetConcurrency()", "S1009", getExceptionInterceptor());
/*      */     
/*      */ 
/*      */ 
/*      */     case 1003: 
/* 7954 */       if ((concurrency == 1007) || (concurrency == 1008))
/*      */       {
/* 7956 */         return true;
/*      */       }
/* 7958 */       throw SQLError.createSQLException("Illegal arguments to supportsResultSetConcurrency()", "S1009", getExceptionInterceptor());
/*      */     
/*      */ 
/*      */ 
/*      */     case 1005: 
/* 7963 */       return false;
/*      */     }
/* 7965 */     throw SQLError.createSQLException("Illegal arguments to supportsResultSetConcurrency()", "S1009", getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsResultSetHoldability(int holdability)
/*      */     throws SQLException
/*      */   {
/* 7977 */     return holdability == 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsResultSetType(int type)
/*      */     throws SQLException
/*      */   {
/* 7991 */     return type == 1004;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean supportsSavepoints()
/*      */     throws SQLException
/*      */   {
/* 7999 */     return (this.conn.versionMeetsMinimum(4, 0, 14)) || (this.conn.versionMeetsMinimum(4, 1, 1));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsSchemasInDataManipulation()
/*      */     throws SQLException
/*      */   {
/* 8011 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsSchemasInIndexDefinitions()
/*      */     throws SQLException
/*      */   {
/* 8022 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsSchemasInPrivilegeDefinitions()
/*      */     throws SQLException
/*      */   {
/* 8033 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsSchemasInProcedureCalls()
/*      */     throws SQLException
/*      */   {
/* 8044 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsSchemasInTableDefinitions()
/*      */     throws SQLException
/*      */   {
/* 8055 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsSelectForUpdate()
/*      */     throws SQLException
/*      */   {
/* 8066 */     return this.conn.versionMeetsMinimum(4, 0, 0);
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean supportsStatementPooling()
/*      */     throws SQLException
/*      */   {
/* 8073 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsStoredProcedures()
/*      */     throws SQLException
/*      */   {
/* 8085 */     return this.conn.versionMeetsMinimum(5, 0, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsSubqueriesInComparisons()
/*      */     throws SQLException
/*      */   {
/* 8097 */     return this.conn.versionMeetsMinimum(4, 1, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsSubqueriesInExists()
/*      */     throws SQLException
/*      */   {
/* 8109 */     return this.conn.versionMeetsMinimum(4, 1, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsSubqueriesInIns()
/*      */     throws SQLException
/*      */   {
/* 8121 */     return this.conn.versionMeetsMinimum(4, 1, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsSubqueriesInQuantifieds()
/*      */     throws SQLException
/*      */   {
/* 8133 */     return this.conn.versionMeetsMinimum(4, 1, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsTableCorrelationNames()
/*      */     throws SQLException
/*      */   {
/* 8145 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsTransactionIsolationLevel(int level)
/*      */     throws SQLException
/*      */   {
/* 8160 */     if (this.conn.supportsIsolationLevel()) {
/* 8161 */       switch (level) {
/*      */       case 1: 
/*      */       case 2: 
/*      */       case 4: 
/*      */       case 8: 
/* 8166 */         return true;
/*      */       }
/*      */       
/* 8169 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 8173 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsTransactions()
/*      */     throws SQLException
/*      */   {
/* 8185 */     return this.conn.supportsTransactions();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsUnion()
/*      */     throws SQLException
/*      */   {
/* 8196 */     return this.conn.versionMeetsMinimum(4, 0, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsUnionAll()
/*      */     throws SQLException
/*      */   {
/* 8207 */     return this.conn.versionMeetsMinimum(4, 0, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean updatesAreDetected(int type)
/*      */     throws SQLException
/*      */   {
/* 8221 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean usesLocalFilePerTable()
/*      */     throws SQLException
/*      */   {
/* 8232 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean usesLocalFiles()
/*      */     throws SQLException
/*      */   {
/* 8243 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSet getFunctionColumns(String catalog, String schemaPattern, String functionNamePattern, String columnNamePattern)
/*      */     throws SQLException
/*      */   {
/* 8259 */     Field[] fields = createFunctionColumnsFields();
/*      */     
/* 8261 */     return getProcedureOrFunctionColumns(fields, catalog, schemaPattern, functionNamePattern, columnNamePattern, false, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected Field[] createFunctionColumnsFields()
/*      */   {
/* 8268 */     Field[] fields = { new Field("", "FUNCTION_CAT", 12, 512), new Field("", "FUNCTION_SCHEM", 12, 512), new Field("", "FUNCTION_NAME", 12, 512), new Field("", "COLUMN_NAME", 12, 512), new Field("", "COLUMN_TYPE", 12, 64), new Field("", "DATA_TYPE", 5, 6), new Field("", "TYPE_NAME", 12, 64), new Field("", "PRECISION", 4, 12), new Field("", "LENGTH", 4, 12), new Field("", "SCALE", 5, 12), new Field("", "RADIX", 5, 6), new Field("", "NULLABLE", 5, 6), new Field("", "REMARKS", 12, 512), new Field("", "CHAR_OCTET_LENGTH", 4, 32), new Field("", "ORDINAL_POSITION", 4, 32), new Field("", "IS_NULLABLE", 12, 12), new Field("", "SPECIFIC_NAME", 12, 64) };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 8286 */     return fields;
/*      */   }
/*      */   
/*      */   public boolean providesQueryObjectGenerator() throws SQLException {
/* 8290 */     return false;
/*      */   }
/*      */   
/*      */   public ResultSet getSchemas(String catalog, String schemaPattern) throws SQLException
/*      */   {
/* 8295 */     Field[] fields = { new Field("", "TABLE_SCHEM", 12, 255), new Field("", "TABLE_CATALOG", 12, 255) };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 8300 */     return buildResultSet(fields, new ArrayList());
/*      */   }
/*      */   
/*      */   public boolean supportsStoredFunctionsUsingCallSyntax() throws SQLException {
/* 8304 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected PreparedStatement prepareMetaDataSafeStatement(String sql)
/*      */     throws SQLException
/*      */   {
/* 8317 */     PreparedStatement pStmt = this.conn.clientPrepareStatement(sql);
/*      */     
/* 8319 */     if (pStmt.getMaxRows() != 0) {
/* 8320 */       pStmt.setMaxRows(0);
/*      */     }
/*      */     
/* 8323 */     ((Statement)pStmt).setHoldResultsOpenOverClose(true);
/*      */     
/* 8325 */     return pStmt;
/*      */   }
/*      */ }


/* Location:              C:\Users\Static\Desktop\G10_Prototype_Client.jar!\mysql-connector-java-5.1.19-bin.jar!\com\mysql\jdbc\DatabaseMetaData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */