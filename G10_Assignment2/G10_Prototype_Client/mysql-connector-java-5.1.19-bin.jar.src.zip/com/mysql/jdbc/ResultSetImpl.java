/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import com.mysql.jdbc.profiler.ProfilerEventHandler;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.StringReader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Date;
/*      */ import java.sql.Ref;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.TimeZone;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ResultSetImpl
/*      */   implements ResultSetInternalMethods
/*      */ {
/*      */   private static final Constructor<?> JDBC_4_RS_4_ARG_CTOR;
/*      */   private static final Constructor<?> JDBC_4_RS_6_ARG_CTOR;
/*      */   private static final Constructor<?> JDBC_4_UPD_RS_6_ARG_CTOR;
/*      */   protected static final double MIN_DIFF_PREC;
/*      */   protected static final double MAX_DIFF_PREC;
/*      */   static int resultCounter;
/*      */   
/*      */   protected static BigInteger convertLongToUlong(long longVal)
/*      */   {
/*  179 */     byte[] asBytes = new byte[8];
/*  180 */     asBytes[7] = ((byte)(int)(longVal & 0xFF));
/*  181 */     asBytes[6] = ((byte)(int)(longVal >>> 8));
/*  182 */     asBytes[5] = ((byte)(int)(longVal >>> 16));
/*  183 */     asBytes[4] = ((byte)(int)(longVal >>> 24));
/*  184 */     asBytes[3] = ((byte)(int)(longVal >>> 32));
/*  185 */     asBytes[2] = ((byte)(int)(longVal >>> 40));
/*  186 */     asBytes[1] = ((byte)(int)(longVal >>> 48));
/*  187 */     asBytes[0] = ((byte)(int)(longVal >>> 56));
/*      */     
/*  189 */     return new BigInteger(1, asBytes);
/*      */   }
/*      */   
/*      */ 
/*  193 */   protected String catalog = null;
/*      */   
/*      */ 
/*  196 */   protected Map<String, Integer> columnLabelToIndex = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  202 */   protected Map<String, Integer> columnToIndexCache = null;
/*      */   
/*      */ 
/*  205 */   protected boolean[] columnUsed = null;
/*      */   
/*      */ 
/*      */   protected MySQLConnection connection;
/*      */   
/*      */ 
/*  211 */   protected long connectionId = 0L;
/*      */   
/*      */ 
/*  214 */   protected int currentRow = -1;
/*      */   
/*      */ 
/*      */   TimeZone defaultTimeZone;
/*      */   
/*  219 */   protected boolean doingUpdates = false;
/*      */   
/*  221 */   protected ProfilerEventHandler eventSink = null;
/*      */   
/*  223 */   Calendar fastDateCal = null;
/*      */   
/*      */ 
/*  226 */   protected int fetchDirection = 1000;
/*      */   
/*      */ 
/*  229 */   protected int fetchSize = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Field[] fields;
/*      */   
/*      */ 
/*      */ 
/*      */   protected char firstCharOfQuery;
/*      */   
/*      */ 
/*      */ 
/*  242 */   protected Map<String, Integer> fullColumnNameToIndex = null;
/*      */   
/*  244 */   protected Map<String, Integer> columnNameToIndex = null;
/*      */   
/*  246 */   protected boolean hasBuiltIndexMapping = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  252 */   protected boolean isBinaryEncoded = false;
/*      */   
/*      */ 
/*  255 */   protected boolean isClosed = false;
/*      */   
/*  257 */   protected ResultSetInternalMethods nextResultSet = null;
/*      */   
/*      */ 
/*  260 */   protected boolean onInsertRow = false;
/*      */   
/*      */ 
/*      */ 
/*      */   protected StatementImpl owningStatement;
/*      */   
/*      */ 
/*      */ 
/*      */   protected Throwable pointOfOrigin;
/*      */   
/*      */ 
/*  271 */   protected boolean profileSql = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  277 */   protected boolean reallyResult = false;
/*      */   
/*      */ 
/*      */   protected int resultId;
/*      */   
/*      */ 
/*  283 */   protected int resultSetConcurrency = 0;
/*      */   
/*      */ 
/*  286 */   protected int resultSetType = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected RowData rowData;
/*      */   
/*      */ 
/*      */ 
/*  295 */   protected String serverInfo = null;
/*      */   
/*      */ 
/*      */   PreparedStatement statementUsedForFetchingRows;
/*      */   
/*  300 */   protected ResultSetRow thisRow = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected long updateCount;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  314 */   protected long updateId = -1L;
/*      */   
/*  316 */   private boolean useStrictFloatingPoint = false;
/*      */   
/*  318 */   protected boolean useUsageAdvisor = false;
/*      */   
/*      */ 
/*  321 */   protected SQLWarning warningChain = null;
/*      */   
/*      */ 
/*  324 */   protected boolean wasNullFlag = false;
/*      */   
/*      */   protected Statement wrapperStatement;
/*      */   
/*      */   protected boolean retainOwningStatement;
/*      */   
/*  330 */   protected Calendar gmtCalendar = null;
/*      */   
/*  332 */   protected boolean useFastDateParsing = false;
/*      */   
/*  334 */   private boolean padCharsWithSpace = false;
/*      */   
/*      */   private boolean jdbcCompliantTruncationForReads;
/*      */   
/*  338 */   private boolean useFastIntParsing = true;
/*      */   private boolean useColumnNamesInFindColumn;
/*      */   private ExceptionInterceptor exceptionInterceptor;
/*      */   static final char[] EMPTY_SPACE;
/*      */   
/*      */   static
/*      */   {
/*  125 */     if (Util.isJdbc4()) {
/*      */       try {
/*  127 */         JDBC_4_RS_4_ARG_CTOR = Class.forName("com.mysql.jdbc.JDBC4ResultSet").getConstructor(new Class[] { Long.TYPE, Long.TYPE, MySQLConnection.class, StatementImpl.class });
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  132 */         JDBC_4_RS_6_ARG_CTOR = Class.forName("com.mysql.jdbc.JDBC4ResultSet").getConstructor(new Class[] { String.class, Field[].class, RowData.class, MySQLConnection.class, StatementImpl.class });
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  138 */         JDBC_4_UPD_RS_6_ARG_CTOR = Class.forName("com.mysql.jdbc.JDBC4UpdatableResultSet").getConstructor(new Class[] { String.class, Field[].class, RowData.class, MySQLConnection.class, StatementImpl.class });
/*      */ 
/*      */ 
/*      */       }
/*      */       catch (SecurityException e)
/*      */       {
/*      */ 
/*      */ 
/*  146 */         throw new RuntimeException(e);
/*      */       } catch (NoSuchMethodException e) {
/*  148 */         throw new RuntimeException(e);
/*      */       } catch (ClassNotFoundException e) {
/*  150 */         throw new RuntimeException(e);
/*      */       }
/*      */     } else {
/*  153 */       JDBC_4_RS_4_ARG_CTOR = null;
/*  154 */       JDBC_4_RS_6_ARG_CTOR = null;
/*  155 */       JDBC_4_UPD_RS_6_ARG_CTOR = null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  162 */     MIN_DIFF_PREC = Float.parseFloat(Float.toString(Float.MIN_VALUE)) - Double.parseDouble(Float.toString(Float.MIN_VALUE));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  168 */     MAX_DIFF_PREC = Float.parseFloat(Float.toString(Float.MAX_VALUE)) - Double.parseDouble(Float.toString(Float.MAX_VALUE));
/*      */     
/*      */ 
/*      */ 
/*  172 */     resultCounter = 1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  343 */     EMPTY_SPACE = new char['ÿ'];
/*      */     
/*      */ 
/*  346 */     for (int i = 0; i < EMPTY_SPACE.length; i++) {
/*  347 */       EMPTY_SPACE[i] = ' ';
/*      */     }
/*      */   }
/*      */   
/*      */   protected static ResultSetImpl getInstance(long updateCount, long updateID, MySQLConnection conn, StatementImpl creatorStmt) throws SQLException
/*      */   {
/*  353 */     if (!Util.isJdbc4()) {
/*  354 */       return new ResultSetImpl(updateCount, updateID, conn, creatorStmt);
/*      */     }
/*      */     
/*  357 */     return (ResultSetImpl)Util.handleNewInstance(JDBC_4_RS_4_ARG_CTOR, new Object[] { Long.valueOf(updateCount), Long.valueOf(updateID), conn, creatorStmt }, conn.getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static ResultSetImpl getInstance(String catalog, Field[] fields, RowData tuples, MySQLConnection conn, StatementImpl creatorStmt, boolean isUpdatable)
/*      */     throws SQLException
/*      */   {
/*  373 */     if (!Util.isJdbc4()) {
/*  374 */       if (!isUpdatable) {
/*  375 */         return new ResultSetImpl(catalog, fields, tuples, conn, creatorStmt);
/*      */       }
/*      */       
/*  378 */       return new UpdatableResultSet(catalog, fields, tuples, conn, creatorStmt);
/*      */     }
/*      */     
/*      */ 
/*  382 */     if (!isUpdatable) {
/*  383 */       return (ResultSetImpl)Util.handleNewInstance(JDBC_4_RS_6_ARG_CTOR, new Object[] { catalog, fields, tuples, conn, creatorStmt }, conn.getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  388 */     return (ResultSetImpl)Util.handleNewInstance(JDBC_4_UPD_RS_6_ARG_CTOR, new Object[] { catalog, fields, tuples, conn, creatorStmt }, conn.getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSetImpl(long updateCount, long updateID, MySQLConnection conn, StatementImpl creatorStmt)
/*      */   {
/*  406 */     this.updateCount = updateCount;
/*  407 */     this.updateId = updateID;
/*  408 */     this.reallyResult = false;
/*  409 */     this.fields = new Field[0];
/*      */     
/*  411 */     this.connection = conn;
/*  412 */     this.owningStatement = creatorStmt;
/*      */     
/*  414 */     this.retainOwningStatement = false;
/*      */     
/*  416 */     if (this.connection != null) {
/*  417 */       this.exceptionInterceptor = this.connection.getExceptionInterceptor();
/*      */       
/*  419 */       this.retainOwningStatement = this.connection.getRetainStatementAfterResultSetClose();
/*      */       
/*      */ 
/*  422 */       this.connectionId = this.connection.getId();
/*  423 */       this.serverTimeZoneTz = this.connection.getServerTimezoneTZ();
/*  424 */       this.padCharsWithSpace = this.connection.getPadCharsWithSpace();
/*      */       
/*  426 */       this.useLegacyDatetimeCode = this.connection.getUseLegacyDatetimeCode();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ResultSetImpl(String catalog, Field[] fields, RowData tuples, MySQLConnection conn, StatementImpl creatorStmt)
/*      */     throws SQLException
/*      */   {
/*  449 */     this.connection = conn;
/*      */     
/*  451 */     this.retainOwningStatement = false;
/*      */     
/*  453 */     if (this.connection != null) {
/*  454 */       this.useStrictFloatingPoint = this.connection.getStrictFloatingPoint();
/*      */       
/*  456 */       setDefaultTimeZone(this.connection.getDefaultTimeZone());
/*  457 */       this.connectionId = this.connection.getId();
/*  458 */       this.useFastDateParsing = this.connection.getUseFastDateParsing();
/*  459 */       this.profileSql = this.connection.getProfileSql();
/*  460 */       this.retainOwningStatement = this.connection.getRetainStatementAfterResultSetClose();
/*      */       
/*  462 */       this.jdbcCompliantTruncationForReads = this.connection.getJdbcCompliantTruncationForReads();
/*  463 */       this.useFastIntParsing = this.connection.getUseFastIntParsing();
/*  464 */       this.serverTimeZoneTz = this.connection.getServerTimezoneTZ();
/*  465 */       this.padCharsWithSpace = this.connection.getPadCharsWithSpace();
/*      */     }
/*      */     
/*  468 */     this.owningStatement = creatorStmt;
/*      */     
/*  470 */     this.catalog = catalog;
/*      */     
/*  472 */     this.fields = fields;
/*  473 */     this.rowData = tuples;
/*  474 */     this.updateCount = this.rowData.size();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  481 */     this.reallyResult = true;
/*      */     
/*      */ 
/*  484 */     if (this.rowData.size() > 0) {
/*  485 */       if ((this.updateCount == 1L) && 
/*  486 */         (this.thisRow == null)) {
/*  487 */         this.rowData.close();
/*  488 */         this.updateCount = -1L;
/*      */       }
/*      */     }
/*      */     else {
/*  492 */       this.thisRow = null;
/*      */     }
/*      */     
/*  495 */     this.rowData.setOwner(this);
/*      */     
/*  497 */     if (this.fields != null) {
/*  498 */       initializeWithMetadata();
/*      */     }
/*  500 */     this.useLegacyDatetimeCode = this.connection.getUseLegacyDatetimeCode();
/*      */     
/*  502 */     this.useColumnNamesInFindColumn = this.connection.getUseColumnNamesInFindColumn();
/*      */     
/*  504 */     setRowPositionValidity();
/*      */   }
/*      */   
/*      */   public synchronized void initializeWithMetadata() throws SQLException {
/*  508 */     this.rowData.setMetadata(this.fields);
/*      */     
/*  510 */     this.columnToIndexCache = new HashMap();
/*      */     
/*  512 */     if ((this.profileSql) || (this.connection.getUseUsageAdvisor())) {
/*  513 */       this.columnUsed = new boolean[this.fields.length];
/*  514 */       this.pointOfOrigin = new Throwable();
/*  515 */       this.resultId = (resultCounter++);
/*  516 */       this.useUsageAdvisor = this.connection.getUseUsageAdvisor();
/*  517 */       this.eventSink = ProfilerEventHandlerFactory.getInstance(this.connection);
/*      */     }
/*      */     
/*  520 */     if (this.connection.getGatherPerformanceMetrics()) {
/*  521 */       this.connection.incrementNumberOfResultSetsCreated();
/*      */       
/*  523 */       Set<String> tableNamesSet = new HashSet();
/*      */       
/*  525 */       for (int i = 0; i < this.fields.length; i++) {
/*  526 */         Field f = this.fields[i];
/*      */         
/*  528 */         String tableName = f.getOriginalTableName();
/*      */         
/*  530 */         if (tableName == null) {
/*  531 */           tableName = f.getTableName();
/*      */         }
/*      */         
/*  534 */         if (tableName != null) {
/*  535 */           if (this.connection.lowerCaseTableNames()) {
/*  536 */             tableName = tableName.toLowerCase();
/*      */           }
/*      */           
/*      */ 
/*  540 */           tableNamesSet.add(tableName);
/*      */         }
/*      */       }
/*      */       
/*  544 */       this.connection.reportNumberOfTablesAccessed(tableNamesSet.size());
/*      */     }
/*      */   }
/*      */   
/*      */   private synchronized void createCalendarIfNeeded() {
/*  549 */     if (this.fastDateCal == null) {
/*  550 */       this.fastDateCal = new GregorianCalendar(Locale.US);
/*  551 */       this.fastDateCal.setTimeZone(getDefaultTimeZone());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean absolute(int row)
/*      */     throws SQLException
/*      */   {
/*  594 */     checkClosed();
/*      */     
/*      */     boolean b;
/*      */     boolean b;
/*  598 */     if (this.rowData.size() == 0) {
/*  599 */       b = false;
/*      */     } else {
/*  601 */       if (row == 0) {
/*  602 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Cannot_absolute_position_to_row_0_110"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  608 */       if (this.onInsertRow) {
/*  609 */         this.onInsertRow = false;
/*      */       }
/*      */       
/*  612 */       if (this.doingUpdates) {
/*  613 */         this.doingUpdates = false;
/*      */       }
/*      */       
/*  616 */       if (this.thisRow != null) {
/*  617 */         this.thisRow.closeOpenStreams();
/*      */       }
/*      */       boolean b;
/*  620 */       if (row == 1) {
/*  621 */         b = first(); } else { boolean b;
/*  622 */         if (row == -1) {
/*  623 */           b = last(); } else { boolean b;
/*  624 */           if (row > this.rowData.size()) {
/*  625 */             afterLast();
/*  626 */             b = false;
/*      */           } else { boolean b;
/*  628 */             if (row < 0)
/*      */             {
/*  630 */               int newRowPosition = this.rowData.size() + row + 1;
/*      */               boolean b;
/*  632 */               if (newRowPosition <= 0) {
/*  633 */                 beforeFirst();
/*  634 */                 b = false;
/*      */               } else {
/*  636 */                 b = absolute(newRowPosition);
/*      */               }
/*      */             } else {
/*  639 */               row--;
/*  640 */               this.rowData.setCurrentRow(row);
/*  641 */               this.thisRow = this.rowData.getAt(row);
/*  642 */               b = true;
/*      */             }
/*      */           }
/*      */         }
/*      */       } }
/*  647 */     setRowPositionValidity();
/*      */     
/*  649 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void afterLast()
/*      */     throws SQLException
/*      */   {
/*  665 */     checkClosed();
/*      */     
/*  667 */     if (this.onInsertRow) {
/*  668 */       this.onInsertRow = false;
/*      */     }
/*      */     
/*  671 */     if (this.doingUpdates) {
/*  672 */       this.doingUpdates = false;
/*      */     }
/*      */     
/*  675 */     if (this.thisRow != null) {
/*  676 */       this.thisRow.closeOpenStreams();
/*      */     }
/*      */     
/*  679 */     if (this.rowData.size() != 0) {
/*  680 */       this.rowData.afterLast();
/*  681 */       this.thisRow = null;
/*      */     }
/*      */     
/*  684 */     setRowPositionValidity();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void beforeFirst()
/*      */     throws SQLException
/*      */   {
/*  700 */     checkClosed();
/*      */     
/*  702 */     if (this.onInsertRow) {
/*  703 */       this.onInsertRow = false;
/*      */     }
/*      */     
/*  706 */     if (this.doingUpdates) {
/*  707 */       this.doingUpdates = false;
/*      */     }
/*      */     
/*  710 */     if (this.rowData.size() == 0) {
/*  711 */       return;
/*      */     }
/*      */     
/*  714 */     if (this.thisRow != null) {
/*  715 */       this.thisRow.closeOpenStreams();
/*      */     }
/*      */     
/*  718 */     this.rowData.beforeFirst();
/*  719 */     this.thisRow = null;
/*      */     
/*  721 */     setRowPositionValidity();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void buildIndexMapping()
/*      */     throws SQLException
/*      */   {
/*  732 */     int numFields = this.fields.length;
/*  733 */     this.columnLabelToIndex = new TreeMap(String.CASE_INSENSITIVE_ORDER);
/*  734 */     this.fullColumnNameToIndex = new TreeMap(String.CASE_INSENSITIVE_ORDER);
/*  735 */     this.columnNameToIndex = new TreeMap(String.CASE_INSENSITIVE_ORDER);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  749 */     for (int i = numFields - 1; i >= 0; i--) {
/*  750 */       Integer index = Integer.valueOf(i);
/*  751 */       String columnName = this.fields[i].getOriginalName();
/*  752 */       String columnLabel = this.fields[i].getName();
/*  753 */       String fullColumnName = this.fields[i].getFullName();
/*      */       
/*  755 */       if (columnLabel != null) {
/*  756 */         this.columnLabelToIndex.put(columnLabel, index);
/*      */       }
/*      */       
/*  759 */       if (fullColumnName != null) {
/*  760 */         this.fullColumnNameToIndex.put(fullColumnName, index);
/*      */       }
/*      */       
/*  763 */       if (columnName != null) {
/*  764 */         this.columnNameToIndex.put(columnName, index);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  769 */     this.hasBuiltIndexMapping = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void cancelRowUpdates()
/*      */     throws SQLException
/*      */   {
/*  785 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void checkClosed()
/*      */     throws SQLException
/*      */   {
/*  795 */     if (this.isClosed) {
/*  796 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Operation_not_allowed_after_ResultSet_closed_144"), "S1000", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final synchronized void checkColumnBounds(int columnIndex)
/*      */     throws SQLException
/*      */   {
/*  813 */     if (columnIndex < 1) {
/*  814 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Column_Index_out_of_range_low", new Object[] { Integer.valueOf(columnIndex), Integer.valueOf(this.fields.length) }), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  819 */     if (columnIndex > this.fields.length) {
/*  820 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Column_Index_out_of_range_high", new Object[] { Integer.valueOf(columnIndex), Integer.valueOf(this.fields.length) }), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  827 */     if ((this.profileSql) || (this.useUsageAdvisor)) {
/*  828 */       this.columnUsed[(columnIndex - 1)] = true;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void checkRowPos()
/*      */     throws SQLException
/*      */   {
/*  840 */     checkClosed();
/*      */     
/*  842 */     if (!this.onValidRow) {
/*  843 */       throw SQLError.createSQLException(this.invalidRowReason, "S1000", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*  848 */   private boolean onValidRow = false;
/*  849 */   private String invalidRowReason = null;
/*      */   protected boolean useLegacyDatetimeCode;
/*      */   private TimeZone serverTimeZoneTz;
/*      */   
/*      */   private void setRowPositionValidity() throws SQLException {
/*  854 */     if ((!this.rowData.isDynamic()) && (this.rowData.size() == 0)) {
/*  855 */       this.invalidRowReason = Messages.getString("ResultSet.Illegal_operation_on_empty_result_set");
/*      */       
/*  857 */       this.onValidRow = false;
/*  858 */     } else if (this.rowData.isBeforeFirst()) {
/*  859 */       this.invalidRowReason = Messages.getString("ResultSet.Before_start_of_result_set_146");
/*      */       
/*  861 */       this.onValidRow = false;
/*  862 */     } else if (this.rowData.isAfterLast()) {
/*  863 */       this.invalidRowReason = Messages.getString("ResultSet.After_end_of_result_set_148");
/*      */       
/*  865 */       this.onValidRow = false;
/*      */     } else {
/*  867 */       this.onValidRow = true;
/*  868 */       this.invalidRowReason = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void clearNextResult()
/*      */   {
/*  877 */     this.nextResultSet = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void clearWarnings()
/*      */     throws SQLException
/*      */   {
/*  888 */     this.warningChain = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void close()
/*      */     throws SQLException
/*      */   {
/*  909 */     realClose(true);
/*      */   }
/*      */   
/*      */ 
/*      */   private int convertToZeroWithEmptyCheck()
/*      */     throws SQLException
/*      */   {
/*  916 */     if (this.connection.getEmptyStringsConvertToZero()) {
/*  917 */       return 0;
/*      */     }
/*      */     
/*  920 */     throw SQLError.createSQLException("Can't convert empty string ('') to numeric", "22018", getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */   private String convertToZeroLiteralStringWithEmptyCheck()
/*      */     throws SQLException
/*      */   {
/*  927 */     if (this.connection.getEmptyStringsConvertToZero()) {
/*  928 */       return "0";
/*      */     }
/*      */     
/*  931 */     throw SQLError.createSQLException("Can't convert empty string ('') to numeric", "22018", getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized ResultSetInternalMethods copy()
/*      */     throws SQLException
/*      */   {
/*  939 */     ResultSetInternalMethods rs = getInstance(this.catalog, this.fields, this.rowData, this.connection, this.owningStatement, false);
/*      */     
/*      */ 
/*  942 */     return rs;
/*      */   }
/*      */   
/*      */   public void redefineFieldsForDBMD(Field[] f) {
/*  946 */     this.fields = f;
/*      */     
/*  948 */     for (int i = 0; i < this.fields.length; i++) {
/*  949 */       this.fields[i].setUseOldNameMetadata(true);
/*  950 */       this.fields[i].setConnection(this.connection);
/*      */     }
/*      */   }
/*      */   
/*      */   public void populateCachedMetaData(CachedResultSetMetaData cachedMetaData) throws SQLException
/*      */   {
/*  956 */     cachedMetaData.fields = this.fields;
/*  957 */     cachedMetaData.columnNameToIndex = this.columnLabelToIndex;
/*  958 */     cachedMetaData.fullColumnNameToIndex = this.fullColumnNameToIndex;
/*  959 */     cachedMetaData.metadata = getMetaData();
/*      */   }
/*      */   
/*      */   public void initializeFromCachedMetaData(CachedResultSetMetaData cachedMetaData) {
/*  963 */     this.fields = cachedMetaData.fields;
/*  964 */     this.columnLabelToIndex = cachedMetaData.columnNameToIndex;
/*  965 */     this.fullColumnNameToIndex = cachedMetaData.fullColumnNameToIndex;
/*  966 */     this.hasBuiltIndexMapping = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void deleteRow()
/*      */     throws SQLException
/*      */   {
/*  981 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String extractStringFromNativeColumn(int columnIndex, int mysqlType)
/*      */     throws SQLException
/*      */   {
/*  993 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/*  995 */     this.wasNullFlag = false;
/*      */     
/*  997 */     if (this.thisRow.isNull(columnIndexMinusOne)) {
/*  998 */       this.wasNullFlag = true;
/*      */       
/* 1000 */       return null;
/*      */     }
/*      */     
/* 1003 */     this.wasNullFlag = false;
/*      */     
/* 1005 */     String encoding = this.fields[columnIndexMinusOne].getCharacterSet();
/*      */     
/*      */ 
/* 1008 */     return this.thisRow.getString(columnIndex - 1, encoding, this.connection);
/*      */   }
/*      */   
/*      */   protected synchronized Date fastDateCreate(Calendar cal, int year, int month, int day)
/*      */   {
/* 1013 */     if (this.useLegacyDatetimeCode) {
/* 1014 */       return TimeUtil.fastDateCreate(year, month, day, cal);
/*      */     }
/*      */     
/* 1017 */     if (cal == null) {
/* 1018 */       createCalendarIfNeeded();
/* 1019 */       cal = this.fastDateCal;
/*      */     }
/*      */     
/* 1022 */     boolean useGmtMillis = this.connection.getUseGmtMillisForDatetimes();
/*      */     
/* 1024 */     return TimeUtil.fastDateCreate(useGmtMillis, useGmtMillis ? getGmtCalendar() : cal, cal, year, month, day);
/*      */   }
/*      */   
/*      */ 
/*      */   protected synchronized Time fastTimeCreate(Calendar cal, int hour, int minute, int second)
/*      */     throws SQLException
/*      */   {
/* 1031 */     if (!this.useLegacyDatetimeCode) {
/* 1032 */       return TimeUtil.fastTimeCreate(hour, minute, second, cal, getExceptionInterceptor());
/*      */     }
/*      */     
/* 1035 */     if (cal == null) {
/* 1036 */       createCalendarIfNeeded();
/* 1037 */       cal = this.fastDateCal;
/*      */     }
/*      */     
/* 1040 */     return TimeUtil.fastTimeCreate(cal, hour, minute, second, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */   protected synchronized Timestamp fastTimestampCreate(Calendar cal, int year, int month, int day, int hour, int minute, int seconds, int secondsPart)
/*      */   {
/* 1046 */     if (!this.useLegacyDatetimeCode) {
/* 1047 */       return TimeUtil.fastTimestampCreate(cal.getTimeZone(), year, month, day, hour, minute, seconds, secondsPart);
/*      */     }
/*      */     
/*      */ 
/* 1051 */     if (cal == null) {
/* 1052 */       createCalendarIfNeeded();
/* 1053 */       cal = this.fastDateCal;
/*      */     }
/*      */     
/* 1056 */     boolean useGmtMillis = this.connection.getUseGmtMillisForDatetimes();
/*      */     
/* 1058 */     return TimeUtil.fastTimestampCreate(useGmtMillis, useGmtMillis ? getGmtCalendar() : null, cal, year, month, day, hour, minute, seconds, secondsPart);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int findColumn(String columnName)
/*      */     throws SQLException
/*      */   {
/* 1107 */     checkClosed();
/*      */     
/* 1109 */     if (!this.hasBuiltIndexMapping) {
/* 1110 */       buildIndexMapping();
/*      */     }
/*      */     
/* 1113 */     Integer index = (Integer)this.columnToIndexCache.get(columnName);
/*      */     
/* 1115 */     if (index != null) {
/* 1116 */       return index.intValue() + 1;
/*      */     }
/*      */     
/* 1119 */     index = (Integer)this.columnLabelToIndex.get(columnName);
/*      */     
/* 1121 */     if ((index == null) && (this.useColumnNamesInFindColumn)) {
/* 1122 */       index = (Integer)this.columnNameToIndex.get(columnName);
/*      */     }
/*      */     
/* 1125 */     if (index == null) {
/* 1126 */       index = (Integer)this.fullColumnNameToIndex.get(columnName);
/*      */     }
/*      */     
/* 1129 */     if (index != null) {
/* 1130 */       this.columnToIndexCache.put(columnName, index);
/*      */       
/* 1132 */       return index.intValue() + 1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1137 */     for (int i = 0; i < this.fields.length; i++) {
/* 1138 */       if (this.fields[i].getName().equalsIgnoreCase(columnName))
/* 1139 */         return i + 1;
/* 1140 */       if (this.fields[i].getFullName().equalsIgnoreCase(columnName))
/*      */       {
/* 1142 */         return i + 1;
/*      */       }
/*      */     }
/*      */     
/* 1146 */     throw SQLError.createSQLException(Messages.getString("ResultSet.Column____112") + columnName + Messages.getString("ResultSet.___not_found._113"), "S0022", getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean first()
/*      */     throws SQLException
/*      */   {
/* 1166 */     checkClosed();
/*      */     
/* 1168 */     boolean b = true;
/*      */     
/* 1170 */     if (this.rowData.isEmpty()) {
/* 1171 */       b = false;
/*      */     }
/*      */     else {
/* 1174 */       if (this.onInsertRow) {
/* 1175 */         this.onInsertRow = false;
/*      */       }
/*      */       
/* 1178 */       if (this.doingUpdates) {
/* 1179 */         this.doingUpdates = false;
/*      */       }
/*      */       
/* 1182 */       this.rowData.beforeFirst();
/* 1183 */       this.thisRow = this.rowData.next();
/*      */     }
/*      */     
/* 1186 */     setRowPositionValidity();
/*      */     
/* 1188 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Array getArray(int i)
/*      */     throws SQLException
/*      */   {
/* 1205 */     checkColumnBounds(i);
/*      */     
/* 1207 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Array getArray(String colName)
/*      */     throws SQLException
/*      */   {
/* 1224 */     return getArray(findColumn(colName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getAsciiStream(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 1253 */     checkRowPos();
/*      */     
/* 1255 */     if (!this.isBinaryEncoded) {
/* 1256 */       return getBinaryStream(columnIndex);
/*      */     }
/*      */     
/* 1259 */     return getNativeBinaryStream(columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getAsciiStream(String columnName)
/*      */     throws SQLException
/*      */   {
/* 1274 */     return getAsciiStream(findColumn(columnName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BigDecimal getBigDecimal(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 1291 */     if (!this.isBinaryEncoded) {
/* 1292 */       String stringVal = getString(columnIndex);
/*      */       
/*      */ 
/* 1295 */       if (stringVal != null) {
/* 1296 */         if (stringVal.length() == 0)
/*      */         {
/* 1298 */           BigDecimal val = new BigDecimal(convertToZeroLiteralStringWithEmptyCheck());
/*      */           
/*      */ 
/* 1301 */           return val;
/*      */         }
/*      */         try
/*      */         {
/* 1305 */           return new BigDecimal(stringVal);
/*      */         }
/*      */         catch (NumberFormatException ex)
/*      */         {
/* 1309 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1317 */       return null;
/*      */     }
/*      */     
/* 1320 */     return getNativeBigDecimal(columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public BigDecimal getBigDecimal(int columnIndex, int scale)
/*      */     throws SQLException
/*      */   {
/* 1341 */     if (!this.isBinaryEncoded) {
/* 1342 */       String stringVal = getString(columnIndex);
/*      */       
/*      */ 
/* 1345 */       if (stringVal != null) {
/* 1346 */         if (stringVal.length() == 0) {
/* 1347 */           BigDecimal val = new BigDecimal(convertToZeroLiteralStringWithEmptyCheck());
/*      */           
/*      */           try
/*      */           {
/* 1351 */             return val.setScale(scale);
/*      */           } catch (ArithmeticException ex) {
/*      */             try {
/* 1354 */               return val.setScale(scale, 4);
/*      */             }
/*      */             catch (ArithmeticException arEx) {
/* 1357 */               throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */         try
/*      */         {
/* 1367 */           val = new BigDecimal(stringVal);
/*      */         } catch (NumberFormatException ex) { BigDecimal val;
/* 1369 */           if (this.fields[(columnIndex - 1)].getMysqlType() == 16) {
/* 1370 */             long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex);
/*      */             
/* 1372 */             val = new BigDecimal(valueAsLong);
/*      */           } else {
/* 1374 */             throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { Integer.valueOf(columnIndex), stringVal }), "S1009", getExceptionInterceptor());
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */         try
/*      */         {
/* 1383 */           return val.setScale(scale);
/*      */         } catch (ArithmeticException ex) {
/*      */           try { BigDecimal val;
/* 1386 */             return val.setScale(scale, 4);
/*      */           } catch (ArithmeticException arithEx) {
/* 1388 */             throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { Integer.valueOf(columnIndex), stringVal }), "S1009", getExceptionInterceptor());
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1397 */       return null;
/*      */     }
/*      */     
/* 1400 */     return getNativeBigDecimal(columnIndex, scale);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BigDecimal getBigDecimal(String columnName)
/*      */     throws SQLException
/*      */   {
/* 1416 */     return getBigDecimal(findColumn(columnName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public BigDecimal getBigDecimal(String columnName, int scale)
/*      */     throws SQLException
/*      */   {
/* 1436 */     return getBigDecimal(findColumn(columnName), scale);
/*      */   }
/*      */   
/*      */ 
/*      */   private final BigDecimal getBigDecimalFromString(String stringVal, int columnIndex, int scale)
/*      */     throws SQLException
/*      */   {
/* 1443 */     if (stringVal != null) {
/* 1444 */       if (stringVal.length() == 0) {
/* 1445 */         BigDecimal bdVal = new BigDecimal(convertToZeroLiteralStringWithEmptyCheck());
/*      */         try
/*      */         {
/* 1448 */           return bdVal.setScale(scale);
/*      */         } catch (ArithmeticException ex) {
/*      */           try {
/* 1451 */             return bdVal.setScale(scale, 4);
/*      */           } catch (ArithmeticException arEx) {
/* 1453 */             throw new SQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009");
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/* 1464 */         return new BigDecimal(stringVal).setScale(scale);
/*      */       } catch (ArithmeticException ex) {
/*      */         try {
/* 1467 */           return new BigDecimal(stringVal).setScale(scale, 4);
/*      */         }
/*      */         catch (ArithmeticException arEx) {
/* 1470 */           throw new SQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009");
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       catch (NumberFormatException ex)
/*      */       {
/*      */ 
/* 1478 */         if (this.fields[(columnIndex - 1)].getMysqlType() == 16) {
/* 1479 */           long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex);
/*      */           try
/*      */           {
/* 1482 */             return new BigDecimal(valueAsLong).setScale(scale);
/*      */           } catch (ArithmeticException arEx1) {
/*      */             try {
/* 1485 */               return new BigDecimal(valueAsLong).setScale(scale, 4);
/*      */             }
/*      */             catch (ArithmeticException arEx2) {
/* 1488 */               throw new SQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009");
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1497 */         if ((this.fields[(columnIndex - 1)].getMysqlType() == 1) && (this.connection.getTinyInt1isBit()) && (this.fields[(columnIndex - 1)].getLength() == 1L))
/*      */         {
/* 1499 */           return new BigDecimal(stringVal.equalsIgnoreCase("true") ? 1 : 0).setScale(scale);
/*      */         }
/*      */         
/* 1502 */         throw new SQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1510 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getBinaryStream(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 1531 */     checkRowPos();
/*      */     
/* 1533 */     if (!this.isBinaryEncoded) {
/* 1534 */       checkColumnBounds(columnIndex);
/*      */       
/* 1536 */       int columnIndexMinusOne = columnIndex - 1;
/*      */       
/* 1538 */       if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 1539 */         this.wasNullFlag = true;
/*      */         
/* 1541 */         return null;
/*      */       }
/*      */       
/* 1544 */       this.wasNullFlag = false;
/*      */       
/* 1546 */       return this.thisRow.getBinaryInputStream(columnIndexMinusOne);
/*      */     }
/*      */     
/* 1549 */     return getNativeBinaryStream(columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getBinaryStream(String columnName)
/*      */     throws SQLException
/*      */   {
/* 1564 */     return getBinaryStream(findColumn(columnName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.Blob getBlob(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 1579 */     if (!this.isBinaryEncoded) {
/* 1580 */       checkRowPos();
/*      */       
/* 1582 */       checkColumnBounds(columnIndex);
/*      */       
/* 1584 */       int columnIndexMinusOne = columnIndex - 1;
/*      */       
/* 1586 */       if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 1587 */         this.wasNullFlag = true;
/*      */       } else {
/* 1589 */         this.wasNullFlag = false;
/*      */       }
/*      */       
/* 1592 */       if (this.wasNullFlag) {
/* 1593 */         return null;
/*      */       }
/*      */       
/* 1596 */       if (!this.connection.getEmulateLocators()) {
/* 1597 */         return new Blob(this.thisRow.getColumnValue(columnIndexMinusOne), getExceptionInterceptor());
/*      */       }
/*      */       
/* 1600 */       return new BlobFromLocator(this, columnIndex, getExceptionInterceptor());
/*      */     }
/*      */     
/* 1603 */     return getNativeBlob(columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.Blob getBlob(String colName)
/*      */     throws SQLException
/*      */   {
/* 1618 */     return getBlob(findColumn(colName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getBoolean(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 1634 */     checkColumnBounds(columnIndex);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1641 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 1643 */     Field field = this.fields[columnIndexMinusOne];
/*      */     
/* 1645 */     if (field.getMysqlType() == 16) {
/* 1646 */       return byteArrayToBoolean(columnIndexMinusOne);
/*      */     }
/*      */     
/* 1649 */     this.wasNullFlag = false;
/*      */     
/* 1651 */     int sqlType = field.getSQLType();
/*      */     long boolVal;
/* 1653 */     switch (sqlType) {
/*      */     case 16: 
/* 1655 */       if (field.getMysqlType() == -1) {
/* 1656 */         String stringVal = getString(columnIndex);
/*      */         
/* 1658 */         return getBooleanFromString(stringVal);
/*      */       }
/*      */       
/* 1661 */       boolVal = getLong(columnIndex, false);
/*      */       
/* 1663 */       return (boolVal == -1L) || (boolVal > 0L);
/*      */     case -7: 
/*      */     case -6: 
/*      */     case -5: 
/*      */     case 2: 
/*      */     case 3: 
/*      */     case 4: 
/*      */     case 5: 
/*      */     case 6: 
/*      */     case 7: 
/*      */     case 8: 
/* 1674 */       boolVal = getLong(columnIndex, false);
/*      */       
/* 1676 */       return (boolVal == -1L) || (boolVal > 0L);
/*      */     }
/* 1678 */     if (this.connection.getPedantic())
/*      */     {
/* 1680 */       switch (sqlType) {
/*      */       case -4: 
/*      */       case -3: 
/*      */       case -2: 
/*      */       case 70: 
/*      */       case 91: 
/*      */       case 92: 
/*      */       case 93: 
/*      */       case 2000: 
/*      */       case 2002: 
/*      */       case 2003: 
/*      */       case 2004: 
/*      */       case 2005: 
/*      */       case 2006: 
/* 1694 */         throw SQLError.createSQLException("Required type conversion not allowed", "22018", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */     }
/*      */     
/* 1699 */     if ((sqlType == -2) || (sqlType == -3) || (sqlType == -4) || (sqlType == 2004))
/*      */     {
/*      */ 
/*      */ 
/* 1703 */       return byteArrayToBoolean(columnIndexMinusOne);
/*      */     }
/*      */     
/* 1706 */     if (this.useUsageAdvisor) {
/* 1707 */       issueConversionViaParsingWarning("getBoolean()", columnIndex, this.thisRow.getColumnValue(columnIndexMinusOne), this.fields[columnIndex], new int[] { 16, 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1719 */     String stringVal = getString(columnIndex);
/*      */     
/* 1721 */     return getBooleanFromString(stringVal);
/*      */   }
/*      */   
/*      */   private boolean byteArrayToBoolean(int columnIndexMinusOne) throws SQLException
/*      */   {
/* 1726 */     Object value = this.thisRow.getColumnValue(columnIndexMinusOne);
/*      */     
/* 1728 */     if (value == null) {
/* 1729 */       this.wasNullFlag = true;
/*      */       
/* 1731 */       return false;
/*      */     }
/*      */     
/* 1734 */     this.wasNullFlag = false;
/*      */     
/* 1736 */     if (((byte[])value).length == 0) {
/* 1737 */       return false;
/*      */     }
/*      */     
/* 1740 */     byte boolVal = ((byte[])(byte[])value)[0];
/*      */     
/* 1742 */     if (boolVal == 49)
/* 1743 */       return true;
/* 1744 */     if (boolVal == 48) {
/* 1745 */       return false;
/*      */     }
/*      */     
/* 1748 */     return (boolVal == -1) || (boolVal > 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getBoolean(String columnName)
/*      */     throws SQLException
/*      */   {
/* 1763 */     return getBoolean(findColumn(columnName));
/*      */   }
/*      */   
/*      */   private final boolean getBooleanFromString(String stringVal) throws SQLException
/*      */   {
/* 1768 */     if ((stringVal != null) && (stringVal.length() > 0)) {
/* 1769 */       int c = Character.toLowerCase(stringVal.charAt(0));
/*      */       
/* 1771 */       return (c == 116) || (c == 121) || (c == 49) || (stringVal.equals("-1"));
/*      */     }
/*      */     
/*      */ 
/* 1775 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte getByte(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 1790 */     if (!this.isBinaryEncoded) {
/* 1791 */       String stringVal = getString(columnIndex);
/*      */       
/* 1793 */       if ((this.wasNullFlag) || (stringVal == null)) {
/* 1794 */         return 0;
/*      */       }
/*      */       
/* 1797 */       return getByteFromString(stringVal, columnIndex);
/*      */     }
/*      */     
/* 1800 */     return getNativeByte(columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte getByte(String columnName)
/*      */     throws SQLException
/*      */   {
/* 1815 */     return getByte(findColumn(columnName));
/*      */   }
/*      */   
/*      */   private final byte getByteFromString(String stringVal, int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 1821 */     if ((stringVal != null) && (stringVal.length() == 0)) {
/* 1822 */       return (byte)convertToZeroWithEmptyCheck();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1833 */     if (stringVal == null) {
/* 1834 */       return 0;
/*      */     }
/*      */     
/* 1837 */     stringVal = stringVal.trim();
/*      */     try
/*      */     {
/* 1840 */       int decimalIndex = stringVal.indexOf(".");
/*      */       
/*      */ 
/* 1843 */       if (decimalIndex != -1) {
/* 1844 */         double valueAsDouble = Double.parseDouble(stringVal);
/*      */         
/* 1846 */         if ((this.jdbcCompliantTruncationForReads) && (
/* 1847 */           (valueAsDouble < -128.0D) || (valueAsDouble > 127.0D)))
/*      */         {
/* 1849 */           throwRangeException(stringVal, columnIndex, -6);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1854 */         return (byte)(int)valueAsDouble;
/*      */       }
/*      */       
/* 1857 */       long valueAsLong = Long.parseLong(stringVal);
/*      */       
/* 1859 */       if ((this.jdbcCompliantTruncationForReads) && (
/* 1860 */         (valueAsLong < -128L) || (valueAsLong > 127L)))
/*      */       {
/* 1862 */         throwRangeException(String.valueOf(valueAsLong), columnIndex, -6);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1867 */       return (byte)(int)valueAsLong;
/*      */     } catch (NumberFormatException NFE) {
/* 1869 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Value____173") + stringVal + Messages.getString("ResultSet.___is_out_of_range_[-127,127]_174"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] getBytes(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 1894 */     return getBytes(columnIndex, false);
/*      */   }
/*      */   
/*      */   protected byte[] getBytes(int columnIndex, boolean noConversion) throws SQLException
/*      */   {
/* 1899 */     if (!this.isBinaryEncoded) {
/* 1900 */       checkRowPos();
/*      */       
/* 1902 */       checkColumnBounds(columnIndex);
/*      */       
/* 1904 */       int columnIndexMinusOne = columnIndex - 1;
/*      */       
/* 1906 */       if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 1907 */         this.wasNullFlag = true;
/*      */       } else {
/* 1909 */         this.wasNullFlag = false;
/*      */       }
/*      */       
/* 1912 */       if (this.wasNullFlag) {
/* 1913 */         return null;
/*      */       }
/*      */       
/* 1916 */       return this.thisRow.getColumnValue(columnIndexMinusOne);
/*      */     }
/*      */     
/* 1919 */     return getNativeBytes(columnIndex, noConversion);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] getBytes(String columnName)
/*      */     throws SQLException
/*      */   {
/* 1934 */     return getBytes(findColumn(columnName));
/*      */   }
/*      */   
/*      */   private final byte[] getBytesFromString(String stringVal) throws SQLException
/*      */   {
/* 1939 */     if (stringVal != null) {
/* 1940 */       return StringUtils.getBytes(stringVal, this.connection.getEncoding(), this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), this.connection, getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1947 */     return null;
/*      */   }
/*      */   
/*      */   public int getBytesSize() throws SQLException {
/* 1951 */     RowData localRowData = this.rowData;
/*      */     
/* 1953 */     checkClosed();
/*      */     
/* 1955 */     if ((localRowData instanceof RowDataStatic)) {
/* 1956 */       int bytesSize = 0;
/*      */       
/* 1958 */       int numRows = localRowData.size();
/*      */       
/* 1960 */       for (int i = 0; i < numRows; i++) {
/* 1961 */         bytesSize += localRowData.getAt(i).getBytesSize();
/*      */       }
/*      */       
/* 1964 */       return bytesSize;
/*      */     }
/*      */     
/* 1967 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Calendar getCalendarInstanceForSessionOrNew()
/*      */   {
/* 1975 */     if (this.connection != null) {
/* 1976 */       return this.connection.getCalendarInstanceForSessionOrNew();
/*      */     }
/*      */     
/*      */ 
/* 1980 */     return new GregorianCalendar();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Reader getCharacterStream(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 2000 */     if (!this.isBinaryEncoded) {
/* 2001 */       checkColumnBounds(columnIndex);
/*      */       
/* 2003 */       int columnIndexMinusOne = columnIndex - 1;
/*      */       
/* 2005 */       if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 2006 */         this.wasNullFlag = true;
/*      */         
/* 2008 */         return null;
/*      */       }
/*      */       
/* 2011 */       this.wasNullFlag = false;
/*      */       
/* 2013 */       return this.thisRow.getReader(columnIndexMinusOne);
/*      */     }
/*      */     
/* 2016 */     return getNativeCharacterStream(columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Reader getCharacterStream(String columnName)
/*      */     throws SQLException
/*      */   {
/* 2036 */     return getCharacterStream(findColumn(columnName));
/*      */   }
/*      */   
/*      */   private final Reader getCharacterStreamFromString(String stringVal) throws SQLException
/*      */   {
/* 2041 */     if (stringVal != null) {
/* 2042 */       return new StringReader(stringVal);
/*      */     }
/*      */     
/* 2045 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.Clob getClob(int i)
/*      */     throws SQLException
/*      */   {
/* 2060 */     if (!this.isBinaryEncoded) {
/* 2061 */       String asString = getStringForClob(i);
/*      */       
/* 2063 */       if (asString == null) {
/* 2064 */         return null;
/*      */       }
/*      */       
/* 2067 */       return new Clob(asString, getExceptionInterceptor());
/*      */     }
/*      */     
/* 2070 */     return getNativeClob(i);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.Clob getClob(String colName)
/*      */     throws SQLException
/*      */   {
/* 2085 */     return getClob(findColumn(colName));
/*      */   }
/*      */   
/*      */   private final java.sql.Clob getClobFromString(String stringVal) throws SQLException {
/* 2089 */     return new Clob(stringVal, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getConcurrency()
/*      */     throws SQLException
/*      */   {
/* 2102 */     return 1007;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCursorName()
/*      */     throws SQLException
/*      */   {
/* 2131 */     throw SQLError.createSQLException(Messages.getString("ResultSet.Positioned_Update_not_supported"), "S1C00", getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Date getDate(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 2148 */     return getDate(columnIndex, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Date getDate(int columnIndex, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 2169 */     if (this.isBinaryEncoded) {
/* 2170 */       return getNativeDate(columnIndex, cal);
/*      */     }
/*      */     
/* 2173 */     if (!this.useFastDateParsing) {
/* 2174 */       String stringVal = getStringInternal(columnIndex, false);
/*      */       
/* 2176 */       if (stringVal == null) {
/* 2177 */         return null;
/*      */       }
/*      */       
/* 2180 */       return getDateFromString(stringVal, columnIndex, cal);
/*      */     }
/*      */     
/* 2183 */     checkColumnBounds(columnIndex);
/*      */     
/* 2185 */     int columnIndexMinusOne = columnIndex - 1;
/* 2186 */     Date tmpDate = this.thisRow.getDateFast(columnIndexMinusOne, this.connection, this, cal);
/* 2187 */     if ((this.thisRow.isNull(columnIndexMinusOne)) || (tmpDate == null))
/*      */     {
/*      */ 
/* 2190 */       this.wasNullFlag = true;
/*      */       
/* 2192 */       return null;
/*      */     }
/*      */     
/* 2195 */     this.wasNullFlag = false;
/*      */     
/* 2197 */     return tmpDate;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Date getDate(String columnName)
/*      */     throws SQLException
/*      */   {
/* 2213 */     return getDate(findColumn(columnName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Date getDate(String columnName, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 2233 */     return getDate(findColumn(columnName), cal);
/*      */   }
/*      */   
/*      */   private final Date getDateFromString(String stringVal, int columnIndex, Calendar targetCalendar) throws SQLException
/*      */   {
/* 2238 */     int year = 0;
/* 2239 */     int month = 0;
/* 2240 */     int day = 0;
/*      */     try
/*      */     {
/* 2243 */       this.wasNullFlag = false;
/*      */       
/* 2245 */       if (stringVal == null) {
/* 2246 */         this.wasNullFlag = true;
/*      */         
/* 2248 */         return null;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2259 */       stringVal = stringVal.trim();
/*      */       
/* 2261 */       if ((stringVal.equals("0")) || (stringVal.equals("0000-00-00")) || (stringVal.equals("0000-00-00 00:00:00")) || (stringVal.equals("00000000000000")) || (stringVal.equals("0")))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 2266 */         if ("convertToNull".equals(this.connection.getZeroDateTimeBehavior()))
/*      */         {
/* 2268 */           this.wasNullFlag = true;
/*      */           
/* 2270 */           return null; }
/* 2271 */         if ("exception".equals(this.connection.getZeroDateTimeBehavior()))
/*      */         {
/* 2273 */           throw SQLError.createSQLException("Value '" + stringVal + "' can not be represented as java.sql.Date", "S1009", getExceptionInterceptor());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2280 */         return fastDateCreate(targetCalendar, 1, 1, 1);
/*      */       }
/* 2282 */       if (this.fields[(columnIndex - 1)].getMysqlType() == 7)
/*      */       {
/* 2284 */         switch (stringVal.length()) {
/*      */         case 19: 
/*      */         case 21: 
/* 2287 */           year = Integer.parseInt(stringVal.substring(0, 4));
/* 2288 */           month = Integer.parseInt(stringVal.substring(5, 7));
/* 2289 */           day = Integer.parseInt(stringVal.substring(8, 10));
/*      */           
/* 2291 */           return fastDateCreate(targetCalendar, year, month, day);
/*      */         
/*      */ 
/*      */         case 8: 
/*      */         case 14: 
/* 2296 */           year = Integer.parseInt(stringVal.substring(0, 4));
/* 2297 */           month = Integer.parseInt(stringVal.substring(4, 6));
/* 2298 */           day = Integer.parseInt(stringVal.substring(6, 8));
/*      */           
/* 2300 */           return fastDateCreate(targetCalendar, year, month, day);
/*      */         
/*      */ 
/*      */         case 6: 
/*      */         case 10: 
/*      */         case 12: 
/* 2306 */           year = Integer.parseInt(stringVal.substring(0, 2));
/*      */           
/* 2308 */           if (year <= 69) {
/* 2309 */             year += 100;
/*      */           }
/*      */           
/* 2312 */           month = Integer.parseInt(stringVal.substring(2, 4));
/* 2313 */           day = Integer.parseInt(stringVal.substring(4, 6));
/*      */           
/* 2315 */           return fastDateCreate(targetCalendar, year + 1900, month, day);
/*      */         
/*      */ 
/*      */         case 4: 
/* 2319 */           year = Integer.parseInt(stringVal.substring(0, 4));
/*      */           
/* 2321 */           if (year <= 69) {
/* 2322 */             year += 100;
/*      */           }
/*      */           
/* 2325 */           month = Integer.parseInt(stringVal.substring(2, 4));
/*      */           
/* 2327 */           return fastDateCreate(targetCalendar, year + 1900, month, 1);
/*      */         
/*      */ 
/*      */         case 2: 
/* 2331 */           year = Integer.parseInt(stringVal.substring(0, 2));
/*      */           
/* 2333 */           if (year <= 69) {
/* 2334 */             year += 100;
/*      */           }
/*      */           
/* 2337 */           return fastDateCreate(targetCalendar, year + 1900, 1, 1);
/*      */         }
/*      */         
/*      */         
/* 2341 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_Date", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2346 */       if (this.fields[(columnIndex - 1)].getMysqlType() == 13)
/*      */       {
/* 2348 */         if ((stringVal.length() == 2) || (stringVal.length() == 1)) {
/* 2349 */           year = Integer.parseInt(stringVal);
/*      */           
/* 2351 */           if (year <= 69) {
/* 2352 */             year += 100;
/*      */           }
/*      */           
/* 2355 */           year += 1900;
/*      */         } else {
/* 2357 */           year = Integer.parseInt(stringVal.substring(0, 4));
/*      */         }
/*      */         
/* 2360 */         return fastDateCreate(targetCalendar, year, 1, 1); }
/* 2361 */       if (this.fields[(columnIndex - 1)].getMysqlType() == 11) {
/* 2362 */         return fastDateCreate(targetCalendar, 1970, 1, 1);
/*      */       }
/* 2364 */       if (stringVal.length() < 10) {
/* 2365 */         if (stringVal.length() == 8) {
/* 2366 */           return fastDateCreate(targetCalendar, 1970, 1, 1);
/*      */         }
/*      */         
/* 2369 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_Date", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2375 */       if (stringVal.length() != 18) {
/* 2376 */         year = Integer.parseInt(stringVal.substring(0, 4));
/* 2377 */         month = Integer.parseInt(stringVal.substring(5, 7));
/* 2378 */         day = Integer.parseInt(stringVal.substring(8, 10));
/*      */       }
/*      */       else {
/* 2381 */         StringTokenizer st = new StringTokenizer(stringVal, "- ");
/*      */         
/* 2383 */         year = Integer.parseInt(st.nextToken());
/* 2384 */         month = Integer.parseInt(st.nextToken());
/* 2385 */         day = Integer.parseInt(st.nextToken());
/*      */       }
/*      */       
/*      */ 
/* 2389 */       return fastDateCreate(targetCalendar, year, month, day);
/*      */     } catch (SQLException sqlEx) {
/* 2391 */       throw sqlEx;
/*      */     } catch (Exception e) {
/* 2393 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_Date", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2398 */       sqlEx.initCause(e);
/*      */       
/* 2400 */       throw sqlEx;
/*      */     }
/*      */   }
/*      */   
/*      */   private TimeZone getDefaultTimeZone() {
/* 2405 */     if ((!this.useLegacyDatetimeCode) && (this.connection != null)) {
/* 2406 */       return this.serverTimeZoneTz;
/*      */     }
/*      */     
/* 2409 */     return this.connection.getDefaultTimeZone();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getDouble(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 2424 */     if (!this.isBinaryEncoded) {
/* 2425 */       return getDoubleInternal(columnIndex);
/*      */     }
/*      */     
/* 2428 */     return getNativeDouble(columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getDouble(String columnName)
/*      */     throws SQLException
/*      */   {
/* 2443 */     return getDouble(findColumn(columnName));
/*      */   }
/*      */   
/*      */   private final double getDoubleFromString(String stringVal, int columnIndex) throws SQLException
/*      */   {
/* 2448 */     return getDoubleInternal(stringVal, columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected double getDoubleInternal(int colIndex)
/*      */     throws SQLException
/*      */   {
/* 2464 */     return getDoubleInternal(getString(colIndex), colIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected double getDoubleInternal(String stringVal, int colIndex)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 2484 */       if (stringVal == null) {
/* 2485 */         return 0.0D;
/*      */       }
/*      */       
/* 2488 */       if (stringVal.length() == 0) {
/* 2489 */         return convertToZeroWithEmptyCheck();
/*      */       }
/*      */       
/* 2492 */       double d = Double.parseDouble(stringVal);
/*      */       
/* 2494 */       if (this.useStrictFloatingPoint)
/*      */       {
/* 2496 */         if (d == 2.147483648E9D)
/*      */         {
/* 2498 */           d = 2.147483647E9D;
/* 2499 */         } else if (d == 1.0000000036275E-15D)
/*      */         {
/* 2501 */           d = 1.0E-15D;
/* 2502 */         } else if (d == 9.999999869911E14D) {
/* 2503 */           d = 9.99999999999999E14D;
/* 2504 */         } else if (d == 1.4012984643248E-45D) {
/* 2505 */           d = 1.4E-45D;
/* 2506 */         } else if (d == 1.4013E-45D) {
/* 2507 */           d = 1.4E-45D;
/* 2508 */         } else if (d == 3.4028234663853E37D) {
/* 2509 */           d = 3.4028235E37D;
/* 2510 */         } else if (d == -2.14748E9D) {
/* 2511 */           d = -2.147483648E9D;
/* 2512 */         } else if (d != 3.40282E37D) {} }
/* 2513 */       return 3.4028235E37D;
/*      */ 
/*      */     }
/*      */     catch (NumberFormatException e)
/*      */     {
/*      */ 
/* 2519 */       if (this.fields[(colIndex - 1)].getMysqlType() == 16) {
/* 2520 */         long valueAsLong = getNumericRepresentationOfSQLBitType(colIndex);
/*      */         
/* 2522 */         return valueAsLong;
/*      */       }
/*      */       
/* 2525 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_number", new Object[] { stringVal, Integer.valueOf(colIndex) }), "S1009", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int getFetchDirection()
/*      */     throws SQLException
/*      */   {
/* 2541 */     return this.fetchDirection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int getFetchSize()
/*      */     throws SQLException
/*      */   {
/* 2553 */     return this.fetchSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized char getFirstCharOfQuery()
/*      */   {
/* 2563 */     return this.firstCharOfQuery;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getFloat(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 2578 */     if (!this.isBinaryEncoded) {
/* 2579 */       String val = null;
/*      */       
/* 2581 */       val = getString(columnIndex);
/*      */       
/* 2583 */       return getFloatFromString(val, columnIndex);
/*      */     }
/*      */     
/* 2586 */     return getNativeFloat(columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public float getFloat(String columnName)
/*      */     throws SQLException
/*      */   {
/* 2601 */     return getFloat(findColumn(columnName));
/*      */   }
/*      */   
/*      */   private final float getFloatFromString(String val, int columnIndex) throws SQLException
/*      */   {
/*      */     try {
/* 2607 */       if (val != null) {
/* 2608 */         if (val.length() == 0) {
/* 2609 */           return convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 2612 */         float f = Float.parseFloat(val);
/*      */         
/* 2614 */         if ((this.jdbcCompliantTruncationForReads) && (
/* 2615 */           (f == Float.MIN_VALUE) || (f == Float.MAX_VALUE))) {
/* 2616 */           double valAsDouble = Double.parseDouble(val);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2622 */           if ((valAsDouble < 1.401298464324817E-45D - MIN_DIFF_PREC) || (valAsDouble > 3.4028234663852886E38D - MAX_DIFF_PREC))
/*      */           {
/* 2624 */             throwRangeException(String.valueOf(valAsDouble), columnIndex, 6);
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 2630 */         return f;
/*      */       }
/*      */       
/* 2633 */       return 0.0F;
/*      */     } catch (NumberFormatException nfe) {
/*      */       try {
/* 2636 */         Double valueAsDouble = new Double(val);
/* 2637 */         float valueAsFloat = valueAsDouble.floatValue();
/*      */         
/* 2639 */         if (this.jdbcCompliantTruncationForReads)
/*      */         {
/* 2641 */           if (((this.jdbcCompliantTruncationForReads) && (valueAsFloat == Float.NEGATIVE_INFINITY)) || (valueAsFloat == Float.POSITIVE_INFINITY))
/*      */           {
/*      */ 
/* 2644 */             throwRangeException(valueAsDouble.toString(), columnIndex, 6);
/*      */           }
/*      */         }
/*      */         
/*      */ 
/* 2649 */         return valueAsFloat;
/*      */ 
/*      */       }
/*      */       catch (NumberFormatException newNfe)
/*      */       {
/* 2654 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getFloat()_-____200") + val + Messages.getString("ResultSet.___in_column__201") + columnIndex, "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getInt(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 2675 */     checkRowPos();
/*      */     
/* 2677 */     if (!this.isBinaryEncoded) {
/* 2678 */       int columnIndexMinusOne = columnIndex - 1;
/* 2679 */       if (this.useFastIntParsing) {
/* 2680 */         checkColumnBounds(columnIndex);
/*      */         
/* 2682 */         if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 2683 */           this.wasNullFlag = true;
/*      */         } else {
/* 2685 */           this.wasNullFlag = false;
/*      */         }
/*      */         
/* 2688 */         if (this.wasNullFlag) {
/* 2689 */           return 0;
/*      */         }
/*      */         
/* 2692 */         if (this.thisRow.length(columnIndexMinusOne) == 0L) {
/* 2693 */           return convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 2696 */         boolean needsFullParse = this.thisRow.isFloatingPointNumber(columnIndexMinusOne);
/*      */         
/*      */ 
/* 2699 */         if (!needsFullParse) {
/*      */           try {
/* 2701 */             return getIntWithOverflowCheck(columnIndexMinusOne);
/*      */           }
/*      */           catch (NumberFormatException nfe) {
/*      */             try {
/* 2705 */               return parseIntAsDouble(columnIndex, this.thisRow.getString(columnIndexMinusOne, this.fields[columnIndexMinusOne].getCharacterSet(), this.connection));
/*      */ 
/*      */ 
/*      */ 
/*      */             }
/*      */             catch (NumberFormatException newNfe)
/*      */             {
/*      */ 
/*      */ 
/* 2714 */               if (this.fields[columnIndexMinusOne].getMysqlType() == 16) {
/* 2715 */                 long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex);
/*      */                 
/* 2717 */                 if ((this.connection.getJdbcCompliantTruncationForReads()) && ((valueAsLong < -2147483648L) || (valueAsLong > 2147483647L)))
/*      */                 {
/*      */ 
/* 2720 */                   throwRangeException(String.valueOf(valueAsLong), columnIndex, 4);
/*      */                 }
/*      */                 
/*      */ 
/*      */ 
/* 2725 */                 return (int)valueAsLong;
/*      */               }
/*      */               
/* 2728 */               throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getInt()_-____74") + this.thisRow.getString(columnIndexMinusOne, this.fields[columnIndexMinusOne].getCharacterSet(), this.connection) + "'", "S1009", getExceptionInterceptor());
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2744 */       String val = null;
/*      */       try
/*      */       {
/* 2747 */         val = getString(columnIndex);
/*      */         
/* 2749 */         if (val != null) {
/* 2750 */           if (val.length() == 0) {
/* 2751 */             return convertToZeroWithEmptyCheck();
/*      */           }
/*      */           
/* 2754 */           if ((val.indexOf("e") == -1) && (val.indexOf("E") == -1) && (val.indexOf(".") == -1))
/*      */           {
/* 2756 */             int intVal = Integer.parseInt(val);
/*      */             
/* 2758 */             checkForIntegerTruncation(columnIndexMinusOne, null, intVal);
/*      */             
/* 2760 */             return intVal;
/*      */           }
/*      */           
/*      */ 
/* 2764 */           int intVal = parseIntAsDouble(columnIndex, val);
/*      */           
/* 2766 */           checkForIntegerTruncation(columnIndex, null, intVal);
/*      */           
/* 2768 */           return intVal;
/*      */         }
/*      */         
/* 2771 */         return 0;
/*      */       } catch (NumberFormatException nfe) {
/*      */         try {
/* 2774 */           return parseIntAsDouble(columnIndex, val);
/*      */ 
/*      */         }
/*      */         catch (NumberFormatException newNfe)
/*      */         {
/* 2779 */           if (this.fields[columnIndexMinusOne].getMysqlType() == 16) {
/* 2780 */             long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex);
/*      */             
/* 2782 */             if ((this.jdbcCompliantTruncationForReads) && ((valueAsLong < -2147483648L) || (valueAsLong > 2147483647L)))
/*      */             {
/* 2784 */               throwRangeException(String.valueOf(valueAsLong), columnIndex, 4);
/*      */             }
/*      */             
/*      */ 
/* 2788 */             return (int)valueAsLong;
/*      */           }
/*      */           
/* 2791 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getInt()_-____74") + val + "'", "S1009", getExceptionInterceptor());
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2801 */     return getNativeInt(columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getInt(String columnName)
/*      */     throws SQLException
/*      */   {
/* 2816 */     return getInt(findColumn(columnName));
/*      */   }
/*      */   
/*      */   private final int getIntFromString(String val, int columnIndex) throws SQLException
/*      */   {
/*      */     try {
/* 2822 */       if (val != null)
/*      */       {
/* 2824 */         if (val.length() == 0) {
/* 2825 */           return convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 2828 */         if ((val.indexOf("e") == -1) && (val.indexOf("E") == -1) && (val.indexOf(".") == -1))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2838 */           val = val.trim();
/*      */           
/* 2840 */           int valueAsInt = Integer.parseInt(val);
/*      */           
/* 2842 */           if ((this.jdbcCompliantTruncationForReads) && (
/* 2843 */             (valueAsInt == Integer.MIN_VALUE) || (valueAsInt == Integer.MAX_VALUE)))
/*      */           {
/* 2845 */             long valueAsLong = Long.parseLong(val);
/*      */             
/* 2847 */             if ((valueAsLong < -2147483648L) || (valueAsLong > 2147483647L))
/*      */             {
/* 2849 */               throwRangeException(String.valueOf(valueAsLong), columnIndex, 4);
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 2856 */           return valueAsInt;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 2861 */         double valueAsDouble = Double.parseDouble(val);
/*      */         
/* 2863 */         if ((this.jdbcCompliantTruncationForReads) && (
/* 2864 */           (valueAsDouble < -2.147483648E9D) || (valueAsDouble > 2.147483647E9D)))
/*      */         {
/* 2866 */           throwRangeException(String.valueOf(valueAsDouble), columnIndex, 4);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 2871 */         return (int)valueAsDouble;
/*      */       }
/*      */       
/* 2874 */       return 0;
/*      */     } catch (NumberFormatException nfe) {
/*      */       try {
/* 2877 */         double valueAsDouble = Double.parseDouble(val);
/*      */         
/* 2879 */         if ((this.jdbcCompliantTruncationForReads) && (
/* 2880 */           (valueAsDouble < -2.147483648E9D) || (valueAsDouble > 2.147483647E9D)))
/*      */         {
/* 2882 */           throwRangeException(String.valueOf(valueAsDouble), columnIndex, 4);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 2887 */         return (int)valueAsDouble;
/*      */ 
/*      */       }
/*      */       catch (NumberFormatException newNfe)
/*      */       {
/* 2892 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getInt()_-____206") + val + Messages.getString("ResultSet.___in_column__207") + columnIndex, "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getLong(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 2912 */     return getLong(columnIndex, true);
/*      */   }
/*      */   
/*      */   private long getLong(int columnIndex, boolean overflowCheck) throws SQLException {
/* 2916 */     if (!this.isBinaryEncoded) {
/* 2917 */       checkRowPos();
/*      */       
/* 2919 */       int columnIndexMinusOne = columnIndex - 1;
/*      */       
/* 2921 */       if (this.useFastIntParsing)
/*      */       {
/* 2923 */         checkColumnBounds(columnIndex);
/*      */         
/* 2925 */         if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 2926 */           this.wasNullFlag = true;
/*      */         } else {
/* 2928 */           this.wasNullFlag = false;
/*      */         }
/*      */         
/* 2931 */         if (this.wasNullFlag) {
/* 2932 */           return 0L;
/*      */         }
/*      */         
/* 2935 */         if (this.thisRow.length(columnIndexMinusOne) == 0L) {
/* 2936 */           return convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 2939 */         boolean needsFullParse = this.thisRow.isFloatingPointNumber(columnIndexMinusOne);
/*      */         
/* 2941 */         if (!needsFullParse) {
/*      */           try {
/* 2943 */             return getLongWithOverflowCheck(columnIndexMinusOne, overflowCheck);
/*      */           }
/*      */           catch (NumberFormatException nfe) {
/*      */             try {
/* 2947 */               return parseLongAsDouble(columnIndexMinusOne, this.thisRow.getString(columnIndexMinusOne, this.fields[columnIndexMinusOne].getCharacterSet(), this.connection));
/*      */ 
/*      */ 
/*      */ 
/*      */             }
/*      */             catch (NumberFormatException newNfe)
/*      */             {
/*      */ 
/*      */ 
/* 2956 */               if (this.fields[columnIndexMinusOne].getMysqlType() == 16) {
/* 2957 */                 return getNumericRepresentationOfSQLBitType(columnIndex);
/*      */               }
/*      */               
/* 2960 */               throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getLong()_-____79") + this.thisRow.getString(columnIndexMinusOne, this.fields[columnIndexMinusOne].getCharacterSet(), this.connection) + "'", "S1009", getExceptionInterceptor());
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2974 */       String val = null;
/*      */       try
/*      */       {
/* 2977 */         val = getString(columnIndex);
/*      */         
/* 2979 */         if (val != null) {
/* 2980 */           if (val.length() == 0) {
/* 2981 */             return convertToZeroWithEmptyCheck();
/*      */           }
/*      */           
/* 2984 */           if ((val.indexOf("e") == -1) && (val.indexOf("E") == -1)) {
/* 2985 */             return parseLongWithOverflowCheck(columnIndexMinusOne, null, val, overflowCheck);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 2990 */           return parseLongAsDouble(columnIndexMinusOne, val);
/*      */         }
/*      */         
/* 2993 */         return 0L;
/*      */       } catch (NumberFormatException nfe) {
/*      */         try {
/* 2996 */           return parseLongAsDouble(columnIndexMinusOne, val);
/*      */ 
/*      */         }
/*      */         catch (NumberFormatException newNfe)
/*      */         {
/* 3001 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getLong()_-____79") + val + "'", "S1009", getExceptionInterceptor());
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 3009 */     return getNativeLong(columnIndex, overflowCheck, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getLong(String columnName)
/*      */     throws SQLException
/*      */   {
/* 3024 */     return getLong(findColumn(columnName));
/*      */   }
/*      */   
/*      */   private final long getLongFromString(String val, int columnIndexZeroBased) throws SQLException
/*      */   {
/*      */     try {
/* 3030 */       if (val != null)
/*      */       {
/* 3032 */         if (val.length() == 0) {
/* 3033 */           return convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 3036 */         if ((val.indexOf("e") == -1) && (val.indexOf("E") == -1)) {
/* 3037 */           return parseLongWithOverflowCheck(columnIndexZeroBased, null, val, true);
/*      */         }
/*      */         
/*      */ 
/* 3041 */         return parseLongAsDouble(columnIndexZeroBased, val);
/*      */       }
/*      */       
/* 3044 */       return 0L;
/*      */     }
/*      */     catch (NumberFormatException nfe) {
/*      */       try {
/* 3048 */         return parseLongAsDouble(columnIndexZeroBased, val);
/*      */ 
/*      */       }
/*      */       catch (NumberFormatException newNfe)
/*      */       {
/* 3053 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getLong()_-____211") + val + Messages.getString("ResultSet.___in_column__212") + (columnIndexZeroBased + 1), "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public java.sql.ResultSetMetaData getMetaData()
/*      */     throws SQLException
/*      */   {
/* 3072 */     checkClosed();
/*      */     
/* 3074 */     return new ResultSetMetaData(this.fields, this.connection.getUseOldAliasMetadataBehavior(), getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Array getNativeArray(int i)
/*      */     throws SQLException
/*      */   {
/* 3092 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected InputStream getNativeAsciiStream(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 3122 */     checkRowPos();
/*      */     
/* 3124 */     return getNativeBinaryStream(columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected BigDecimal getNativeBigDecimal(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 3143 */     checkColumnBounds(columnIndex);
/*      */     
/* 3145 */     int scale = this.fields[(columnIndex - 1)].getDecimals();
/*      */     
/* 3147 */     return getNativeBigDecimal(columnIndex, scale);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected BigDecimal getNativeBigDecimal(int columnIndex, int scale)
/*      */     throws SQLException
/*      */   {
/* 3166 */     checkColumnBounds(columnIndex);
/*      */     
/* 3168 */     String stringVal = null;
/*      */     
/* 3170 */     Field f = this.fields[(columnIndex - 1)];
/*      */     
/* 3172 */     Object value = this.thisRow.getColumnValue(columnIndex - 1);
/*      */     
/* 3174 */     if (value == null) {
/* 3175 */       this.wasNullFlag = true;
/*      */       
/* 3177 */       return null;
/*      */     }
/*      */     
/* 3180 */     this.wasNullFlag = false;
/*      */     
/* 3182 */     switch (f.getSQLType()) {
/*      */     case 2: 
/*      */     case 3: 
/* 3185 */       stringVal = StringUtils.toAsciiString((byte[])value);
/*      */       
/* 3187 */       break;
/*      */     default: 
/* 3189 */       stringVal = getNativeString(columnIndex);
/*      */     }
/*      */     
/* 3192 */     return getBigDecimalFromString(stringVal, columnIndex, scale);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected InputStream getNativeBinaryStream(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 3214 */     checkRowPos();
/*      */     
/* 3216 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 3218 */     if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 3219 */       this.wasNullFlag = true;
/*      */       
/* 3221 */       return null;
/*      */     }
/*      */     
/* 3224 */     this.wasNullFlag = false;
/*      */     
/* 3226 */     switch (this.fields[columnIndexMinusOne].getSQLType()) {
/*      */     case -7: 
/*      */     case -4: 
/*      */     case -3: 
/*      */     case -2: 
/*      */     case 2004: 
/* 3232 */       return this.thisRow.getBinaryInputStream(columnIndexMinusOne);
/*      */     }
/*      */     
/* 3235 */     byte[] b = getNativeBytes(columnIndex, false);
/*      */     
/* 3237 */     if (b != null) {
/* 3238 */       return new ByteArrayInputStream(b);
/*      */     }
/*      */     
/* 3241 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected java.sql.Blob getNativeBlob(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 3256 */     checkRowPos();
/*      */     
/* 3258 */     checkColumnBounds(columnIndex);
/*      */     
/* 3260 */     Object value = this.thisRow.getColumnValue(columnIndex - 1);
/*      */     
/* 3262 */     if (value == null) {
/* 3263 */       this.wasNullFlag = true;
/*      */     } else {
/* 3265 */       this.wasNullFlag = false;
/*      */     }
/*      */     
/* 3268 */     if (this.wasNullFlag) {
/* 3269 */       return null;
/*      */     }
/*      */     
/* 3272 */     int mysqlType = this.fields[(columnIndex - 1)].getMysqlType();
/*      */     
/* 3274 */     byte[] dataAsBytes = null;
/*      */     
/* 3276 */     switch (mysqlType) {
/*      */     case 249: 
/*      */     case 250: 
/*      */     case 251: 
/*      */     case 252: 
/* 3281 */       dataAsBytes = (byte[])value;
/* 3282 */       break;
/*      */     
/*      */     default: 
/* 3285 */       dataAsBytes = getNativeBytes(columnIndex, false);
/*      */     }
/*      */     
/* 3288 */     if (!this.connection.getEmulateLocators()) {
/* 3289 */       return new Blob(dataAsBytes, getExceptionInterceptor());
/*      */     }
/*      */     
/* 3292 */     return new BlobFromLocator(this, columnIndex, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */   public static boolean arraysEqual(byte[] left, byte[] right) {
/* 3296 */     if (left == null) {
/* 3297 */       return right == null;
/*      */     }
/* 3299 */     if (right == null) {
/* 3300 */       return false;
/*      */     }
/* 3302 */     if (left.length != right.length) {
/* 3303 */       return false;
/*      */     }
/* 3305 */     for (int i = 0; i < left.length; i++) {
/* 3306 */       if (left[i] != right[i]) {
/* 3307 */         return false;
/*      */       }
/*      */     }
/* 3310 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected byte getNativeByte(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 3325 */     return getNativeByte(columnIndex, true);
/*      */   }
/*      */   
/*      */   protected byte getNativeByte(int columnIndex, boolean overflowCheck) throws SQLException {
/* 3329 */     checkRowPos();
/*      */     
/* 3331 */     checkColumnBounds(columnIndex);
/*      */     
/* 3333 */     Object value = this.thisRow.getColumnValue(columnIndex - 1);
/*      */     
/* 3335 */     if (value == null) {
/* 3336 */       this.wasNullFlag = true;
/*      */       
/* 3338 */       return 0;
/*      */     }
/*      */     
/* 3341 */     this.wasNullFlag = false;
/*      */     
/* 3343 */     columnIndex--;
/*      */     
/* 3345 */     Field field = this.fields[columnIndex];
/*      */     long valueAsLong;
/* 3347 */     short valueAsShort; switch (field.getMysqlType()) {
/*      */     case 16: 
/* 3349 */       valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex + 1);
/*      */       
/* 3351 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && ((valueAsLong < -128L) || (valueAsLong > 127L)))
/*      */       {
/*      */ 
/* 3354 */         throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, -6);
/*      */       }
/*      */       
/*      */ 
/* 3358 */       return (byte)(int)valueAsLong;
/*      */     case 1: 
/* 3360 */       byte valueAsByte = ((byte[])(byte[])value)[0];
/*      */       
/* 3362 */       if (!field.isUnsigned()) {
/* 3363 */         return valueAsByte;
/*      */       }
/*      */       
/* 3366 */       valueAsShort = valueAsByte >= 0 ? (short)valueAsByte : (short)(valueAsByte + 256);
/*      */       
/*      */ 
/* 3369 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && 
/* 3370 */         (valueAsShort > 127)) {
/* 3371 */         throwRangeException(String.valueOf(valueAsShort), columnIndex + 1, -6);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 3376 */       return (byte)valueAsShort;
/*      */     
/*      */     case 2: 
/*      */     case 13: 
/* 3380 */       valueAsShort = getNativeShort(columnIndex + 1);
/*      */       
/* 3382 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (
/* 3383 */         (valueAsShort < -128) || (valueAsShort > 127)))
/*      */       {
/* 3385 */         throwRangeException(String.valueOf(valueAsShort), columnIndex + 1, -6);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 3390 */       return (byte)valueAsShort;
/*      */     case 3: 
/*      */     case 9: 
/* 3393 */       int valueAsInt = getNativeInt(columnIndex + 1, false);
/*      */       
/* 3395 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (
/* 3396 */         (valueAsInt < -128) || (valueAsInt > 127))) {
/* 3397 */         throwRangeException(String.valueOf(valueAsInt), columnIndex + 1, -6);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 3402 */       return (byte)valueAsInt;
/*      */     
/*      */     case 4: 
/* 3405 */       float valueAsFloat = getNativeFloat(columnIndex + 1);
/*      */       
/* 3407 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (
/* 3408 */         (valueAsFloat < -128.0F) || (valueAsFloat > 127.0F)))
/*      */       {
/*      */ 
/* 3411 */         throwRangeException(String.valueOf(valueAsFloat), columnIndex + 1, -6);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 3416 */       return (byte)(int)valueAsFloat;
/*      */     
/*      */     case 5: 
/* 3419 */       double valueAsDouble = getNativeDouble(columnIndex + 1);
/*      */       
/* 3421 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (
/* 3422 */         (valueAsDouble < -128.0D) || (valueAsDouble > 127.0D)))
/*      */       {
/* 3424 */         throwRangeException(String.valueOf(valueAsDouble), columnIndex + 1, -6);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 3429 */       return (byte)(int)valueAsDouble;
/*      */     
/*      */     case 8: 
/* 3432 */       valueAsLong = getNativeLong(columnIndex + 1, false, true);
/*      */       
/* 3434 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (
/* 3435 */         (valueAsLong < -128L) || (valueAsLong > 127L)))
/*      */       {
/* 3437 */         throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, -6);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 3442 */       return (byte)(int)valueAsLong;
/*      */     }
/*      */     
/* 3445 */     if (this.useUsageAdvisor) {
/* 3446 */       issueConversionViaParsingWarning("getByte()", columnIndex, this.thisRow.getColumnValue(columnIndex - 1), this.fields[columnIndex], new int[] { 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3456 */     return getByteFromString(getNativeString(columnIndex + 1), columnIndex + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected byte[] getNativeBytes(int columnIndex, boolean noConversion)
/*      */     throws SQLException
/*      */   {
/* 3478 */     checkRowPos();
/*      */     
/* 3480 */     checkColumnBounds(columnIndex);
/*      */     
/* 3482 */     Object value = this.thisRow.getColumnValue(columnIndex - 1);
/*      */     
/* 3484 */     if (value == null) {
/* 3485 */       this.wasNullFlag = true;
/*      */     } else {
/* 3487 */       this.wasNullFlag = false;
/*      */     }
/*      */     
/* 3490 */     if (this.wasNullFlag) {
/* 3491 */       return null;
/*      */     }
/*      */     
/* 3494 */     Field field = this.fields[(columnIndex - 1)];
/*      */     
/* 3496 */     int mysqlType = field.getMysqlType();
/*      */     
/*      */ 
/*      */ 
/* 3500 */     if (noConversion) {
/* 3501 */       mysqlType = 252;
/*      */     }
/*      */     
/* 3504 */     switch (mysqlType) {
/*      */     case 16: 
/*      */     case 249: 
/*      */     case 250: 
/*      */     case 251: 
/*      */     case 252: 
/* 3510 */       return (byte[])value;
/*      */     
/*      */     case 15: 
/*      */     case 253: 
/*      */     case 254: 
/* 3515 */       if ((value instanceof byte[])) {
/* 3516 */         return (byte[])value;
/*      */       }
/*      */       break;
/*      */     }
/* 3520 */     int sqlType = field.getSQLType();
/*      */     
/* 3522 */     if ((sqlType == -3) || (sqlType == -2)) {
/* 3523 */       return (byte[])value;
/*      */     }
/*      */     
/* 3526 */     return getBytesFromString(getNativeString(columnIndex));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Reader getNativeCharacterStream(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 3547 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 3549 */     switch (this.fields[columnIndexMinusOne].getSQLType()) {
/*      */     case -1: 
/*      */     case 1: 
/*      */     case 12: 
/*      */     case 2005: 
/* 3554 */       if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 3555 */         this.wasNullFlag = true;
/*      */         
/* 3557 */         return null;
/*      */       }
/*      */       
/* 3560 */       this.wasNullFlag = false;
/*      */       
/* 3562 */       return this.thisRow.getReader(columnIndexMinusOne);
/*      */     }
/*      */     
/* 3565 */     String asString = getStringForClob(columnIndex);
/*      */     
/* 3567 */     if (asString == null) {
/* 3568 */       return null;
/*      */     }
/*      */     
/* 3571 */     return getCharacterStreamFromString(asString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected java.sql.Clob getNativeClob(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 3586 */     String stringVal = getStringForClob(columnIndex);
/*      */     
/* 3588 */     if (stringVal == null) {
/* 3589 */       return null;
/*      */     }
/*      */     
/* 3592 */     return getClobFromString(stringVal);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private synchronized String getNativeConvertToString(int columnIndex, Field field)
/*      */     throws SQLException
/*      */   {
/* 3600 */     int sqlType = field.getSQLType();
/* 3601 */     int mysqlType = field.getMysqlType();
/*      */     int intVal;
/* 3603 */     long longVal; switch (sqlType) {
/*      */     case -7: 
/* 3605 */       return String.valueOf(getNumericRepresentationOfSQLBitType(columnIndex));
/*      */     case 16: 
/* 3607 */       boolean booleanVal = getBoolean(columnIndex);
/*      */       
/* 3609 */       if (this.wasNullFlag) {
/* 3610 */         return null;
/*      */       }
/*      */       
/* 3613 */       return String.valueOf(booleanVal);
/*      */     
/*      */     case -6: 
/* 3616 */       byte tinyintVal = getNativeByte(columnIndex, false);
/*      */       
/* 3618 */       if (this.wasNullFlag) {
/* 3619 */         return null;
/*      */       }
/*      */       
/* 3622 */       if ((!field.isUnsigned()) || (tinyintVal >= 0)) {
/* 3623 */         return String.valueOf(tinyintVal);
/*      */       }
/*      */       
/* 3626 */       short unsignedTinyVal = (short)(tinyintVal & 0xFF);
/*      */       
/* 3628 */       return String.valueOf(unsignedTinyVal);
/*      */     
/*      */ 
/*      */     case 5: 
/* 3632 */       intVal = getNativeInt(columnIndex, false);
/*      */       
/* 3634 */       if (this.wasNullFlag) {
/* 3635 */         return null;
/*      */       }
/*      */       
/* 3638 */       if ((!field.isUnsigned()) || (intVal >= 0)) {
/* 3639 */         return String.valueOf(intVal);
/*      */       }
/*      */       
/* 3642 */       intVal &= 0xFFFF;
/*      */       
/* 3644 */       return String.valueOf(intVal);
/*      */     
/*      */     case 4: 
/* 3647 */       intVal = getNativeInt(columnIndex, false);
/*      */       
/* 3649 */       if (this.wasNullFlag) {
/* 3650 */         return null;
/*      */       }
/*      */       
/* 3653 */       if ((!field.isUnsigned()) || (intVal >= 0) || (field.getMysqlType() == 9))
/*      */       {
/*      */ 
/* 3656 */         return String.valueOf(intVal);
/*      */       }
/*      */       
/* 3659 */       longVal = intVal & 0xFFFFFFFF;
/*      */       
/* 3661 */       return String.valueOf(longVal);
/*      */     
/*      */ 
/*      */     case -5: 
/* 3665 */       if (!field.isUnsigned()) {
/* 3666 */         longVal = getNativeLong(columnIndex, false, true);
/*      */         
/* 3668 */         if (this.wasNullFlag) {
/* 3669 */           return null;
/*      */         }
/*      */         
/* 3672 */         return String.valueOf(longVal);
/*      */       }
/*      */       
/* 3675 */       long longVal = getNativeLong(columnIndex, false, false);
/*      */       
/* 3677 */       if (this.wasNullFlag) {
/* 3678 */         return null;
/*      */       }
/*      */       
/* 3681 */       return String.valueOf(convertLongToUlong(longVal));
/*      */     case 7: 
/* 3683 */       float floatVal = getNativeFloat(columnIndex);
/*      */       
/* 3685 */       if (this.wasNullFlag) {
/* 3686 */         return null;
/*      */       }
/*      */       
/* 3689 */       return String.valueOf(floatVal);
/*      */     
/*      */     case 6: 
/*      */     case 8: 
/* 3693 */       double doubleVal = getNativeDouble(columnIndex);
/*      */       
/* 3695 */       if (this.wasNullFlag) {
/* 3696 */         return null;
/*      */       }
/*      */       
/* 3699 */       return String.valueOf(doubleVal);
/*      */     
/*      */     case 2: 
/*      */     case 3: 
/* 3703 */       String stringVal = StringUtils.toAsciiString(this.thisRow.getColumnValue(columnIndex - 1));
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 3708 */       if (stringVal != null) {
/* 3709 */         this.wasNullFlag = false;
/*      */         
/* 3711 */         if (stringVal.length() == 0) {
/* 3712 */           BigDecimal val = new BigDecimal(0);
/*      */           
/* 3714 */           return val.toString();
/*      */         }
/*      */         BigDecimal val;
/*      */         try {
/* 3718 */           val = new BigDecimal(stringVal);
/*      */         } catch (NumberFormatException ex) {
/* 3720 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3727 */         return val.toString();
/*      */       }
/*      */       
/* 3730 */       this.wasNullFlag = true;
/*      */       
/* 3732 */       return null;
/*      */     
/*      */ 
/*      */     case -1: 
/*      */     case 1: 
/*      */     case 12: 
/* 3738 */       return extractStringFromNativeColumn(columnIndex, mysqlType);
/*      */     
/*      */     case -4: 
/*      */     case -3: 
/*      */     case -2: 
/* 3743 */       if (!field.isBlob())
/* 3744 */         return extractStringFromNativeColumn(columnIndex, mysqlType);
/* 3745 */       if (!field.isBinary()) {
/* 3746 */         return extractStringFromNativeColumn(columnIndex, mysqlType);
/*      */       }
/* 3748 */       byte[] data = getBytes(columnIndex);
/* 3749 */       Object obj = data;
/*      */       
/* 3751 */       if ((data != null) && (data.length >= 2)) {
/* 3752 */         if ((data[0] == -84) && (data[1] == -19)) {
/*      */           try
/*      */           {
/* 3755 */             ByteArrayInputStream bytesIn = new ByteArrayInputStream(data);
/*      */             
/* 3757 */             ObjectInputStream objIn = new ObjectInputStream(bytesIn);
/*      */             
/* 3759 */             obj = objIn.readObject();
/* 3760 */             objIn.close();
/* 3761 */             bytesIn.close();
/*      */           } catch (ClassNotFoundException cnfe) {
/* 3763 */             throw SQLError.createSQLException(Messages.getString("ResultSet.Class_not_found___91") + cnfe.toString() + Messages.getString("ResultSet._while_reading_serialized_object_92"), getExceptionInterceptor());
/*      */ 
/*      */ 
/*      */           }
/*      */           catch (IOException ex)
/*      */           {
/*      */ 
/* 3770 */             obj = data;
/*      */           }
/*      */         }
/*      */         
/* 3774 */         return obj.toString();
/*      */       }
/*      */       
/* 3777 */       return extractStringFromNativeColumn(columnIndex, mysqlType);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 91: 
/* 3783 */       if (mysqlType == 13) {
/* 3784 */         short shortVal = getNativeShort(columnIndex);
/*      */         
/* 3786 */         if (!this.connection.getYearIsDateType())
/*      */         {
/* 3788 */           if (this.wasNullFlag) {
/* 3789 */             return null;
/*      */           }
/*      */           
/* 3792 */           return String.valueOf(shortVal);
/*      */         }
/*      */         
/* 3795 */         if (field.getLength() == 2L)
/*      */         {
/* 3797 */           if (shortVal <= 69) {
/* 3798 */             shortVal = (short)(shortVal + 100);
/*      */           }
/*      */           
/* 3801 */           shortVal = (short)(shortVal + 1900);
/*      */         }
/*      */         
/* 3804 */         return fastDateCreate(null, shortVal, 1, 1).toString();
/*      */       }
/*      */       
/*      */ 
/* 3808 */       if (this.connection.getNoDatetimeStringSync()) {
/* 3809 */         byte[] asBytes = getNativeBytes(columnIndex, true);
/*      */         
/* 3811 */         if (asBytes == null) {
/* 3812 */           return null;
/*      */         }
/*      */         
/* 3815 */         if (asBytes.length == 0)
/*      */         {
/* 3817 */           return "0000-00-00";
/*      */         }
/*      */         
/* 3820 */         int year = asBytes[0] & 0xFF | (asBytes[1] & 0xFF) << 8;
/*      */         
/* 3822 */         int month = asBytes[2];
/* 3823 */         int day = asBytes[3];
/*      */         
/* 3825 */         if ((year == 0) && (month == 0) && (day == 0)) {
/* 3826 */           return "0000-00-00";
/*      */         }
/*      */       }
/*      */       
/* 3830 */       Date dt = getNativeDate(columnIndex);
/*      */       
/* 3832 */       if (dt == null) {
/* 3833 */         return null;
/*      */       }
/*      */       
/* 3836 */       return String.valueOf(dt);
/*      */     
/*      */     case 92: 
/* 3839 */       Time tm = getNativeTime(columnIndex, null, this.defaultTimeZone, false);
/*      */       
/* 3841 */       if (tm == null) {
/* 3842 */         return null;
/*      */       }
/*      */       
/* 3845 */       return String.valueOf(tm);
/*      */     
/*      */     case 93: 
/* 3848 */       if (this.connection.getNoDatetimeStringSync()) {
/* 3849 */         byte[] asBytes = getNativeBytes(columnIndex, true);
/*      */         
/* 3851 */         if (asBytes == null) {
/* 3852 */           return null;
/*      */         }
/*      */         
/* 3855 */         if (asBytes.length == 0)
/*      */         {
/* 3857 */           return "0000-00-00 00:00:00";
/*      */         }
/*      */         
/* 3860 */         int year = asBytes[0] & 0xFF | (asBytes[1] & 0xFF) << 8;
/*      */         
/* 3862 */         int month = asBytes[2];
/* 3863 */         int day = asBytes[3];
/*      */         
/* 3865 */         if ((year == 0) && (month == 0) && (day == 0)) {
/* 3866 */           return "0000-00-00 00:00:00";
/*      */         }
/*      */       }
/*      */       
/* 3870 */       Timestamp tstamp = getNativeTimestamp(columnIndex, null, this.defaultTimeZone, false);
/*      */       
/*      */ 
/* 3873 */       if (tstamp == null) {
/* 3874 */         return null;
/*      */       }
/*      */       
/* 3877 */       String result = String.valueOf(tstamp);
/*      */       
/* 3879 */       if (!this.connection.getNoDatetimeStringSync()) {
/* 3880 */         return result;
/*      */       }
/*      */       
/* 3883 */       if (result.endsWith(".0")) {
/* 3884 */         return result.substring(0, result.length() - 2);
/*      */       }
/*      */       break;
/*      */     }
/* 3888 */     return extractStringFromNativeColumn(columnIndex, mysqlType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Date getNativeDate(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 3904 */     return getNativeDate(columnIndex, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Date getNativeDate(int columnIndex, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 3925 */     checkRowPos();
/* 3926 */     checkColumnBounds(columnIndex);
/*      */     
/* 3928 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 3930 */     int mysqlType = this.fields[columnIndexMinusOne].getMysqlType();
/*      */     
/* 3932 */     Date dateToReturn = null;
/*      */     
/* 3934 */     if (mysqlType == 10)
/*      */     {
/* 3936 */       dateToReturn = this.thisRow.getNativeDate(columnIndexMinusOne, this.connection, this, cal);
/*      */     }
/*      */     else {
/* 3939 */       TimeZone tz = cal != null ? cal.getTimeZone() : getDefaultTimeZone();
/*      */       
/*      */ 
/* 3942 */       boolean rollForward = (tz != null) && (!tz.equals(getDefaultTimeZone()));
/*      */       
/* 3944 */       dateToReturn = (Date)this.thisRow.getNativeDateTimeValue(columnIndexMinusOne, null, 91, mysqlType, tz, rollForward, this.connection, this);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3956 */     if (dateToReturn == null)
/*      */     {
/* 3958 */       this.wasNullFlag = true;
/*      */       
/* 3960 */       return null;
/*      */     }
/*      */     
/* 3963 */     this.wasNullFlag = false;
/*      */     
/* 3965 */     return dateToReturn;
/*      */   }
/*      */   
/*      */   Date getNativeDateViaParseConversion(int columnIndex) throws SQLException {
/* 3969 */     if (this.useUsageAdvisor) {
/* 3970 */       issueConversionViaParsingWarning("getDate()", columnIndex, this.thisRow.getColumnValue(columnIndex - 1), this.fields[(columnIndex - 1)], new int[] { 10 });
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3975 */     String stringVal = getNativeString(columnIndex);
/*      */     
/* 3977 */     return getDateFromString(stringVal, columnIndex, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected double getNativeDouble(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 3992 */     checkRowPos();
/* 3993 */     checkColumnBounds(columnIndex);
/*      */     
/* 3995 */     columnIndex--;
/*      */     
/* 3997 */     if (this.thisRow.isNull(columnIndex)) {
/* 3998 */       this.wasNullFlag = true;
/*      */       
/* 4000 */       return 0.0D;
/*      */     }
/*      */     
/* 4003 */     this.wasNullFlag = false;
/*      */     
/* 4005 */     Field f = this.fields[columnIndex];
/*      */     
/* 4007 */     switch (f.getMysqlType()) {
/*      */     case 5: 
/* 4009 */       return this.thisRow.getNativeDouble(columnIndex);
/*      */     case 1: 
/* 4011 */       if (!f.isUnsigned()) {
/* 4012 */         return getNativeByte(columnIndex + 1);
/*      */       }
/*      */       
/* 4015 */       return getNativeShort(columnIndex + 1);
/*      */     case 2: 
/*      */     case 13: 
/* 4018 */       if (!f.isUnsigned()) {
/* 4019 */         return getNativeShort(columnIndex + 1);
/*      */       }
/*      */       
/* 4022 */       return getNativeInt(columnIndex + 1);
/*      */     case 3: 
/*      */     case 9: 
/* 4025 */       if (!f.isUnsigned()) {
/* 4026 */         return getNativeInt(columnIndex + 1);
/*      */       }
/*      */       
/* 4029 */       return getNativeLong(columnIndex + 1);
/*      */     case 8: 
/* 4031 */       long valueAsLong = getNativeLong(columnIndex + 1);
/*      */       
/* 4033 */       if (!f.isUnsigned()) {
/* 4034 */         return valueAsLong;
/*      */       }
/*      */       
/* 4037 */       BigInteger asBigInt = convertLongToUlong(valueAsLong);
/*      */       
/*      */ 
/*      */ 
/* 4041 */       return asBigInt.doubleValue();
/*      */     case 4: 
/* 4043 */       return getNativeFloat(columnIndex + 1);
/*      */     case 16: 
/* 4045 */       return getNumericRepresentationOfSQLBitType(columnIndex + 1);
/*      */     }
/* 4047 */     String stringVal = getNativeString(columnIndex + 1);
/*      */     
/* 4049 */     if (this.useUsageAdvisor) {
/* 4050 */       issueConversionViaParsingWarning("getDouble()", columnIndex, stringVal, this.fields[columnIndex], new int[] { 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4060 */     return getDoubleFromString(stringVal, columnIndex + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected float getNativeFloat(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 4076 */     checkRowPos();
/* 4077 */     checkColumnBounds(columnIndex);
/*      */     
/* 4079 */     columnIndex--;
/*      */     
/* 4081 */     if (this.thisRow.isNull(columnIndex)) {
/* 4082 */       this.wasNullFlag = true;
/*      */       
/* 4084 */       return 0.0F;
/*      */     }
/*      */     
/* 4087 */     this.wasNullFlag = false;
/*      */     
/* 4089 */     Field f = this.fields[columnIndex];
/*      */     long valueAsLong;
/* 4091 */     switch (f.getMysqlType()) {
/*      */     case 16: 
/* 4093 */       valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex + 1);
/*      */       
/* 4095 */       return (float)valueAsLong;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 5: 
/* 4102 */       Double valueAsDouble = new Double(getNativeDouble(columnIndex + 1));
/*      */       
/* 4104 */       float valueAsFloat = valueAsDouble.floatValue();
/*      */       
/* 4106 */       if (((this.jdbcCompliantTruncationForReads) && (valueAsFloat == Float.NEGATIVE_INFINITY)) || (valueAsFloat == Float.POSITIVE_INFINITY))
/*      */       {
/*      */ 
/* 4109 */         throwRangeException(valueAsDouble.toString(), columnIndex + 1, 6);
/*      */       }
/*      */       
/*      */ 
/* 4113 */       return (float)getNativeDouble(columnIndex + 1);
/*      */     case 1: 
/* 4115 */       if (!f.isUnsigned()) {
/* 4116 */         return getNativeByte(columnIndex + 1);
/*      */       }
/*      */       
/* 4119 */       return getNativeShort(columnIndex + 1);
/*      */     case 2: 
/*      */     case 13: 
/* 4122 */       if (!f.isUnsigned()) {
/* 4123 */         return getNativeShort(columnIndex + 1);
/*      */       }
/*      */       
/* 4126 */       return getNativeInt(columnIndex + 1);
/*      */     case 3: 
/*      */     case 9: 
/* 4129 */       if (!f.isUnsigned()) {
/* 4130 */         return getNativeInt(columnIndex + 1);
/*      */       }
/*      */       
/* 4133 */       return (float)getNativeLong(columnIndex + 1);
/*      */     case 8: 
/* 4135 */       valueAsLong = getNativeLong(columnIndex + 1);
/*      */       
/* 4137 */       if (!f.isUnsigned()) {
/* 4138 */         return (float)valueAsLong;
/*      */       }
/*      */       
/* 4141 */       BigInteger asBigInt = convertLongToUlong(valueAsLong);
/*      */       
/*      */ 
/*      */ 
/* 4145 */       return asBigInt.floatValue();
/*      */     
/*      */     case 4: 
/* 4148 */       return this.thisRow.getNativeFloat(columnIndex);
/*      */     }
/*      */     
/* 4151 */     String stringVal = getNativeString(columnIndex + 1);
/*      */     
/* 4153 */     if (this.useUsageAdvisor) {
/* 4154 */       issueConversionViaParsingWarning("getFloat()", columnIndex, stringVal, this.fields[columnIndex], new int[] { 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4164 */     return getFloatFromString(stringVal, columnIndex + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int getNativeInt(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 4180 */     return getNativeInt(columnIndex, true);
/*      */   }
/*      */   
/*      */   protected int getNativeInt(int columnIndex, boolean overflowCheck) throws SQLException {
/* 4184 */     checkRowPos();
/* 4185 */     checkColumnBounds(columnIndex);
/*      */     
/* 4187 */     columnIndex--;
/*      */     
/* 4189 */     if (this.thisRow.isNull(columnIndex)) {
/* 4190 */       this.wasNullFlag = true;
/*      */       
/* 4192 */       return 0;
/*      */     }
/*      */     
/* 4195 */     this.wasNullFlag = false;
/*      */     
/* 4197 */     Field f = this.fields[columnIndex];
/*      */     long valueAsLong;
/* 4199 */     double valueAsDouble; switch (f.getMysqlType()) {
/*      */     case 16: 
/* 4201 */       valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex + 1);
/*      */       
/* 4203 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && ((valueAsLong < -2147483648L) || (valueAsLong > 2147483647L)))
/*      */       {
/*      */ 
/* 4206 */         throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, 4);
/*      */       }
/*      */       
/*      */ 
/* 4210 */       return (short)(int)valueAsLong;
/*      */     case 1: 
/* 4212 */       byte tinyintVal = getNativeByte(columnIndex + 1, false);
/*      */       
/* 4214 */       if ((!f.isUnsigned()) || (tinyintVal >= 0)) {
/* 4215 */         return tinyintVal;
/*      */       }
/*      */       
/* 4218 */       return tinyintVal + 256;
/*      */     case 2: 
/*      */     case 13: 
/* 4221 */       short asShort = getNativeShort(columnIndex + 1, false);
/*      */       
/* 4223 */       if ((!f.isUnsigned()) || (asShort >= 0)) {
/* 4224 */         return asShort;
/*      */       }
/*      */       
/* 4227 */       return asShort + 65536;
/*      */     
/*      */     case 3: 
/*      */     case 9: 
/* 4231 */       int valueAsInt = this.thisRow.getNativeInt(columnIndex);
/*      */       
/* 4233 */       if (!f.isUnsigned()) {
/* 4234 */         return valueAsInt;
/*      */       }
/*      */       
/* 4237 */       valueAsLong = valueAsInt >= 0 ? valueAsInt : valueAsInt + 4294967296L;
/*      */       
/*      */ 
/* 4240 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (valueAsLong > 2147483647L))
/*      */       {
/* 4242 */         throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, 4);
/*      */       }
/*      */       
/*      */ 
/* 4246 */       return (int)valueAsLong;
/*      */     case 8: 
/* 4248 */       valueAsLong = getNativeLong(columnIndex + 1, false, true);
/*      */       
/* 4250 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (
/* 4251 */         (valueAsLong < -2147483648L) || (valueAsLong > 2147483647L)))
/*      */       {
/* 4253 */         throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, 4);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 4258 */       return (int)valueAsLong;
/*      */     case 5: 
/* 4260 */       valueAsDouble = getNativeDouble(columnIndex + 1);
/*      */       
/* 4262 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (
/* 4263 */         (valueAsDouble < -2.147483648E9D) || (valueAsDouble > 2.147483647E9D)))
/*      */       {
/* 4265 */         throwRangeException(String.valueOf(valueAsDouble), columnIndex + 1, 4);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 4270 */       return (int)valueAsDouble;
/*      */     case 4: 
/* 4272 */       valueAsDouble = getNativeFloat(columnIndex + 1);
/*      */       
/* 4274 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (
/* 4275 */         (valueAsDouble < -2.147483648E9D) || (valueAsDouble > 2.147483647E9D)))
/*      */       {
/* 4277 */         throwRangeException(String.valueOf(valueAsDouble), columnIndex + 1, 4);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 4282 */       return (int)valueAsDouble;
/*      */     }
/*      */     
/* 4285 */     String stringVal = getNativeString(columnIndex + 1);
/*      */     
/* 4287 */     if (this.useUsageAdvisor) {
/* 4288 */       issueConversionViaParsingWarning("getInt()", columnIndex, stringVal, this.fields[columnIndex], new int[] { 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4298 */     return getIntFromString(stringVal, columnIndex + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected long getNativeLong(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 4314 */     return getNativeLong(columnIndex, true, true);
/*      */   }
/*      */   
/*      */   protected long getNativeLong(int columnIndex, boolean overflowCheck, boolean expandUnsignedLong) throws SQLException
/*      */   {
/* 4319 */     checkRowPos();
/* 4320 */     checkColumnBounds(columnIndex);
/*      */     
/* 4322 */     columnIndex--;
/*      */     
/* 4324 */     if (this.thisRow.isNull(columnIndex)) {
/* 4325 */       this.wasNullFlag = true;
/*      */       
/* 4327 */       return 0L;
/*      */     }
/*      */     
/* 4330 */     this.wasNullFlag = false;
/*      */     
/* 4332 */     Field f = this.fields[columnIndex];
/*      */     double valueAsDouble;
/* 4334 */     switch (f.getMysqlType()) {
/*      */     case 16: 
/* 4336 */       return getNumericRepresentationOfSQLBitType(columnIndex + 1);
/*      */     case 1: 
/* 4338 */       if (!f.isUnsigned()) {
/* 4339 */         return getNativeByte(columnIndex + 1);
/*      */       }
/*      */       
/* 4342 */       return getNativeInt(columnIndex + 1);
/*      */     case 2: 
/* 4344 */       if (!f.isUnsigned()) {
/* 4345 */         return getNativeShort(columnIndex + 1);
/*      */       }
/*      */       
/* 4348 */       return getNativeInt(columnIndex + 1, false);
/*      */     
/*      */     case 13: 
/* 4351 */       return getNativeShort(columnIndex + 1);
/*      */     case 3: 
/*      */     case 9: 
/* 4354 */       int asInt = getNativeInt(columnIndex + 1, false);
/*      */       
/* 4356 */       if ((!f.isUnsigned()) || (asInt >= 0)) {
/* 4357 */         return asInt;
/*      */       }
/*      */       
/* 4360 */       return asInt + 4294967296L;
/*      */     case 8: 
/* 4362 */       long valueAsLong = this.thisRow.getNativeLong(columnIndex);
/*      */       
/* 4364 */       if ((!f.isUnsigned()) || (!expandUnsignedLong)) {
/* 4365 */         return valueAsLong;
/*      */       }
/*      */       
/* 4368 */       BigInteger asBigInt = convertLongToUlong(valueAsLong);
/*      */       
/* 4370 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && ((asBigInt.compareTo(new BigInteger(String.valueOf(Long.MAX_VALUE))) > 0) || (asBigInt.compareTo(new BigInteger(String.valueOf(Long.MIN_VALUE))) < 0)))
/*      */       {
/*      */ 
/* 4373 */         throwRangeException(asBigInt.toString(), columnIndex + 1, -5);
/*      */       }
/*      */       
/*      */ 
/* 4377 */       return getLongFromString(asBigInt.toString(), columnIndex);
/*      */     
/*      */     case 5: 
/* 4380 */       valueAsDouble = getNativeDouble(columnIndex + 1);
/*      */       
/* 4382 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (
/* 4383 */         (valueAsDouble < -9.223372036854776E18D) || (valueAsDouble > 9.223372036854776E18D)))
/*      */       {
/* 4385 */         throwRangeException(String.valueOf(valueAsDouble), columnIndex + 1, -5);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 4390 */       return valueAsDouble;
/*      */     case 4: 
/* 4392 */       valueAsDouble = getNativeFloat(columnIndex + 1);
/*      */       
/* 4394 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (
/* 4395 */         (valueAsDouble < -9.223372036854776E18D) || (valueAsDouble > 9.223372036854776E18D)))
/*      */       {
/* 4397 */         throwRangeException(String.valueOf(valueAsDouble), columnIndex + 1, -5);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 4402 */       return valueAsDouble;
/*      */     }
/* 4404 */     String stringVal = getNativeString(columnIndex + 1);
/*      */     
/* 4406 */     if (this.useUsageAdvisor) {
/* 4407 */       issueConversionViaParsingWarning("getLong()", columnIndex, stringVal, this.fields[columnIndex], new int[] { 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4417 */     return getLongFromString(stringVal, columnIndex + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Ref getNativeRef(int i)
/*      */     throws SQLException
/*      */   {
/* 4435 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected short getNativeShort(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 4450 */     return getNativeShort(columnIndex, true);
/*      */   }
/*      */   
/*      */   protected short getNativeShort(int columnIndex, boolean overflowCheck) throws SQLException {
/* 4454 */     checkRowPos();
/* 4455 */     checkColumnBounds(columnIndex);
/*      */     
/* 4457 */     columnIndex--;
/*      */     
/*      */ 
/* 4460 */     if (this.thisRow.isNull(columnIndex)) {
/* 4461 */       this.wasNullFlag = true;
/*      */       
/* 4463 */       return 0;
/*      */     }
/*      */     
/* 4466 */     this.wasNullFlag = false;
/*      */     
/* 4468 */     Field f = this.fields[columnIndex];
/*      */     int valueAsInt;
/* 4470 */     long valueAsLong; switch (f.getMysqlType())
/*      */     {
/*      */     case 1: 
/* 4473 */       byte tinyintVal = getNativeByte(columnIndex + 1, false);
/*      */       
/* 4475 */       if ((!f.isUnsigned()) || (tinyintVal >= 0)) {
/* 4476 */         return (short)tinyintVal;
/*      */       }
/*      */       
/* 4479 */       return (short)(tinyintVal + 256);
/*      */     
/*      */     case 2: 
/*      */     case 13: 
/* 4483 */       short asShort = this.thisRow.getNativeShort(columnIndex);
/*      */       
/* 4485 */       if (!f.isUnsigned()) {
/* 4486 */         return asShort;
/*      */       }
/*      */       
/* 4489 */       valueAsInt = asShort & 0xFFFF;
/*      */       
/* 4491 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (valueAsInt > 32767))
/*      */       {
/* 4493 */         throwRangeException(String.valueOf(valueAsInt), columnIndex + 1, 5);
/*      */       }
/*      */       
/*      */ 
/* 4497 */       return (short)valueAsInt;
/*      */     case 3: 
/*      */     case 9: 
/* 4500 */       if (!f.isUnsigned()) {
/* 4501 */         valueAsInt = getNativeInt(columnIndex + 1, false);
/*      */         
/* 4503 */         if (((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (valueAsInt > 32767)) || (valueAsInt < 32768))
/*      */         {
/*      */ 
/* 4506 */           throwRangeException(String.valueOf(valueAsInt), columnIndex + 1, 5);
/*      */         }
/*      */         
/*      */ 
/* 4510 */         return (short)valueAsInt;
/*      */       }
/*      */       
/* 4513 */       valueAsLong = getNativeLong(columnIndex + 1, false, true);
/*      */       
/* 4515 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (valueAsLong > 32767L))
/*      */       {
/* 4517 */         throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, 5);
/*      */       }
/*      */       
/*      */ 
/* 4521 */       return (short)(int)valueAsLong;
/*      */     
/*      */     case 8: 
/* 4524 */       valueAsLong = getNativeLong(columnIndex + 1, false, false);
/*      */       
/* 4526 */       if (!f.isUnsigned()) {
/* 4527 */         if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (
/* 4528 */           (valueAsLong < -32768L) || (valueAsLong > 32767L)))
/*      */         {
/* 4530 */           throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, 5);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 4535 */         return (short)(int)valueAsLong;
/*      */       }
/*      */       
/* 4538 */       BigInteger asBigInt = convertLongToUlong(valueAsLong);
/*      */       
/* 4540 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && ((asBigInt.compareTo(new BigInteger(String.valueOf(32767))) > 0) || (asBigInt.compareTo(new BigInteger(String.valueOf(32768))) < 0)))
/*      */       {
/*      */ 
/* 4543 */         throwRangeException(asBigInt.toString(), columnIndex + 1, 5);
/*      */       }
/*      */       
/*      */ 
/* 4547 */       return (short)getIntFromString(asBigInt.toString(), columnIndex + 1);
/*      */     
/*      */     case 5: 
/* 4550 */       double valueAsDouble = getNativeDouble(columnIndex + 1);
/*      */       
/* 4552 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (
/* 4553 */         (valueAsDouble < -32768.0D) || (valueAsDouble > 32767.0D)))
/*      */       {
/* 4555 */         throwRangeException(String.valueOf(valueAsDouble), columnIndex + 1, 5);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 4560 */       return (short)(int)valueAsDouble;
/*      */     case 4: 
/* 4562 */       float valueAsFloat = getNativeFloat(columnIndex + 1);
/*      */       
/* 4564 */       if ((overflowCheck) && (this.jdbcCompliantTruncationForReads) && (
/* 4565 */         (valueAsFloat < -32768.0F) || (valueAsFloat > 32767.0F)))
/*      */       {
/* 4567 */         throwRangeException(String.valueOf(valueAsFloat), columnIndex + 1, 5);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 4572 */       return (short)(int)valueAsFloat;
/*      */     }
/* 4574 */     String stringVal = getNativeString(columnIndex + 1);
/*      */     
/* 4576 */     if (this.useUsageAdvisor) {
/* 4577 */       issueConversionViaParsingWarning("getShort()", columnIndex, stringVal, this.fields[columnIndex], new int[] { 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4587 */     return getShortFromString(stringVal, columnIndex + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getNativeString(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 4603 */     checkRowPos();
/* 4604 */     checkColumnBounds(columnIndex);
/*      */     
/* 4606 */     if (this.fields == null) {
/* 4607 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Query_generated_no_fields_for_ResultSet_133"), "S1002", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4613 */     if (this.thisRow.isNull(columnIndex - 1)) {
/* 4614 */       this.wasNullFlag = true;
/*      */       
/* 4616 */       return null;
/*      */     }
/*      */     
/* 4619 */     this.wasNullFlag = false;
/*      */     
/* 4621 */     String stringVal = null;
/*      */     
/* 4623 */     Field field = this.fields[(columnIndex - 1)];
/*      */     
/*      */ 
/* 4626 */     stringVal = getNativeConvertToString(columnIndex, field);
/* 4627 */     int mysqlType = field.getMysqlType();
/*      */     
/* 4629 */     if ((mysqlType != 7) && (mysqlType != 10) && (field.isZeroFill()) && (stringVal != null))
/*      */     {
/*      */ 
/* 4632 */       int origLength = stringVal.length();
/*      */       
/* 4634 */       StringBuffer zeroFillBuf = new StringBuffer(origLength);
/*      */       
/* 4636 */       long numZeros = field.getLength() - origLength;
/*      */       
/* 4638 */       for (long i = 0L; i < numZeros; i += 1L) {
/* 4639 */         zeroFillBuf.append('0');
/*      */       }
/*      */       
/* 4642 */       zeroFillBuf.append(stringVal);
/*      */       
/* 4644 */       stringVal = zeroFillBuf.toString();
/*      */     }
/*      */     
/* 4647 */     return stringVal;
/*      */   }
/*      */   
/*      */   private Time getNativeTime(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward)
/*      */     throws SQLException
/*      */   {
/* 4653 */     checkRowPos();
/* 4654 */     checkColumnBounds(columnIndex);
/*      */     
/* 4656 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 4658 */     int mysqlType = this.fields[columnIndexMinusOne].getMysqlType();
/*      */     
/* 4660 */     Time timeVal = null;
/*      */     
/* 4662 */     if (mysqlType == 11) {
/* 4663 */       timeVal = this.thisRow.getNativeTime(columnIndexMinusOne, targetCalendar, tz, rollForward, this.connection, this);
/*      */     }
/*      */     else
/*      */     {
/* 4667 */       timeVal = (Time)this.thisRow.getNativeDateTimeValue(columnIndexMinusOne, null, 92, mysqlType, tz, rollForward, this.connection, this);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4679 */     if (timeVal == null)
/*      */     {
/* 4681 */       this.wasNullFlag = true;
/*      */       
/* 4683 */       return null;
/*      */     }
/*      */     
/* 4686 */     this.wasNullFlag = false;
/*      */     
/* 4688 */     return timeVal;
/*      */   }
/*      */   
/*      */   Time getNativeTimeViaParseConversion(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward) throws SQLException
/*      */   {
/* 4693 */     if (this.useUsageAdvisor) {
/* 4694 */       issueConversionViaParsingWarning("getTime()", columnIndex, this.thisRow.getColumnValue(columnIndex - 1), this.fields[(columnIndex - 1)], new int[] { 11 });
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 4699 */     String strTime = getNativeString(columnIndex);
/*      */     
/* 4701 */     return getTimeFromString(strTime, targetCalendar, columnIndex, tz, rollForward);
/*      */   }
/*      */   
/*      */ 
/*      */   private Timestamp getNativeTimestamp(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward)
/*      */     throws SQLException
/*      */   {
/* 4708 */     checkRowPos();
/* 4709 */     checkColumnBounds(columnIndex);
/*      */     
/* 4711 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 4713 */     Timestamp tsVal = null;
/*      */     
/* 4715 */     int mysqlType = this.fields[columnIndexMinusOne].getMysqlType();
/*      */     
/* 4717 */     switch (mysqlType) {
/*      */     case 7: 
/*      */     case 12: 
/* 4720 */       tsVal = this.thisRow.getNativeTimestamp(columnIndexMinusOne, targetCalendar, tz, rollForward, this.connection, this);
/*      */       
/* 4722 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     default: 
/* 4727 */       tsVal = (Timestamp)this.thisRow.getNativeDateTimeValue(columnIndexMinusOne, null, 93, mysqlType, tz, rollForward, this.connection, this);
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4739 */     if (tsVal == null)
/*      */     {
/* 4741 */       this.wasNullFlag = true;
/*      */       
/* 4743 */       return null;
/*      */     }
/*      */     
/* 4746 */     this.wasNullFlag = false;
/*      */     
/* 4748 */     return tsVal;
/*      */   }
/*      */   
/*      */   Timestamp getNativeTimestampViaParseConversion(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward) throws SQLException
/*      */   {
/* 4753 */     if (this.useUsageAdvisor) {
/* 4754 */       issueConversionViaParsingWarning("getTimestamp()", columnIndex, this.thisRow.getColumnValue(columnIndex - 1), this.fields[(columnIndex - 1)], new int[] { 7, 12 });
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4760 */     String strTimestamp = getNativeString(columnIndex);
/*      */     
/* 4762 */     return getTimestampFromString(columnIndex, targetCalendar, strTimestamp, tz, rollForward);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected InputStream getNativeUnicodeStream(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 4789 */     checkRowPos();
/*      */     
/* 4791 */     return getBinaryStream(columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */   protected URL getNativeURL(int colIndex)
/*      */     throws SQLException
/*      */   {
/* 4798 */     String val = getString(colIndex);
/*      */     
/* 4800 */     if (val == null) {
/* 4801 */       return null;
/*      */     }
/*      */     try
/*      */     {
/* 4805 */       return new URL(val);
/*      */     } catch (MalformedURLException mfe) {
/* 4807 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Malformed_URL____141") + val + "'", "S1009", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized ResultSetInternalMethods getNextResultSet()
/*      */   {
/* 4819 */     return this.nextResultSet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getObject(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 4846 */     checkRowPos();
/* 4847 */     checkColumnBounds(columnIndex);
/*      */     
/* 4849 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 4851 */     if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 4852 */       this.wasNullFlag = true;
/*      */       
/* 4854 */       return null;
/*      */     }
/*      */     
/* 4857 */     this.wasNullFlag = false;
/*      */     
/*      */ 
/* 4860 */     Field field = this.fields[columnIndexMinusOne];
/*      */     String stringVal;
/* 4862 */     switch (field.getSQLType()) {
/*      */     case -7: 
/*      */     case 16: 
/* 4865 */       if ((field.getMysqlType() == 16) && (!field.isSingleBit()))
/*      */       {
/* 4867 */         return getBytes(columnIndex);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 4873 */       return Boolean.valueOf(getBoolean(columnIndex));
/*      */     
/*      */     case -6: 
/* 4876 */       if (!field.isUnsigned()) {
/* 4877 */         return Integer.valueOf(getByte(columnIndex));
/*      */       }
/*      */       
/* 4880 */       return Integer.valueOf(getInt(columnIndex));
/*      */     
/*      */ 
/*      */     case 5: 
/* 4884 */       return Integer.valueOf(getInt(columnIndex));
/*      */     
/*      */ 
/*      */     case 4: 
/* 4888 */       if ((!field.isUnsigned()) || (field.getMysqlType() == 9))
/*      */       {
/* 4890 */         return Integer.valueOf(getInt(columnIndex));
/*      */       }
/*      */       
/* 4893 */       return Long.valueOf(getLong(columnIndex));
/*      */     
/*      */ 
/*      */     case -5: 
/* 4897 */       if (!field.isUnsigned()) {
/* 4898 */         return Long.valueOf(getLong(columnIndex));
/*      */       }
/*      */       
/* 4901 */       stringVal = getString(columnIndex);
/*      */       
/* 4903 */       if (stringVal == null) {
/* 4904 */         return null;
/*      */       }
/*      */       try
/*      */       {
/* 4908 */         return new BigInteger(stringVal);
/*      */       } catch (NumberFormatException nfe) {
/* 4910 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigInteger", new Object[] { Integer.valueOf(columnIndex), stringVal }), "S1009", getExceptionInterceptor());
/*      */       }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 2: 
/*      */     case 3: 
/* 4918 */       stringVal = getString(columnIndex);
/*      */       
/*      */ 
/*      */ 
/* 4922 */       if (stringVal != null) {
/* 4923 */         if (stringVal.length() == 0) {
/* 4924 */           BigDecimal val = new BigDecimal(0);
/*      */           
/* 4926 */           return val;
/*      */         }
/*      */         BigDecimal val;
/*      */         try {
/* 4930 */           val = new BigDecimal(stringVal);
/*      */         } catch (NumberFormatException ex) {
/* 4932 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4939 */         return val;
/*      */       }
/*      */       
/* 4942 */       return null;
/*      */     
/*      */     case 7: 
/* 4945 */       return new Float(getFloat(columnIndex));
/*      */     
/*      */     case 6: 
/*      */     case 8: 
/* 4949 */       return new Double(getDouble(columnIndex));
/*      */     
/*      */     case 1: 
/*      */     case 12: 
/* 4953 */       if (!field.isOpaqueBinary()) {
/* 4954 */         return getString(columnIndex);
/*      */       }
/*      */       
/* 4957 */       return getBytes(columnIndex);
/*      */     case -1: 
/* 4959 */       if (!field.isOpaqueBinary()) {
/* 4960 */         return getStringForClob(columnIndex);
/*      */       }
/*      */       
/* 4963 */       return getBytes(columnIndex);
/*      */     
/*      */     case -4: 
/*      */     case -3: 
/*      */     case -2: 
/* 4968 */       if (field.getMysqlType() == 255)
/* 4969 */         return getBytes(columnIndex);
/* 4970 */       if ((field.isBinary()) || (field.isBlob())) {
/* 4971 */         byte[] data = getBytes(columnIndex);
/*      */         
/* 4973 */         if (this.connection.getAutoDeserialize()) {
/* 4974 */           Object obj = data;
/*      */           
/* 4976 */           if ((data != null) && (data.length >= 2)) {
/* 4977 */             if ((data[0] == -84) && (data[1] == -19)) {
/*      */               try
/*      */               {
/* 4980 */                 ByteArrayInputStream bytesIn = new ByteArrayInputStream(data);
/*      */                 
/* 4982 */                 ObjectInputStream objIn = new ObjectInputStream(bytesIn);
/*      */                 
/* 4984 */                 obj = objIn.readObject();
/* 4985 */                 objIn.close();
/* 4986 */                 bytesIn.close();
/*      */               } catch (ClassNotFoundException cnfe) {
/* 4988 */                 throw SQLError.createSQLException(Messages.getString("ResultSet.Class_not_found___91") + cnfe.toString() + Messages.getString("ResultSet._while_reading_serialized_object_92"), getExceptionInterceptor());
/*      */ 
/*      */ 
/*      */               }
/*      */               catch (IOException ex)
/*      */               {
/*      */ 
/* 4995 */                 obj = data;
/*      */               }
/*      */             } else {
/* 4998 */               return getString(columnIndex);
/*      */             }
/*      */           }
/*      */           
/* 5002 */           return obj;
/*      */         }
/*      */         
/* 5005 */         return data;
/*      */       }
/*      */       
/* 5008 */       return getBytes(columnIndex);
/*      */     
/*      */     case 91: 
/* 5011 */       if ((field.getMysqlType() == 13) && (!this.connection.getYearIsDateType()))
/*      */       {
/* 5013 */         return Short.valueOf(getShort(columnIndex));
/*      */       }
/*      */       
/* 5016 */       return getDate(columnIndex);
/*      */     
/*      */     case 92: 
/* 5019 */       return getTime(columnIndex);
/*      */     
/*      */     case 93: 
/* 5022 */       return getTimestamp(columnIndex);
/*      */     }
/*      */     
/* 5025 */     return getString(columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getObject(int i, Map map)
/*      */     throws SQLException
/*      */   {
/* 5045 */     return getObject(i);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getObject(String columnName)
/*      */     throws SQLException
/*      */   {
/* 5072 */     return getObject(findColumn(columnName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getObject(String colName, Map map)
/*      */     throws SQLException
/*      */   {
/* 5092 */     return getObject(findColumn(colName), map);
/*      */   }
/*      */   
/*      */   public Object getObjectStoredProc(int columnIndex, int desiredSqlType) throws SQLException
/*      */   {
/* 5097 */     checkRowPos();
/* 5098 */     checkColumnBounds(columnIndex);
/*      */     
/* 5100 */     Object value = this.thisRow.getColumnValue(columnIndex - 1);
/*      */     
/* 5102 */     if (value == null) {
/* 5103 */       this.wasNullFlag = true;
/*      */       
/* 5105 */       return null;
/*      */     }
/*      */     
/* 5108 */     this.wasNullFlag = false;
/*      */     
/*      */ 
/* 5111 */     Field field = this.fields[(columnIndex - 1)];
/*      */     
/* 5113 */     switch (desiredSqlType)
/*      */     {
/*      */ 
/*      */ 
/*      */     case -7: 
/*      */     case 16: 
/* 5119 */       return Boolean.valueOf(getBoolean(columnIndex));
/*      */     
/*      */     case -6: 
/* 5122 */       return Integer.valueOf(getInt(columnIndex));
/*      */     
/*      */     case 5: 
/* 5125 */       return Integer.valueOf(getInt(columnIndex));
/*      */     
/*      */ 
/*      */     case 4: 
/* 5129 */       if ((!field.isUnsigned()) || (field.getMysqlType() == 9))
/*      */       {
/* 5131 */         return Integer.valueOf(getInt(columnIndex));
/*      */       }
/*      */       
/* 5134 */       return Long.valueOf(getLong(columnIndex));
/*      */     
/*      */ 
/*      */     case -5: 
/* 5138 */       if (field.isUnsigned()) {
/* 5139 */         return getBigDecimal(columnIndex);
/*      */       }
/*      */       
/* 5142 */       return Long.valueOf(getLong(columnIndex));
/*      */     
/*      */ 
/*      */     case 2: 
/*      */     case 3: 
/* 5147 */       String stringVal = getString(columnIndex);
/*      */       
/*      */ 
/* 5150 */       if (stringVal != null) {
/* 5151 */         if (stringVal.length() == 0) {
/* 5152 */           BigDecimal val = new BigDecimal(0);
/*      */           
/* 5154 */           return val;
/*      */         }
/*      */         BigDecimal val;
/*      */         try {
/* 5158 */           val = new BigDecimal(stringVal);
/*      */         } catch (NumberFormatException ex) {
/* 5160 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5167 */         return val;
/*      */       }
/*      */       
/* 5170 */       return null;
/*      */     
/*      */     case 7: 
/* 5173 */       return new Float(getFloat(columnIndex));
/*      */     
/*      */ 
/*      */     case 6: 
/* 5177 */       if (!this.connection.getRunningCTS13()) {
/* 5178 */         return new Double(getFloat(columnIndex));
/*      */       }
/* 5180 */       return new Float(getFloat(columnIndex));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 8: 
/* 5187 */       return new Double(getDouble(columnIndex));
/*      */     
/*      */     case 1: 
/*      */     case 12: 
/* 5191 */       return getString(columnIndex);
/*      */     case -1: 
/* 5193 */       return getStringForClob(columnIndex);
/*      */     case -4: 
/*      */     case -3: 
/*      */     case -2: 
/* 5197 */       return getBytes(columnIndex);
/*      */     
/*      */     case 91: 
/* 5200 */       if ((field.getMysqlType() == 13) && (!this.connection.getYearIsDateType()))
/*      */       {
/* 5202 */         return Short.valueOf(getShort(columnIndex));
/*      */       }
/*      */       
/* 5205 */       return getDate(columnIndex);
/*      */     
/*      */     case 92: 
/* 5208 */       return getTime(columnIndex);
/*      */     
/*      */     case 93: 
/* 5211 */       return getTimestamp(columnIndex);
/*      */     }
/*      */     
/* 5214 */     return getString(columnIndex);
/*      */   }
/*      */   
/*      */   public Object getObjectStoredProc(int i, Map map, int desiredSqlType)
/*      */     throws SQLException
/*      */   {
/* 5220 */     return getObjectStoredProc(i, desiredSqlType);
/*      */   }
/*      */   
/*      */   public Object getObjectStoredProc(String columnName, int desiredSqlType) throws SQLException
/*      */   {
/* 5225 */     return getObjectStoredProc(findColumn(columnName), desiredSqlType);
/*      */   }
/*      */   
/*      */   public Object getObjectStoredProc(String colName, Map map, int desiredSqlType) throws SQLException
/*      */   {
/* 5230 */     return getObjectStoredProc(findColumn(colName), map, desiredSqlType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Ref getRef(int i)
/*      */     throws SQLException
/*      */   {
/* 5247 */     checkColumnBounds(i);
/* 5248 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Ref getRef(String colName)
/*      */     throws SQLException
/*      */   {
/* 5265 */     return getRef(findColumn(colName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getRow()
/*      */     throws SQLException
/*      */   {
/* 5282 */     checkClosed();
/*      */     
/* 5284 */     int currentRowNumber = this.rowData.getCurrentRowNumber();
/* 5285 */     int row = 0;
/*      */     
/*      */ 
/*      */ 
/* 5289 */     if (!this.rowData.isDynamic()) {
/* 5290 */       if ((currentRowNumber < 0) || (this.rowData.isAfterLast()) || (this.rowData.isEmpty()))
/*      */       {
/* 5292 */         row = 0;
/*      */       } else {
/* 5294 */         row = currentRowNumber + 1;
/*      */       }
/*      */     }
/*      */     else {
/* 5298 */       row = currentRowNumber + 1;
/*      */     }
/*      */     
/* 5301 */     return row;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized String getServerInfo()
/*      */   {
/* 5310 */     return this.serverInfo;
/*      */   }
/*      */   
/*      */   private long getNumericRepresentationOfSQLBitType(int columnIndex) throws SQLException
/*      */   {
/* 5315 */     Object value = this.thisRow.getColumnValue(columnIndex - 1);
/*      */     
/* 5317 */     if ((this.fields[(columnIndex - 1)].isSingleBit()) || (((byte[])value).length == 1))
/*      */     {
/* 5319 */       return ((byte[])(byte[])value)[0];
/*      */     }
/*      */     
/*      */ 
/* 5323 */     byte[] asBytes = (byte[])value;
/*      */     
/*      */ 
/* 5326 */     int shift = 0;
/*      */     
/* 5328 */     long[] steps = new long[asBytes.length];
/*      */     
/* 5330 */     for (int i = asBytes.length - 1; i >= 0; i--) {
/* 5331 */       steps[i] = ((asBytes[i] & 0xFF) << shift);
/* 5332 */       shift += 8;
/*      */     }
/*      */     
/* 5335 */     long valueAsLong = 0L;
/*      */     
/* 5337 */     for (int i = 0; i < asBytes.length; i++) {
/* 5338 */       valueAsLong |= steps[i];
/*      */     }
/*      */     
/* 5341 */     return valueAsLong;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getShort(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 5356 */     if (!this.isBinaryEncoded) {
/* 5357 */       checkRowPos();
/*      */       
/* 5359 */       if (this.useFastIntParsing)
/*      */       {
/* 5361 */         checkColumnBounds(columnIndex);
/*      */         
/* 5363 */         Object value = this.thisRow.getColumnValue(columnIndex - 1);
/*      */         
/* 5365 */         if (value == null) {
/* 5366 */           this.wasNullFlag = true;
/*      */         } else {
/* 5368 */           this.wasNullFlag = false;
/*      */         }
/*      */         
/* 5371 */         if (this.wasNullFlag) {
/* 5372 */           return 0;
/*      */         }
/*      */         
/* 5375 */         byte[] shortAsBytes = (byte[])value;
/*      */         
/* 5377 */         if (shortAsBytes.length == 0) {
/* 5378 */           return (short)convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 5381 */         boolean needsFullParse = false;
/*      */         
/* 5383 */         for (int i = 0; i < shortAsBytes.length; i++) {
/* 5384 */           if (((char)shortAsBytes[i] == 'e') || ((char)shortAsBytes[i] == 'E'))
/*      */           {
/* 5386 */             needsFullParse = true;
/*      */             
/* 5388 */             break;
/*      */           }
/*      */         }
/*      */         
/* 5392 */         if (!needsFullParse) {
/*      */           try {
/* 5394 */             return parseShortWithOverflowCheck(columnIndex, shortAsBytes, null);
/*      */           }
/*      */           catch (NumberFormatException nfe)
/*      */           {
/*      */             try {
/* 5399 */               return parseShortAsDouble(columnIndex, StringUtils.toString(shortAsBytes));
/*      */ 
/*      */             }
/*      */             catch (NumberFormatException newNfe)
/*      */             {
/*      */ 
/* 5405 */               if (this.fields[(columnIndex - 1)].getMysqlType() == 16) {
/* 5406 */                 long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex);
/*      */                 
/* 5408 */                 if ((this.jdbcCompliantTruncationForReads) && ((valueAsLong < -32768L) || (valueAsLong > 32767L)))
/*      */                 {
/*      */ 
/* 5411 */                   throwRangeException(String.valueOf(valueAsLong), columnIndex, 5);
/*      */                 }
/*      */                 
/*      */ 
/* 5415 */                 return (short)(int)valueAsLong;
/*      */               }
/*      */               
/* 5418 */               throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getShort()_-____96") + StringUtils.toString(shortAsBytes) + "'", "S1009", getExceptionInterceptor());
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5428 */       String val = null;
/*      */       try
/*      */       {
/* 5431 */         val = getString(columnIndex);
/*      */         
/* 5433 */         if (val != null)
/*      */         {
/* 5435 */           if (val.length() == 0) {
/* 5436 */             return (short)convertToZeroWithEmptyCheck();
/*      */           }
/*      */           
/* 5439 */           if ((val.indexOf("e") == -1) && (val.indexOf("E") == -1) && (val.indexOf(".") == -1))
/*      */           {
/* 5441 */             return parseShortWithOverflowCheck(columnIndex, null, val);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 5446 */           return parseShortAsDouble(columnIndex, val);
/*      */         }
/*      */         
/* 5449 */         return 0;
/*      */       } catch (NumberFormatException nfe) {
/*      */         try {
/* 5452 */           return parseShortAsDouble(columnIndex, val);
/*      */ 
/*      */         }
/*      */         catch (NumberFormatException newNfe)
/*      */         {
/* 5457 */           if (this.fields[(columnIndex - 1)].getMysqlType() == 16) {
/* 5458 */             long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex);
/*      */             
/* 5460 */             if ((this.jdbcCompliantTruncationForReads) && ((valueAsLong < -32768L) || (valueAsLong > 32767L)))
/*      */             {
/*      */ 
/* 5463 */               throwRangeException(String.valueOf(valueAsLong), columnIndex, 5);
/*      */             }
/*      */             
/*      */ 
/* 5467 */             return (short)(int)valueAsLong;
/*      */           }
/*      */           
/* 5470 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getShort()_-____96") + val + "'", "S1009", getExceptionInterceptor());
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5478 */     return getNativeShort(columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getShort(String columnName)
/*      */     throws SQLException
/*      */   {
/* 5493 */     return getShort(findColumn(columnName));
/*      */   }
/*      */   
/*      */   private final short getShortFromString(String val, int columnIndex) throws SQLException
/*      */   {
/*      */     try {
/* 5499 */       if (val != null)
/*      */       {
/* 5501 */         if (val.length() == 0) {
/* 5502 */           return (short)convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 5505 */         if ((val.indexOf("e") == -1) && (val.indexOf("E") == -1) && (val.indexOf(".") == -1))
/*      */         {
/* 5507 */           return parseShortWithOverflowCheck(columnIndex, null, val);
/*      */         }
/*      */         
/*      */ 
/* 5511 */         return parseShortAsDouble(columnIndex, val);
/*      */       }
/*      */       
/* 5514 */       return 0;
/*      */     } catch (NumberFormatException nfe) {
/*      */       try {
/* 5517 */         return parseShortAsDouble(columnIndex, val);
/*      */ 
/*      */       }
/*      */       catch (NumberFormatException newNfe)
/*      */       {
/* 5522 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getShort()_-____217") + val + Messages.getString("ResultSet.___in_column__218") + columnIndex, "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized Statement getStatement()
/*      */     throws SQLException
/*      */   {
/* 5541 */     if ((this.isClosed) && (!this.retainOwningStatement)) {
/* 5542 */       throw SQLError.createSQLException("Operation not allowed on closed ResultSet. Statements can be retained over result set closure by setting the connection property \"retainStatementAfterResultSetClose\" to \"true\".", "S1000", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5550 */     if (this.wrapperStatement != null) {
/* 5551 */       return this.wrapperStatement;
/*      */     }
/*      */     
/* 5554 */     return this.owningStatement;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getString(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 5569 */     String stringVal = getStringInternal(columnIndex, true);
/*      */     
/* 5571 */     if ((this.padCharsWithSpace) && (stringVal != null)) {
/* 5572 */       Field f = this.fields[(columnIndex - 1)];
/*      */       
/* 5574 */       if (f.getMysqlType() == 254) {
/* 5575 */         int fieldLength = (int)f.getLength() / f.getMaxBytesPerCharacter();
/*      */         
/*      */ 
/* 5578 */         int currentLength = stringVal.length();
/*      */         
/* 5580 */         if (currentLength < fieldLength) {
/* 5581 */           StringBuffer paddedBuf = new StringBuffer(fieldLength);
/* 5582 */           paddedBuf.append(stringVal);
/*      */           
/* 5584 */           int difference = fieldLength - currentLength;
/*      */           
/* 5586 */           paddedBuf.append(EMPTY_SPACE, 0, difference);
/*      */           
/* 5588 */           stringVal = paddedBuf.toString();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 5593 */     return stringVal;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getString(String columnName)
/*      */     throws SQLException
/*      */   {
/* 5609 */     return getString(findColumn(columnName));
/*      */   }
/*      */   
/*      */   private String getStringForClob(int columnIndex) throws SQLException {
/* 5613 */     String asString = null;
/*      */     
/* 5615 */     String forcedEncoding = this.connection.getClobCharacterEncoding();
/*      */     
/*      */ 
/* 5618 */     if (forcedEncoding == null) {
/* 5619 */       if (!this.isBinaryEncoded) {
/* 5620 */         asString = getString(columnIndex);
/*      */       } else {
/* 5622 */         asString = getNativeString(columnIndex);
/*      */       }
/*      */     } else {
/*      */       try {
/* 5626 */         byte[] asBytes = null;
/*      */         
/* 5628 */         if (!this.isBinaryEncoded) {
/* 5629 */           asBytes = getBytes(columnIndex);
/*      */         } else {
/* 5631 */           asBytes = getNativeBytes(columnIndex, true);
/*      */         }
/*      */         
/* 5634 */         if (asBytes != null) {
/* 5635 */           asString = StringUtils.toString(asBytes, forcedEncoding);
/*      */         }
/*      */       } catch (UnsupportedEncodingException uee) {
/* 5638 */         throw SQLError.createSQLException("Unsupported character encoding " + forcedEncoding, "S1009", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 5643 */     return asString;
/*      */   }
/*      */   
/*      */   protected String getStringInternal(int columnIndex, boolean checkDateTypes) throws SQLException
/*      */   {
/* 5648 */     if (!this.isBinaryEncoded) {
/* 5649 */       checkRowPos();
/* 5650 */       checkColumnBounds(columnIndex);
/*      */       
/* 5652 */       if (this.fields == null) {
/* 5653 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Query_generated_no_fields_for_ResultSet_99"), "S1002", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5661 */       int internalColumnIndex = columnIndex - 1;
/*      */       
/* 5663 */       if (this.thisRow.isNull(internalColumnIndex)) {
/* 5664 */         this.wasNullFlag = true;
/*      */         
/* 5666 */         return null;
/*      */       }
/*      */       
/* 5669 */       this.wasNullFlag = false;
/*      */       
/*      */ 
/* 5672 */       Field metadata = this.fields[internalColumnIndex];
/*      */       
/* 5674 */       String stringVal = null;
/*      */       
/* 5676 */       if (metadata.getMysqlType() == 16) {
/* 5677 */         if (metadata.isSingleBit()) {
/* 5678 */           byte[] value = this.thisRow.getColumnValue(internalColumnIndex);
/*      */           
/* 5680 */           if (value.length == 0) {
/* 5681 */             return String.valueOf(convertToZeroWithEmptyCheck());
/*      */           }
/*      */           
/* 5684 */           return String.valueOf(value[0]);
/*      */         }
/*      */         
/* 5687 */         return String.valueOf(getNumericRepresentationOfSQLBitType(columnIndex));
/*      */       }
/*      */       
/* 5690 */       String encoding = metadata.getCharacterSet();
/*      */       
/* 5692 */       stringVal = this.thisRow.getString(internalColumnIndex, encoding, this.connection);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5699 */       if (metadata.getMysqlType() == 13) {
/* 5700 */         if (!this.connection.getYearIsDateType()) {
/* 5701 */           return stringVal;
/*      */         }
/*      */         
/* 5704 */         Date dt = getDateFromString(stringVal, columnIndex, null);
/*      */         
/* 5706 */         if (dt == null) {
/* 5707 */           this.wasNullFlag = true;
/*      */           
/* 5709 */           return null;
/*      */         }
/*      */         
/* 5712 */         this.wasNullFlag = false;
/*      */         
/* 5714 */         return dt.toString();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 5719 */       if ((checkDateTypes) && (!this.connection.getNoDatetimeStringSync())) {
/* 5720 */         switch (metadata.getSQLType()) {
/*      */         case 92: 
/* 5722 */           Time tm = getTimeFromString(stringVal, null, columnIndex, getDefaultTimeZone(), false);
/*      */           
/*      */ 
/* 5725 */           if (tm == null) {
/* 5726 */             this.wasNullFlag = true;
/*      */             
/* 5728 */             return null;
/*      */           }
/*      */           
/* 5731 */           this.wasNullFlag = false;
/*      */           
/* 5733 */           return tm.toString();
/*      */         
/*      */         case 91: 
/* 5736 */           Date dt = getDateFromString(stringVal, columnIndex, null);
/*      */           
/* 5738 */           if (dt == null) {
/* 5739 */             this.wasNullFlag = true;
/*      */             
/* 5741 */             return null;
/*      */           }
/*      */           
/* 5744 */           this.wasNullFlag = false;
/*      */           
/* 5746 */           return dt.toString();
/*      */         case 93: 
/* 5748 */           Timestamp ts = getTimestampFromString(columnIndex, null, stringVal, getDefaultTimeZone(), false);
/*      */           
/*      */ 
/* 5751 */           if (ts == null) {
/* 5752 */             this.wasNullFlag = true;
/*      */             
/* 5754 */             return null;
/*      */           }
/*      */           
/* 5757 */           this.wasNullFlag = false;
/*      */           
/* 5759 */           return ts.toString();
/*      */         }
/*      */         
/*      */       }
/*      */       
/*      */ 
/* 5765 */       return stringVal;
/*      */     }
/*      */     
/* 5768 */     return getNativeString(columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time getTime(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 5783 */     return getTimeInternal(columnIndex, null, getDefaultTimeZone(), false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time getTime(int columnIndex, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 5803 */     return getTimeInternal(columnIndex, cal, cal.getTimeZone(), true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time getTime(String columnName)
/*      */     throws SQLException
/*      */   {
/* 5818 */     return getTime(findColumn(columnName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time getTime(String columnName, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 5838 */     return getTime(findColumn(columnName), cal);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Time getTimeInternal(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward)
/*      */     throws SQLException
/*      */   {
/* 6024 */     checkRowPos();
/*      */     
/* 6026 */     if (this.isBinaryEncoded) {
/* 6027 */       return getNativeTime(columnIndex, targetCalendar, tz, rollForward);
/*      */     }
/*      */     
/* 6030 */     if (!this.useFastDateParsing) {
/* 6031 */       String timeAsString = getStringInternal(columnIndex, false);
/*      */       
/* 6033 */       return getTimeFromString(timeAsString, targetCalendar, columnIndex, tz, rollForward);
/*      */     }
/*      */     
/*      */ 
/* 6037 */     checkColumnBounds(columnIndex);
/*      */     
/* 6039 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 6041 */     if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 6042 */       this.wasNullFlag = true;
/*      */       
/* 6044 */       return null;
/*      */     }
/*      */     
/* 6047 */     this.wasNullFlag = false;
/*      */     
/* 6049 */     return this.thisRow.getTimeFast(columnIndexMinusOne, targetCalendar, tz, rollForward, this.connection, this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 6066 */     return getTimestampInternal(columnIndex, null, getDefaultTimeZone(), false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(int columnIndex, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 6088 */     return getTimestampInternal(columnIndex, cal, cal.getTimeZone(), true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(String columnName)
/*      */     throws SQLException
/*      */   {
/* 6104 */     return getTimestamp(findColumn(columnName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Timestamp getTimestamp(String columnName, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 6125 */     return getTimestamp(findColumn(columnName), cal);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Timestamp getTimestampInternal(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward)
/*      */     throws SQLException
/*      */   {
/* 6449 */     if (this.isBinaryEncoded) {
/* 6450 */       return getNativeTimestamp(columnIndex, targetCalendar, tz, rollForward);
/*      */     }
/*      */     
/* 6453 */     Timestamp tsVal = null;
/*      */     
/* 6455 */     if (!this.useFastDateParsing) {
/* 6456 */       String timestampValue = getStringInternal(columnIndex, false);
/*      */       
/* 6458 */       tsVal = getTimestampFromString(columnIndex, targetCalendar, timestampValue, tz, rollForward);
/*      */     }
/*      */     else
/*      */     {
/* 6462 */       checkClosed();
/* 6463 */       checkRowPos();
/* 6464 */       checkColumnBounds(columnIndex);
/*      */       
/* 6466 */       tsVal = this.thisRow.getTimestampFast(columnIndex - 1, targetCalendar, tz, rollForward, this.connection, this);
/*      */     }
/*      */     
/*      */ 
/* 6470 */     if (tsVal == null) {
/* 6471 */       this.wasNullFlag = true;
/*      */     } else {
/* 6473 */       this.wasNullFlag = false;
/*      */     }
/*      */     
/* 6476 */     return tsVal;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getType()
/*      */     throws SQLException
/*      */   {
/* 6490 */     return this.resultSetType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public InputStream getUnicodeStream(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 6512 */     if (!this.isBinaryEncoded) {
/* 6513 */       checkRowPos();
/*      */       
/* 6515 */       return getBinaryStream(columnIndex);
/*      */     }
/*      */     
/* 6518 */     return getNativeBinaryStream(columnIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public InputStream getUnicodeStream(String columnName)
/*      */     throws SQLException
/*      */   {
/* 6535 */     return getUnicodeStream(findColumn(columnName));
/*      */   }
/*      */   
/*      */   public long getUpdateCount() {
/* 6539 */     return this.updateCount;
/*      */   }
/*      */   
/*      */   public long getUpdateID() {
/* 6543 */     return this.updateId;
/*      */   }
/*      */   
/*      */ 
/*      */   public URL getURL(int colIndex)
/*      */     throws SQLException
/*      */   {
/* 6550 */     String val = getString(colIndex);
/*      */     
/* 6552 */     if (val == null) {
/* 6553 */       return null;
/*      */     }
/*      */     try
/*      */     {
/* 6557 */       return new URL(val);
/*      */     } catch (MalformedURLException mfe) {
/* 6559 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Malformed_URL____104") + val + "'", "S1009", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public URL getURL(String colName)
/*      */     throws SQLException
/*      */   {
/* 6569 */     String val = getString(colName);
/*      */     
/* 6571 */     if (val == null) {
/* 6572 */       return null;
/*      */     }
/*      */     try
/*      */     {
/* 6576 */       return new URL(val);
/*      */     } catch (MalformedURLException mfe) {
/* 6578 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Malformed_URL____107") + val + "'", "S1009", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized SQLWarning getWarnings()
/*      */     throws SQLException
/*      */   {
/* 6605 */     return this.warningChain;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void insertRow()
/*      */     throws SQLException
/*      */   {
/* 6620 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isAfterLast()
/*      */     throws SQLException
/*      */   {
/* 6637 */     checkClosed();
/*      */     
/* 6639 */     boolean b = this.rowData.isAfterLast();
/*      */     
/* 6641 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean isBeforeFirst()
/*      */     throws SQLException
/*      */   {
/* 6658 */     checkClosed();
/*      */     
/* 6660 */     return this.rowData.isBeforeFirst();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean isFirst()
/*      */     throws SQLException
/*      */   {
/* 6676 */     checkClosed();
/*      */     
/* 6678 */     return this.rowData.isFirst();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isLast()
/*      */     throws SQLException
/*      */   {
/* 6697 */     checkClosed();
/*      */     
/* 6699 */     return this.rowData.isLast();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private synchronized void issueConversionViaParsingWarning(String methodName, int columnIndex, Object value, Field fieldInfo, int[] typesWithNoParseConversion)
/*      */     throws SQLException
/*      */   {
/* 6711 */     StringBuffer originalQueryBuf = new StringBuffer();
/*      */     
/* 6713 */     if ((this.owningStatement != null) && ((this.owningStatement instanceof PreparedStatement)))
/*      */     {
/* 6715 */       originalQueryBuf.append(Messages.getString("ResultSet.CostlyConversionCreatedFromQuery"));
/* 6716 */       originalQueryBuf.append(((PreparedStatement)this.owningStatement).originalSql);
/*      */       
/* 6718 */       originalQueryBuf.append("\n\n");
/*      */     } else {
/* 6720 */       originalQueryBuf.append(".");
/*      */     }
/*      */     
/* 6723 */     StringBuffer convertibleTypesBuf = new StringBuffer();
/*      */     
/* 6725 */     for (int i = 0; i < typesWithNoParseConversion.length; i++) {
/* 6726 */       convertibleTypesBuf.append(MysqlDefs.typeToName(typesWithNoParseConversion[i]));
/* 6727 */       convertibleTypesBuf.append("\n");
/*      */     }
/*      */     
/* 6730 */     String message = Messages.getString("ResultSet.CostlyConversion", new Object[] { methodName, Integer.valueOf(columnIndex + 1), fieldInfo.getOriginalName(), fieldInfo.getOriginalTableName(), originalQueryBuf.toString(), value != null ? value.getClass().getName() : ResultSetMetaData.getClassNameForJavaType(fieldInfo.getSQLType(), fieldInfo.isUnsigned(), fieldInfo.getMysqlType(), (fieldInfo.isBinary()) || (fieldInfo.isBlob()) ? 1 : false, fieldInfo.isOpaqueBinary()), MysqlDefs.typeToName(fieldInfo.getMysqlType()), convertibleTypesBuf.toString() });
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6745 */     this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", this.owningStatement == null ? "N/A" : this.owningStatement.currentCatalog, this.connectionId, this.owningStatement == null ? -1 : this.owningStatement.getId(), this.resultId, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, message));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean last()
/*      */     throws SQLException
/*      */   {
/* 6769 */     checkClosed();
/*      */     
/* 6771 */     boolean b = true;
/*      */     
/* 6773 */     if (this.rowData.size() == 0) {
/* 6774 */       b = false;
/*      */     }
/*      */     else {
/* 6777 */       if (this.onInsertRow) {
/* 6778 */         this.onInsertRow = false;
/*      */       }
/*      */       
/* 6781 */       if (this.doingUpdates) {
/* 6782 */         this.doingUpdates = false;
/*      */       }
/*      */       
/* 6785 */       if (this.thisRow != null) {
/* 6786 */         this.thisRow.closeOpenStreams();
/*      */       }
/*      */       
/* 6789 */       this.rowData.beforeLast();
/* 6790 */       this.thisRow = this.rowData.next();
/*      */     }
/*      */     
/* 6793 */     setRowPositionValidity();
/*      */     
/* 6795 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void moveToCurrentRow()
/*      */     throws SQLException
/*      */   {
/* 6817 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void moveToInsertRow()
/*      */     throws SQLException
/*      */   {
/* 6838 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean next()
/*      */     throws SQLException
/*      */   {
/* 6857 */     checkClosed();
/*      */     
/* 6859 */     if (this.onInsertRow) {
/* 6860 */       this.onInsertRow = false;
/*      */     }
/*      */     
/* 6863 */     if (this.doingUpdates) {
/* 6864 */       this.doingUpdates = false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 6869 */     if (!reallyResult()) {
/* 6870 */       throw SQLError.createSQLException(Messages.getString("ResultSet.ResultSet_is_from_UPDATE._No_Data_115"), "S1000", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 6876 */     if (this.thisRow != null)
/* 6877 */       this.thisRow.closeOpenStreams();
/*      */     boolean b;
/*      */     boolean b;
/* 6880 */     if (this.rowData.size() == 0) {
/* 6881 */       b = false;
/*      */     } else {
/* 6883 */       this.thisRow = this.rowData.next();
/*      */       boolean b;
/* 6885 */       if (this.thisRow == null) {
/* 6886 */         b = false;
/*      */       } else {
/* 6888 */         clearWarnings();
/*      */         
/* 6890 */         b = true;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 6895 */     setRowPositionValidity();
/*      */     
/* 6897 */     return b;
/*      */   }
/*      */   
/*      */   private int parseIntAsDouble(int columnIndex, String val) throws NumberFormatException, SQLException
/*      */   {
/* 6902 */     if (val == null) {
/* 6903 */       return 0;
/*      */     }
/*      */     
/* 6906 */     double valueAsDouble = Double.parseDouble(val);
/*      */     
/* 6908 */     if ((this.jdbcCompliantTruncationForReads) && (
/* 6909 */       (valueAsDouble < -2.147483648E9D) || (valueAsDouble > 2.147483647E9D)))
/*      */     {
/* 6911 */       throwRangeException(String.valueOf(valueAsDouble), columnIndex, 4);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 6916 */     return (int)valueAsDouble;
/*      */   }
/*      */   
/*      */   private int getIntWithOverflowCheck(int columnIndex) throws SQLException {
/* 6920 */     int intValue = this.thisRow.getInt(columnIndex);
/*      */     
/* 6922 */     checkForIntegerTruncation(columnIndex, null, intValue);
/*      */     
/*      */ 
/* 6925 */     return intValue;
/*      */   }
/*      */   
/*      */   private void checkForIntegerTruncation(int columnIndex, byte[] valueAsBytes, int intValue)
/*      */     throws SQLException
/*      */   {
/* 6931 */     if ((this.jdbcCompliantTruncationForReads) && (
/* 6932 */       (intValue == Integer.MIN_VALUE) || (intValue == Integer.MAX_VALUE))) {
/* 6933 */       String valueAsString = null;
/*      */       
/* 6935 */       if (valueAsBytes == null) {
/* 6936 */         valueAsString = this.thisRow.getString(columnIndex, this.fields[columnIndex].getCharacterSet(), this.connection);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 6941 */       long valueAsLong = Long.parseLong(valueAsString == null ? StringUtils.toString(valueAsBytes) : valueAsString);
/*      */       
/*      */ 
/*      */ 
/* 6945 */       if ((valueAsLong < -2147483648L) || (valueAsLong > 2147483647L))
/*      */       {
/* 6947 */         throwRangeException(valueAsString == null ? StringUtils.toString(valueAsBytes) : valueAsString, columnIndex + 1, 4);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private long parseLongAsDouble(int columnIndexZeroBased, String val)
/*      */     throws NumberFormatException, SQLException
/*      */   {
/* 6957 */     if (val == null) {
/* 6958 */       return 0L;
/*      */     }
/*      */     
/* 6961 */     double valueAsDouble = Double.parseDouble(val);
/*      */     
/* 6963 */     if ((this.jdbcCompliantTruncationForReads) && (
/* 6964 */       (valueAsDouble < -9.223372036854776E18D) || (valueAsDouble > 9.223372036854776E18D)))
/*      */     {
/* 6966 */       throwRangeException(val, columnIndexZeroBased + 1, -5);
/*      */     }
/*      */     
/*      */ 
/* 6970 */     return valueAsDouble;
/*      */   }
/*      */   
/*      */   private long getLongWithOverflowCheck(int columnIndexZeroBased, boolean doOverflowCheck) throws SQLException {
/* 6974 */     long longValue = this.thisRow.getLong(columnIndexZeroBased);
/*      */     
/* 6976 */     if (doOverflowCheck) {
/* 6977 */       checkForLongTruncation(columnIndexZeroBased, null, longValue);
/*      */     }
/*      */     
/* 6980 */     return longValue;
/*      */   }
/*      */   
/*      */ 
/*      */   private long parseLongWithOverflowCheck(int columnIndexZeroBased, byte[] valueAsBytes, String valueAsString, boolean doCheck)
/*      */     throws NumberFormatException, SQLException
/*      */   {
/* 6987 */     long longValue = 0L;
/*      */     
/* 6989 */     if ((valueAsBytes == null) && (valueAsString == null)) {
/* 6990 */       return 0L;
/*      */     }
/*      */     
/* 6993 */     if (valueAsBytes != null) {
/* 6994 */       longValue = StringUtils.getLong(valueAsBytes);
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 7004 */       valueAsString = valueAsString.trim();
/*      */       
/* 7006 */       longValue = Long.parseLong(valueAsString);
/*      */     }
/*      */     
/* 7009 */     if ((doCheck) && (this.jdbcCompliantTruncationForReads)) {
/* 7010 */       checkForLongTruncation(columnIndexZeroBased, valueAsBytes, longValue);
/*      */     }
/*      */     
/* 7013 */     return longValue;
/*      */   }
/*      */   
/*      */   private void checkForLongTruncation(int columnIndexZeroBased, byte[] valueAsBytes, long longValue) throws SQLException {
/* 7017 */     if ((longValue == Long.MIN_VALUE) || (longValue == Long.MAX_VALUE))
/*      */     {
/* 7019 */       String valueAsString = null;
/*      */       
/* 7021 */       if (valueAsBytes == null) {
/* 7022 */         valueAsString = this.thisRow.getString(columnIndexZeroBased, this.fields[columnIndexZeroBased].getCharacterSet(), this.connection);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 7027 */       double valueAsDouble = Double.parseDouble(valueAsString == null ? StringUtils.toString(valueAsBytes) : valueAsString);
/*      */       
/*      */ 
/*      */ 
/* 7031 */       if ((valueAsDouble < -9.223372036854776E18D) || (valueAsDouble > 9.223372036854776E18D))
/*      */       {
/* 7033 */         throwRangeException(valueAsString == null ? StringUtils.toString(valueAsBytes) : valueAsString, columnIndexZeroBased + 1, -5);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private short parseShortAsDouble(int columnIndex, String val)
/*      */     throws NumberFormatException, SQLException
/*      */   {
/* 7042 */     if (val == null) {
/* 7043 */       return 0;
/*      */     }
/*      */     
/* 7046 */     double valueAsDouble = Double.parseDouble(val);
/*      */     
/* 7048 */     if ((this.jdbcCompliantTruncationForReads) && (
/* 7049 */       (valueAsDouble < -32768.0D) || (valueAsDouble > 32767.0D)))
/*      */     {
/* 7051 */       throwRangeException(String.valueOf(valueAsDouble), columnIndex, 5);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 7056 */     return (short)(int)valueAsDouble;
/*      */   }
/*      */   
/*      */ 
/*      */   private short parseShortWithOverflowCheck(int columnIndex, byte[] valueAsBytes, String valueAsString)
/*      */     throws NumberFormatException, SQLException
/*      */   {
/* 7063 */     short shortValue = 0;
/*      */     
/* 7065 */     if ((valueAsBytes == null) && (valueAsString == null)) {
/* 7066 */       return 0;
/*      */     }
/*      */     
/* 7069 */     if (valueAsBytes != null) {
/* 7070 */       shortValue = StringUtils.getShort(valueAsBytes);
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 7080 */       valueAsString = valueAsString.trim();
/*      */       
/* 7082 */       shortValue = Short.parseShort(valueAsString);
/*      */     }
/*      */     
/* 7085 */     if ((this.jdbcCompliantTruncationForReads) && (
/* 7086 */       (shortValue == Short.MIN_VALUE) || (shortValue == Short.MAX_VALUE))) {
/* 7087 */       long valueAsLong = Long.parseLong(valueAsString == null ? StringUtils.toString(valueAsBytes) : valueAsString);
/*      */       
/*      */ 
/*      */ 
/* 7091 */       if ((valueAsLong < -32768L) || (valueAsLong > 32767L))
/*      */       {
/* 7093 */         throwRangeException(valueAsString == null ? StringUtils.toString(valueAsBytes) : valueAsString, columnIndex, 5);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 7100 */     return shortValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean prev()
/*      */     throws SQLException
/*      */   {
/* 7124 */     checkClosed();
/*      */     
/* 7126 */     int rowIndex = this.rowData.getCurrentRowNumber();
/*      */     
/* 7128 */     if (this.thisRow != null) {
/* 7129 */       this.thisRow.closeOpenStreams();
/*      */     }
/*      */     
/* 7132 */     boolean b = true;
/*      */     
/* 7134 */     if (rowIndex - 1 >= 0) {
/* 7135 */       rowIndex--;
/* 7136 */       this.rowData.setCurrentRow(rowIndex);
/* 7137 */       this.thisRow = this.rowData.getAt(rowIndex);
/*      */       
/* 7139 */       b = true;
/* 7140 */     } else if (rowIndex - 1 == -1) {
/* 7141 */       rowIndex--;
/* 7142 */       this.rowData.setCurrentRow(rowIndex);
/* 7143 */       this.thisRow = null;
/*      */       
/* 7145 */       b = false;
/*      */     } else {
/* 7147 */       b = false;
/*      */     }
/*      */     
/* 7150 */     setRowPositionValidity();
/*      */     
/* 7152 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean previous()
/*      */     throws SQLException
/*      */   {
/* 7174 */     if (this.onInsertRow) {
/* 7175 */       this.onInsertRow = false;
/*      */     }
/*      */     
/* 7178 */     if (this.doingUpdates) {
/* 7179 */       this.doingUpdates = false;
/*      */     }
/*      */     
/* 7182 */     return prev();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void realClose(boolean calledExplicitly)
/*      */     throws SQLException
/*      */   {
/* 7195 */     if (this.isClosed) {
/* 7196 */       return;
/*      */     }
/*      */     try
/*      */     {
/* 7200 */       if (this.useUsageAdvisor)
/*      */       {
/*      */ 
/*      */ 
/* 7204 */         if (!calledExplicitly) {
/* 7205 */           this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", this.owningStatement == null ? "N/A" : this.owningStatement.currentCatalog, this.connectionId, this.owningStatement == null ? -1 : this.owningStatement.getId(), this.resultId, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, Messages.getString("ResultSet.ResultSet_implicitly_closed_by_driver")));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7224 */         if ((this.rowData instanceof RowDataStatic))
/*      */         {
/*      */ 
/*      */ 
/* 7228 */           if (this.rowData.size() > this.connection.getResultSetSizeThreshold())
/*      */           {
/* 7230 */             this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", this.owningStatement == null ? Messages.getString("ResultSet.N/A_159") : this.owningStatement.currentCatalog, this.connectionId, this.owningStatement == null ? -1 : this.owningStatement.getId(), this.resultId, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, Messages.getString("ResultSet.Too_Large_Result_Set", new Object[] { Integer.valueOf(this.rowData.size()), Integer.valueOf(this.connection.getResultSetSizeThreshold()) })));
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7258 */           if ((!isLast()) && (!isAfterLast()) && (this.rowData.size() != 0))
/*      */           {
/* 7260 */             this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", this.owningStatement == null ? Messages.getString("ResultSet.N/A_159") : this.owningStatement.currentCatalog, this.connectionId, this.owningStatement == null ? -1 : this.owningStatement.getId(), this.resultId, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, Messages.getString("ResultSet.Possible_incomplete_traversal_of_result_set", new Object[] { Integer.valueOf(getRow()), Integer.valueOf(this.rowData.size()) })));
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7293 */         if ((this.columnUsed.length > 0) && (!this.rowData.wasEmpty())) {
/* 7294 */           StringBuffer buf = new StringBuffer(Messages.getString("ResultSet.The_following_columns_were_never_referenced"));
/*      */           
/*      */ 
/*      */ 
/* 7298 */           boolean issueWarn = false;
/*      */           
/* 7300 */           for (int i = 0; i < this.columnUsed.length; i++) {
/* 7301 */             if (this.columnUsed[i] == 0) {
/* 7302 */               if (!issueWarn) {
/* 7303 */                 issueWarn = true;
/*      */               } else {
/* 7305 */                 buf.append(", ");
/*      */               }
/*      */               
/* 7308 */               buf.append(this.fields[i].getFullName());
/*      */             }
/*      */           }
/*      */           
/* 7312 */           if (issueWarn) {
/* 7313 */             this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", this.owningStatement == null ? "N/A" : this.owningStatement.currentCatalog, this.connectionId, this.owningStatement == null ? -1 : this.owningStatement.getId(), 0, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, buf.toString()));
/*      */ 
/*      */           }
/*      */           
/*      */ 
/*      */         }
/*      */         
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*      */ 
/* 7327 */       if ((this.owningStatement != null) && (calledExplicitly)) {
/* 7328 */         this.owningStatement.removeOpenResultSet(this);
/*      */       }
/*      */       
/* 7331 */       SQLException exceptionDuringClose = null;
/*      */       
/* 7333 */       if (this.rowData != null) {
/*      */         try {
/* 7335 */           this.rowData.close();
/*      */         } catch (SQLException sqlEx) {
/* 7337 */           exceptionDuringClose = sqlEx;
/*      */         }
/*      */       }
/*      */       
/* 7341 */       if (this.statementUsedForFetchingRows != null) {
/*      */         try {
/* 7343 */           this.statementUsedForFetchingRows.realClose(true, false);
/*      */         } catch (SQLException sqlEx) {
/* 7345 */           if (exceptionDuringClose != null) {
/* 7346 */             exceptionDuringClose.setNextException(sqlEx);
/*      */           } else {
/* 7348 */             exceptionDuringClose = sqlEx;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 7353 */       this.rowData = null;
/* 7354 */       this.defaultTimeZone = null;
/* 7355 */       this.fields = null;
/* 7356 */       this.columnLabelToIndex = null;
/* 7357 */       this.fullColumnNameToIndex = null;
/* 7358 */       this.columnToIndexCache = null;
/* 7359 */       this.eventSink = null;
/* 7360 */       this.warningChain = null;
/*      */       
/* 7362 */       if (!this.retainOwningStatement) {
/* 7363 */         this.owningStatement = null;
/*      */       }
/*      */       
/* 7366 */       this.catalog = null;
/* 7367 */       this.serverInfo = null;
/* 7368 */       this.thisRow = null;
/* 7369 */       this.fastDateCal = null;
/* 7370 */       this.connection = null;
/*      */       
/* 7372 */       this.isClosed = true;
/*      */       
/* 7374 */       if (exceptionDuringClose != null) {
/* 7375 */         throw exceptionDuringClose;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean reallyResult() {
/* 7381 */     if (this.rowData != null) {
/* 7382 */       return true;
/*      */     }
/*      */     
/* 7385 */     return this.reallyResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void refreshRow()
/*      */     throws SQLException
/*      */   {
/* 7409 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean relative(int rows)
/*      */     throws SQLException
/*      */   {
/* 7439 */     checkClosed();
/*      */     
/* 7441 */     if (this.rowData.size() == 0) {
/* 7442 */       setRowPositionValidity();
/*      */       
/* 7444 */       return false;
/*      */     }
/*      */     
/* 7447 */     if (this.thisRow != null) {
/* 7448 */       this.thisRow.closeOpenStreams();
/*      */     }
/*      */     
/* 7451 */     this.rowData.moveRowRelative(rows);
/* 7452 */     this.thisRow = this.rowData.getAt(this.rowData.getCurrentRowNumber());
/*      */     
/* 7454 */     setRowPositionValidity();
/*      */     
/* 7456 */     return (!this.rowData.isAfterLast()) && (!this.rowData.isBeforeFirst());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean rowDeleted()
/*      */     throws SQLException
/*      */   {
/* 7475 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean rowInserted()
/*      */     throws SQLException
/*      */   {
/* 7493 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean rowUpdated()
/*      */     throws SQLException
/*      */   {
/* 7511 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setBinaryEncoded()
/*      */   {
/* 7519 */     this.isBinaryEncoded = true;
/*      */   }
/*      */   
/*      */   private synchronized void setDefaultTimeZone(TimeZone defaultTimeZone) {
/* 7523 */     this.defaultTimeZone = defaultTimeZone;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setFetchDirection(int direction)
/*      */     throws SQLException
/*      */   {
/* 7542 */     if ((direction != 1000) && (direction != 1001) && (direction != 1002))
/*      */     {
/* 7544 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Illegal_value_for_fetch_direction_64"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 7550 */     this.fetchDirection = direction;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setFetchSize(int rows)
/*      */     throws SQLException
/*      */   {
/* 7570 */     if (rows < 0) {
/* 7571 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Value_must_be_between_0_and_getMaxRows()_66"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 7577 */     this.fetchSize = rows;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setFirstCharOfQuery(char c)
/*      */   {
/* 7588 */     this.firstCharOfQuery = c;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void setNextResultSet(ResultSetInternalMethods nextResultSet)
/*      */   {
/* 7599 */     this.nextResultSet = nextResultSet;
/*      */   }
/*      */   
/*      */   public synchronized void setOwningStatement(StatementImpl owningStatement) {
/* 7603 */     this.owningStatement = owningStatement;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void setResultSetConcurrency(int concurrencyFlag)
/*      */   {
/* 7613 */     this.resultSetConcurrency = concurrencyFlag;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void setResultSetType(int typeFlag)
/*      */   {
/* 7624 */     this.resultSetType = typeFlag;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void setServerInfo(String info)
/*      */   {
/* 7634 */     this.serverInfo = info;
/*      */   }
/*      */   
/*      */   public synchronized void setStatementUsedForFetchingRows(PreparedStatement stmt) {
/* 7638 */     this.statementUsedForFetchingRows = stmt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setWrapperStatement(Statement wrapperStatement)
/*      */   {
/* 7646 */     this.wrapperStatement = wrapperStatement;
/*      */   }
/*      */   
/*      */   private void throwRangeException(String valueAsString, int columnIndex, int jdbcType) throws SQLException
/*      */   {
/* 7651 */     String datatype = null;
/*      */     
/* 7653 */     switch (jdbcType) {
/*      */     case -6: 
/* 7655 */       datatype = "TINYINT";
/* 7656 */       break;
/*      */     case 5: 
/* 7658 */       datatype = "SMALLINT";
/* 7659 */       break;
/*      */     case 4: 
/* 7661 */       datatype = "INTEGER";
/* 7662 */       break;
/*      */     case -5: 
/* 7664 */       datatype = "BIGINT";
/* 7665 */       break;
/*      */     case 7: 
/* 7667 */       datatype = "REAL";
/* 7668 */       break;
/*      */     case 6: 
/* 7670 */       datatype = "FLOAT";
/* 7671 */       break;
/*      */     case 8: 
/* 7673 */       datatype = "DOUBLE";
/* 7674 */       break;
/*      */     case 3: 
/* 7676 */       datatype = "DECIMAL";
/* 7677 */       break;
/*      */     case -4: case -3: case -2: case -1: case 0: case 1: case 2: default: 
/* 7679 */       datatype = " (JDBC type '" + jdbcType + "')";
/*      */     }
/*      */     
/* 7682 */     throw SQLError.createSQLException("'" + valueAsString + "' in column '" + columnIndex + "' is outside valid range for the datatype " + datatype + ".", "22003", getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/* 7693 */     if (this.reallyResult) {
/* 7694 */       return super.toString();
/*      */     }
/*      */     
/* 7697 */     return "Result set representing update count of " + this.updateCount;
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateArray(int arg0, Array arg1)
/*      */     throws SQLException
/*      */   {
/* 7704 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateArray(String arg0, Array arg1)
/*      */     throws SQLException
/*      */   {
/* 7711 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateAsciiStream(int columnIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 7735 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateAsciiStream(String columnName, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 7757 */     updateAsciiStream(findColumn(columnName), x, length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBigDecimal(int columnIndex, BigDecimal x)
/*      */     throws SQLException
/*      */   {
/* 7778 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBigDecimal(String columnName, BigDecimal x)
/*      */     throws SQLException
/*      */   {
/* 7797 */     updateBigDecimal(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBinaryStream(int columnIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 7821 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBinaryStream(String columnName, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 7843 */     updateBinaryStream(findColumn(columnName), x, length);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateBlob(int arg0, java.sql.Blob arg1)
/*      */     throws SQLException
/*      */   {
/* 7850 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateBlob(String arg0, java.sql.Blob arg1)
/*      */     throws SQLException
/*      */   {
/* 7857 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBoolean(int columnIndex, boolean x)
/*      */     throws SQLException
/*      */   {
/* 7877 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBoolean(String columnName, boolean x)
/*      */     throws SQLException
/*      */   {
/* 7895 */     updateBoolean(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateByte(int columnIndex, byte x)
/*      */     throws SQLException
/*      */   {
/* 7915 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateByte(String columnName, byte x)
/*      */     throws SQLException
/*      */   {
/* 7933 */     updateByte(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBytes(int columnIndex, byte[] x)
/*      */     throws SQLException
/*      */   {
/* 7953 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateBytes(String columnName, byte[] x)
/*      */     throws SQLException
/*      */   {
/* 7971 */     updateBytes(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateCharacterStream(int columnIndex, Reader x, int length)
/*      */     throws SQLException
/*      */   {
/* 7995 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateCharacterStream(String columnName, Reader reader, int length)
/*      */     throws SQLException
/*      */   {
/* 8017 */     updateCharacterStream(findColumn(columnName), reader, length);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateClob(int arg0, java.sql.Clob arg1)
/*      */     throws SQLException
/*      */   {
/* 8024 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void updateClob(String columnName, java.sql.Clob clob)
/*      */     throws SQLException
/*      */   {
/* 8032 */     updateClob(findColumn(columnName), clob);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateDate(int columnIndex, Date x)
/*      */     throws SQLException
/*      */   {
/* 8053 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateDate(String columnName, Date x)
/*      */     throws SQLException
/*      */   {
/* 8072 */     updateDate(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateDouble(int columnIndex, double x)
/*      */     throws SQLException
/*      */   {
/* 8092 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateDouble(String columnName, double x)
/*      */     throws SQLException
/*      */   {
/* 8110 */     updateDouble(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateFloat(int columnIndex, float x)
/*      */     throws SQLException
/*      */   {
/* 8130 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateFloat(String columnName, float x)
/*      */     throws SQLException
/*      */   {
/* 8148 */     updateFloat(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateInt(int columnIndex, int x)
/*      */     throws SQLException
/*      */   {
/* 8168 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateInt(String columnName, int x)
/*      */     throws SQLException
/*      */   {
/* 8186 */     updateInt(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateLong(int columnIndex, long x)
/*      */     throws SQLException
/*      */   {
/* 8206 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateLong(String columnName, long x)
/*      */     throws SQLException
/*      */   {
/* 8224 */     updateLong(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateNull(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 8242 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateNull(String columnName)
/*      */     throws SQLException
/*      */   {
/* 8258 */     updateNull(findColumn(columnName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateObject(int columnIndex, Object x)
/*      */     throws SQLException
/*      */   {
/* 8278 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateObject(int columnIndex, Object x, int scale)
/*      */     throws SQLException
/*      */   {
/* 8303 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateObject(String columnName, Object x)
/*      */     throws SQLException
/*      */   {
/* 8321 */     updateObject(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateObject(String columnName, Object x, int scale)
/*      */     throws SQLException
/*      */   {
/* 8344 */     updateObject(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateRef(int arg0, Ref arg1)
/*      */     throws SQLException
/*      */   {
/* 8351 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateRef(String arg0, Ref arg1)
/*      */     throws SQLException
/*      */   {
/* 8358 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateRow()
/*      */     throws SQLException
/*      */   {
/* 8372 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateShort(int columnIndex, short x)
/*      */     throws SQLException
/*      */   {
/* 8392 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateShort(String columnName, short x)
/*      */     throws SQLException
/*      */   {
/* 8410 */     updateShort(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateString(int columnIndex, String x)
/*      */     throws SQLException
/*      */   {
/* 8430 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateString(String columnName, String x)
/*      */     throws SQLException
/*      */   {
/* 8448 */     updateString(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateTime(int columnIndex, Time x)
/*      */     throws SQLException
/*      */   {
/* 8469 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateTime(String columnName, Time x)
/*      */     throws SQLException
/*      */   {
/* 8488 */     updateTime(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateTimestamp(int columnIndex, Timestamp x)
/*      */     throws SQLException
/*      */   {
/* 8510 */     throw new NotUpdatable();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateTimestamp(String columnName, Timestamp x)
/*      */     throws SQLException
/*      */   {
/* 8529 */     updateTimestamp(findColumn(columnName), x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean wasNull()
/*      */     throws SQLException
/*      */   {
/* 8544 */     return this.wasNullFlag;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected Calendar getGmtCalendar()
/*      */   {
/* 8551 */     if (this.gmtCalendar == null) {
/* 8552 */       this.gmtCalendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
/*      */     }
/*      */     
/* 8555 */     return this.gmtCalendar;
/*      */   }
/*      */   
/*      */   protected ExceptionInterceptor getExceptionInterceptor() {
/* 8559 */     return this.exceptionInterceptor;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   private synchronized Time getTimeFromString(String timeAsString, Calendar targetCalendar, int columnIndex, TimeZone tz, boolean rollForward)
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: iconst_0
/*      */     //   1: istore 6
/*      */     //   3: iconst_0
/*      */     //   4: istore 7
/*      */     //   6: iconst_0
/*      */     //   7: istore 8
/*      */     //   9: aload_1
/*      */     //   10: ifnonnull +10 -> 20
/*      */     //   13: aload_0
/*      */     //   14: iconst_1
/*      */     //   15: putfield 49	com/mysql/jdbc/ResultSetImpl:wasNullFlag	Z
/*      */     //   18: aconst_null
/*      */     //   19: areturn
/*      */     //   20: aload_1
/*      */     //   21: invokevirtual 247	java/lang/String:trim	()Ljava/lang/String;
/*      */     //   24: astore_1
/*      */     //   25: aload_1
/*      */     //   26: ldc -103
/*      */     //   28: invokevirtual 242	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   31: ifne +33 -> 64
/*      */     //   34: aload_1
/*      */     //   35: ldc_w 293
/*      */     //   38: invokevirtual 242	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   41: ifne +23 -> 64
/*      */     //   44: aload_1
/*      */     //   45: ldc_w 294
/*      */     //   48: invokevirtual 242	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   51: ifne +13 -> 64
/*      */     //   54: aload_1
/*      */     //   55: ldc_w 295
/*      */     //   58: invokevirtual 242	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   61: ifeq +91 -> 152
/*      */     //   64: ldc_w 296
/*      */     //   67: aload_0
/*      */     //   68: getfield 59	com/mysql/jdbc/ResultSetImpl:connection	Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   71: invokeinterface 297 1 0
/*      */     //   76: invokevirtual 242	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   79: ifeq +10 -> 89
/*      */     //   82: aload_0
/*      */     //   83: iconst_1
/*      */     //   84: putfield 49	com/mysql/jdbc/ResultSetImpl:wasNullFlag	Z
/*      */     //   87: aconst_null
/*      */     //   88: areturn
/*      */     //   89: ldc_w 298
/*      */     //   92: aload_0
/*      */     //   93: getfield 59	com/mysql/jdbc/ResultSetImpl:connection	Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   96: invokeinterface 297 1 0
/*      */     //   101: invokevirtual 242	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   104: ifeq +39 -> 143
/*      */     //   107: new 180	java/lang/StringBuilder
/*      */     //   110: dup
/*      */     //   111: invokespecial 181	java/lang/StringBuilder:<init>	()V
/*      */     //   114: ldc_w 299
/*      */     //   117: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   120: aload_1
/*      */     //   121: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   124: ldc_w 555
/*      */     //   127: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   130: invokevirtual 185	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   133: ldc 115
/*      */     //   135: aload_0
/*      */     //   136: invokevirtual 116	com/mysql/jdbc/ResultSetImpl:getExceptionInterceptor	()Lcom/mysql/jdbc/ExceptionInterceptor;
/*      */     //   139: invokestatic 117	com/mysql/jdbc/SQLError:createSQLException	(Ljava/lang/String;Ljava/lang/String;Lcom/mysql/jdbc/ExceptionInterceptor;)Ljava/sql/SQLException;
/*      */     //   142: athrow
/*      */     //   143: aload_0
/*      */     //   144: aload_2
/*      */     //   145: iconst_0
/*      */     //   146: iconst_0
/*      */     //   147: iconst_0
/*      */     //   148: invokevirtual 556	com/mysql/jdbc/ResultSetImpl:fastTimeCreate	(Ljava/util/Calendar;III)Ljava/sql/Time;
/*      */     //   151: areturn
/*      */     //   152: aload_0
/*      */     //   153: iconst_0
/*      */     //   154: putfield 49	com/mysql/jdbc/ResultSetImpl:wasNullFlag	Z
/*      */     //   157: aload_0
/*      */     //   158: getfield 58	com/mysql/jdbc/ResultSetImpl:fields	[Lcom/mysql/jdbc/Field;
/*      */     //   161: iload_3
/*      */     //   162: iconst_1
/*      */     //   163: isub
/*      */     //   164: aaload
/*      */     //   165: astore 9
/*      */     //   167: aload 9
/*      */     //   169: invokevirtual 208	com/mysql/jdbc/Field:getMysqlType	()I
/*      */     //   172: bipush 7
/*      */     //   174: if_icmpne +344 -> 518
/*      */     //   177: aload_1
/*      */     //   178: invokevirtual 198	java/lang/String:length	()I
/*      */     //   181: istore 10
/*      */     //   183: iload 10
/*      */     //   185: tableswitch	default:+194->379, 10:+162->347, 11:+194->379, 12:+109->294, 13:+194->379, 14:+109->294, 15:+194->379, 16:+194->379, 17:+194->379, 18:+194->379, 19:+55->240
/*      */     //   240: aload_1
/*      */     //   241: iload 10
/*      */     //   243: bipush 8
/*      */     //   245: isub
/*      */     //   246: iload 10
/*      */     //   248: bipush 6
/*      */     //   250: isub
/*      */     //   251: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   254: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   257: istore 6
/*      */     //   259: aload_1
/*      */     //   260: iload 10
/*      */     //   262: iconst_5
/*      */     //   263: isub
/*      */     //   264: iload 10
/*      */     //   266: iconst_3
/*      */     //   267: isub
/*      */     //   268: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   271: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   274: istore 7
/*      */     //   276: aload_1
/*      */     //   277: iload 10
/*      */     //   279: iconst_2
/*      */     //   280: isub
/*      */     //   281: iload 10
/*      */     //   283: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   286: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   289: istore 8
/*      */     //   291: goto +144 -> 435
/*      */     //   294: aload_1
/*      */     //   295: iload 10
/*      */     //   297: bipush 6
/*      */     //   299: isub
/*      */     //   300: iload 10
/*      */     //   302: iconst_4
/*      */     //   303: isub
/*      */     //   304: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   307: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   310: istore 6
/*      */     //   312: aload_1
/*      */     //   313: iload 10
/*      */     //   315: iconst_4
/*      */     //   316: isub
/*      */     //   317: iload 10
/*      */     //   319: iconst_2
/*      */     //   320: isub
/*      */     //   321: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   324: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   327: istore 7
/*      */     //   329: aload_1
/*      */     //   330: iload 10
/*      */     //   332: iconst_2
/*      */     //   333: isub
/*      */     //   334: iload 10
/*      */     //   336: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   339: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   342: istore 8
/*      */     //   344: goto +91 -> 435
/*      */     //   347: aload_1
/*      */     //   348: bipush 6
/*      */     //   350: bipush 8
/*      */     //   352: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   355: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   358: istore 6
/*      */     //   360: aload_1
/*      */     //   361: bipush 8
/*      */     //   363: bipush 10
/*      */     //   365: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   368: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   371: istore 7
/*      */     //   373: iconst_0
/*      */     //   374: istore 8
/*      */     //   376: goto +59 -> 435
/*      */     //   379: new 180	java/lang/StringBuilder
/*      */     //   382: dup
/*      */     //   383: invokespecial 181	java/lang/StringBuilder:<init>	()V
/*      */     //   386: ldc_w 557
/*      */     //   389: invokestatic 114	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   392: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   395: iload_3
/*      */     //   396: invokevirtual 366	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*      */     //   399: ldc_w 558
/*      */     //   402: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   405: aload_0
/*      */     //   406: getfield 58	com/mysql/jdbc/ResultSetImpl:fields	[Lcom/mysql/jdbc/Field;
/*      */     //   409: iload_3
/*      */     //   410: iconst_1
/*      */     //   411: isub
/*      */     //   412: aaload
/*      */     //   413: invokevirtual 559	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*      */     //   416: ldc_w 560
/*      */     //   419: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   422: invokevirtual 185	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   425: ldc 115
/*      */     //   427: aload_0
/*      */     //   428: invokevirtual 116	com/mysql/jdbc/ResultSetImpl:getExceptionInterceptor	()Lcom/mysql/jdbc/ExceptionInterceptor;
/*      */     //   431: invokestatic 117	com/mysql/jdbc/SQLError:createSQLException	(Ljava/lang/String;Ljava/lang/String;Lcom/mysql/jdbc/ExceptionInterceptor;)Ljava/sql/SQLException;
/*      */     //   434: athrow
/*      */     //   435: new 561	java/sql/SQLWarning
/*      */     //   438: dup
/*      */     //   439: new 180	java/lang/StringBuilder
/*      */     //   442: dup
/*      */     //   443: invokespecial 181	java/lang/StringBuilder:<init>	()V
/*      */     //   446: ldc_w 562
/*      */     //   449: invokestatic 114	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   452: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   455: iload_3
/*      */     //   456: invokevirtual 366	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*      */     //   459: ldc_w 558
/*      */     //   462: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   465: aload_0
/*      */     //   466: getfield 58	com/mysql/jdbc/ResultSetImpl:fields	[Lcom/mysql/jdbc/Field;
/*      */     //   469: iload_3
/*      */     //   470: iconst_1
/*      */     //   471: isub
/*      */     //   472: aaload
/*      */     //   473: invokevirtual 559	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*      */     //   476: ldc_w 560
/*      */     //   479: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   482: invokevirtual 185	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   485: invokespecial 563	java/sql/SQLWarning:<init>	(Ljava/lang/String;)V
/*      */     //   488: astore 11
/*      */     //   490: aload_0
/*      */     //   491: getfield 48	com/mysql/jdbc/ResultSetImpl:warningChain	Ljava/sql/SQLWarning;
/*      */     //   494: ifnonnull +12 -> 506
/*      */     //   497: aload_0
/*      */     //   498: aload 11
/*      */     //   500: putfield 48	com/mysql/jdbc/ResultSetImpl:warningChain	Ljava/sql/SQLWarning;
/*      */     //   503: goto +12 -> 515
/*      */     //   506: aload_0
/*      */     //   507: getfield 48	com/mysql/jdbc/ResultSetImpl:warningChain	Ljava/sql/SQLWarning;
/*      */     //   510: aload 11
/*      */     //   512: invokevirtual 564	java/sql/SQLWarning:setNextWarning	(Ljava/sql/SQLWarning;)V
/*      */     //   515: goto +262 -> 777
/*      */     //   518: aload 9
/*      */     //   520: invokevirtual 208	com/mysql/jdbc/Field:getMysqlType	()I
/*      */     //   523: bipush 12
/*      */     //   525: if_icmpne +125 -> 650
/*      */     //   528: aload_1
/*      */     //   529: bipush 11
/*      */     //   531: bipush 13
/*      */     //   533: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   536: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   539: istore 6
/*      */     //   541: aload_1
/*      */     //   542: bipush 14
/*      */     //   544: bipush 16
/*      */     //   546: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   549: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   552: istore 7
/*      */     //   554: aload_1
/*      */     //   555: bipush 17
/*      */     //   557: bipush 19
/*      */     //   559: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   562: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   565: istore 8
/*      */     //   567: new 561	java/sql/SQLWarning
/*      */     //   570: dup
/*      */     //   571: new 180	java/lang/StringBuilder
/*      */     //   574: dup
/*      */     //   575: invokespecial 181	java/lang/StringBuilder:<init>	()V
/*      */     //   578: ldc_w 565
/*      */     //   581: invokestatic 114	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   584: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   587: iload_3
/*      */     //   588: invokevirtual 366	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*      */     //   591: ldc_w 558
/*      */     //   594: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   597: aload_0
/*      */     //   598: getfield 58	com/mysql/jdbc/ResultSetImpl:fields	[Lcom/mysql/jdbc/Field;
/*      */     //   601: iload_3
/*      */     //   602: iconst_1
/*      */     //   603: isub
/*      */     //   604: aaload
/*      */     //   605: invokevirtual 559	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*      */     //   608: ldc_w 560
/*      */     //   611: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   614: invokevirtual 185	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   617: invokespecial 563	java/sql/SQLWarning:<init>	(Ljava/lang/String;)V
/*      */     //   620: astore 10
/*      */     //   622: aload_0
/*      */     //   623: getfield 48	com/mysql/jdbc/ResultSetImpl:warningChain	Ljava/sql/SQLWarning;
/*      */     //   626: ifnonnull +12 -> 638
/*      */     //   629: aload_0
/*      */     //   630: aload 10
/*      */     //   632: putfield 48	com/mysql/jdbc/ResultSetImpl:warningChain	Ljava/sql/SQLWarning;
/*      */     //   635: goto +12 -> 647
/*      */     //   638: aload_0
/*      */     //   639: getfield 48	com/mysql/jdbc/ResultSetImpl:warningChain	Ljava/sql/SQLWarning;
/*      */     //   642: aload 10
/*      */     //   644: invokevirtual 564	java/sql/SQLWarning:setNextWarning	(Ljava/sql/SQLWarning;)V
/*      */     //   647: goto +130 -> 777
/*      */     //   650: aload 9
/*      */     //   652: invokevirtual 208	com/mysql/jdbc/Field:getMysqlType	()I
/*      */     //   655: bipush 10
/*      */     //   657: if_icmpne +12 -> 669
/*      */     //   660: aload_0
/*      */     //   661: aload_2
/*      */     //   662: iconst_0
/*      */     //   663: iconst_0
/*      */     //   664: iconst_0
/*      */     //   665: invokevirtual 556	com/mysql/jdbc/ResultSetImpl:fastTimeCreate	(Ljava/util/Calendar;III)Ljava/sql/Time;
/*      */     //   668: areturn
/*      */     //   669: aload_1
/*      */     //   670: invokevirtual 198	java/lang/String:length	()I
/*      */     //   673: iconst_5
/*      */     //   674: if_icmpeq +58 -> 732
/*      */     //   677: aload_1
/*      */     //   678: invokevirtual 198	java/lang/String:length	()I
/*      */     //   681: bipush 8
/*      */     //   683: if_icmpeq +49 -> 732
/*      */     //   686: new 180	java/lang/StringBuilder
/*      */     //   689: dup
/*      */     //   690: invokespecial 181	java/lang/StringBuilder:<init>	()V
/*      */     //   693: ldc_w 566
/*      */     //   696: invokestatic 114	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   699: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   702: aload_1
/*      */     //   703: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   706: ldc_w 567
/*      */     //   709: invokestatic 114	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   712: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   715: iload_3
/*      */     //   716: invokevirtual 366	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*      */     //   719: invokevirtual 185	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   722: ldc 115
/*      */     //   724: aload_0
/*      */     //   725: invokevirtual 116	com/mysql/jdbc/ResultSetImpl:getExceptionInterceptor	()Lcom/mysql/jdbc/ExceptionInterceptor;
/*      */     //   728: invokestatic 117	com/mysql/jdbc/SQLError:createSQLException	(Ljava/lang/String;Ljava/lang/String;Lcom/mysql/jdbc/ExceptionInterceptor;)Ljava/sql/SQLException;
/*      */     //   731: athrow
/*      */     //   732: aload_1
/*      */     //   733: iconst_0
/*      */     //   734: iconst_2
/*      */     //   735: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   738: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   741: istore 6
/*      */     //   743: aload_1
/*      */     //   744: iconst_3
/*      */     //   745: iconst_5
/*      */     //   746: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   749: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   752: istore 7
/*      */     //   754: aload_1
/*      */     //   755: invokevirtual 198	java/lang/String:length	()I
/*      */     //   758: iconst_5
/*      */     //   759: if_icmpne +7 -> 766
/*      */     //   762: iconst_0
/*      */     //   763: goto +12 -> 775
/*      */     //   766: aload_1
/*      */     //   767: bipush 6
/*      */     //   769: invokevirtual 568	java/lang/String:substring	(I)Ljava/lang/String;
/*      */     //   772: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   775: istore 8
/*      */     //   777: aload_0
/*      */     //   778: invokevirtual 569	com/mysql/jdbc/ResultSetImpl:getCalendarInstanceForSessionOrNew	()Ljava/util/Calendar;
/*      */     //   781: astore 10
/*      */     //   783: aload 10
/*      */     //   785: dup
/*      */     //   786: astore 11
/*      */     //   788: monitorenter
/*      */     //   789: aload_0
/*      */     //   790: getfield 59	com/mysql/jdbc/ResultSetImpl:connection	Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   793: aload 10
/*      */     //   795: aload_2
/*      */     //   796: aload_0
/*      */     //   797: aload 10
/*      */     //   799: iload 6
/*      */     //   801: iload 7
/*      */     //   803: iload 8
/*      */     //   805: invokevirtual 556	com/mysql/jdbc/ResultSetImpl:fastTimeCreate	(Ljava/util/Calendar;III)Ljava/sql/Time;
/*      */     //   808: aload_0
/*      */     //   809: getfield 59	com/mysql/jdbc/ResultSetImpl:connection	Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   812: invokeinterface 65 1 0
/*      */     //   817: aload 4
/*      */     //   819: iload 5
/*      */     //   821: invokestatic 570	com/mysql/jdbc/TimeUtil:changeTimezone	(Lcom/mysql/jdbc/MySQLConnection;Ljava/util/Calendar;Ljava/util/Calendar;Ljava/sql/Time;Ljava/util/TimeZone;Ljava/util/TimeZone;Z)Ljava/sql/Time;
/*      */     //   824: aload 11
/*      */     //   826: monitorexit
/*      */     //   827: areturn
/*      */     //   828: astore 12
/*      */     //   830: aload 11
/*      */     //   832: monitorexit
/*      */     //   833: aload 12
/*      */     //   835: athrow
/*      */     //   836: astore 9
/*      */     //   838: aload 9
/*      */     //   840: invokevirtual 572	java/lang/RuntimeException:toString	()Ljava/lang/String;
/*      */     //   843: ldc 115
/*      */     //   845: aload_0
/*      */     //   846: invokevirtual 116	com/mysql/jdbc/ResultSetImpl:getExceptionInterceptor	()Lcom/mysql/jdbc/ExceptionInterceptor;
/*      */     //   849: invokestatic 117	com/mysql/jdbc/SQLError:createSQLException	(Ljava/lang/String;Ljava/lang/String;Lcom/mysql/jdbc/ExceptionInterceptor;)Ljava/sql/SQLException;
/*      */     //   852: astore 10
/*      */     //   854: aload 10
/*      */     //   856: aload 9
/*      */     //   858: invokevirtual 310	java/sql/SQLException:initCause	(Ljava/lang/Throwable;)Ljava/lang/Throwable;
/*      */     //   861: pop
/*      */     //   862: aload 10
/*      */     //   864: athrow
/*      */     // Line number table:
/*      */     //   Java source line #5845	-> byte code offset #0
/*      */     //   Java source line #5846	-> byte code offset #3
/*      */     //   Java source line #5847	-> byte code offset #6
/*      */     //   Java source line #5851	-> byte code offset #9
/*      */     //   Java source line #5852	-> byte code offset #13
/*      */     //   Java source line #5854	-> byte code offset #18
/*      */     //   Java source line #5865	-> byte code offset #20
/*      */     //   Java source line #5867	-> byte code offset #25
/*      */     //   Java source line #5871	-> byte code offset #64
/*      */     //   Java source line #5873	-> byte code offset #82
/*      */     //   Java source line #5875	-> byte code offset #87
/*      */     //   Java source line #5876	-> byte code offset #89
/*      */     //   Java source line #5878	-> byte code offset #107
/*      */     //   Java source line #5885	-> byte code offset #143
/*      */     //   Java source line #5888	-> byte code offset #152
/*      */     //   Java source line #5890	-> byte code offset #157
/*      */     //   Java source line #5892	-> byte code offset #167
/*      */     //   Java source line #5894	-> byte code offset #177
/*      */     //   Java source line #5896	-> byte code offset #183
/*      */     //   Java source line #5899	-> byte code offset #240
/*      */     //   Java source line #5901	-> byte code offset #259
/*      */     //   Java source line #5903	-> byte code offset #276
/*      */     //   Java source line #5907	-> byte code offset #291
/*      */     //   Java source line #5910	-> byte code offset #294
/*      */     //   Java source line #5912	-> byte code offset #312
/*      */     //   Java source line #5914	-> byte code offset #329
/*      */     //   Java source line #5918	-> byte code offset #344
/*      */     //   Java source line #5921	-> byte code offset #347
/*      */     //   Java source line #5922	-> byte code offset #360
/*      */     //   Java source line #5923	-> byte code offset #373
/*      */     //   Java source line #5926	-> byte code offset #376
/*      */     //   Java source line #5929	-> byte code offset #379
/*      */     //   Java source line #5938	-> byte code offset #435
/*      */     //   Java source line #5945	-> byte code offset #490
/*      */     //   Java source line #5946	-> byte code offset #497
/*      */     //   Java source line #5948	-> byte code offset #506
/*      */     //   Java source line #5950	-> byte code offset #515
/*      */     //   Java source line #5951	-> byte code offset #528
/*      */     //   Java source line #5952	-> byte code offset #541
/*      */     //   Java source line #5953	-> byte code offset #554
/*      */     //   Java source line #5955	-> byte code offset #567
/*      */     //   Java source line #5962	-> byte code offset #622
/*      */     //   Java source line #5963	-> byte code offset #629
/*      */     //   Java source line #5965	-> byte code offset #638
/*      */     //   Java source line #5967	-> byte code offset #647
/*      */     //   Java source line #5968	-> byte code offset #660
/*      */     //   Java source line #5972	-> byte code offset #669
/*      */     //   Java source line #5974	-> byte code offset #686
/*      */     //   Java source line #5981	-> byte code offset #732
/*      */     //   Java source line #5982	-> byte code offset #743
/*      */     //   Java source line #5983	-> byte code offset #754
/*      */     //   Java source line #5987	-> byte code offset #777
/*      */     //   Java source line #5989	-> byte code offset #783
/*      */     //   Java source line #5990	-> byte code offset #789
/*      */     //   Java source line #5997	-> byte code offset #828
/*      */     //   Java source line #5998	-> byte code offset #836
/*      */     //   Java source line #5999	-> byte code offset #838
/*      */     //   Java source line #6001	-> byte code offset #854
/*      */     //   Java source line #6003	-> byte code offset #862
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	865	0	this	ResultSetImpl
/*      */     //   0	865	1	timeAsString	String
/*      */     //   0	865	2	targetCalendar	Calendar
/*      */     //   0	865	3	columnIndex	int
/*      */     //   0	865	4	tz	TimeZone
/*      */     //   0	865	5	rollForward	boolean
/*      */     //   1	799	6	hr	int
/*      */     //   4	798	7	min	int
/*      */     //   7	797	8	sec	int
/*      */     //   165	486	9	timeColField	Field
/*      */     //   836	21	9	ex	RuntimeException
/*      */     //   181	154	10	length	int
/*      */     //   620	23	10	precisionLost	SQLWarning
/*      */     //   781	17	10	sessionCalendar	Calendar
/*      */     //   852	11	10	sqlEx	SQLException
/*      */     //   488	23	11	precisionLost	SQLWarning
/*      */     //   786	45	11	Ljava/lang/Object;	Object
/*      */     //   828	6	12	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   789	827	828	finally
/*      */     //   828	833	828	finally
/*      */     //   9	19	836	java/lang/RuntimeException
/*      */     //   20	88	836	java/lang/RuntimeException
/*      */     //   89	151	836	java/lang/RuntimeException
/*      */     //   152	668	836	java/lang/RuntimeException
/*      */     //   669	827	836	java/lang/RuntimeException
/*      */     //   828	836	836	java/lang/RuntimeException
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   private Timestamp getTimestampFromString(int columnIndex, Calendar targetCalendar, String timestampValue, TimeZone tz, boolean rollForward)
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: iconst_0
/*      */     //   2: putfield 49	com/mysql/jdbc/ResultSetImpl:wasNullFlag	Z
/*      */     //   5: aload_3
/*      */     //   6: ifnonnull +10 -> 16
/*      */     //   9: aload_0
/*      */     //   10: iconst_1
/*      */     //   11: putfield 49	com/mysql/jdbc/ResultSetImpl:wasNullFlag	Z
/*      */     //   14: aconst_null
/*      */     //   15: areturn
/*      */     //   16: aload_3
/*      */     //   17: invokevirtual 247	java/lang/String:trim	()Ljava/lang/String;
/*      */     //   20: astore_3
/*      */     //   21: aload_3
/*      */     //   22: invokevirtual 198	java/lang/String:length	()I
/*      */     //   25: istore 6
/*      */     //   27: aload_0
/*      */     //   28: getfield 59	com/mysql/jdbc/ResultSetImpl:connection	Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   31: invokeinterface 576 1 0
/*      */     //   36: ifeq +15 -> 51
/*      */     //   39: aload_0
/*      */     //   40: getfield 59	com/mysql/jdbc/ResultSetImpl:connection	Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   43: invokeinterface 577 1 0
/*      */     //   48: goto +7 -> 55
/*      */     //   51: aload_0
/*      */     //   52: invokevirtual 569	com/mysql/jdbc/ResultSetImpl:getCalendarInstanceForSessionOrNew	()Ljava/util/Calendar;
/*      */     //   55: astore 7
/*      */     //   57: aload 7
/*      */     //   59: dup
/*      */     //   60: astore 8
/*      */     //   62: monitorenter
/*      */     //   63: iload 6
/*      */     //   65: ifle +150 -> 215
/*      */     //   68: aload_3
/*      */     //   69: iconst_0
/*      */     //   70: invokevirtual 239	java/lang/String:charAt	(I)C
/*      */     //   73: bipush 48
/*      */     //   75: if_icmpne +140 -> 215
/*      */     //   78: aload_3
/*      */     //   79: ldc_w 293
/*      */     //   82: invokevirtual 242	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   85: ifne +32 -> 117
/*      */     //   88: aload_3
/*      */     //   89: ldc_w 294
/*      */     //   92: invokevirtual 242	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   95: ifne +22 -> 117
/*      */     //   98: aload_3
/*      */     //   99: ldc_w 295
/*      */     //   102: invokevirtual 242	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   105: ifne +12 -> 117
/*      */     //   108: aload_3
/*      */     //   109: ldc -103
/*      */     //   111: invokevirtual 242	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   114: ifeq +101 -> 215
/*      */     //   117: ldc_w 296
/*      */     //   120: aload_0
/*      */     //   121: getfield 59	com/mysql/jdbc/ResultSetImpl:connection	Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   124: invokeinterface 297 1 0
/*      */     //   129: invokevirtual 242	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   132: ifeq +13 -> 145
/*      */     //   135: aload_0
/*      */     //   136: iconst_1
/*      */     //   137: putfield 49	com/mysql/jdbc/ResultSetImpl:wasNullFlag	Z
/*      */     //   140: aconst_null
/*      */     //   141: aload 8
/*      */     //   143: monitorexit
/*      */     //   144: areturn
/*      */     //   145: ldc_w 298
/*      */     //   148: aload_0
/*      */     //   149: getfield 59	com/mysql/jdbc/ResultSetImpl:connection	Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   152: invokeinterface 297 1 0
/*      */     //   157: invokevirtual 242	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   160: ifeq +39 -> 199
/*      */     //   163: new 180	java/lang/StringBuilder
/*      */     //   166: dup
/*      */     //   167: invokespecial 181	java/lang/StringBuilder:<init>	()V
/*      */     //   170: ldc_w 299
/*      */     //   173: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   176: aload_3
/*      */     //   177: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   180: ldc_w 578
/*      */     //   183: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   186: invokevirtual 185	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   189: ldc 115
/*      */     //   191: aload_0
/*      */     //   192: invokevirtual 116	com/mysql/jdbc/ResultSetImpl:getExceptionInterceptor	()Lcom/mysql/jdbc/ExceptionInterceptor;
/*      */     //   195: invokestatic 117	com/mysql/jdbc/SQLError:createSQLException	(Ljava/lang/String;Ljava/lang/String;Lcom/mysql/jdbc/ExceptionInterceptor;)Ljava/sql/SQLException;
/*      */     //   198: athrow
/*      */     //   199: aload_0
/*      */     //   200: aconst_null
/*      */     //   201: iconst_1
/*      */     //   202: iconst_1
/*      */     //   203: iconst_1
/*      */     //   204: iconst_0
/*      */     //   205: iconst_0
/*      */     //   206: iconst_0
/*      */     //   207: iconst_0
/*      */     //   208: invokevirtual 579	com/mysql/jdbc/ResultSetImpl:fastTimestampCreate	(Ljava/util/Calendar;IIIIIII)Ljava/sql/Timestamp;
/*      */     //   211: aload 8
/*      */     //   213: monitorexit
/*      */     //   214: areturn
/*      */     //   215: aload_0
/*      */     //   216: getfield 58	com/mysql/jdbc/ResultSetImpl:fields	[Lcom/mysql/jdbc/Field;
/*      */     //   219: iload_1
/*      */     //   220: iconst_1
/*      */     //   221: isub
/*      */     //   222: aaload
/*      */     //   223: invokevirtual 208	com/mysql/jdbc/Field:getMysqlType	()I
/*      */     //   226: bipush 13
/*      */     //   228: if_icmpne +82 -> 310
/*      */     //   231: aload_0
/*      */     //   232: getfield 69	com/mysql/jdbc/ResultSetImpl:useLegacyDatetimeCode	Z
/*      */     //   235: ifne +27 -> 262
/*      */     //   238: aload 4
/*      */     //   240: aload_3
/*      */     //   241: iconst_0
/*      */     //   242: iconst_4
/*      */     //   243: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   246: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   249: iconst_1
/*      */     //   250: iconst_1
/*      */     //   251: iconst_0
/*      */     //   252: iconst_0
/*      */     //   253: iconst_0
/*      */     //   254: iconst_0
/*      */     //   255: invokestatic 173	com/mysql/jdbc/TimeUtil:fastTimestampCreate	(Ljava/util/TimeZone;IIIIIII)Ljava/sql/Timestamp;
/*      */     //   258: aload 8
/*      */     //   260: monitorexit
/*      */     //   261: areturn
/*      */     //   262: aload_0
/*      */     //   263: getfield 59	com/mysql/jdbc/ResultSetImpl:connection	Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   266: aload 7
/*      */     //   268: aload_2
/*      */     //   269: aload_0
/*      */     //   270: aload 7
/*      */     //   272: aload_3
/*      */     //   273: iconst_0
/*      */     //   274: iconst_4
/*      */     //   275: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   278: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   281: iconst_1
/*      */     //   282: iconst_1
/*      */     //   283: iconst_0
/*      */     //   284: iconst_0
/*      */     //   285: iconst_0
/*      */     //   286: iconst_0
/*      */     //   287: invokevirtual 579	com/mysql/jdbc/ResultSetImpl:fastTimestampCreate	(Ljava/util/Calendar;IIIIIII)Ljava/sql/Timestamp;
/*      */     //   290: aload_0
/*      */     //   291: getfield 59	com/mysql/jdbc/ResultSetImpl:connection	Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   294: invokeinterface 65 1 0
/*      */     //   299: aload 4
/*      */     //   301: iload 5
/*      */     //   303: invokestatic 580	com/mysql/jdbc/TimeUtil:changeTimezone	(Lcom/mysql/jdbc/MySQLConnection;Ljava/util/Calendar;Ljava/util/Calendar;Ljava/sql/Timestamp;Ljava/util/TimeZone;Ljava/util/TimeZone;Z)Ljava/sql/Timestamp;
/*      */     //   306: aload 8
/*      */     //   308: monitorexit
/*      */     //   309: areturn
/*      */     //   310: aload_3
/*      */     //   311: ldc -8
/*      */     //   313: invokevirtual 447	java/lang/String:endsWith	(Ljava/lang/String;)Z
/*      */     //   316: ifeq +15 -> 331
/*      */     //   319: aload_3
/*      */     //   320: iconst_0
/*      */     //   321: aload_3
/*      */     //   322: invokevirtual 198	java/lang/String:length	()I
/*      */     //   325: iconst_1
/*      */     //   326: isub
/*      */     //   327: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   330: astore_3
/*      */     //   331: iconst_0
/*      */     //   332: istore 9
/*      */     //   334: iconst_0
/*      */     //   335: istore 10
/*      */     //   337: iconst_0
/*      */     //   338: istore 11
/*      */     //   340: iconst_0
/*      */     //   341: istore 12
/*      */     //   343: iconst_0
/*      */     //   344: istore 13
/*      */     //   346: iconst_0
/*      */     //   347: istore 14
/*      */     //   349: iconst_0
/*      */     //   350: istore 15
/*      */     //   352: iload 6
/*      */     //   354: tableswitch	default:+869->1223, 2:+829->1183, 3:+869->1223, 4:+781->1135, 5:+869->1223, 6:+724->1078, 7:+869->1223, 8:+616->970, 9:+869->1223, 10:+461->815, 11:+869->1223, 12:+365->719, 13:+869->1223, 14:+287->641, 15:+869->1223, 16:+869->1223, 17:+869->1223, 18:+869->1223, 19:+114->468, 20:+114->468, 21:+114->468, 22:+114->468, 23:+114->468, 24:+114->468, 25:+114->468, 26:+114->468
/*      */     //   468: aload_3
/*      */     //   469: iconst_0
/*      */     //   470: iconst_4
/*      */     //   471: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   474: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   477: istore 9
/*      */     //   479: aload_3
/*      */     //   480: iconst_5
/*      */     //   481: bipush 7
/*      */     //   483: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   486: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   489: istore 10
/*      */     //   491: aload_3
/*      */     //   492: bipush 8
/*      */     //   494: bipush 10
/*      */     //   496: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   499: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   502: istore 11
/*      */     //   504: aload_3
/*      */     //   505: bipush 11
/*      */     //   507: bipush 13
/*      */     //   509: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   512: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   515: istore 12
/*      */     //   517: aload_3
/*      */     //   518: bipush 14
/*      */     //   520: bipush 16
/*      */     //   522: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   525: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   528: istore 13
/*      */     //   530: aload_3
/*      */     //   531: bipush 17
/*      */     //   533: bipush 19
/*      */     //   535: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   538: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   541: istore 14
/*      */     //   543: iconst_0
/*      */     //   544: istore 15
/*      */     //   546: iload 6
/*      */     //   548: bipush 19
/*      */     //   550: if_icmple +718 -> 1268
/*      */     //   553: aload_3
/*      */     //   554: bipush 46
/*      */     //   556: invokevirtual 581	java/lang/String:lastIndexOf	(I)I
/*      */     //   559: istore 16
/*      */     //   561: iload 16
/*      */     //   563: iconst_m1
/*      */     //   564: if_icmpeq +74 -> 638
/*      */     //   567: iload 16
/*      */     //   569: iconst_2
/*      */     //   570: iadd
/*      */     //   571: iload 6
/*      */     //   573: if_icmpgt +57 -> 630
/*      */     //   576: aload_3
/*      */     //   577: iload 16
/*      */     //   579: iconst_1
/*      */     //   580: iadd
/*      */     //   581: invokevirtual 568	java/lang/String:substring	(I)Ljava/lang/String;
/*      */     //   584: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   587: istore 15
/*      */     //   589: iload 6
/*      */     //   591: iload 16
/*      */     //   593: iconst_1
/*      */     //   594: iadd
/*      */     //   595: isub
/*      */     //   596: istore 17
/*      */     //   598: iload 17
/*      */     //   600: bipush 9
/*      */     //   602: if_icmpge +25 -> 627
/*      */     //   605: ldc2_w 582
/*      */     //   608: bipush 9
/*      */     //   610: iload 17
/*      */     //   612: isub
/*      */     //   613: i2d
/*      */     //   614: invokestatic 584	java/lang/Math:pow	(DD)D
/*      */     //   617: d2i
/*      */     //   618: istore 18
/*      */     //   620: iload 15
/*      */     //   622: iload 18
/*      */     //   624: imul
/*      */     //   625: istore 15
/*      */     //   627: goto +11 -> 638
/*      */     //   630: new 585	java/lang/IllegalArgumentException
/*      */     //   633: dup
/*      */     //   634: invokespecial 586	java/lang/IllegalArgumentException:<init>	()V
/*      */     //   637: athrow
/*      */     //   638: goto +630 -> 1268
/*      */     //   641: aload_3
/*      */     //   642: iconst_0
/*      */     //   643: iconst_4
/*      */     //   644: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   647: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   650: istore 9
/*      */     //   652: aload_3
/*      */     //   653: iconst_4
/*      */     //   654: bipush 6
/*      */     //   656: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   659: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   662: istore 10
/*      */     //   664: aload_3
/*      */     //   665: bipush 6
/*      */     //   667: bipush 8
/*      */     //   669: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   672: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   675: istore 11
/*      */     //   677: aload_3
/*      */     //   678: bipush 8
/*      */     //   680: bipush 10
/*      */     //   682: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   685: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   688: istore 12
/*      */     //   690: aload_3
/*      */     //   691: bipush 10
/*      */     //   693: bipush 12
/*      */     //   695: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   698: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   701: istore 13
/*      */     //   703: aload_3
/*      */     //   704: bipush 12
/*      */     //   706: bipush 14
/*      */     //   708: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   711: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   714: istore 14
/*      */     //   716: goto +552 -> 1268
/*      */     //   719: aload_3
/*      */     //   720: iconst_0
/*      */     //   721: iconst_2
/*      */     //   722: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   725: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   728: istore 9
/*      */     //   730: iload 9
/*      */     //   732: bipush 69
/*      */     //   734: if_icmpgt +10 -> 744
/*      */     //   737: iload 9
/*      */     //   739: bipush 100
/*      */     //   741: iadd
/*      */     //   742: istore 9
/*      */     //   744: wide
/*      */     //   750: aload_3
/*      */     //   751: iconst_2
/*      */     //   752: iconst_4
/*      */     //   753: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   756: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   759: istore 10
/*      */     //   761: aload_3
/*      */     //   762: iconst_4
/*      */     //   763: bipush 6
/*      */     //   765: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   768: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   771: istore 11
/*      */     //   773: aload_3
/*      */     //   774: bipush 6
/*      */     //   776: bipush 8
/*      */     //   778: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   781: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   784: istore 12
/*      */     //   786: aload_3
/*      */     //   787: bipush 8
/*      */     //   789: bipush 10
/*      */     //   791: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   794: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   797: istore 13
/*      */     //   799: aload_3
/*      */     //   800: bipush 10
/*      */     //   802: bipush 12
/*      */     //   804: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   807: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   810: istore 14
/*      */     //   812: goto +456 -> 1268
/*      */     //   815: aload_0
/*      */     //   816: getfield 58	com/mysql/jdbc/ResultSetImpl:fields	[Lcom/mysql/jdbc/Field;
/*      */     //   819: iload_1
/*      */     //   820: iconst_1
/*      */     //   821: isub
/*      */     //   822: aaload
/*      */     //   823: invokevirtual 208	com/mysql/jdbc/Field:getMysqlType	()I
/*      */     //   826: bipush 10
/*      */     //   828: if_icmpeq +14 -> 842
/*      */     //   831: aload_3
/*      */     //   832: ldc_w 587
/*      */     //   835: invokevirtual 249	java/lang/String:indexOf	(Ljava/lang/String;)I
/*      */     //   838: iconst_m1
/*      */     //   839: if_icmpeq +48 -> 887
/*      */     //   842: aload_3
/*      */     //   843: iconst_0
/*      */     //   844: iconst_4
/*      */     //   845: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   848: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   851: istore 9
/*      */     //   853: aload_3
/*      */     //   854: iconst_5
/*      */     //   855: bipush 7
/*      */     //   857: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   860: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   863: istore 10
/*      */     //   865: aload_3
/*      */     //   866: bipush 8
/*      */     //   868: bipush 10
/*      */     //   870: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   873: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   876: istore 11
/*      */     //   878: iconst_0
/*      */     //   879: istore 12
/*      */     //   881: iconst_0
/*      */     //   882: istore 13
/*      */     //   884: goto +384 -> 1268
/*      */     //   887: aload_3
/*      */     //   888: iconst_0
/*      */     //   889: iconst_2
/*      */     //   890: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   893: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   896: istore 9
/*      */     //   898: iload 9
/*      */     //   900: bipush 69
/*      */     //   902: if_icmpgt +10 -> 912
/*      */     //   905: iload 9
/*      */     //   907: bipush 100
/*      */     //   909: iadd
/*      */     //   910: istore 9
/*      */     //   912: aload_3
/*      */     //   913: iconst_2
/*      */     //   914: iconst_4
/*      */     //   915: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   918: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   921: istore 10
/*      */     //   923: aload_3
/*      */     //   924: iconst_4
/*      */     //   925: bipush 6
/*      */     //   927: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   930: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   933: istore 11
/*      */     //   935: aload_3
/*      */     //   936: bipush 6
/*      */     //   938: bipush 8
/*      */     //   940: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   943: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   946: istore 12
/*      */     //   948: aload_3
/*      */     //   949: bipush 8
/*      */     //   951: bipush 10
/*      */     //   953: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   956: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   959: istore 13
/*      */     //   961: wide
/*      */     //   967: goto +301 -> 1268
/*      */     //   970: aload_3
/*      */     //   971: ldc_w 588
/*      */     //   974: invokevirtual 249	java/lang/String:indexOf	(Ljava/lang/String;)I
/*      */     //   977: iconst_m1
/*      */     //   978: if_icmpeq +52 -> 1030
/*      */     //   981: aload_3
/*      */     //   982: iconst_0
/*      */     //   983: iconst_2
/*      */     //   984: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   987: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   990: istore 12
/*      */     //   992: aload_3
/*      */     //   993: iconst_3
/*      */     //   994: iconst_5
/*      */     //   995: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   998: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   1001: istore 13
/*      */     //   1003: aload_3
/*      */     //   1004: bipush 6
/*      */     //   1006: bipush 8
/*      */     //   1008: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   1011: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   1014: istore 14
/*      */     //   1016: sipush 1970
/*      */     //   1019: istore 9
/*      */     //   1021: iconst_1
/*      */     //   1022: istore 10
/*      */     //   1024: iconst_1
/*      */     //   1025: istore 11
/*      */     //   1027: goto +241 -> 1268
/*      */     //   1030: aload_3
/*      */     //   1031: iconst_0
/*      */     //   1032: iconst_4
/*      */     //   1033: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   1036: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   1039: istore 9
/*      */     //   1041: aload_3
/*      */     //   1042: iconst_4
/*      */     //   1043: bipush 6
/*      */     //   1045: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   1048: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   1051: istore 10
/*      */     //   1053: aload_3
/*      */     //   1054: bipush 6
/*      */     //   1056: bipush 8
/*      */     //   1058: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   1061: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   1064: istore 11
/*      */     //   1066: wide
/*      */     //   1072: iinc 10 -1
/*      */     //   1075: goto +193 -> 1268
/*      */     //   1078: aload_3
/*      */     //   1079: iconst_0
/*      */     //   1080: iconst_2
/*      */     //   1081: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   1084: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   1087: istore 9
/*      */     //   1089: iload 9
/*      */     //   1091: bipush 69
/*      */     //   1093: if_icmpgt +10 -> 1103
/*      */     //   1096: iload 9
/*      */     //   1098: bipush 100
/*      */     //   1100: iadd
/*      */     //   1101: istore 9
/*      */     //   1103: wide
/*      */     //   1109: aload_3
/*      */     //   1110: iconst_2
/*      */     //   1111: iconst_4
/*      */     //   1112: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   1115: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   1118: istore 10
/*      */     //   1120: aload_3
/*      */     //   1121: iconst_4
/*      */     //   1122: bipush 6
/*      */     //   1124: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   1127: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   1130: istore 11
/*      */     //   1132: goto +136 -> 1268
/*      */     //   1135: aload_3
/*      */     //   1136: iconst_0
/*      */     //   1137: iconst_2
/*      */     //   1138: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   1141: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   1144: istore 9
/*      */     //   1146: iload 9
/*      */     //   1148: bipush 69
/*      */     //   1150: if_icmpgt +10 -> 1160
/*      */     //   1153: iload 9
/*      */     //   1155: bipush 100
/*      */     //   1157: iadd
/*      */     //   1158: istore 9
/*      */     //   1160: wide
/*      */     //   1166: aload_3
/*      */     //   1167: iconst_2
/*      */     //   1168: iconst_4
/*      */     //   1169: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   1172: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   1175: istore 10
/*      */     //   1177: iconst_1
/*      */     //   1178: istore 11
/*      */     //   1180: goto +88 -> 1268
/*      */     //   1183: aload_3
/*      */     //   1184: iconst_0
/*      */     //   1185: iconst_2
/*      */     //   1186: invokevirtual 302	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   1189: invokestatic 303	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   1192: istore 9
/*      */     //   1194: iload 9
/*      */     //   1196: bipush 69
/*      */     //   1198: if_icmpgt +10 -> 1208
/*      */     //   1201: iload 9
/*      */     //   1203: bipush 100
/*      */     //   1205: iadd
/*      */     //   1206: istore 9
/*      */     //   1208: wide
/*      */     //   1214: iconst_1
/*      */     //   1215: istore 10
/*      */     //   1217: iconst_1
/*      */     //   1218: istore 11
/*      */     //   1220: goto +48 -> 1268
/*      */     //   1223: new 214	java/sql/SQLException
/*      */     //   1226: dup
/*      */     //   1227: new 180	java/lang/StringBuilder
/*      */     //   1230: dup
/*      */     //   1231: invokespecial 181	java/lang/StringBuilder:<init>	()V
/*      */     //   1234: ldc_w 589
/*      */     //   1237: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   1240: aload_3
/*      */     //   1241: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   1244: ldc_w 590
/*      */     //   1247: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   1250: iload_1
/*      */     //   1251: invokevirtual 366	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*      */     //   1254: ldc -8
/*      */     //   1256: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   1259: invokevirtual 185	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   1262: ldc 115
/*      */     //   1264: invokespecial 215	java/sql/SQLException:<init>	(Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   1267: athrow
/*      */     //   1268: aload_0
/*      */     //   1269: getfield 69	com/mysql/jdbc/ResultSetImpl:useLegacyDatetimeCode	Z
/*      */     //   1272: ifne +26 -> 1298
/*      */     //   1275: aload 4
/*      */     //   1277: iload 9
/*      */     //   1279: iload 10
/*      */     //   1281: iload 11
/*      */     //   1283: iload 12
/*      */     //   1285: iload 13
/*      */     //   1287: iload 14
/*      */     //   1289: iload 15
/*      */     //   1291: invokestatic 173	com/mysql/jdbc/TimeUtil:fastTimestampCreate	(Ljava/util/TimeZone;IIIIIII)Ljava/sql/Timestamp;
/*      */     //   1294: aload 8
/*      */     //   1296: monitorexit
/*      */     //   1297: areturn
/*      */     //   1298: aload_0
/*      */     //   1299: getfield 59	com/mysql/jdbc/ResultSetImpl:connection	Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   1302: aload 7
/*      */     //   1304: aload_2
/*      */     //   1305: aload_0
/*      */     //   1306: aload 7
/*      */     //   1308: iload 9
/*      */     //   1310: iload 10
/*      */     //   1312: iload 11
/*      */     //   1314: iload 12
/*      */     //   1316: iload 13
/*      */     //   1318: iload 14
/*      */     //   1320: iload 15
/*      */     //   1322: invokevirtual 579	com/mysql/jdbc/ResultSetImpl:fastTimestampCreate	(Ljava/util/Calendar;IIIIIII)Ljava/sql/Timestamp;
/*      */     //   1325: aload_0
/*      */     //   1326: getfield 59	com/mysql/jdbc/ResultSetImpl:connection	Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   1329: invokeinterface 65 1 0
/*      */     //   1334: aload 4
/*      */     //   1336: iload 5
/*      */     //   1338: invokestatic 580	com/mysql/jdbc/TimeUtil:changeTimezone	(Lcom/mysql/jdbc/MySQLConnection;Ljava/util/Calendar;Ljava/util/Calendar;Ljava/sql/Timestamp;Ljava/util/TimeZone;Ljava/util/TimeZone;Z)Ljava/sql/Timestamp;
/*      */     //   1341: aload 8
/*      */     //   1343: monitorexit
/*      */     //   1344: areturn
/*      */     //   1345: astore 19
/*      */     //   1347: aload 8
/*      */     //   1349: monitorexit
/*      */     //   1350: aload 19
/*      */     //   1352: athrow
/*      */     //   1353: astore 6
/*      */     //   1355: new 180	java/lang/StringBuilder
/*      */     //   1358: dup
/*      */     //   1359: invokespecial 181	java/lang/StringBuilder:<init>	()V
/*      */     //   1362: ldc_w 591
/*      */     //   1365: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   1368: aload_3
/*      */     //   1369: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   1372: ldc_w 592
/*      */     //   1375: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   1378: iload_1
/*      */     //   1379: invokevirtual 366	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*      */     //   1382: ldc_w 593
/*      */     //   1385: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   1388: invokevirtual 185	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   1391: ldc 115
/*      */     //   1393: aload_0
/*      */     //   1394: invokevirtual 116	com/mysql/jdbc/ResultSetImpl:getExceptionInterceptor	()Lcom/mysql/jdbc/ExceptionInterceptor;
/*      */     //   1397: invokestatic 117	com/mysql/jdbc/SQLError:createSQLException	(Ljava/lang/String;Ljava/lang/String;Lcom/mysql/jdbc/ExceptionInterceptor;)Ljava/sql/SQLException;
/*      */     //   1400: astore 7
/*      */     //   1402: aload 7
/*      */     //   1404: aload 6
/*      */     //   1406: invokevirtual 310	java/sql/SQLException:initCause	(Ljava/lang/Throwable;)Ljava/lang/Throwable;
/*      */     //   1409: pop
/*      */     //   1410: aload 7
/*      */     //   1412: athrow
/*      */     // Line number table:
/*      */     //   Java source line #6133	-> byte code offset #0
/*      */     //   Java source line #6135	-> byte code offset #5
/*      */     //   Java source line #6136	-> byte code offset #9
/*      */     //   Java source line #6138	-> byte code offset #14
/*      */     //   Java source line #6149	-> byte code offset #16
/*      */     //   Java source line #6151	-> byte code offset #21
/*      */     //   Java source line #6153	-> byte code offset #27
/*      */     //   Java source line #6157	-> byte code offset #57
/*      */     //   Java source line #6158	-> byte code offset #63
/*      */     //   Java source line #6165	-> byte code offset #117
/*      */     //   Java source line #6167	-> byte code offset #135
/*      */     //   Java source line #6169	-> byte code offset #140
/*      */     //   Java source line #6170	-> byte code offset #145
/*      */     //   Java source line #6172	-> byte code offset #163
/*      */     //   Java source line #6179	-> byte code offset #199
/*      */     //   Java source line #6181	-> byte code offset #215
/*      */     //   Java source line #6183	-> byte code offset #231
/*      */     //   Java source line #6184	-> byte code offset #238
/*      */     //   Java source line #6189	-> byte code offset #262
/*      */     //   Java source line #6199	-> byte code offset #310
/*      */     //   Java source line #6200	-> byte code offset #319
/*      */     //   Java source line #6206	-> byte code offset #331
/*      */     //   Java source line #6207	-> byte code offset #334
/*      */     //   Java source line #6208	-> byte code offset #337
/*      */     //   Java source line #6209	-> byte code offset #340
/*      */     //   Java source line #6210	-> byte code offset #343
/*      */     //   Java source line #6211	-> byte code offset #346
/*      */     //   Java source line #6212	-> byte code offset #349
/*      */     //   Java source line #6214	-> byte code offset #352
/*      */     //   Java source line #6223	-> byte code offset #468
/*      */     //   Java source line #6224	-> byte code offset #479
/*      */     //   Java source line #6226	-> byte code offset #491
/*      */     //   Java source line #6227	-> byte code offset #504
/*      */     //   Java source line #6229	-> byte code offset #517
/*      */     //   Java source line #6231	-> byte code offset #530
/*      */     //   Java source line #6234	-> byte code offset #543
/*      */     //   Java source line #6236	-> byte code offset #546
/*      */     //   Java source line #6237	-> byte code offset #553
/*      */     //   Java source line #6239	-> byte code offset #561
/*      */     //   Java source line #6240	-> byte code offset #567
/*      */     //   Java source line #6241	-> byte code offset #576
/*      */     //   Java source line #6244	-> byte code offset #589
/*      */     //   Java source line #6246	-> byte code offset #598
/*      */     //   Java source line #6247	-> byte code offset #605
/*      */     //   Java source line #6248	-> byte code offset #620
/*      */     //   Java source line #6250	-> byte code offset #627
/*      */     //   Java source line #6251	-> byte code offset #630
/*      */     //   Java source line #6259	-> byte code offset #638
/*      */     //   Java source line #6265	-> byte code offset #641
/*      */     //   Java source line #6266	-> byte code offset #652
/*      */     //   Java source line #6268	-> byte code offset #664
/*      */     //   Java source line #6269	-> byte code offset #677
/*      */     //   Java source line #6271	-> byte code offset #690
/*      */     //   Java source line #6273	-> byte code offset #703
/*      */     //   Java source line #6276	-> byte code offset #716
/*      */     //   Java source line #6280	-> byte code offset #719
/*      */     //   Java source line #6282	-> byte code offset #730
/*      */     //   Java source line #6283	-> byte code offset #737
/*      */     //   Java source line #6286	-> byte code offset #744
/*      */     //   Java source line #6288	-> byte code offset #750
/*      */     //   Java source line #6290	-> byte code offset #761
/*      */     //   Java source line #6291	-> byte code offset #773
/*      */     //   Java source line #6292	-> byte code offset #786
/*      */     //   Java source line #6294	-> byte code offset #799
/*      */     //   Java source line #6297	-> byte code offset #812
/*      */     //   Java source line #6301	-> byte code offset #815
/*      */     //   Java source line #6303	-> byte code offset #842
/*      */     //   Java source line #6304	-> byte code offset #853
/*      */     //   Java source line #6306	-> byte code offset #865
/*      */     //   Java source line #6307	-> byte code offset #878
/*      */     //   Java source line #6308	-> byte code offset #881
/*      */     //   Java source line #6310	-> byte code offset #887
/*      */     //   Java source line #6312	-> byte code offset #898
/*      */     //   Java source line #6313	-> byte code offset #905
/*      */     //   Java source line #6316	-> byte code offset #912
/*      */     //   Java source line #6318	-> byte code offset #923
/*      */     //   Java source line #6319	-> byte code offset #935
/*      */     //   Java source line #6320	-> byte code offset #948
/*      */     //   Java source line #6323	-> byte code offset #961
/*      */     //   Java source line #6326	-> byte code offset #967
/*      */     //   Java source line #6330	-> byte code offset #970
/*      */     //   Java source line #6331	-> byte code offset #981
/*      */     //   Java source line #6333	-> byte code offset #992
/*      */     //   Java source line #6335	-> byte code offset #1003
/*      */     //   Java source line #6337	-> byte code offset #1016
/*      */     //   Java source line #6338	-> byte code offset #1021
/*      */     //   Java source line #6339	-> byte code offset #1024
/*      */     //   Java source line #6340	-> byte code offset #1027
/*      */     //   Java source line #6343	-> byte code offset #1030
/*      */     //   Java source line #6344	-> byte code offset #1041
/*      */     //   Java source line #6346	-> byte code offset #1053
/*      */     //   Java source line #6348	-> byte code offset #1066
/*      */     //   Java source line #6349	-> byte code offset #1072
/*      */     //   Java source line #6351	-> byte code offset #1075
/*      */     //   Java source line #6355	-> byte code offset #1078
/*      */     //   Java source line #6357	-> byte code offset #1089
/*      */     //   Java source line #6358	-> byte code offset #1096
/*      */     //   Java source line #6361	-> byte code offset #1103
/*      */     //   Java source line #6363	-> byte code offset #1109
/*      */     //   Java source line #6365	-> byte code offset #1120
/*      */     //   Java source line #6367	-> byte code offset #1132
/*      */     //   Java source line #6371	-> byte code offset #1135
/*      */     //   Java source line #6373	-> byte code offset #1146
/*      */     //   Java source line #6374	-> byte code offset #1153
/*      */     //   Java source line #6377	-> byte code offset #1160
/*      */     //   Java source line #6379	-> byte code offset #1166
/*      */     //   Java source line #6382	-> byte code offset #1177
/*      */     //   Java source line #6384	-> byte code offset #1180
/*      */     //   Java source line #6388	-> byte code offset #1183
/*      */     //   Java source line #6390	-> byte code offset #1194
/*      */     //   Java source line #6391	-> byte code offset #1201
/*      */     //   Java source line #6394	-> byte code offset #1208
/*      */     //   Java source line #6395	-> byte code offset #1214
/*      */     //   Java source line #6396	-> byte code offset #1217
/*      */     //   Java source line #6398	-> byte code offset #1220
/*      */     //   Java source line #6402	-> byte code offset #1223
/*      */     //   Java source line #6408	-> byte code offset #1268
/*      */     //   Java source line #6409	-> byte code offset #1275
/*      */     //   Java source line #6413	-> byte code offset #1298
/*      */     //   Java source line #6420	-> byte code offset #1345
/*      */     //   Java source line #6421	-> byte code offset #1353
/*      */     //   Java source line #6422	-> byte code offset #1355
/*      */     //   Java source line #6425	-> byte code offset #1402
/*      */     //   Java source line #6427	-> byte code offset #1410
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	1413	0	this	ResultSetImpl
/*      */     //   0	1413	1	columnIndex	int
/*      */     //   0	1413	2	targetCalendar	Calendar
/*      */     //   0	1413	3	timestampValue	String
/*      */     //   0	1413	4	tz	TimeZone
/*      */     //   0	1413	5	rollForward	boolean
/*      */     //   25	565	6	length	int
/*      */     //   1353	52	6	e	RuntimeException
/*      */     //   55	1252	7	sessionCalendar	Calendar
/*      */     //   1400	11	7	sqlEx	SQLException
/*      */     //   332	977	9	year	int
/*      */     //   335	976	10	month	int
/*      */     //   338	975	11	day	int
/*      */     //   341	974	12	hour	int
/*      */     //   344	973	13	minutes	int
/*      */     //   347	972	14	seconds	int
/*      */     //   350	971	15	nanos	int
/*      */     //   559	33	16	decimalIndex	int
/*      */     //   596	15	17	numDigits	int
/*      */     //   618	5	18	factor	int
/*      */     //   1345	6	19	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   63	144	1345	finally
/*      */     //   145	214	1345	finally
/*      */     //   215	261	1345	finally
/*      */     //   262	309	1345	finally
/*      */     //   310	1297	1345	finally
/*      */     //   1298	1344	1345	finally
/*      */     //   1345	1350	1345	finally
/*      */     //   0	15	1353	java/lang/RuntimeException
/*      */     //   16	144	1353	java/lang/RuntimeException
/*      */     //   145	214	1353	java/lang/RuntimeException
/*      */     //   215	261	1353	java/lang/RuntimeException
/*      */     //   262	309	1353	java/lang/RuntimeException
/*      */     //   310	1297	1353	java/lang/RuntimeException
/*      */     //   1298	1344	1353	java/lang/RuntimeException
/*      */     //   1345	1353	1353	java/lang/RuntimeException
/*      */   }
/*      */ }


/* Location:              C:\Users\Static\Desktop\G10_Prototype_Client.jar!\mysql-connector-java-5.1.19-bin.jar!\com\mysql\jdbc\ResultSetImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */