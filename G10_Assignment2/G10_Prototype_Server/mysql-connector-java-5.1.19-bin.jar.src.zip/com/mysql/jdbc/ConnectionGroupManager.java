/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import com.mysql.jdbc.jmx.LoadBalanceConnectionGroupManager;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConnectionGroupManager
/*     */ {
/*  37 */   private static HashMap GROUP_MAP = new HashMap();
/*     */   
/*  39 */   private static LoadBalanceConnectionGroupManager mbean = new LoadBalanceConnectionGroupManager();
/*     */   
/*  41 */   private static boolean hasRegisteredJmx = false;
/*     */   
/*     */   public static synchronized ConnectionGroup getConnectionGroupInstance(String groupName)
/*     */   {
/*  45 */     if (GROUP_MAP.containsKey(groupName)) {
/*  46 */       return (ConnectionGroup)GROUP_MAP.get(groupName);
/*     */     }
/*  48 */     ConnectionGroup group = new ConnectionGroup(groupName);
/*  49 */     GROUP_MAP.put(groupName, group);
/*  50 */     return group;
/*     */   }
/*     */   
/*     */   public static void registerJmx() throws SQLException {
/*  54 */     if (hasRegisteredJmx) {
/*  55 */       return;
/*     */     }
/*     */     
/*  58 */     mbean.registerJmx();
/*  59 */     hasRegisteredJmx = true;
/*     */   }
/*     */   
/*     */   public static ConnectionGroup getConnectionGroup(String groupName) {
/*  63 */     return (ConnectionGroup)GROUP_MAP.get(groupName);
/*     */   }
/*     */   
/*     */   private static Collection getGroupsMatching(String group) {
/*  67 */     if ((group == null) || (group.equals(""))) {
/*  68 */       Set s = new HashSet();
/*     */       
/*  70 */       s.addAll(GROUP_MAP.values());
/*  71 */       return s;
/*     */     }
/*  73 */     Set s = new HashSet();
/*  74 */     Object o = GROUP_MAP.get(group);
/*  75 */     if (o != null) {
/*  76 */       s.add(o);
/*     */     }
/*  78 */     return s;
/*     */   }
/*     */   
/*     */   public static void addHost(String group, String host, boolean forExisting)
/*     */   {
/*  83 */     Collection s = getGroupsMatching(group);
/*  84 */     for (Iterator i = s.iterator(); i.hasNext();) {
/*  85 */       ((ConnectionGroup)i.next()).addHost(host, forExisting);
/*     */     }
/*     */   }
/*     */   
/*     */   public static int getActiveHostCount(String group)
/*     */   {
/*  91 */     Set active = new HashSet();
/*  92 */     Collection s = getGroupsMatching(group);
/*  93 */     for (Iterator i = s.iterator(); i.hasNext();) {
/*  94 */       active.addAll(((ConnectionGroup)i.next()).getInitialHosts());
/*     */     }
/*  96 */     return active.size();
/*     */   }
/*     */   
/*     */ 
/*     */   public static long getActiveLogicalConnectionCount(String group)
/*     */   {
/* 102 */     int count = 0;
/* 103 */     Collection s = getGroupsMatching(group);
/* 104 */     for (Iterator i = s.iterator(); i.hasNext();) {
/* 105 */       count = (int)(count + ((ConnectionGroup)i.next()).getActiveLogicalConnectionCount());
/*     */     }
/* 107 */     return count;
/*     */   }
/*     */   
/*     */   public static long getActivePhysicalConnectionCount(String group) {
/* 111 */     int count = 0;
/* 112 */     Collection s = getGroupsMatching(group);
/* 113 */     for (Iterator i = s.iterator(); i.hasNext();) {
/* 114 */       count = (int)(count + ((ConnectionGroup)i.next()).getActivePhysicalConnectionCount());
/*     */     }
/* 116 */     return count;
/*     */   }
/*     */   
/*     */   public static int getTotalHostCount(String group)
/*     */   {
/* 121 */     Collection s = getGroupsMatching(group);
/* 122 */     Set hosts = new HashSet();
/* 123 */     for (Iterator i = s.iterator(); i.hasNext();) {
/* 124 */       ConnectionGroup cg = (ConnectionGroup)i.next();
/* 125 */       hosts.addAll(cg.getInitialHosts());
/* 126 */       hosts.addAll(cg.getClosedHosts());
/*     */     }
/* 128 */     return hosts.size();
/*     */   }
/*     */   
/*     */   public static long getTotalLogicalConnectionCount(String group) {
/* 132 */     long count = 0L;
/* 133 */     Collection s = getGroupsMatching(group);
/* 134 */     for (Iterator i = s.iterator(); i.hasNext();) {
/* 135 */       count += ((ConnectionGroup)i.next()).getTotalLogicalConnectionCount();
/*     */     }
/* 137 */     return count;
/*     */   }
/*     */   
/*     */   public static long getTotalPhysicalConnectionCount(String group) {
/* 141 */     long count = 0L;
/* 142 */     Collection s = getGroupsMatching(group);
/* 143 */     for (Iterator i = s.iterator(); i.hasNext();) {
/* 144 */       count += ((ConnectionGroup)i.next()).getTotalPhysicalConnectionCount();
/*     */     }
/* 146 */     return count;
/*     */   }
/*     */   
/*     */   public static long getTotalTransactionCount(String group) {
/* 150 */     long count = 0L;
/* 151 */     Collection s = getGroupsMatching(group);
/* 152 */     for (Iterator i = s.iterator(); i.hasNext();) {
/* 153 */       count += ((ConnectionGroup)i.next()).getTotalTransactionCount();
/*     */     }
/* 155 */     return count;
/*     */   }
/*     */   
/*     */   public static void removeHost(String group, String host) throws SQLException {
/* 159 */     removeHost(group, host, false);
/*     */   }
/*     */   
/*     */   public static void removeHost(String group, String host, boolean removeExisting) throws SQLException {
/* 163 */     Collection s = getGroupsMatching(group);
/* 164 */     for (Iterator i = s.iterator(); i.hasNext();) {
/* 165 */       ((ConnectionGroup)i.next()).removeHost(host, removeExisting);
/*     */     }
/*     */   }
/*     */   
/*     */   public static String getActiveHostLists(String group) {
/* 170 */     Collection s = getGroupsMatching(group);
/* 171 */     Map hosts = new HashMap();
/* 172 */     for (Iterator i = s.iterator(); i.hasNext();)
/*     */     {
/* 174 */       Collection l = ((ConnectionGroup)i.next()).getInitialHosts();
/* 175 */       for (j = l.iterator(); j.hasNext();) {
/* 176 */         String host = j.next().toString();
/* 177 */         Object o = hosts.get(host);
/* 178 */         if (o == null) {
/* 179 */           o = Integer.valueOf(1);
/*     */         } else {
/* 181 */           o = Integer.valueOf(((Integer)o).intValue() + 1);
/*     */         }
/* 183 */         hosts.put(host, o);
/*     */       }
/*     */     }
/*     */     
/*     */     Iterator j;
/* 188 */     StringBuffer sb = new StringBuffer();
/* 189 */     String sep = "";
/* 190 */     for (Iterator i = hosts.keySet().iterator(); i.hasNext();) {
/* 191 */       String host = i.next().toString();
/*     */       
/* 193 */       sb.append(sep);
/* 194 */       sb.append(host);
/* 195 */       sb.append('(');
/* 196 */       sb.append(hosts.get(host));
/* 197 */       sb.append(')');
/* 198 */       sep = ",";
/*     */     }
/* 200 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public static String getRegisteredConnectionGroups() {
/* 204 */     Collection s = getGroupsMatching(null);
/* 205 */     StringBuffer sb = new StringBuffer();
/* 206 */     String sep = "";
/* 207 */     for (Iterator i = s.iterator(); i.hasNext();) {
/* 208 */       String group = ((ConnectionGroup)i.next()).getGroupName();
/* 209 */       sb.append(sep);
/* 210 */       sb.append(group);
/* 211 */       sep = ",";
/*     */     }
/* 213 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Static\Desktop\G10_Prototype_Server.jar!\mysql-connector-java-5.1.19-bin.jar!\com\mysql\jdbc\ConnectionGroupManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */