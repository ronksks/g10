/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import com.mysql.jdbc.log.Log;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.InetAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketException;
/*     */ import java.net.UnknownHostException;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardSocketFactory
/*     */   implements SocketFactory, SocketMetadata
/*     */ {
/*     */   public static final String TCP_NO_DELAY_PROPERTY_NAME = "tcpNoDelay";
/*     */   public static final String TCP_KEEP_ALIVE_DEFAULT_VALUE = "true";
/*     */   public static final String TCP_KEEP_ALIVE_PROPERTY_NAME = "tcpKeepAlive";
/*     */   public static final String TCP_RCV_BUF_PROPERTY_NAME = "tcpRcvBuf";
/*     */   public static final String TCP_SND_BUF_PROPERTY_NAME = "tcpSndBuf";
/*     */   public static final String TCP_TRAFFIC_CLASS_PROPERTY_NAME = "tcpTrafficClass";
/*     */   public static final String TCP_RCV_BUF_DEFAULT_VALUE = "0";
/*     */   public static final String TCP_SND_BUF_DEFAULT_VALUE = "0";
/*     */   public static final String TCP_TRAFFIC_CLASS_DEFAULT_VALUE = "0";
/*     */   public static final String TCP_NO_DELAY_DEFAULT_VALUE = "true";
/*     */   private static Method setTraficClassMethod;
/*     */   
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  73 */       setTraficClassMethod = Socket.class.getMethod("setTrafficClass", new Class[] { Integer.TYPE });
/*     */     }
/*     */     catch (SecurityException e) {
/*  76 */       setTraficClassMethod = null;
/*     */     } catch (NoSuchMethodException e) {
/*  78 */       setTraficClassMethod = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*  83 */   protected String host = null;
/*     */   
/*     */ 
/*  86 */   protected int port = 3306;
/*     */   
/*     */ 
/*  89 */   protected Socket rawSocket = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Socket afterHandshake()
/*     */     throws SocketException, IOException
/*     */   {
/* 103 */     return this.rawSocket;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Socket beforeHandshake()
/*     */     throws SocketException, IOException
/*     */   {
/* 118 */     return this.rawSocket;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void configureSocket(Socket sock, Properties props)
/*     */     throws SocketException, IOException
/*     */   {
/*     */     try
/*     */     {
/* 132 */       sock.setTcpNoDelay(Boolean.valueOf(props.getProperty("tcpNoDelay", "true")).booleanValue());
/*     */       
/*     */ 
/*     */ 
/* 136 */       String keepAlive = props.getProperty("tcpKeepAlive", "true");
/*     */       
/*     */ 
/* 139 */       if ((keepAlive != null) && (keepAlive.length() > 0)) {
/* 140 */         sock.setKeepAlive(Boolean.valueOf(keepAlive).booleanValue());
/*     */       }
/*     */       
/*     */ 
/* 144 */       int receiveBufferSize = Integer.parseInt(props.getProperty("tcpRcvBuf", "0"));
/*     */       
/*     */ 
/* 147 */       if (receiveBufferSize > 0) {
/* 148 */         sock.setReceiveBufferSize(receiveBufferSize);
/*     */       }
/*     */       
/* 151 */       int sendBufferSize = Integer.parseInt(props.getProperty("tcpSndBuf", "0"));
/*     */       
/*     */ 
/* 154 */       if (sendBufferSize > 0) {
/* 155 */         sock.setSendBufferSize(sendBufferSize);
/*     */       }
/*     */       
/* 158 */       int trafficClass = Integer.parseInt(props.getProperty("tcpTrafficClass", "0"));
/*     */       
/*     */ 
/*     */ 
/* 162 */       if ((trafficClass > 0) && (setTraficClassMethod != null)) {
/* 163 */         setTraficClassMethod.invoke(sock, new Object[] { Integer.valueOf(trafficClass) });
/*     */       }
/*     */     }
/*     */     catch (Throwable t) {
/* 167 */       unwrapExceptionToProperClassAndThrowIt(t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Socket connect(String hostname, int portNumber, Properties props)
/*     */     throws SocketException, IOException
/*     */   {
/* 177 */     if (props != null) {
/* 178 */       this.host = hostname;
/*     */       
/* 180 */       this.port = portNumber;
/*     */       
/* 182 */       Method connectWithTimeoutMethod = null;
/* 183 */       Method socketBindMethod = null;
/* 184 */       Class socketAddressClass = null;
/*     */       
/* 186 */       String localSocketHostname = props.getProperty("localSocketAddress");
/*     */       
/*     */ 
/* 189 */       String connectTimeoutStr = props.getProperty("connectTimeout");
/*     */       
/* 191 */       int connectTimeout = 0;
/*     */       
/* 193 */       boolean wantsTimeout = (connectTimeoutStr != null) && (connectTimeoutStr.length() > 0) && (!connectTimeoutStr.equals("0"));
/*     */       
/*     */ 
/*     */ 
/* 197 */       boolean wantsLocalBind = (localSocketHostname != null) && (localSocketHostname.length() > 0);
/*     */       
/*     */ 
/* 200 */       boolean needsConfigurationBeforeConnect = socketNeedsConfigurationBeforeConnect(props);
/*     */       
/* 202 */       if ((wantsTimeout) || (wantsLocalBind) || (needsConfigurationBeforeConnect))
/*     */       {
/* 204 */         if (connectTimeoutStr != null) {
/*     */           try {
/* 206 */             connectTimeout = Integer.parseInt(connectTimeoutStr);
/*     */           } catch (NumberFormatException nfe) {
/* 208 */             throw new SocketException("Illegal value '" + connectTimeoutStr + "' for connectTimeout");
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */         try
/*     */         {
/* 216 */           socketAddressClass = Class.forName("java.net.SocketAddress");
/*     */           
/*     */ 
/* 219 */           connectWithTimeoutMethod = Socket.class.getMethod("connect", new Class[] { socketAddressClass, Integer.TYPE });
/*     */           
/*     */ 
/*     */ 
/* 223 */           socketBindMethod = Socket.class.getMethod("bind", new Class[] { socketAddressClass });
/*     */         }
/*     */         catch (NoClassDefFoundError noClassDefFound) {}catch (NoSuchMethodException noSuchMethodEx) {}catch (Throwable catchAll) {}
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 234 */         if ((wantsLocalBind) && (socketBindMethod == null)) {
/* 235 */           throw new SocketException("Can't specify \"localSocketAddress\" on JVMs older than 1.4");
/*     */         }
/*     */         
/*     */ 
/* 239 */         if ((wantsTimeout) && (connectWithTimeoutMethod == null)) {
/* 240 */           throw new SocketException("Can't specify \"connectTimeout\" on JVMs older than 1.4");
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 245 */       if (this.host != null) {
/* 246 */         if ((!wantsLocalBind) && (!wantsTimeout) && (!needsConfigurationBeforeConnect)) {
/* 247 */           InetAddress[] possibleAddresses = InetAddress.getAllByName(this.host);
/*     */           
/*     */ 
/* 250 */           Throwable caughtWhileConnecting = null;
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 255 */           for (int i = 0; i < possibleAddresses.length; i++) {
/*     */             try {
/* 257 */               this.rawSocket = new Socket(possibleAddresses[i], this.port);
/*     */               
/*     */ 
/* 260 */               configureSocket(this.rawSocket, props);
/*     */             }
/*     */             catch (Exception ex)
/*     */             {
/* 264 */               caughtWhileConnecting = ex;
/*     */             }
/*     */           }
/*     */           
/* 268 */           if (this.rawSocket == null) {
/* 269 */             unwrapExceptionToProperClassAndThrowIt(caughtWhileConnecting);
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/*     */           try
/*     */           {
/* 276 */             InetAddress[] possibleAddresses = InetAddress.getAllByName(this.host);
/*     */             
/*     */ 
/* 279 */             Throwable caughtWhileConnecting = null;
/*     */             
/* 281 */             Object localSockAddr = null;
/*     */             
/* 283 */             Class inetSocketAddressClass = null;
/*     */             
/* 285 */             Constructor addrConstructor = null;
/*     */             try
/*     */             {
/* 288 */               inetSocketAddressClass = Class.forName("java.net.InetSocketAddress");
/*     */               
/*     */ 
/* 291 */               addrConstructor = inetSocketAddressClass.getConstructor(new Class[] { InetAddress.class, Integer.TYPE });
/*     */               
/*     */ 
/*     */ 
/* 295 */               if (wantsLocalBind) {
/* 296 */                 localSockAddr = addrConstructor.newInstance(new Object[] { InetAddress.getByName(localSocketHostname), new Integer(0) });
/*     */ 
/*     */               }
/*     */               
/*     */ 
/*     */ 
/*     */             }
/*     */             catch (Throwable ex)
/*     */             {
/*     */ 
/*     */ 
/* 307 */               unwrapExceptionToProperClassAndThrowIt(ex);
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/* 313 */             for (int i = 0; i < possibleAddresses.length; i++) {
/*     */               try
/*     */               {
/* 316 */                 this.rawSocket = new Socket();
/*     */                 
/* 318 */                 configureSocket(this.rawSocket, props);
/*     */                 
/* 320 */                 Object sockAddr = addrConstructor.newInstance(new Object[] { possibleAddresses[i], Integer.valueOf(this.port) });
/*     */                 
/*     */ 
/*     */ 
/*     */ 
/* 325 */                 if (localSockAddr != null) {
/* 326 */                   socketBindMethod.invoke(this.rawSocket, new Object[] { localSockAddr });
/*     */                 }
/*     */                 
/*     */ 
/* 330 */                 connectWithTimeoutMethod.invoke(this.rawSocket, new Object[] { sockAddr, Integer.valueOf(connectTimeout) });
/*     */ 
/*     */               }
/*     */               catch (Exception ex)
/*     */               {
/*     */ 
/* 336 */                 this.rawSocket = null;
/*     */                 
/* 338 */                 caughtWhileConnecting = ex;
/*     */               }
/*     */             }
/*     */             
/* 342 */             if (this.rawSocket == null) {
/* 343 */               unwrapExceptionToProperClassAndThrowIt(caughtWhileConnecting);
/*     */             }
/*     */           }
/*     */           catch (Throwable t) {
/* 347 */             unwrapExceptionToProperClassAndThrowIt(t);
/*     */           }
/*     */         }
/*     */         
/* 351 */         return this.rawSocket;
/*     */       }
/*     */     }
/*     */     
/* 355 */     throw new SocketException("Unable to create socket");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean socketNeedsConfigurationBeforeConnect(Properties props)
/*     */   {
/* 364 */     int receiveBufferSize = Integer.parseInt(props.getProperty("tcpRcvBuf", "0"));
/*     */     
/*     */ 
/* 367 */     if (receiveBufferSize > 0) {
/* 368 */       return true;
/*     */     }
/*     */     
/* 371 */     int sendBufferSize = Integer.parseInt(props.getProperty("tcpSndBuf", "0"));
/*     */     
/*     */ 
/* 374 */     if (sendBufferSize > 0) {
/* 375 */       return true;
/*     */     }
/*     */     
/* 378 */     int trafficClass = Integer.parseInt(props.getProperty("tcpTrafficClass", "0"));
/*     */     
/*     */ 
/*     */ 
/* 382 */     if ((trafficClass > 0) && (setTraficClassMethod != null)) {
/* 383 */       return true;
/*     */     }
/*     */     
/* 386 */     return false;
/*     */   }
/*     */   
/*     */   private void unwrapExceptionToProperClassAndThrowIt(Throwable caughtWhileConnecting)
/*     */     throws SocketException, IOException
/*     */   {
/* 392 */     if ((caughtWhileConnecting instanceof InvocationTargetException))
/*     */     {
/*     */ 
/*     */ 
/* 396 */       caughtWhileConnecting = ((InvocationTargetException)caughtWhileConnecting).getTargetException();
/*     */     }
/*     */     
/*     */ 
/* 400 */     if ((caughtWhileConnecting instanceof SocketException)) {
/* 401 */       throw ((SocketException)caughtWhileConnecting);
/*     */     }
/*     */     
/* 404 */     if ((caughtWhileConnecting instanceof IOException)) {
/* 405 */       throw ((IOException)caughtWhileConnecting);
/*     */     }
/*     */     
/* 408 */     throw new SocketException(caughtWhileConnecting.toString());
/*     */   }
/*     */   
/*     */   public boolean isLocallyConnected(ConnectionImpl conn) throws SQLException {
/* 412 */     long threadId = conn.getId();
/* 413 */     Statement processListStmt = conn.getMetadataSafeStatement();
/* 414 */     ResultSet rs = null;
/*     */     try
/*     */     {
/* 417 */       String processHost = null;
/*     */       
/* 419 */       rs = processListStmt.executeQuery("SHOW PROCESSLIST");
/*     */       
/* 421 */       while (rs.next()) {
/* 422 */         long id = rs.getLong(1);
/*     */         
/* 424 */         if (threadId == id) {
/* 425 */           processHost = rs.getString(3);
/*     */           
/* 427 */           break;
/*     */         }
/*     */       }
/*     */       
/* 431 */       if ((processHost != null) && 
/* 432 */         (processHost.indexOf(":") != -1)) {
/* 433 */         processHost = processHost.split(":")[0];
/*     */         
/*     */ 
/*     */         try
/*     */         {
/* 438 */           boolean isLocal = InetAddress.getByName(processHost).equals(this.rawSocket.getLocalAddress());
/*     */           
/*     */ 
/* 441 */           return isLocal;
/*     */         } catch (UnknownHostException e) { boolean bool1;
/* 443 */           conn.getLog().logWarn(Messages.getString("Connection.CantDetectLocalConnect", new Object[] { this.host }), e);
/*     */           
/* 445 */           return false;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 450 */       return 0;
/*     */     } finally {
/* 452 */       processListStmt.close();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Static\Desktop\G10_Prototype_Server.jar!\mysql-connector-java-5.1.19-bin.jar!\com\mysql\jdbc\StandardSocketFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */