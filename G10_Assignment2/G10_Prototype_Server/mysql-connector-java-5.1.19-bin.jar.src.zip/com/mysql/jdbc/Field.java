/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.util.regex.PatternSyntaxException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Field
/*      */ {
/*      */   private static final int AUTO_INCREMENT_FLAG = 512;
/*      */   private static final int NO_CHARSET_INFO = -1;
/*      */   private byte[] buffer;
/*   47 */   private int charsetIndex = 0;
/*      */   
/*   49 */   private String charsetName = null;
/*      */   
/*      */   private int colDecimals;
/*      */   
/*      */   private short colFlag;
/*      */   
/*   55 */   private String collationName = null;
/*      */   
/*   57 */   private MySQLConnection connection = null;
/*      */   
/*   59 */   private String databaseName = null;
/*      */   
/*   61 */   private int databaseNameLength = -1;
/*      */   
/*      */ 
/*   64 */   private int databaseNameStart = -1;
/*      */   
/*   66 */   private int defaultValueLength = -1;
/*      */   
/*      */ 
/*   69 */   private int defaultValueStart = -1;
/*      */   
/*   71 */   private String fullName = null;
/*      */   
/*   73 */   private String fullOriginalName = null;
/*      */   
/*   75 */   private boolean isImplicitTempTable = false;
/*      */   
/*      */   private long length;
/*      */   
/*   79 */   private int mysqlType = -1;
/*      */   
/*      */   private String name;
/*      */   
/*      */   private int nameLength;
/*      */   
/*      */   private int nameStart;
/*      */   
/*   87 */   private String originalColumnName = null;
/*      */   
/*   89 */   private int originalColumnNameLength = -1;
/*      */   
/*      */ 
/*   92 */   private int originalColumnNameStart = -1;
/*      */   
/*   94 */   private String originalTableName = null;
/*      */   
/*   96 */   private int originalTableNameLength = -1;
/*      */   
/*      */ 
/*   99 */   private int originalTableNameStart = -1;
/*      */   
/*  101 */   private int precisionAdjustFactor = 0;
/*      */   
/*  103 */   private int sqlType = -1;
/*      */   
/*      */   private String tableName;
/*      */   
/*      */   private int tableNameLength;
/*      */   
/*      */   private int tableNameStart;
/*      */   
/*  111 */   private boolean useOldNameMetadata = false;
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean isSingleBit;
/*      */   
/*      */ 
/*      */ 
/*      */   private int maxBytesPerChar;
/*      */   
/*      */ 
/*      */   private final boolean valueNeedsQuoting;
/*      */   
/*      */ 
/*      */ 
/*      */   Field(MySQLConnection conn, byte[] buffer, int databaseNameStart, int databaseNameLength, int tableNameStart, int tableNameLength, int originalTableNameStart, int originalTableNameLength, int nameStart, int nameLength, int originalColumnNameStart, int originalColumnNameLength, long length, int mysqlType, short colFlag, int colDecimals, int defaultValueStart, int defaultValueLength, int charsetIndex)
/*      */     throws SQLException
/*      */   {
/*  129 */     this.connection = conn;
/*  130 */     this.buffer = buffer;
/*  131 */     this.nameStart = nameStart;
/*  132 */     this.nameLength = nameLength;
/*  133 */     this.tableNameStart = tableNameStart;
/*  134 */     this.tableNameLength = tableNameLength;
/*  135 */     this.length = length;
/*  136 */     this.colFlag = colFlag;
/*  137 */     this.colDecimals = colDecimals;
/*  138 */     this.mysqlType = mysqlType;
/*      */     
/*      */ 
/*  141 */     this.databaseNameStart = databaseNameStart;
/*  142 */     this.databaseNameLength = databaseNameLength;
/*      */     
/*  144 */     this.originalTableNameStart = originalTableNameStart;
/*  145 */     this.originalTableNameLength = originalTableNameLength;
/*      */     
/*  147 */     this.originalColumnNameStart = originalColumnNameStart;
/*  148 */     this.originalColumnNameLength = originalColumnNameLength;
/*      */     
/*  150 */     this.defaultValueStart = defaultValueStart;
/*  151 */     this.defaultValueLength = defaultValueLength;
/*      */     
/*      */ 
/*      */ 
/*  155 */     this.charsetIndex = charsetIndex;
/*      */     
/*      */ 
/*      */ 
/*  159 */     this.sqlType = MysqlDefs.mysqlToJavaType(this.mysqlType);
/*      */     
/*  161 */     checkForImplicitTemporaryTable();
/*      */     
/*  163 */     boolean isFromFunction = this.originalTableNameLength == 0;
/*      */     
/*  165 */     if (this.mysqlType == 252) {
/*  166 */       if (((this.connection != null) && (this.connection.getBlobsAreStrings())) || ((this.connection.getFunctionsNeverReturnBlobs()) && (isFromFunction)))
/*      */       {
/*  168 */         this.sqlType = 12;
/*  169 */         this.mysqlType = 15;
/*  170 */       } else if ((this.charsetIndex == 63) || (!this.connection.versionMeetsMinimum(4, 1, 0)))
/*      */       {
/*  172 */         if ((this.connection.getUseBlobToStoreUTF8OutsideBMP()) && (shouldSetupForUtf8StringInBlob()))
/*      */         {
/*  174 */           setupForUtf8StringInBlob();
/*      */         } else {
/*  176 */           setBlobTypeBasedOnLength();
/*  177 */           this.sqlType = MysqlDefs.mysqlToJavaType(this.mysqlType);
/*      */         }
/*      */       }
/*      */       else {
/*  181 */         this.mysqlType = 253;
/*  182 */         this.sqlType = -1;
/*      */       }
/*      */     }
/*      */     
/*  186 */     if ((this.sqlType == -6) && (this.length == 1L) && (this.connection.getTinyInt1isBit()))
/*      */     {
/*      */ 
/*  189 */       if (conn.getTinyInt1isBit()) {
/*  190 */         if (conn.getTransformedBitIsBoolean()) {
/*  191 */           this.sqlType = 16;
/*      */         } else {
/*  193 */           this.sqlType = -7;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  199 */     if ((!isNativeNumericType()) && (!isNativeDateTimeType())) {
/*  200 */       this.charsetName = this.connection.getCharsetNameForIndex(this.charsetIndex);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  207 */       boolean isBinary = isBinary();
/*      */       
/*  209 */       if ((this.connection.versionMeetsMinimum(4, 1, 0)) && (this.mysqlType == 253) && (isBinary) && (this.charsetIndex == 63))
/*      */       {
/*      */ 
/*      */ 
/*  213 */         if ((this.connection != null) && (this.connection.getFunctionsNeverReturnBlobs()) && (isFromFunction)) {
/*  214 */           this.sqlType = 12;
/*  215 */           this.mysqlType = 15;
/*  216 */         } else if (isOpaqueBinary()) {
/*  217 */           this.sqlType = -3;
/*      */         }
/*      */       }
/*      */       
/*  221 */       if ((this.connection.versionMeetsMinimum(4, 1, 0)) && (this.mysqlType == 254) && (isBinary) && (this.charsetIndex == 63))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  231 */         if ((isOpaqueBinary()) && (!this.connection.getBlobsAreStrings())) {
/*  232 */           this.sqlType = -2;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  238 */       if (this.mysqlType == 16) {
/*  239 */         this.isSingleBit = (this.length == 0L);
/*      */         
/*  241 */         if ((this.connection != null) && ((this.connection.versionMeetsMinimum(5, 0, 21)) || (this.connection.versionMeetsMinimum(5, 1, 10))) && (this.length == 1L))
/*      */         {
/*  243 */           this.isSingleBit = true;
/*      */         }
/*      */         
/*  246 */         if (this.isSingleBit) {
/*  247 */           this.sqlType = -7;
/*      */         } else {
/*  249 */           this.sqlType = -3;
/*  250 */           this.colFlag = ((short)(this.colFlag | 0x80));
/*  251 */           this.colFlag = ((short)(this.colFlag | 0x10));
/*  252 */           isBinary = true;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  259 */       if ((this.sqlType == -4) && (!isBinary)) {
/*  260 */         this.sqlType = -1;
/*  261 */       } else if ((this.sqlType == -3) && (!isBinary)) {
/*  262 */         this.sqlType = 12;
/*      */       }
/*      */     } else {
/*  265 */       this.charsetName = "US-ASCII";
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  271 */     if (!isUnsigned()) {
/*  272 */       switch (this.mysqlType) {
/*      */       case 0: 
/*      */       case 246: 
/*  275 */         this.precisionAdjustFactor = -1;
/*      */         
/*  277 */         break;
/*      */       case 4: 
/*      */       case 5: 
/*  280 */         this.precisionAdjustFactor = 1;
/*      */       
/*      */       }
/*      */       
/*      */     } else {
/*  285 */       switch (this.mysqlType) {
/*      */       case 4: 
/*      */       case 5: 
/*  288 */         this.precisionAdjustFactor = 1;
/*      */       }
/*      */       
/*      */     }
/*      */     
/*  293 */     this.valueNeedsQuoting = determineNeedsQuoting();
/*      */   }
/*      */   
/*      */   private boolean shouldSetupForUtf8StringInBlob() throws SQLException {
/*  297 */     String includePattern = this.connection.getUtf8OutsideBmpIncludedColumnNamePattern();
/*      */     
/*  299 */     String excludePattern = this.connection.getUtf8OutsideBmpExcludedColumnNamePattern();
/*      */     
/*      */ 
/*  302 */     if ((excludePattern != null) && (!StringUtils.isEmptyOrWhitespaceOnly(excludePattern))) {
/*      */       try
/*      */       {
/*  305 */         if (getOriginalName().matches(excludePattern)) {
/*  306 */           if ((includePattern != null) && (!StringUtils.isEmptyOrWhitespaceOnly(includePattern))) {
/*      */             try
/*      */             {
/*  309 */               if (getOriginalName().matches(includePattern)) {
/*  310 */                 return true;
/*      */               }
/*      */             } catch (PatternSyntaxException pse) {
/*  313 */               SQLException sqlEx = SQLError.createSQLException("Illegal regex specified for \"utf8OutsideBmpIncludedColumnNamePattern\"", "S1009", this.connection.getExceptionInterceptor());
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*  318 */               if (!this.connection.getParanoid()) {
/*  319 */                 sqlEx.initCause(pse);
/*      */               }
/*      */               
/*  322 */               throw sqlEx;
/*      */             }
/*      */           }
/*      */           
/*  326 */           return false;
/*      */         }
/*      */       } catch (PatternSyntaxException pse) {
/*  329 */         SQLException sqlEx = SQLError.createSQLException("Illegal regex specified for \"utf8OutsideBmpExcludedColumnNamePattern\"", "S1009", this.connection.getExceptionInterceptor());
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  334 */         if (!this.connection.getParanoid()) {
/*  335 */           sqlEx.initCause(pse);
/*      */         }
/*      */         
/*  338 */         throw sqlEx;
/*      */       }
/*      */     }
/*      */     
/*  342 */     return true;
/*      */   }
/*      */   
/*      */   private void setupForUtf8StringInBlob() {
/*  346 */     if ((this.length == 255L) || (this.length == 65535L)) {
/*  347 */       this.mysqlType = 15;
/*  348 */       this.sqlType = 12;
/*      */     } else {
/*  350 */       this.mysqlType = 253;
/*  351 */       this.sqlType = -1;
/*      */     }
/*      */     
/*  354 */     this.charsetIndex = 33;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   Field(MySQLConnection conn, byte[] buffer, int nameStart, int nameLength, int tableNameStart, int tableNameLength, int length, int mysqlType, short colFlag, int colDecimals)
/*      */     throws SQLException
/*      */   {
/*  363 */     this(conn, buffer, -1, -1, tableNameStart, tableNameLength, -1, -1, nameStart, nameLength, -1, -1, length, mysqlType, colFlag, colDecimals, -1, -1, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Field(String tableName, String columnName, int jdbcType, int length)
/*      */   {
/*  372 */     this.tableName = tableName;
/*  373 */     this.name = columnName;
/*  374 */     this.length = length;
/*  375 */     this.sqlType = jdbcType;
/*  376 */     this.colFlag = 0;
/*  377 */     this.colDecimals = 0;
/*  378 */     this.valueNeedsQuoting = determineNeedsQuoting();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Field(String tableName, String columnName, int charsetIndex, int jdbcType, int length)
/*      */   {
/*  399 */     this.tableName = tableName;
/*  400 */     this.name = columnName;
/*  401 */     this.length = length;
/*  402 */     this.sqlType = jdbcType;
/*  403 */     this.colFlag = 0;
/*  404 */     this.colDecimals = 0;
/*  405 */     this.charsetIndex = charsetIndex;
/*  406 */     this.valueNeedsQuoting = determineNeedsQuoting();
/*      */     
/*  408 */     switch (this.sqlType) {
/*      */     case -3: 
/*      */     case -2: 
/*  411 */       this.colFlag = ((short)(this.colFlag | 0x80));
/*  412 */       this.colFlag = ((short)(this.colFlag | 0x10));
/*      */     }
/*      */   }
/*      */   
/*      */   private void checkForImplicitTemporaryTable()
/*      */   {
/*  418 */     this.isImplicitTempTable = ((this.tableNameLength > 5) && (this.buffer[this.tableNameStart] == 35) && (this.buffer[(this.tableNameStart + 1)] == 115) && (this.buffer[(this.tableNameStart + 2)] == 113) && (this.buffer[(this.tableNameStart + 3)] == 108) && (this.buffer[(this.tableNameStart + 4)] == 95));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCharacterSet()
/*      */     throws SQLException
/*      */   {
/*  432 */     return this.charsetName;
/*      */   }
/*      */   
/*      */   public void setCharacterSet(String javaEncodingName) throws SQLException {
/*  436 */     this.charsetName = javaEncodingName;
/*      */     try {
/*  438 */       this.charsetIndex = CharsetMapping.getCharsetIndexForMysqlEncodingName(javaEncodingName);
/*      */     }
/*      */     catch (RuntimeException ex) {
/*  441 */       SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", null);
/*  442 */       sqlEx.initCause(ex);
/*  443 */       throw sqlEx;
/*      */     }
/*      */   }
/*      */   
/*      */   public synchronized String getCollation() throws SQLException {
/*  448 */     if ((this.collationName == null) && 
/*  449 */       (this.connection != null) && 
/*  450 */       (this.connection.versionMeetsMinimum(4, 1, 0))) {
/*  451 */       if (this.connection.getUseDynamicCharsetInfo()) {
/*  452 */         DatabaseMetaData dbmd = this.connection.getMetaData();
/*      */         
/*      */ 
/*  455 */         String quotedIdStr = dbmd.getIdentifierQuoteString();
/*      */         
/*  457 */         if (" ".equals(quotedIdStr)) {
/*  458 */           quotedIdStr = "";
/*      */         }
/*      */         
/*  461 */         String csCatalogName = getDatabaseName();
/*  462 */         String csTableName = getOriginalTableName();
/*  463 */         String csColumnName = getOriginalName();
/*      */         
/*  465 */         if ((csCatalogName != null) && (csCatalogName.length() != 0) && (csTableName != null) && (csTableName.length() != 0) && (csColumnName != null) && (csColumnName.length() != 0))
/*      */         {
/*      */ 
/*      */ 
/*  469 */           StringBuffer queryBuf = new StringBuffer(csCatalogName.length() + csTableName.length() + 28);
/*      */           
/*      */ 
/*  472 */           queryBuf.append("SHOW FULL COLUMNS FROM ");
/*  473 */           queryBuf.append(quotedIdStr);
/*  474 */           queryBuf.append(csCatalogName);
/*  475 */           queryBuf.append(quotedIdStr);
/*  476 */           queryBuf.append(".");
/*  477 */           queryBuf.append(quotedIdStr);
/*  478 */           queryBuf.append(csTableName);
/*  479 */           queryBuf.append(quotedIdStr);
/*      */           
/*  481 */           Statement collationStmt = null;
/*  482 */           ResultSet collationRs = null;
/*      */           try
/*      */           {
/*  485 */             collationStmt = this.connection.createStatement();
/*      */             
/*  487 */             collationRs = collationStmt.executeQuery(queryBuf.toString());
/*      */             
/*      */ 
/*  490 */             while (collationRs.next()) {
/*  491 */               if (csColumnName.equals(collationRs.getString("Field")))
/*      */               {
/*  493 */                 this.collationName = collationRs.getString("Collation");
/*      */               }
/*      */               
/*      */             }
/*      */           }
/*      */           finally
/*      */           {
/*  500 */             if (collationRs != null) {
/*  501 */               collationRs.close();
/*  502 */               collationRs = null;
/*      */             }
/*      */             
/*  505 */             if (collationStmt != null) {
/*  506 */               collationStmt.close();
/*  507 */               collationStmt = null;
/*      */             }
/*      */           }
/*      */         }
/*      */       } else {
/*      */         try {
/*  513 */           this.collationName = CharsetMapping.INDEX_TO_COLLATION[this.charsetIndex];
/*      */         } catch (RuntimeException ex) {
/*  515 */           SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", null);
/*  516 */           sqlEx.initCause(ex);
/*  517 */           throw sqlEx;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  524 */     return this.collationName;
/*      */   }
/*      */   
/*      */   public String getColumnLabel() throws SQLException {
/*  528 */     return getName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDatabaseName()
/*      */     throws SQLException
/*      */   {
/*  537 */     if ((this.databaseName == null) && (this.databaseNameStart != -1) && (this.databaseNameLength != -1))
/*      */     {
/*  539 */       this.databaseName = getStringFromBytes(this.databaseNameStart, this.databaseNameLength);
/*      */     }
/*      */     
/*      */ 
/*  543 */     return this.databaseName;
/*      */   }
/*      */   
/*      */   int getDecimals() {
/*  547 */     return this.colDecimals;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getFullName()
/*      */     throws SQLException
/*      */   {
/*  556 */     if (this.fullName == null) {
/*  557 */       StringBuffer fullNameBuf = new StringBuffer(getTableName().length() + 1 + getName().length());
/*      */       
/*  559 */       fullNameBuf.append(this.tableName);
/*      */       
/*      */ 
/*  562 */       fullNameBuf.append('.');
/*  563 */       fullNameBuf.append(this.name);
/*  564 */       this.fullName = fullNameBuf.toString();
/*  565 */       fullNameBuf = null;
/*      */     }
/*      */     
/*  568 */     return this.fullName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getFullOriginalName()
/*      */     throws SQLException
/*      */   {
/*  577 */     getOriginalName();
/*      */     
/*  579 */     if (this.originalColumnName == null) {
/*  580 */       return null;
/*      */     }
/*      */     
/*  583 */     if (this.fullName == null) {
/*  584 */       StringBuffer fullOriginalNameBuf = new StringBuffer(getOriginalTableName().length() + 1 + getOriginalName().length());
/*      */       
/*      */ 
/*  587 */       fullOriginalNameBuf.append(this.originalTableName);
/*      */       
/*      */ 
/*  590 */       fullOriginalNameBuf.append('.');
/*  591 */       fullOriginalNameBuf.append(this.originalColumnName);
/*  592 */       this.fullOriginalName = fullOriginalNameBuf.toString();
/*  593 */       fullOriginalNameBuf = null;
/*      */     }
/*      */     
/*  596 */     return this.fullOriginalName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getLength()
/*      */   {
/*  605 */     return this.length;
/*      */   }
/*      */   
/*      */   public synchronized int getMaxBytesPerCharacter() throws SQLException {
/*  609 */     if (this.maxBytesPerChar == 0) {
/*  610 */       this.maxBytesPerChar = this.connection.getMaxBytesPerChar(Integer.valueOf(this.charsetIndex), getCharacterSet());
/*      */     }
/*  612 */     return this.maxBytesPerChar;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMysqlType()
/*      */   {
/*  621 */     return this.mysqlType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getName()
/*      */     throws SQLException
/*      */   {
/*  630 */     if (this.name == null) {
/*  631 */       this.name = getStringFromBytes(this.nameStart, this.nameLength);
/*      */     }
/*      */     
/*  634 */     return this.name;
/*      */   }
/*      */   
/*      */   public String getNameNoAliases() throws SQLException {
/*  638 */     if (this.useOldNameMetadata) {
/*  639 */       return getName();
/*      */     }
/*      */     
/*  642 */     if ((this.connection != null) && (this.connection.versionMeetsMinimum(4, 1, 0)))
/*      */     {
/*  644 */       return getOriginalName();
/*      */     }
/*      */     
/*  647 */     return getName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getOriginalName()
/*      */     throws SQLException
/*      */   {
/*  656 */     if ((this.originalColumnName == null) && (this.originalColumnNameStart != -1) && (this.originalColumnNameLength != -1))
/*      */     {
/*      */ 
/*  659 */       this.originalColumnName = getStringFromBytes(this.originalColumnNameStart, this.originalColumnNameLength);
/*      */     }
/*      */     
/*      */ 
/*  663 */     return this.originalColumnName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getOriginalTableName()
/*      */     throws SQLException
/*      */   {
/*  672 */     if ((this.originalTableName == null) && (this.originalTableNameStart != -1) && (this.originalTableNameLength != -1))
/*      */     {
/*      */ 
/*  675 */       this.originalTableName = getStringFromBytes(this.originalTableNameStart, this.originalTableNameLength);
/*      */     }
/*      */     
/*      */ 
/*  679 */     return this.originalTableName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getPrecisionAdjustFactor()
/*      */   {
/*  691 */     return this.precisionAdjustFactor;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getSQLType()
/*      */   {
/*  700 */     return this.sqlType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getStringFromBytes(int stringStart, int stringLength)
/*      */     throws SQLException
/*      */   {
/*  709 */     if ((stringStart == -1) || (stringLength == -1)) {
/*  710 */       return null;
/*      */     }
/*      */     
/*  713 */     String stringVal = null;
/*      */     
/*  715 */     if (this.connection != null) {
/*  716 */       if (this.connection.getUseUnicode()) {
/*  717 */         String encoding = this.connection.getCharacterSetMetadata();
/*      */         
/*  719 */         if (encoding == null) {
/*  720 */           encoding = this.connection.getEncoding();
/*      */         }
/*      */         
/*  723 */         if (encoding != null) {
/*  724 */           SingleByteCharsetConverter converter = null;
/*      */           
/*  726 */           if (this.connection != null) {
/*  727 */             converter = this.connection.getCharsetConverter(encoding);
/*      */           }
/*      */           
/*      */ 
/*  731 */           if (converter != null) {
/*  732 */             stringVal = converter.toString(this.buffer, stringStart, stringLength);
/*      */           }
/*      */           else
/*      */           {
/*  736 */             byte[] stringBytes = new byte[stringLength];
/*      */             
/*  738 */             int endIndex = stringStart + stringLength;
/*  739 */             int pos = 0;
/*      */             
/*  741 */             for (int i = stringStart; i < endIndex; i++) {
/*  742 */               stringBytes[(pos++)] = this.buffer[i];
/*      */             }
/*      */             try
/*      */             {
/*  746 */               stringVal = StringUtils.toString(stringBytes, encoding);
/*      */             } catch (UnsupportedEncodingException ue) {
/*  748 */               throw new RuntimeException(Messages.getString("Field.12") + encoding + Messages.getString("Field.13"));
/*      */             }
/*      */             
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/*  755 */           stringVal = StringUtils.toAsciiString(this.buffer, stringStart, stringLength);
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  760 */         stringVal = StringUtils.toAsciiString(this.buffer, stringStart, stringLength);
/*      */       }
/*      */       
/*      */     }
/*      */     else {
/*  765 */       stringVal = StringUtils.toAsciiString(this.buffer, stringStart, stringLength);
/*      */     }
/*      */     
/*      */ 
/*  769 */     return stringVal;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getTable()
/*      */     throws SQLException
/*      */   {
/*  778 */     return getTableName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getTableName()
/*      */     throws SQLException
/*      */   {
/*  787 */     if (this.tableName == null) {
/*  788 */       this.tableName = getStringFromBytes(this.tableNameStart, this.tableNameLength);
/*      */     }
/*      */     
/*      */ 
/*  792 */     return this.tableName;
/*      */   }
/*      */   
/*      */   public String getTableNameNoAliases() throws SQLException {
/*  796 */     if (this.connection.versionMeetsMinimum(4, 1, 0)) {
/*  797 */       return getOriginalTableName();
/*      */     }
/*      */     
/*  800 */     return getTableName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isAutoIncrement()
/*      */   {
/*  809 */     return (this.colFlag & 0x200) > 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isBinary()
/*      */   {
/*  818 */     return (this.colFlag & 0x80) > 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isBlob()
/*      */   {
/*  827 */     return (this.colFlag & 0x10) > 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean isImplicitTemporaryTable()
/*      */   {
/*  836 */     return this.isImplicitTempTable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isMultipleKey()
/*      */   {
/*  845 */     return (this.colFlag & 0x8) > 0;
/*      */   }
/*      */   
/*      */   boolean isNotNull() {
/*  849 */     return (this.colFlag & 0x1) > 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean isOpaqueBinary()
/*      */     throws SQLException
/*      */   {
/*  859 */     if ((this.charsetIndex == 63) && (isBinary()) && ((getMysqlType() == 254) || (getMysqlType() == 253)))
/*      */     {
/*      */ 
/*      */ 
/*  863 */       if ((this.originalTableNameLength == 0) && (this.connection != null) && (!this.connection.versionMeetsMinimum(5, 0, 25)))
/*      */       {
/*  865 */         return false;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  871 */       return !isImplicitTemporaryTable();
/*      */     }
/*      */     
/*  874 */     return (this.connection.versionMeetsMinimum(4, 1, 0)) && ("binary".equalsIgnoreCase(getCharacterSet()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isPrimaryKey()
/*      */   {
/*  885 */     return (this.colFlag & 0x2) > 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean isReadOnly()
/*      */     throws SQLException
/*      */   {
/*  895 */     if (this.connection.versionMeetsMinimum(4, 1, 0)) {
/*  896 */       String orgColumnName = getOriginalName();
/*  897 */       String orgTableName = getOriginalTableName();
/*      */       
/*  899 */       return (orgColumnName == null) || (orgColumnName.length() <= 0) || (orgTableName == null) || (orgTableName.length() <= 0);
/*      */     }
/*      */     
/*      */ 
/*  903 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isUniqueKey()
/*      */   {
/*  912 */     return (this.colFlag & 0x4) > 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isUnsigned()
/*      */   {
/*  921 */     return (this.colFlag & 0x20) > 0;
/*      */   }
/*      */   
/*      */   public void setUnsigned() {
/*  925 */     this.colFlag = ((short)(this.colFlag | 0x20));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isZeroFill()
/*      */   {
/*  934 */     return (this.colFlag & 0x40) > 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void setBlobTypeBasedOnLength()
/*      */   {
/*  943 */     if (this.length == 255L) {
/*  944 */       this.mysqlType = 249;
/*  945 */     } else if (this.length == 65535L) {
/*  946 */       this.mysqlType = 252;
/*  947 */     } else if (this.length == 16777215L) {
/*  948 */       this.mysqlType = 250;
/*  949 */     } else if (this.length == 4294967295L) {
/*  950 */       this.mysqlType = 251;
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean isNativeNumericType() {
/*  955 */     return ((this.mysqlType >= 1) && (this.mysqlType <= 5)) || (this.mysqlType == 8) || (this.mysqlType == 13);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean isNativeDateTimeType()
/*      */   {
/*  962 */     return (this.mysqlType == 10) || (this.mysqlType == 14) || (this.mysqlType == 12) || (this.mysqlType == 11) || (this.mysqlType == 7);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConnection(MySQLConnection conn)
/*      */   {
/*  976 */     this.connection = conn;
/*      */     
/*  978 */     if ((this.charsetName == null) || (this.charsetIndex == 0)) {
/*  979 */       this.charsetName = this.connection.getEncoding();
/*      */     }
/*      */   }
/*      */   
/*      */   void setMysqlType(int type) {
/*  984 */     this.mysqlType = type;
/*  985 */     this.sqlType = MysqlDefs.mysqlToJavaType(this.mysqlType);
/*      */   }
/*      */   
/*      */   protected void setUseOldNameMetadata(boolean useOldNameMetadata) {
/*  989 */     this.useOldNameMetadata = useOldNameMetadata;
/*      */   }
/*      */   
/*      */   public String toString() {
/*      */     try {
/*  994 */       StringBuffer asString = new StringBuffer();
/*  995 */       asString.append(super.toString());
/*  996 */       asString.append("[");
/*  997 */       asString.append("catalog=");
/*  998 */       asString.append(getDatabaseName());
/*  999 */       asString.append(",tableName=");
/* 1000 */       asString.append(getTableName());
/* 1001 */       asString.append(",originalTableName=");
/* 1002 */       asString.append(getOriginalTableName());
/* 1003 */       asString.append(",columnName=");
/* 1004 */       asString.append(getName());
/* 1005 */       asString.append(",originalColumnName=");
/* 1006 */       asString.append(getOriginalName());
/* 1007 */       asString.append(",mysqlType=");
/* 1008 */       asString.append(getMysqlType());
/* 1009 */       asString.append("(");
/* 1010 */       asString.append(MysqlDefs.typeToName(getMysqlType()));
/* 1011 */       asString.append(")");
/* 1012 */       asString.append(",flags=");
/*      */       
/* 1014 */       if (isAutoIncrement()) {
/* 1015 */         asString.append(" AUTO_INCREMENT");
/*      */       }
/*      */       
/* 1018 */       if (isPrimaryKey()) {
/* 1019 */         asString.append(" PRIMARY_KEY");
/*      */       }
/*      */       
/* 1022 */       if (isUniqueKey()) {
/* 1023 */         asString.append(" UNIQUE_KEY");
/*      */       }
/*      */       
/* 1026 */       if (isBinary()) {
/* 1027 */         asString.append(" BINARY");
/*      */       }
/*      */       
/* 1030 */       if (isBlob()) {
/* 1031 */         asString.append(" BLOB");
/*      */       }
/*      */       
/* 1034 */       if (isMultipleKey()) {
/* 1035 */         asString.append(" MULTI_KEY");
/*      */       }
/*      */       
/* 1038 */       if (isUnsigned()) {
/* 1039 */         asString.append(" UNSIGNED");
/*      */       }
/*      */       
/* 1042 */       if (isZeroFill()) {
/* 1043 */         asString.append(" ZEROFILL");
/*      */       }
/*      */       
/* 1046 */       asString.append(", charsetIndex=");
/* 1047 */       asString.append(this.charsetIndex);
/* 1048 */       asString.append(", charsetName=");
/* 1049 */       asString.append(this.charsetName);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1058 */       asString.append("]");
/*      */       
/* 1060 */       return asString.toString();
/*      */     } catch (Throwable t) {}
/* 1062 */     return super.toString();
/*      */   }
/*      */   
/*      */   protected boolean isSingleBit()
/*      */   {
/* 1067 */     return this.isSingleBit;
/*      */   }
/*      */   
/*      */   protected boolean getvalueNeedsQuoting() {
/* 1071 */     return this.valueNeedsQuoting;
/*      */   }
/*      */   
/*      */   private boolean determineNeedsQuoting() {
/* 1075 */     boolean retVal = false;
/*      */     
/* 1077 */     switch (this.sqlType) {
/*      */     case -7: 
/*      */     case -6: 
/*      */     case -5: 
/*      */     case 2: 
/*      */     case 3: 
/*      */     case 4: 
/*      */     case 5: 
/*      */     case 6: 
/*      */     case 7: 
/*      */     case 8: 
/* 1088 */       retVal = false;
/* 1089 */       break;
/*      */     case -4: case -3: case -2: case -1: case 0: case 1: default: 
/* 1091 */       retVal = true;
/*      */     }
/* 1093 */     return retVal;
/*      */   }
/*      */ }


/* Location:              C:\Users\Static\Desktop\G10_Prototype_Server.jar!\mysql-connector-java-5.1.19-bin.jar!\com\mysql\jdbc\Field.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */