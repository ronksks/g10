/*    */ package com.mysql.jdbc.authentication;
/*    */ 
/*    */ import com.mysql.jdbc.AuthenticationPlugin;
/*    */ import com.mysql.jdbc.Buffer;
/*    */ import com.mysql.jdbc.Connection;
/*    */ import com.mysql.jdbc.StringUtils;
/*    */ import com.mysql.jdbc.Util;
/*    */ import java.sql.SQLException;
/*    */ import java.util.List;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MysqlOldPasswordPlugin
/*    */   implements AuthenticationPlugin
/*    */ {
/*    */   private Properties properties;
/* 44 */   private String password = null;
/*    */   
/*    */   public void init(Connection conn, Properties props) throws SQLException {
/* 47 */     this.properties = props;
/*    */   }
/*    */   
/*    */   public void destroy() {
/* 51 */     this.password = null;
/*    */   }
/*    */   
/*    */   public String getProtocolPluginName() {
/* 55 */     return "mysql_old_password";
/*    */   }
/*    */   
/*    */   public boolean requiresConfidentiality() {
/* 59 */     return false;
/*    */   }
/*    */   
/*    */   public boolean isReusable() {
/* 63 */     return true;
/*    */   }
/*    */   
/*    */   public void setAuthenticationParameters(String user, String password) {
/* 67 */     this.password = password;
/*    */   }
/*    */   
/*    */   public boolean nextAuthenticationStep(Buffer fromServer, List<Buffer> toServer) {
/* 71 */     toServer.clear();
/*    */     
/* 73 */     Buffer bresp = null;
/*    */     
/* 75 */     String pwd = this.password;
/* 76 */     if (pwd == null) { pwd = this.properties.getProperty("password");
/*    */     }
/* 78 */     if ((fromServer == null) || (pwd == null) || (pwd.length() == 0)) {
/* 79 */       bresp = new Buffer(new byte[0]);
/*    */     } else {
/* 81 */       bresp = new Buffer(StringUtils.getBytes(Util.oldCrypt(pwd, fromServer.readString())));
/*    */     }
/* 83 */     toServer.add(bresp);
/*    */     
/* 85 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Static\Desktop\G10_Prototype_Server.jar!\mysql-connector-java-5.1.19-bin.jar!\com\mysql\jdbc\authentication\MysqlOldPasswordPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */