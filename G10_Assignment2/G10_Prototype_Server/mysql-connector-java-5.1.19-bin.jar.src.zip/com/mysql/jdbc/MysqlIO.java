/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.authentication.MysqlNativePasswordPlugin;
/*      */ import com.mysql.jdbc.authentication.MysqlOldPasswordPlugin;
/*      */ import com.mysql.jdbc.exceptions.MySQLStatementCancelledException;
/*      */ import com.mysql.jdbc.exceptions.MySQLTimeoutException;
/*      */ import com.mysql.jdbc.log.Log;
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import com.mysql.jdbc.profiler.ProfilerEventHandler;
/*      */ import com.mysql.jdbc.util.ReadAheadInputStream;
/*      */ import com.mysql.jdbc.util.ResultSetUtil;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.EOFException;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.management.ManagementFactory;
/*      */ import java.lang.management.ThreadInfo;
/*      */ import java.lang.management.ThreadMXBean;
/*      */ import java.lang.ref.SoftReference;
/*      */ import java.math.BigInteger;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.Socket;
/*      */ import java.net.SocketException;
/*      */ import java.net.URL;
/*      */ import java.security.NoSuchAlgorithmException;
/*      */ import java.sql.Connection;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.zip.Deflater;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MysqlIO
/*      */ {
/*      */   private static final int UTF8_CHARSET_INDEX = 33;
/*      */   private static final String CODE_PAGE_1252 = "Cp1252";
/*      */   protected static final int NULL_LENGTH = -1;
/*      */   protected static final int COMP_HEADER_LENGTH = 3;
/*      */   protected static final int MIN_COMPRESS_LEN = 50;
/*      */   protected static final int HEADER_LENGTH = 4;
/*      */   protected static final int AUTH_411_OVERHEAD = 33;
/*   85 */   private static int maxBufferSize = 65535;
/*      */   
/*      */   private static final int CLIENT_COMPRESS = 32;
/*      */   
/*      */   protected static final int CLIENT_CONNECT_WITH_DB = 8;
/*      */   
/*      */   private static final int CLIENT_FOUND_ROWS = 2;
/*      */   
/*      */   private static final int CLIENT_LOCAL_FILES = 128;
/*      */   
/*      */   private static final int CLIENT_LONG_FLAG = 4;
/*      */   
/*      */   private static final int CLIENT_LONG_PASSWORD = 1;
/*      */   
/*      */   private static final int CLIENT_PROTOCOL_41 = 512;
/*      */   
/*      */   private static final int CLIENT_INTERACTIVE = 1024;
/*      */   
/*      */   protected static final int CLIENT_SSL = 2048;
/*      */   
/*      */   private static final int CLIENT_TRANSACTIONS = 8192;
/*      */   protected static final int CLIENT_RESERVED = 16384;
/*      */   protected static final int CLIENT_SECURE_CONNECTION = 32768;
/*      */   private static final int CLIENT_MULTI_QUERIES = 65536;
/*      */   private static final int CLIENT_MULTI_RESULTS = 131072;
/*      */   private static final int CLIENT_PLUGIN_AUTH = 524288;
/*      */   private static final int SERVER_STATUS_IN_TRANS = 1;
/*      */   private static final int SERVER_STATUS_AUTOCOMMIT = 2;
/*      */   static final int SERVER_MORE_RESULTS_EXISTS = 8;
/*      */   private static final int SERVER_QUERY_NO_GOOD_INDEX_USED = 16;
/*      */   private static final int SERVER_QUERY_NO_INDEX_USED = 32;
/*      */   private static final int SERVER_QUERY_WAS_SLOW = 2048;
/*      */   private static final int SERVER_STATUS_CURSOR_EXISTS = 64;
/*      */   private static final String FALSE_SCRAMBLE = "xxxxxxxx";
/*      */   protected static final int MAX_QUERY_SIZE_TO_LOG = 1024;
/*      */   protected static final int MAX_QUERY_SIZE_TO_EXPLAIN = 1048576;
/*      */   protected static final int INITIAL_PACKET_SIZE = 1024;
/*  122 */   private static String jvmPlatformCharset = null;
/*      */   
/*      */   protected static final String ZERO_DATE_VALUE_MARKER = "0000-00-00";
/*      */   
/*      */   protected static final String ZERO_DATETIME_VALUE_MARKER = "0000-00-00 00:00:00";
/*      */   
/*      */   private static final int MAX_PACKET_DUMP_LENGTH = 1024;
/*      */   
/*      */   static
/*      */   {
/*  132 */     OutputStreamWriter outWriter = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  140 */       outWriter = new OutputStreamWriter(new ByteArrayOutputStream());
/*  141 */       jvmPlatformCharset = outWriter.getEncoding();
/*      */     } finally {
/*      */       try {
/*  144 */         if (outWriter != null) {
/*  145 */           outWriter.close();
/*      */         }
/*      */       }
/*      */       catch (IOException ioEx) {}
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  155 */   private boolean packetSequenceReset = false;
/*      */   
/*      */ 
/*      */ 
/*      */   protected int serverCharsetIndex;
/*      */   
/*      */ 
/*      */ 
/*  163 */   private Buffer reusablePacket = null;
/*  164 */   private Buffer sendPacket = null;
/*  165 */   private Buffer sharedSendPacket = null;
/*      */   
/*      */ 
/*  168 */   protected BufferedOutputStream mysqlOutput = null;
/*      */   protected MySQLConnection connection;
/*  170 */   private Deflater deflater = null;
/*  171 */   protected InputStream mysqlInput = null;
/*  172 */   private LinkedList packetDebugRingBuffer = null;
/*  173 */   private RowData streamingData = null;
/*      */   
/*      */ 
/*  176 */   protected Socket mysqlConnection = null;
/*  177 */   protected SocketFactory socketFactory = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private SoftReference loadFileBufRef;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private SoftReference splitBufRef;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  193 */   protected String host = null;
/*      */   protected String seed;
/*  195 */   private String serverVersion = null;
/*  196 */   private String socketFactoryClassName = null;
/*  197 */   private byte[] packetHeaderBuf = new byte[4];
/*  198 */   private boolean colDecimalNeedsBump = false;
/*  199 */   private boolean hadWarnings = false;
/*  200 */   private boolean has41NewNewProt = false;
/*      */   
/*      */ 
/*  203 */   private boolean hasLongColumnInfo = false;
/*  204 */   private boolean isInteractiveClient = false;
/*  205 */   private boolean logSlowQueries = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  211 */   private boolean platformDbCharsetMatches = true;
/*  212 */   private boolean profileSql = false;
/*  213 */   private boolean queryBadIndexUsed = false;
/*  214 */   private boolean queryNoIndexUsed = false;
/*  215 */   private boolean serverQueryWasSlow = false;
/*      */   
/*      */ 
/*  218 */   private boolean use41Extensions = false;
/*  219 */   private boolean useCompression = false;
/*  220 */   private boolean useNewLargePackets = false;
/*  221 */   private boolean useNewUpdateCounts = false;
/*  222 */   private byte packetSequence = 0;
/*  223 */   private byte readPacketSequence = -1;
/*  224 */   private boolean checkPacketSequence = false;
/*  225 */   private byte protocolVersion = 0;
/*  226 */   private int maxAllowedPacket = 1048576;
/*  227 */   protected int maxThreeBytes = 16581375;
/*  228 */   protected int port = 3306;
/*      */   protected int serverCapabilities;
/*  230 */   private int serverMajorVersion = 0;
/*  231 */   private int serverMinorVersion = 0;
/*  232 */   private int oldServerStatus = 0;
/*  233 */   private int serverStatus = 0;
/*  234 */   private int serverSubMinorVersion = 0;
/*  235 */   private int warningCount = 0;
/*  236 */   protected long clientParam = 0L;
/*  237 */   protected long lastPacketSentTimeMs = 0L;
/*  238 */   protected long lastPacketReceivedTimeMs = 0L;
/*  239 */   private boolean traceProtocol = false;
/*  240 */   private boolean enablePacketDebug = false;
/*      */   private boolean useConnectWithDb;
/*      */   private boolean needToGrabQueryFromPacket;
/*      */   private boolean autoGenerateTestcaseScript;
/*      */   private long threadId;
/*      */   private boolean useNanosForElapsedTime;
/*      */   private long slowQueryThreshold;
/*      */   private String queryTimingUnits;
/*  248 */   private boolean useDirectRowUnpack = true;
/*      */   private int useBufferRowSizeThreshold;
/*  250 */   private int commandCount = 0;
/*      */   private List statementInterceptors;
/*      */   private ExceptionInterceptor exceptionInterceptor;
/*  253 */   private int authPluginDataLength = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MysqlIO(String host, int port, Properties props, String socketFactoryClassName, MySQLConnection conn, int socketTimeout, int useBufferRowSizeThreshold)
/*      */     throws IOException, SQLException
/*      */   {
/*  272 */     this.connection = conn;
/*      */     
/*  274 */     if (this.connection.getEnablePacketDebug()) {
/*  275 */       this.packetDebugRingBuffer = new LinkedList();
/*      */     }
/*  277 */     this.traceProtocol = this.connection.getTraceProtocol();
/*      */     
/*      */ 
/*  280 */     this.useAutoSlowLog = this.connection.getAutoSlowLog();
/*      */     
/*  282 */     this.useBufferRowSizeThreshold = useBufferRowSizeThreshold;
/*  283 */     this.useDirectRowUnpack = this.connection.getUseDirectRowUnpack();
/*      */     
/*  285 */     this.logSlowQueries = this.connection.getLogSlowQueries();
/*      */     
/*  287 */     this.reusablePacket = new Buffer(1024);
/*  288 */     this.sendPacket = new Buffer(1024);
/*      */     
/*  290 */     this.port = port;
/*  291 */     this.host = host;
/*      */     
/*  293 */     this.socketFactoryClassName = socketFactoryClassName;
/*  294 */     this.socketFactory = createSocketFactory();
/*  295 */     this.exceptionInterceptor = this.connection.getExceptionInterceptor();
/*      */     try
/*      */     {
/*  298 */       this.mysqlConnection = this.socketFactory.connect(this.host, this.port, props);
/*      */       
/*      */ 
/*      */ 
/*  302 */       if (socketTimeout != 0) {
/*      */         try {
/*  304 */           this.mysqlConnection.setSoTimeout(socketTimeout);
/*      */         }
/*      */         catch (Exception ex) {}
/*      */       }
/*      */       
/*      */ 
/*  310 */       this.mysqlConnection = this.socketFactory.beforeHandshake();
/*      */       
/*  312 */       if (this.connection.getUseReadAheadInput()) {
/*  313 */         this.mysqlInput = new ReadAheadInputStream(this.mysqlConnection.getInputStream(), 16384, this.connection.getTraceProtocol(), this.connection.getLog());
/*      */ 
/*      */       }
/*  316 */       else if (this.connection.useUnbufferedInput()) {
/*  317 */         this.mysqlInput = this.mysqlConnection.getInputStream();
/*      */       } else {
/*  319 */         this.mysqlInput = new BufferedInputStream(this.mysqlConnection.getInputStream(), 16384);
/*      */       }
/*      */       
/*      */ 
/*  323 */       this.mysqlOutput = new BufferedOutputStream(this.mysqlConnection.getOutputStream(), 16384);
/*      */       
/*      */ 
/*      */ 
/*  327 */       this.isInteractiveClient = this.connection.getInteractiveClient();
/*  328 */       this.profileSql = this.connection.getProfileSql();
/*  329 */       this.autoGenerateTestcaseScript = this.connection.getAutoGenerateTestcaseScript();
/*      */       
/*  331 */       this.needToGrabQueryFromPacket = ((this.profileSql) || (this.logSlowQueries) || (this.autoGenerateTestcaseScript));
/*      */       
/*      */ 
/*      */ 
/*  335 */       if ((this.connection.getUseNanosForElapsedTime()) && (Util.nanoTimeAvailable()))
/*      */       {
/*  337 */         this.useNanosForElapsedTime = true;
/*      */         
/*  339 */         this.queryTimingUnits = Messages.getString("Nanoseconds");
/*      */       } else {
/*  341 */         this.queryTimingUnits = Messages.getString("Milliseconds");
/*      */       }
/*      */       
/*  344 */       if (this.connection.getLogSlowQueries()) {
/*  345 */         calculateSlowQueryThreshold();
/*      */       }
/*      */     } catch (IOException ioEx) {
/*  348 */       throw SQLError.createCommunicationsException(this.connection, 0L, 0L, ioEx, getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean hasLongColumnInfo()
/*      */   {
/*  358 */     return this.hasLongColumnInfo;
/*      */   }
/*      */   
/*      */   protected boolean isDataAvailable() throws SQLException {
/*      */     try {
/*  363 */       return this.mysqlInput.available() > 0;
/*      */     } catch (IOException ioEx) {
/*  365 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected long getLastPacketSentTimeMs()
/*      */   {
/*  376 */     return this.lastPacketSentTimeMs;
/*      */   }
/*      */   
/*      */   protected long getLastPacketReceivedTimeMs() {
/*  380 */     return this.lastPacketReceivedTimeMs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ResultSetImpl getResultSet(StatementImpl callingStatement, long columnCount, int maxRows, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, boolean isBinaryEncoded, Field[] metadataFromCache)
/*      */     throws SQLException
/*      */   {
/*  410 */     Field[] fields = null;
/*      */     
/*      */ 
/*      */ 
/*  414 */     if (metadataFromCache == null) {
/*  415 */       fields = new Field[(int)columnCount];
/*      */       
/*  417 */       for (int i = 0; i < columnCount; i++) {
/*  418 */         Buffer fieldPacket = null;
/*      */         
/*  420 */         fieldPacket = readPacket();
/*  421 */         fields[i] = unpackField(fieldPacket, false);
/*      */       }
/*      */     } else {
/*  424 */       for (int i = 0; i < columnCount; i++) {
/*  425 */         skipPacket();
/*      */       }
/*      */     }
/*      */     
/*  429 */     Buffer packet = reuseAndReadPacket(this.reusablePacket);
/*      */     
/*  431 */     readServerStatusForResultSets(packet);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  437 */     if ((this.connection.versionMeetsMinimum(5, 0, 2)) && (this.connection.getUseCursorFetch()) && (isBinaryEncoded) && (callingStatement != null) && (callingStatement.getFetchSize() != 0) && (callingStatement.getResultSetType() == 1003))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  443 */       ServerPreparedStatement prepStmt = (ServerPreparedStatement)callingStatement;
/*      */       
/*  445 */       boolean usingCursor = true;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  453 */       if (this.connection.versionMeetsMinimum(5, 0, 5)) {
/*  454 */         usingCursor = (this.serverStatus & 0x40) != 0;
/*      */       }
/*      */       
/*      */ 
/*  458 */       if (usingCursor) {
/*  459 */         RowData rows = new RowDataCursor(this, prepStmt, fields);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  464 */         ResultSetImpl rs = buildResultSetWithRows(callingStatement, catalog, fields, rows, resultSetType, resultSetConcurrency, isBinaryEncoded);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  470 */         if (usingCursor) {
/*  471 */           rs.setFetchSize(callingStatement.getFetchSize());
/*      */         }
/*      */         
/*  474 */         return rs;
/*      */       }
/*      */     }
/*      */     
/*  478 */     RowData rowData = null;
/*      */     
/*  480 */     if (!streamResults) {
/*  481 */       rowData = readSingleRowSet(columnCount, maxRows, resultSetConcurrency, isBinaryEncoded, metadataFromCache == null ? fields : metadataFromCache);
/*      */     }
/*      */     else
/*      */     {
/*  485 */       rowData = new RowDataDynamic(this, (int)columnCount, metadataFromCache == null ? fields : metadataFromCache, isBinaryEncoded);
/*      */       
/*      */ 
/*  488 */       this.streamingData = rowData;
/*      */     }
/*      */     
/*  491 */     ResultSetImpl rs = buildResultSetWithRows(callingStatement, catalog, metadataFromCache == null ? fields : metadataFromCache, rowData, resultSetType, resultSetConcurrency, isBinaryEncoded);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  497 */     return rs;
/*      */   }
/*      */   
/*      */   protected final void forceClose()
/*      */   {
/*      */     try
/*      */     {
/*      */       try
/*      */       {
/*  506 */         if (this.mysqlInput != null) {
/*  507 */           this.mysqlInput.close();
/*      */         }
/*      */       } finally {
/*  510 */         if ((this.mysqlConnection != null) && (!this.mysqlConnection.isClosed()) && (!this.mysqlConnection.isInputShutdown())) {
/*      */           try {
/*  512 */             this.mysqlConnection.shutdownInput();
/*      */ 
/*      */           }
/*      */           catch (UnsupportedOperationException ex) {}
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (IOException ioEx)
/*      */     {
/*  521 */       this.mysqlInput = null;
/*      */     }
/*      */     try
/*      */     {
/*      */       try {
/*  526 */         if (this.mysqlOutput != null) {
/*  527 */           this.mysqlOutput.close();
/*      */         }
/*      */       } finally {
/*  530 */         if ((this.mysqlConnection != null) && (!this.mysqlConnection.isClosed()) && (!this.mysqlConnection.isOutputShutdown())) {
/*      */           try {
/*  532 */             this.mysqlConnection.shutdownOutput();
/*      */ 
/*      */           }
/*      */           catch (UnsupportedOperationException ex) {}
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (IOException ioEx)
/*      */     {
/*  541 */       this.mysqlOutput = null;
/*      */     }
/*      */     try
/*      */     {
/*  545 */       if (this.mysqlConnection != null) {
/*  546 */         this.mysqlConnection.close();
/*      */       }
/*      */     }
/*      */     catch (IOException ioEx)
/*      */     {
/*  551 */       this.mysqlConnection = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void skipPacket()
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  564 */       int lengthRead = readFully(this.mysqlInput, this.packetHeaderBuf, 0, 4);
/*      */       
/*      */ 
/*  567 */       if (lengthRead < 4) {
/*  568 */         forceClose();
/*  569 */         throw new IOException(Messages.getString("MysqlIO.1"));
/*      */       }
/*      */       
/*  572 */       int packetLength = (this.packetHeaderBuf[0] & 0xFF) + ((this.packetHeaderBuf[1] & 0xFF) << 8) + ((this.packetHeaderBuf[2] & 0xFF) << 16);
/*      */       
/*      */ 
/*      */ 
/*  576 */       if (this.traceProtocol) {
/*  577 */         StringBuffer traceMessageBuf = new StringBuffer();
/*      */         
/*  579 */         traceMessageBuf.append(Messages.getString("MysqlIO.2"));
/*  580 */         traceMessageBuf.append(packetLength);
/*  581 */         traceMessageBuf.append(Messages.getString("MysqlIO.3"));
/*  582 */         traceMessageBuf.append(StringUtils.dumpAsHex(this.packetHeaderBuf, 4));
/*      */         
/*      */ 
/*  585 */         this.connection.getLog().logTrace(traceMessageBuf.toString());
/*      */       }
/*      */       
/*  588 */       byte multiPacketSeq = this.packetHeaderBuf[3];
/*      */       
/*  590 */       if (!this.packetSequenceReset) {
/*  591 */         if ((this.enablePacketDebug) && (this.checkPacketSequence)) {
/*  592 */           checkPacketSequencing(multiPacketSeq);
/*      */         }
/*      */       } else {
/*  595 */         this.packetSequenceReset = false;
/*      */       }
/*      */       
/*  598 */       this.readPacketSequence = multiPacketSeq;
/*      */       
/*  600 */       skipFully(this.mysqlInput, packetLength);
/*      */     } catch (IOException ioEx) {
/*  602 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     }
/*      */     catch (OutOfMemoryError oom) {
/*      */       try {
/*  606 */         this.connection.realClose(false, false, true, oom);
/*      */       }
/*      */       finally {}
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final Buffer readPacket()
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  624 */       int lengthRead = readFully(this.mysqlInput, this.packetHeaderBuf, 0, 4);
/*      */       
/*      */ 
/*  627 */       if (lengthRead < 4) {
/*  628 */         forceClose();
/*  629 */         throw new IOException(Messages.getString("MysqlIO.1"));
/*      */       }
/*      */       
/*  632 */       int packetLength = (this.packetHeaderBuf[0] & 0xFF) + ((this.packetHeaderBuf[1] & 0xFF) << 8) + ((this.packetHeaderBuf[2] & 0xFF) << 16);
/*      */       
/*      */ 
/*      */ 
/*  636 */       if (packetLength > this.maxAllowedPacket) {
/*  637 */         throw new PacketTooBigException(packetLength, this.maxAllowedPacket);
/*      */       }
/*      */       
/*  640 */       if (this.traceProtocol) {
/*  641 */         StringBuffer traceMessageBuf = new StringBuffer();
/*      */         
/*  643 */         traceMessageBuf.append(Messages.getString("MysqlIO.2"));
/*  644 */         traceMessageBuf.append(packetLength);
/*  645 */         traceMessageBuf.append(Messages.getString("MysqlIO.3"));
/*  646 */         traceMessageBuf.append(StringUtils.dumpAsHex(this.packetHeaderBuf, 4));
/*      */         
/*      */ 
/*  649 */         this.connection.getLog().logTrace(traceMessageBuf.toString());
/*      */       }
/*      */       
/*  652 */       byte multiPacketSeq = this.packetHeaderBuf[3];
/*      */       
/*  654 */       if (!this.packetSequenceReset) {
/*  655 */         if ((this.enablePacketDebug) && (this.checkPacketSequence)) {
/*  656 */           checkPacketSequencing(multiPacketSeq);
/*      */         }
/*      */       } else {
/*  659 */         this.packetSequenceReset = false;
/*      */       }
/*      */       
/*  662 */       this.readPacketSequence = multiPacketSeq;
/*      */       
/*      */ 
/*  665 */       byte[] buffer = new byte[packetLength + 1];
/*  666 */       int numBytesRead = readFully(this.mysqlInput, buffer, 0, packetLength);
/*      */       
/*      */ 
/*  669 */       if (numBytesRead != packetLength) {
/*  670 */         throw new IOException("Short read, expected " + packetLength + " bytes, only read " + numBytesRead);
/*      */       }
/*      */       
/*      */ 
/*  674 */       buffer[packetLength] = 0;
/*      */       
/*  676 */       Buffer packet = new Buffer(buffer);
/*  677 */       packet.setBufLength(packetLength + 1);
/*      */       
/*  679 */       if (this.traceProtocol) {
/*  680 */         StringBuffer traceMessageBuf = new StringBuffer();
/*      */         
/*  682 */         traceMessageBuf.append(Messages.getString("MysqlIO.4"));
/*  683 */         traceMessageBuf.append(getPacketDumpToLog(packet, packetLength));
/*      */         
/*      */ 
/*  686 */         this.connection.getLog().logTrace(traceMessageBuf.toString());
/*      */       }
/*      */       
/*  689 */       if (this.enablePacketDebug) {
/*  690 */         enqueuePacketForDebugging(false, false, 0, this.packetHeaderBuf, packet);
/*      */       }
/*      */       
/*      */ 
/*  694 */       if (this.connection.getMaintainTimeStats()) {
/*  695 */         this.lastPacketReceivedTimeMs = System.currentTimeMillis();
/*      */       }
/*      */       
/*  698 */       return packet;
/*      */     } catch (IOException ioEx) {
/*  700 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     }
/*      */     catch (OutOfMemoryError oom) {
/*      */       try {
/*  704 */         this.connection.realClose(false, false, true, oom);
/*      */       }
/*      */       finally {}
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     label459:
/*      */     
/*      */ 
/*      */ 
/*      */     break label459;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final Field unpackField(Buffer packet, boolean extractDefaultValues)
/*      */     throws SQLException
/*      */   {
/*  724 */     if (this.use41Extensions)
/*      */     {
/*      */ 
/*  727 */       if (this.has41NewNewProt)
/*      */       {
/*  729 */         int catalogNameStart = packet.getPosition() + 1;
/*  730 */         int catalogNameLength = packet.fastSkipLenString();
/*  731 */         catalogNameStart = adjustStartForFieldLength(catalogNameStart, catalogNameLength);
/*      */       }
/*      */       
/*  734 */       int databaseNameStart = packet.getPosition() + 1;
/*  735 */       int databaseNameLength = packet.fastSkipLenString();
/*  736 */       databaseNameStart = adjustStartForFieldLength(databaseNameStart, databaseNameLength);
/*      */       
/*  738 */       int tableNameStart = packet.getPosition() + 1;
/*  739 */       int tableNameLength = packet.fastSkipLenString();
/*  740 */       tableNameStart = adjustStartForFieldLength(tableNameStart, tableNameLength);
/*      */       
/*      */ 
/*  743 */       int originalTableNameStart = packet.getPosition() + 1;
/*  744 */       int originalTableNameLength = packet.fastSkipLenString();
/*  745 */       originalTableNameStart = adjustStartForFieldLength(originalTableNameStart, originalTableNameLength);
/*      */       
/*      */ 
/*  748 */       int nameStart = packet.getPosition() + 1;
/*  749 */       int nameLength = packet.fastSkipLenString();
/*      */       
/*  751 */       nameStart = adjustStartForFieldLength(nameStart, nameLength);
/*      */       
/*      */ 
/*  754 */       int originalColumnNameStart = packet.getPosition() + 1;
/*  755 */       int originalColumnNameLength = packet.fastSkipLenString();
/*  756 */       originalColumnNameStart = adjustStartForFieldLength(originalColumnNameStart, originalColumnNameLength);
/*      */       
/*  758 */       packet.readByte();
/*      */       
/*  760 */       short charSetNumber = (short)packet.readInt();
/*      */       
/*  762 */       long colLength = 0L;
/*      */       
/*  764 */       if (this.has41NewNewProt) {
/*  765 */         colLength = packet.readLong();
/*      */       } else {
/*  767 */         colLength = packet.readLongInt();
/*      */       }
/*      */       
/*  770 */       int colType = packet.readByte() & 0xFF;
/*      */       
/*  772 */       short colFlag = 0;
/*      */       
/*  774 */       if (this.hasLongColumnInfo) {
/*  775 */         colFlag = (short)packet.readInt();
/*      */       } else {
/*  777 */         colFlag = (short)(packet.readByte() & 0xFF);
/*      */       }
/*      */       
/*  780 */       int colDecimals = packet.readByte() & 0xFF;
/*      */       
/*  782 */       int defaultValueStart = -1;
/*  783 */       int defaultValueLength = -1;
/*      */       
/*  785 */       if (extractDefaultValues) {
/*  786 */         defaultValueStart = packet.getPosition() + 1;
/*  787 */         defaultValueLength = packet.fastSkipLenString();
/*      */       }
/*      */       
/*  790 */       Field field = new Field(this.connection, packet.getByteBuffer(), databaseNameStart, databaseNameLength, tableNameStart, tableNameLength, originalTableNameStart, originalTableNameLength, nameStart, nameLength, originalColumnNameStart, originalColumnNameLength, colLength, colType, colFlag, colDecimals, defaultValueStart, defaultValueLength, charSetNumber);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  798 */       return field;
/*      */     }
/*      */     
/*  801 */     int tableNameStart = packet.getPosition() + 1;
/*  802 */     int tableNameLength = packet.fastSkipLenString();
/*  803 */     tableNameStart = adjustStartForFieldLength(tableNameStart, tableNameLength);
/*      */     
/*  805 */     int nameStart = packet.getPosition() + 1;
/*  806 */     int nameLength = packet.fastSkipLenString();
/*  807 */     nameStart = adjustStartForFieldLength(nameStart, nameLength);
/*      */     
/*  809 */     int colLength = packet.readnBytes();
/*  810 */     int colType = packet.readnBytes();
/*  811 */     packet.readByte();
/*      */     
/*  813 */     short colFlag = 0;
/*      */     
/*  815 */     if (this.hasLongColumnInfo) {
/*  816 */       colFlag = (short)packet.readInt();
/*      */     } else {
/*  818 */       colFlag = (short)(packet.readByte() & 0xFF);
/*      */     }
/*      */     
/*  821 */     int colDecimals = packet.readByte() & 0xFF;
/*      */     
/*  823 */     if (this.colDecimalNeedsBump) {
/*  824 */       colDecimals++;
/*      */     }
/*      */     
/*  827 */     Field field = new Field(this.connection, packet.getByteBuffer(), nameStart, nameLength, tableNameStart, tableNameLength, colLength, colType, colFlag, colDecimals);
/*      */     
/*      */ 
/*      */ 
/*  831 */     return field;
/*      */   }
/*      */   
/*      */   private int adjustStartForFieldLength(int nameStart, int nameLength) {
/*  835 */     if (nameLength < 251) {
/*  836 */       return nameStart;
/*      */     }
/*      */     
/*  839 */     if ((nameLength >= 251) && (nameLength < 65536)) {
/*  840 */       return nameStart + 2;
/*      */     }
/*      */     
/*  843 */     if ((nameLength >= 65536) && (nameLength < 16777216)) {
/*  844 */       return nameStart + 3;
/*      */     }
/*      */     
/*  847 */     return nameStart + 8;
/*      */   }
/*      */   
/*      */   protected boolean isSetNeededForAutoCommitMode(boolean autoCommitFlag) {
/*  851 */     if ((this.use41Extensions) && (this.connection.getElideSetAutoCommits())) {
/*  852 */       boolean autoCommitModeOnServer = (this.serverStatus & 0x2) != 0;
/*      */       
/*      */ 
/*  855 */       if ((!autoCommitFlag) && (versionMeetsMinimum(5, 0, 0)))
/*      */       {
/*      */ 
/*      */ 
/*  859 */         boolean inTransactionOnServer = (this.serverStatus & 0x1) != 0;
/*      */         
/*      */ 
/*  862 */         return !inTransactionOnServer;
/*      */       }
/*      */       
/*  865 */       return autoCommitModeOnServer != autoCommitFlag;
/*      */     }
/*      */     
/*  868 */     return true;
/*      */   }
/*      */   
/*      */   protected boolean inTransactionOnServer() {
/*  872 */     return (this.serverStatus & 0x1) != 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void changeUser(String userName, String password, String database)
/*      */     throws SQLException
/*      */   {
/*  886 */     this.packetSequence = -1;
/*      */     
/*  888 */     int passwordLength = 16;
/*  889 */     int userLength = userName != null ? userName.length() : 0;
/*  890 */     int databaseLength = database != null ? database.length() : 0;
/*      */     
/*  892 */     int packLength = (userLength + passwordLength + databaseLength) * 2 + 7 + 4 + 33;
/*      */     
/*  894 */     if ((this.serverCapabilities & 0x80000) != 0)
/*      */     {
/*  896 */       proceedHandshakeWithPluggableAuthentication(userName, password, database, null);
/*      */     }
/*  898 */     else if ((this.serverCapabilities & 0x8000) != 0) {
/*  899 */       Buffer changeUserPacket = new Buffer(packLength + 1);
/*  900 */       changeUserPacket.writeByte((byte)17);
/*      */       
/*  902 */       if (versionMeetsMinimum(4, 1, 1)) {
/*  903 */         secureAuth411(changeUserPacket, packLength, userName, password, database, false);
/*      */       }
/*      */       else {
/*  906 */         secureAuth(changeUserPacket, packLength, userName, password, database, false);
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  911 */       Buffer packet = new Buffer(packLength);
/*  912 */       packet.writeByte((byte)17);
/*      */       
/*      */ 
/*  915 */       packet.writeString(userName);
/*      */       
/*  917 */       if (this.protocolVersion > 9) {
/*  918 */         packet.writeString(Util.newCrypt(password, this.seed));
/*      */       } else {
/*  920 */         packet.writeString(Util.oldCrypt(password, this.seed));
/*      */       }
/*      */       
/*  923 */       boolean localUseConnectWithDb = (this.useConnectWithDb) && (database != null) && (database.length() > 0);
/*      */       
/*      */ 
/*  926 */       if (localUseConnectWithDb) {
/*  927 */         packet.writeString(database);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  933 */       send(packet, packet.getPosition());
/*  934 */       checkErrorPacket();
/*      */       
/*  936 */       if (!localUseConnectWithDb) {
/*  937 */         changeDatabaseTo(database);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Buffer checkErrorPacket()
/*      */     throws SQLException
/*      */   {
/*  951 */     return checkErrorPacket(-1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void checkForCharsetMismatch()
/*      */   {
/*  958 */     if ((this.connection.getUseUnicode()) && (this.connection.getEncoding() != null))
/*      */     {
/*  960 */       String encodingToCheck = jvmPlatformCharset;
/*      */       
/*  962 */       if (encodingToCheck == null) {
/*  963 */         encodingToCheck = System.getProperty("file.encoding");
/*      */       }
/*      */       
/*  966 */       if (encodingToCheck == null) {
/*  967 */         this.platformDbCharsetMatches = false;
/*      */       } else {
/*  969 */         this.platformDbCharsetMatches = encodingToCheck.equals(this.connection.getEncoding());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected void clearInputStream() throws SQLException
/*      */   {
/*      */     try {
/*  977 */       int len = this.mysqlInput.available();
/*      */       
/*  979 */       while (len > 0) {
/*  980 */         this.mysqlInput.skip(len);
/*  981 */         len = this.mysqlInput.available();
/*      */       }
/*      */     } catch (IOException ioEx) {
/*  984 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */   protected void resetReadPacketSequence()
/*      */   {
/*  990 */     this.readPacketSequence = 0;
/*      */   }
/*      */   
/*      */   protected void dumpPacketRingBuffer() throws SQLException {
/*  994 */     if ((this.packetDebugRingBuffer != null) && (this.connection.getEnablePacketDebug()))
/*      */     {
/*  996 */       StringBuffer dumpBuffer = new StringBuffer();
/*      */       
/*  998 */       dumpBuffer.append("Last " + this.packetDebugRingBuffer.size() + " packets received from server, from oldest->newest:\n");
/*      */       
/* 1000 */       dumpBuffer.append("\n");
/*      */       
/* 1002 */       Iterator ringBufIter = this.packetDebugRingBuffer.iterator();
/* 1003 */       while (ringBufIter.hasNext()) {
/* 1004 */         dumpBuffer.append((StringBuffer)ringBufIter.next());
/* 1005 */         dumpBuffer.append("\n");
/*      */       }
/*      */       
/* 1008 */       this.connection.getLog().logTrace(dumpBuffer.toString());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void explainSlowQuery(byte[] querySQL, String truncatedQuery)
/*      */     throws SQLException
/*      */   {
/* 1022 */     if (StringUtils.startsWithIgnoreCaseAndWs(truncatedQuery, "SELECT"))
/*      */     {
/* 1024 */       PreparedStatement stmt = null;
/* 1025 */       ResultSet rs = null;
/*      */       try
/*      */       {
/* 1028 */         stmt = (PreparedStatement)this.connection.clientPrepareStatement("EXPLAIN ?");
/* 1029 */         stmt.setBytesNoEscapeNoQuotes(1, querySQL);
/* 1030 */         rs = stmt.executeQuery();
/*      */         
/* 1032 */         StringBuffer explainResults = new StringBuffer(Messages.getString("MysqlIO.8") + truncatedQuery + Messages.getString("MysqlIO.9"));
/*      */         
/*      */ 
/*      */ 
/* 1036 */         ResultSetUtil.appendResultSetSlashGStyle(explainResults, rs);
/*      */         
/* 1038 */         this.connection.getLog().logWarn(explainResults.toString());
/*      */       }
/*      */       catch (SQLException sqlEx) {}finally {
/* 1041 */         if (rs != null) {
/* 1042 */           rs.close();
/*      */         }
/*      */         
/* 1045 */         if (stmt != null) {
/* 1046 */           stmt.close();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   static int getMaxBuf()
/*      */   {
/* 1054 */     return maxBufferSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final int getServerMajorVersion()
/*      */   {
/* 1063 */     return this.serverMajorVersion;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final int getServerMinorVersion()
/*      */   {
/* 1072 */     return this.serverMinorVersion;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final int getServerSubMinorVersion()
/*      */   {
/* 1081 */     return this.serverSubMinorVersion;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   String getServerVersion()
/*      */   {
/* 1090 */     return this.serverVersion;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void doHandshake(String user, String password, String database)
/*      */     throws SQLException
/*      */   {
/* 1107 */     this.checkPacketSequence = false;
/* 1108 */     this.readPacketSequence = 0;
/*      */     
/* 1110 */     Buffer buf = readPacket();
/*      */     
/*      */ 
/* 1113 */     this.protocolVersion = buf.readByte();
/*      */     
/* 1115 */     if (this.protocolVersion == -1) {
/*      */       try {
/* 1117 */         this.mysqlConnection.close();
/*      */       }
/*      */       catch (Exception e) {}
/*      */       
/*      */ 
/* 1122 */       int errno = 2000;
/*      */       
/* 1124 */       errno = buf.readInt();
/*      */       
/* 1126 */       String serverErrorMessage = buf.readString("ASCII", getExceptionInterceptor());
/*      */       
/* 1128 */       StringBuffer errorBuf = new StringBuffer(Messages.getString("MysqlIO.10"));
/*      */       
/* 1130 */       errorBuf.append(serverErrorMessage);
/* 1131 */       errorBuf.append("\"");
/*      */       
/* 1133 */       String xOpen = SQLError.mysqlToSqlState(errno, this.connection.getUseSqlStateCodes());
/*      */       
/*      */ 
/* 1136 */       throw SQLError.createSQLException(SQLError.get(xOpen) + ", " + errorBuf.toString(), xOpen, errno, getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 1140 */     this.serverVersion = buf.readString("ASCII", getExceptionInterceptor());
/*      */     
/*      */ 
/* 1143 */     int point = this.serverVersion.indexOf('.');
/*      */     
/* 1145 */     if (point != -1) {
/*      */       try {
/* 1147 */         int n = Integer.parseInt(this.serverVersion.substring(0, point));
/* 1148 */         this.serverMajorVersion = n;
/*      */       }
/*      */       catch (NumberFormatException NFE1) {}
/*      */       
/*      */ 
/* 1153 */       String remaining = this.serverVersion.substring(point + 1, this.serverVersion.length());
/*      */       
/* 1155 */       point = remaining.indexOf('.');
/*      */       
/* 1157 */       if (point != -1) {
/*      */         try {
/* 1159 */           int n = Integer.parseInt(remaining.substring(0, point));
/* 1160 */           this.serverMinorVersion = n;
/*      */         }
/*      */         catch (NumberFormatException nfe) {}
/*      */         
/*      */ 
/* 1165 */         remaining = remaining.substring(point + 1, remaining.length());
/*      */         
/* 1167 */         int pos = 0;
/*      */         
/* 1169 */         while ((pos < remaining.length()) && 
/* 1170 */           (remaining.charAt(pos) >= '0') && (remaining.charAt(pos) <= '9'))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/* 1175 */           pos++;
/*      */         }
/*      */         try
/*      */         {
/* 1179 */           int n = Integer.parseInt(remaining.substring(0, pos));
/* 1180 */           this.serverSubMinorVersion = n;
/*      */         }
/*      */         catch (NumberFormatException nfe) {}
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1187 */     if (versionMeetsMinimum(4, 0, 8)) {
/* 1188 */       this.maxThreeBytes = 16777215;
/* 1189 */       this.useNewLargePackets = true;
/*      */     } else {
/* 1191 */       this.maxThreeBytes = 16581375;
/* 1192 */       this.useNewLargePackets = false;
/*      */     }
/*      */     
/* 1195 */     this.colDecimalNeedsBump = versionMeetsMinimum(3, 23, 0);
/* 1196 */     this.colDecimalNeedsBump = (!versionMeetsMinimum(3, 23, 15));
/* 1197 */     this.useNewUpdateCounts = versionMeetsMinimum(3, 22, 5);
/*      */     
/* 1199 */     this.threadId = buf.readLong();
/* 1200 */     this.seed = buf.readString("ASCII", getExceptionInterceptor());
/*      */     
/* 1202 */     this.serverCapabilities = 0;
/*      */     
/* 1204 */     if (buf.getPosition() < buf.getBufLength()) {
/* 1205 */       this.serverCapabilities = buf.readInt();
/*      */     }
/*      */     
/* 1208 */     if ((versionMeetsMinimum(4, 1, 1)) || ((this.protocolVersion > 9) && ((this.serverCapabilities & 0x200) != 0))) {
/* 1209 */       int position = buf.getPosition();
/*      */       
/*      */ 
/* 1212 */       this.serverCharsetIndex = (buf.readByte() & 0xFF);
/* 1213 */       this.serverStatus = buf.readInt();
/* 1214 */       checkTransactionState(0);
/*      */       
/* 1216 */       this.serverCapabilities += 65536 * buf.readInt();
/* 1217 */       this.authPluginDataLength = (buf.readByte() & 0xFF);
/*      */       
/* 1219 */       buf.setPosition(position + 16);
/*      */       
/* 1221 */       String seedPart2 = buf.readString("ASCII", getExceptionInterceptor());
/* 1222 */       StringBuffer newSeed = new StringBuffer(20);
/* 1223 */       newSeed.append(this.seed);
/* 1224 */       newSeed.append(seedPart2);
/* 1225 */       this.seed = newSeed.toString();
/*      */     }
/*      */     
/* 1228 */     if (((this.serverCapabilities & 0x20) != 0) && (this.connection.getUseCompression()))
/*      */     {
/* 1230 */       this.clientParam |= 0x20;
/*      */     }
/*      */     
/* 1233 */     this.useConnectWithDb = ((database != null) && (database.length() > 0) && (!this.connection.getCreateDatabaseIfNotExist()));
/*      */     
/*      */ 
/*      */ 
/* 1237 */     if (this.useConnectWithDb) {
/* 1238 */       this.clientParam |= 0x8;
/*      */     }
/*      */     
/* 1241 */     if (((this.serverCapabilities & 0x800) == 0) && (this.connection.getUseSSL()))
/*      */     {
/* 1243 */       if (this.connection.getRequireSSL()) {
/* 1244 */         this.connection.close();
/* 1245 */         forceClose();
/* 1246 */         throw SQLError.createSQLException(Messages.getString("MysqlIO.15"), "08001", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/* 1250 */       this.connection.setUseSSL(false);
/*      */     }
/*      */     
/* 1253 */     if ((this.serverCapabilities & 0x4) != 0)
/*      */     {
/* 1255 */       this.clientParam |= 0x4;
/* 1256 */       this.hasLongColumnInfo = true;
/*      */     }
/*      */     
/*      */ 
/* 1260 */     if (!this.connection.getUseAffectedRows()) {
/* 1261 */       this.clientParam |= 0x2;
/*      */     }
/*      */     
/* 1264 */     if (this.connection.getAllowLoadLocalInfile()) {
/* 1265 */       this.clientParam |= 0x80;
/*      */     }
/*      */     
/* 1268 */     if (this.isInteractiveClient) {
/* 1269 */       this.clientParam |= 0x400;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1275 */     if ((this.serverCapabilities & 0x80000) != 0) {
/* 1276 */       proceedHandshakeWithPluggableAuthentication(user, password, database, buf);
/* 1277 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1281 */     if (this.protocolVersion > 9) {
/* 1282 */       this.clientParam |= 1L;
/*      */     } else {
/* 1284 */       this.clientParam &= 0xFFFFFFFFFFFFFFFE;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1290 */     if ((versionMeetsMinimum(4, 1, 0)) || ((this.protocolVersion > 9) && ((this.serverCapabilities & 0x4000) != 0))) {
/* 1291 */       if ((versionMeetsMinimum(4, 1, 1)) || ((this.protocolVersion > 9) && ((this.serverCapabilities & 0x200) != 0))) {
/* 1292 */         this.clientParam |= 0x200;
/* 1293 */         this.has41NewNewProt = true;
/*      */         
/*      */ 
/* 1296 */         this.clientParam |= 0x2000;
/*      */         
/*      */ 
/* 1299 */         this.clientParam |= 0x20000;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1304 */         if (this.connection.getAllowMultiQueries()) {
/* 1305 */           this.clientParam |= 0x10000;
/*      */         }
/*      */       } else {
/* 1308 */         this.clientParam |= 0x4000;
/* 1309 */         this.has41NewNewProt = false;
/*      */       }
/*      */       
/* 1312 */       this.use41Extensions = true;
/*      */     }
/*      */     
/* 1315 */     int passwordLength = 16;
/* 1316 */     int userLength = user != null ? user.length() : 0;
/* 1317 */     int databaseLength = database != null ? database.length() : 0;
/*      */     
/* 1319 */     int packLength = (userLength + passwordLength + databaseLength) * 2 + 7 + 4 + 33;
/*      */     
/* 1321 */     Buffer packet = null;
/*      */     
/* 1323 */     if (!this.connection.getUseSSL()) {
/* 1324 */       if ((this.serverCapabilities & 0x8000) != 0) {
/* 1325 */         this.clientParam |= 0x8000;
/*      */         
/* 1327 */         if ((versionMeetsMinimum(4, 1, 1)) || ((this.protocolVersion > 9) && ((this.serverCapabilities & 0x200) != 0))) {
/* 1328 */           secureAuth411(null, packLength, user, password, database, true);
/*      */         }
/*      */         else {
/* 1331 */           secureAuth(null, packLength, user, password, database, true);
/*      */         }
/*      */       }
/*      */       else {
/* 1335 */         packet = new Buffer(packLength);
/*      */         
/* 1337 */         if ((this.clientParam & 0x4000) != 0L) {
/* 1338 */           if ((versionMeetsMinimum(4, 1, 1)) || ((this.protocolVersion > 9) && ((this.serverCapabilities & 0x200) != 0))) {
/* 1339 */             packet.writeLong(this.clientParam);
/* 1340 */             packet.writeLong(this.maxThreeBytes);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/* 1345 */             packet.writeByte((byte)8);
/*      */             
/*      */ 
/* 1348 */             packet.writeBytesNoNull(new byte[23]);
/*      */           } else {
/* 1350 */             packet.writeLong(this.clientParam);
/* 1351 */             packet.writeLong(this.maxThreeBytes);
/*      */           }
/*      */         } else {
/* 1354 */           packet.writeInt((int)this.clientParam);
/* 1355 */           packet.writeLongInt(this.maxThreeBytes);
/*      */         }
/*      */         
/*      */ 
/* 1359 */         packet.writeString(user, "Cp1252", this.connection);
/*      */         
/* 1361 */         if (this.protocolVersion > 9) {
/* 1362 */           packet.writeString(Util.newCrypt(password, this.seed), "Cp1252", this.connection);
/*      */         } else {
/* 1364 */           packet.writeString(Util.oldCrypt(password, this.seed), "Cp1252", this.connection);
/*      */         }
/*      */         
/* 1367 */         if (this.useConnectWithDb) {
/* 1368 */           packet.writeString(database, "Cp1252", this.connection);
/*      */         }
/*      */         
/* 1371 */         send(packet, packet.getPosition());
/*      */       }
/*      */     } else {
/* 1374 */       negotiateSSLConnection(user, password, database, packLength);
/*      */       
/* 1376 */       if ((this.serverCapabilities & 0x8000) != 0) {
/* 1377 */         if (versionMeetsMinimum(4, 1, 1)) {
/* 1378 */           secureAuth411(null, packLength, user, password, database, true);
/*      */         } else {
/* 1380 */           secureAuth411(null, packLength, user, password, database, true);
/*      */         }
/*      */       }
/*      */       else {
/* 1384 */         packet = new Buffer(packLength);
/*      */         
/* 1386 */         if (this.use41Extensions) {
/* 1387 */           packet.writeLong(this.clientParam);
/* 1388 */           packet.writeLong(this.maxThreeBytes);
/*      */         } else {
/* 1390 */           packet.writeInt((int)this.clientParam);
/* 1391 */           packet.writeLongInt(this.maxThreeBytes);
/*      */         }
/*      */         
/*      */ 
/* 1395 */         packet.writeString(user);
/*      */         
/* 1397 */         if (this.protocolVersion > 9) {
/* 1398 */           packet.writeString(Util.newCrypt(password, this.seed));
/*      */         } else {
/* 1400 */           packet.writeString(Util.oldCrypt(password, this.seed));
/*      */         }
/*      */         
/* 1403 */         if (((this.serverCapabilities & 0x8) != 0) && (database != null) && (database.length() > 0))
/*      */         {
/* 1405 */           packet.writeString(database);
/*      */         }
/*      */         
/* 1408 */         send(packet, packet.getPosition());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1416 */     if ((!versionMeetsMinimum(4, 1, 1)) && (this.protocolVersion > 9) && ((this.serverCapabilities & 0x200) != 0)) {
/* 1417 */       checkErrorPacket();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1423 */     if (((this.serverCapabilities & 0x20) != 0) && (this.connection.getUseCompression()))
/*      */     {
/*      */ 
/*      */ 
/* 1427 */       this.deflater = new Deflater();
/* 1428 */       this.useCompression = true;
/* 1429 */       this.mysqlInput = new CompressedInputStream(this.connection, this.mysqlInput);
/*      */     }
/*      */     
/*      */ 
/* 1433 */     if (!this.useConnectWithDb) {
/* 1434 */       changeDatabaseTo(database);
/*      */     }
/*      */     try
/*      */     {
/* 1438 */       this.mysqlConnection = this.socketFactory.afterHandshake();
/*      */     } catch (IOException ioEx) {
/* 1440 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1451 */   private Map<String, AuthenticationPlugin> authenticationPlugins = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1456 */   private List<String> disabledAuthenticationPlugins = null;
/*      */   
/*      */ 
/*      */ 
/* 1460 */   private String defaultAuthenticationPlugin = null;
/*      */   
/*      */ 
/*      */ 
/* 1464 */   private String defaultAuthenticationPluginProtocolName = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void loadAuthenticationPlugins()
/*      */     throws SQLException
/*      */   {
/* 1484 */     this.defaultAuthenticationPlugin = this.connection.getDefaultAuthenticationPlugin();
/* 1485 */     if ((this.defaultAuthenticationPlugin == null) || ("".equals(this.defaultAuthenticationPlugin.trim()))) {
/* 1486 */       throw SQLError.createSQLException(Messages.getString("Connection.BadDefaultAuthenticationPlugin", new Object[] { this.defaultAuthenticationPlugin }), getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1493 */     String disabledPlugins = this.connection.getDisabledAuthenticationPlugins();
/* 1494 */     if ((disabledPlugins != null) && (!"".equals(disabledPlugins))) {
/* 1495 */       this.disabledAuthenticationPlugins = new ArrayList();
/* 1496 */       List<String> pluginsToDisable = StringUtils.split(disabledPlugins, ",", true);
/* 1497 */       Iterator<String> iter = pluginsToDisable.iterator();
/* 1498 */       while (iter.hasNext()) {
/* 1499 */         this.disabledAuthenticationPlugins.add(iter.next());
/*      */       }
/*      */     }
/*      */     
/* 1503 */     this.authenticationPlugins = new HashMap();
/*      */     
/*      */ 
/* 1506 */     AuthenticationPlugin plugin = new MysqlOldPasswordPlugin();
/* 1507 */     plugin.init(this.connection, this.connection.getProperties());
/* 1508 */     boolean defaultIsFound = addAuthenticationPlugin(plugin);
/*      */     
/* 1510 */     plugin = new MysqlNativePasswordPlugin();
/* 1511 */     plugin.init(this.connection, this.connection.getProperties());
/* 1512 */     if (addAuthenticationPlugin(plugin)) { defaultIsFound = true;
/*      */     }
/*      */     
/* 1515 */     String authenticationPluginClasses = this.connection.getAuthenticationPlugins();
/* 1516 */     if ((authenticationPluginClasses != null) && (!"".equals(authenticationPluginClasses)))
/*      */     {
/* 1518 */       List<Extension> plugins = Util.loadExtensions(this.connection, this.connection.getProperties(), authenticationPluginClasses, "Connection.BadAuthenticationPlugin", getExceptionInterceptor());
/*      */       
/*      */ 
/*      */ 
/* 1522 */       for (Extension object : plugins) {
/* 1523 */         plugin = (AuthenticationPlugin)object;
/* 1524 */         if (addAuthenticationPlugin(plugin)) { defaultIsFound = true;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1529 */     if (!defaultIsFound) {
/* 1530 */       throw SQLError.createSQLException(Messages.getString("Connection.DefaultAuthenticationPluginIsNotListed", new Object[] { this.defaultAuthenticationPlugin }), getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean addAuthenticationPlugin(AuthenticationPlugin plugin)
/*      */     throws SQLException
/*      */   {
/* 1546 */     boolean isDefault = false;
/* 1547 */     String pluginClassName = plugin.getClass().getName();
/* 1548 */     String pluginProtocolName = plugin.getProtocolPluginName();
/* 1549 */     boolean disabledByClassName = (this.disabledAuthenticationPlugins != null) && (this.disabledAuthenticationPlugins.contains(pluginClassName));
/*      */     
/*      */ 
/* 1552 */     boolean disabledByMechanism = (this.disabledAuthenticationPlugins != null) && (this.disabledAuthenticationPlugins.contains(pluginProtocolName));
/*      */     
/*      */ 
/*      */ 
/* 1556 */     if ((disabledByClassName) || (disabledByMechanism))
/*      */     {
/* 1558 */       if (this.defaultAuthenticationPlugin.equals(pluginClassName)) {
/* 1559 */         throw SQLError.createSQLException(Messages.getString("Connection.BadDisabledAuthenticationPlugin", new Object[] { disabledByClassName ? pluginClassName : pluginProtocolName }), getExceptionInterceptor());
/*      */       }
/*      */       
/*      */     }
/*      */     else
/*      */     {
/* 1565 */       this.authenticationPlugins.put(pluginProtocolName, plugin);
/* 1566 */       if (this.defaultAuthenticationPlugin.equals(pluginClassName)) {
/* 1567 */         this.defaultAuthenticationPluginProtocolName = pluginProtocolName;
/* 1568 */         isDefault = true;
/*      */       }
/*      */     }
/* 1571 */     return isDefault;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AuthenticationPlugin getAuthenticationPlugin(String pluginName)
/*      */     throws SQLException
/*      */   {
/* 1591 */     AuthenticationPlugin plugin = (AuthenticationPlugin)this.authenticationPlugins.get(pluginName);
/*      */     
/* 1593 */     if ((plugin != null) && (!plugin.isReusable())) {
/*      */       try {
/* 1595 */         plugin = (AuthenticationPlugin)plugin.getClass().newInstance();
/* 1596 */         plugin.init(this.connection, this.connection.getProperties());
/*      */       } catch (Throwable t) {
/* 1598 */         SQLException sqlEx = SQLError.createSQLException(Messages.getString("Connection.BadAuthenticationPlugin", new Object[] { plugin.getClass().getName() }), getExceptionInterceptor());
/*      */         
/* 1600 */         sqlEx.initCause(t);
/* 1601 */         throw sqlEx;
/*      */       }
/*      */     }
/*      */     
/* 1605 */     return plugin;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void checkConfidentiality(AuthenticationPlugin plugin)
/*      */     throws SQLException
/*      */   {
/* 1614 */     if ((plugin.requiresConfidentiality()) && ((!this.connection.getUseSSL()) || (!this.connection.getRequireSSL()))) {
/* 1615 */       throw SQLError.createSQLException(Messages.getString("Connection.AuthenticationPluginRequiresSSL", new Object[] { plugin.getProtocolPluginName() }), getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void proceedHandshakeWithPluggableAuthentication(String user, String password, String database, Buffer challenge)
/*      */     throws SQLException
/*      */   {
/* 1642 */     if (this.authenticationPlugins == null) {
/* 1643 */       loadAuthenticationPlugins();
/*      */     }
/*      */     
/* 1646 */     int passwordLength = 16;
/* 1647 */     int userLength = user != null ? user.length() : 0;
/* 1648 */     int databaseLength = database != null ? database.length() : 0;
/*      */     
/* 1650 */     int packLength = (userLength + passwordLength + databaseLength) * 2 + 7 + 4 + 33;
/*      */     
/* 1652 */     AuthenticationPlugin plugin = null;
/* 1653 */     Buffer fromServer = null;
/* 1654 */     ArrayList<Buffer> toServer = new ArrayList();
/* 1655 */     Boolean done = null;
/* 1656 */     Buffer last_sent = null;
/*      */     
/* 1658 */     boolean old_raw_challenge = false;
/*      */     
/* 1660 */     int counter = 100;
/*      */     
/* 1662 */     while (0 < counter--)
/*      */     {
/* 1664 */       if (done == null)
/*      */       {
/* 1666 */         if (challenge != null)
/*      */         {
/*      */ 
/* 1669 */           this.clientParam |= 0xAA201;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1681 */           if (this.connection.getAllowMultiQueries()) {
/* 1682 */             this.clientParam |= 0x10000;
/*      */           }
/*      */           
/* 1685 */           this.has41NewNewProt = true;
/* 1686 */           this.use41Extensions = true;
/*      */           
/* 1688 */           if (this.connection.getUseSSL()) {
/* 1689 */             negotiateSSLConnection(user, password, database, packLength);
/*      */           }
/*      */           
/* 1692 */           String pluginName = null;
/*      */           
/* 1694 */           if ((this.serverCapabilities & 0x80000) != 0) {
/* 1695 */             if ((!versionMeetsMinimum(5, 5, 10)) || ((versionMeetsMinimum(5, 6, 0)) && (!versionMeetsMinimum(5, 6, 2)))) {
/* 1696 */               pluginName = challenge.readString("ASCII", getExceptionInterceptor(), this.authPluginDataLength);
/*      */             } else {
/* 1698 */               pluginName = challenge.readString("ASCII", getExceptionInterceptor());
/*      */             }
/*      */           }
/*      */           
/* 1702 */           plugin = getAuthenticationPlugin(pluginName);
/*      */           
/* 1704 */           if (plugin == null) { plugin = getAuthenticationPlugin(this.defaultAuthenticationPluginProtocolName);
/*      */           }
/* 1706 */           checkConfidentiality(plugin);
/* 1707 */           fromServer = new Buffer(StringUtils.getBytes(this.seed));
/*      */         }
/*      */         else {
/* 1710 */           plugin = getAuthenticationPlugin(this.defaultAuthenticationPluginProtocolName);
/* 1711 */           checkConfidentiality(plugin);
/*      */         }
/*      */         
/*      */       }
/*      */       else
/*      */       {
/* 1717 */         challenge = checkErrorPacket();
/* 1718 */         old_raw_challenge = false;
/*      */         
/* 1720 */         if (challenge.isOKPacket())
/*      */         {
/* 1722 */           if (!done.booleanValue()) {
/* 1723 */             throw SQLError.createSQLException(Messages.getString("Connection.UnexpectedAuthenticationApproval", new Object[] { plugin.getProtocolPluginName() }), getExceptionInterceptor());
/*      */           }
/* 1725 */           plugin.destroy();
/* 1726 */           break;
/*      */         }
/* 1728 */         if (challenge.isAuthMethodSwitchRequestPacket())
/*      */         {
/* 1730 */           String pluginName = challenge.readString("ASCII", getExceptionInterceptor());
/*      */           
/*      */ 
/* 1733 */           if ((plugin != null) && (!plugin.getProtocolPluginName().equals(pluginName))) {
/* 1734 */             plugin.destroy();
/* 1735 */             plugin = getAuthenticationPlugin(pluginName);
/*      */             
/* 1737 */             if (plugin == null) {
/* 1738 */               throw SQLError.createSQLException(Messages.getString("Connection.BadAuthenticationPlugin", new Object[] { pluginName }), getExceptionInterceptor());
/*      */             }
/*      */           }
/*      */           
/* 1742 */           fromServer = new Buffer(StringUtils.getBytes(challenge.readString("ASCII", getExceptionInterceptor())));
/*      */ 
/*      */ 
/*      */         }
/* 1746 */         else if (versionMeetsMinimum(5, 5, 16)) {
/* 1747 */           fromServer = new Buffer(challenge.getBytes(challenge.getPosition(), challenge.getBufLength() - challenge.getPosition()));
/*      */         } else {
/* 1749 */           old_raw_challenge = true;
/* 1750 */           fromServer = new Buffer(challenge.getBytes(challenge.getPosition() - 1, challenge.getBufLength() - challenge.getPosition() + 1));
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/* 1758 */         plugin.setAuthenticationParameters(user, password);
/* 1759 */         done = Boolean.valueOf(plugin.nextAuthenticationStep(fromServer, toServer));
/*      */       } catch (SQLException e) {
/* 1761 */         throw SQLError.createSQLException(e.getMessage(), e.getSQLState(), e, getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/* 1765 */       if (toServer.size() > 0) {
/* 1766 */         if (challenge == null)
/*      */         {
/* 1768 */           last_sent = new Buffer(packLength + 1);
/* 1769 */           last_sent.writeByte((byte)17);
/*      */           
/*      */ 
/* 1772 */           last_sent.writeString(user, "utf-8", this.connection);
/*      */           
/* 1774 */           last_sent.writeByte((byte)((Buffer)toServer.get(0)).getByteBuffer().length);
/* 1775 */           last_sent.writeBytesNoNull(((Buffer)toServer.get(0)).getByteBuffer());
/*      */           
/* 1777 */           if (this.useConnectWithDb) {
/* 1778 */             last_sent.writeString(database, "utf-8", this.connection);
/*      */           }
/*      */           else {
/* 1781 */             last_sent.writeByte((byte)0);
/*      */           }
/*      */           
/* 1784 */           if ((this.serverCapabilities & 0x80000) != 0) {
/* 1785 */             last_sent.writeString(plugin.getProtocolPluginName(), "utf-8", this.connection);
/*      */           }
/*      */           
/* 1788 */           send(last_sent, last_sent.getPosition());
/*      */         }
/* 1790 */         else if (challenge.isAuthMethodSwitchRequestPacket())
/*      */         {
/*      */ 
/* 1793 */           byte savePacketSequence = this.packetSequence++;
/* 1794 */           savePacketSequence = (byte)(savePacketSequence + 1);this.packetSequence = savePacketSequence;
/*      */           
/* 1796 */           last_sent = new Buffer(((Buffer)toServer.get(0)).getBufLength() + 4);
/* 1797 */           last_sent.writeBytesNoNull(((Buffer)toServer.get(0)).getByteBuffer());
/* 1798 */           send(last_sent, last_sent.getPosition());
/*      */         } else { byte savePacketSequence;
/* 1800 */           if ((challenge.isRawPacket()) || (old_raw_challenge))
/*      */           {
/* 1802 */             savePacketSequence = this.packetSequence++;
/*      */             
/* 1804 */             for (Buffer buffer : toServer) {
/* 1805 */               savePacketSequence = (byte)(savePacketSequence + 1);this.packetSequence = savePacketSequence;
/*      */               
/* 1807 */               last_sent = new Buffer(buffer.getBufLength() + 4);
/* 1808 */               last_sent.writeBytesNoNull(buffer.getByteBuffer());
/* 1809 */               send(last_sent, last_sent.getPosition());
/*      */             }
/*      */             
/*      */           }
/*      */           else
/*      */           {
/* 1815 */             last_sent = new Buffer(packLength);
/* 1816 */             last_sent.writeLong(this.clientParam);
/* 1817 */             last_sent.writeLong(this.maxThreeBytes);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/* 1822 */             last_sent.writeByte((byte)33);
/*      */             
/* 1824 */             last_sent.writeBytesNoNull(new byte[23]);
/*      */             
/*      */ 
/* 1827 */             last_sent.writeString(user, "utf-8", this.connection);
/*      */             
/* 1829 */             last_sent.writeByte((byte)((Buffer)toServer.get(0)).getByteBuffer().length);
/* 1830 */             last_sent.writeBytesNoNull(((Buffer)toServer.get(0)).getByteBuffer());
/*      */             
/* 1832 */             if (this.useConnectWithDb) {
/* 1833 */               last_sent.writeString(database, "utf-8", this.connection);
/*      */             }
/*      */             else {
/* 1836 */               last_sent.writeByte((byte)0);
/*      */             }
/*      */             
/* 1839 */             if ((this.serverCapabilities & 0x80000) != 0) {
/* 1840 */               last_sent.writeString(plugin.getProtocolPluginName(), "utf-8", this.connection);
/*      */             }
/*      */             
/* 1843 */             send(last_sent, last_sent.getPosition());
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1850 */     if (counter == 0) {
/* 1851 */       throw SQLError.createSQLException(Messages.getString("CommunicationsException.TooManyAuthenticationPluginNegotiations"), getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1857 */     if (((this.serverCapabilities & 0x20) != 0) && (this.connection.getUseCompression()))
/*      */     {
/*      */ 
/*      */ 
/* 1861 */       this.deflater = new Deflater();
/* 1862 */       this.useCompression = true;
/* 1863 */       this.mysqlInput = new CompressedInputStream(this.connection, this.mysqlInput);
/*      */     }
/*      */     
/* 1866 */     if (!this.useConnectWithDb) {
/* 1867 */       changeDatabaseTo(database);
/*      */     }
/*      */     try
/*      */     {
/* 1871 */       this.mysqlConnection = this.socketFactory.afterHandshake();
/*      */     } catch (IOException ioEx) {
/* 1873 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */   private void changeDatabaseTo(String database) throws SQLException {
/* 1878 */     if ((database == null) || (database.length() == 0)) {
/* 1879 */       return;
/*      */     }
/*      */     try
/*      */     {
/* 1883 */       sendCommand(2, database, null, false, null, 0);
/*      */     } catch (Exception ex) {
/* 1885 */       if (this.connection.getCreateDatabaseIfNotExist()) {
/* 1886 */         sendCommand(3, "CREATE DATABASE IF NOT EXISTS " + database, null, false, null, 0);
/*      */         
/*      */ 
/* 1889 */         sendCommand(2, database, null, false, null, 0);
/*      */       } else {
/* 1891 */         throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ex, getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final ResultSetRow nextRow(Field[] fields, int columnCount, boolean isBinaryEncoded, int resultSetConcurrency, boolean useBufferRowIfPossible, boolean useBufferRowExplicit, boolean canReuseRowPacketForBufferRow, Buffer existingRowPacket)
/*      */     throws SQLException
/*      */   {
/* 1919 */     if ((this.useDirectRowUnpack) && (existingRowPacket == null) && (!isBinaryEncoded) && (!useBufferRowIfPossible) && (!useBufferRowExplicit))
/*      */     {
/*      */ 
/* 1922 */       return nextRowFast(fields, columnCount, isBinaryEncoded, resultSetConcurrency, useBufferRowIfPossible, useBufferRowExplicit, canReuseRowPacketForBufferRow);
/*      */     }
/*      */     
/*      */ 
/* 1926 */     Buffer rowPacket = null;
/*      */     
/* 1928 */     if (existingRowPacket == null) {
/* 1929 */       rowPacket = checkErrorPacket();
/*      */       
/* 1931 */       if ((!useBufferRowExplicit) && (useBufferRowIfPossible) && 
/* 1932 */         (rowPacket.getBufLength() > this.useBufferRowSizeThreshold)) {
/* 1933 */         useBufferRowExplicit = true;
/*      */       }
/*      */       
/*      */     }
/*      */     else
/*      */     {
/* 1939 */       rowPacket = existingRowPacket;
/* 1940 */       checkErrorPacket(existingRowPacket);
/*      */     }
/*      */     
/*      */ 
/* 1944 */     if (!isBinaryEncoded)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1949 */       rowPacket.setPosition(rowPacket.getPosition() - 1);
/*      */       
/* 1951 */       if (!rowPacket.isLastDataPacket()) {
/* 1952 */         if ((resultSetConcurrency == 1008) || ((!useBufferRowIfPossible) && (!useBufferRowExplicit)))
/*      */         {
/*      */ 
/* 1955 */           byte[][] rowData = new byte[columnCount][];
/*      */           
/* 1957 */           for (int i = 0; i < columnCount; i++) {
/* 1958 */             rowData[i] = rowPacket.readLenByteArray(0);
/*      */           }
/*      */           
/* 1961 */           return new ByteArrayRow(rowData, getExceptionInterceptor());
/*      */         }
/*      */         
/* 1964 */         if (!canReuseRowPacketForBufferRow) {
/* 1965 */           this.reusablePacket = new Buffer(rowPacket.getBufLength());
/*      */         }
/*      */         
/* 1968 */         return new BufferRow(rowPacket, fields, false, getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/* 1972 */       readServerStatusForResultSets(rowPacket);
/*      */       
/* 1974 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1981 */     if (!rowPacket.isLastDataPacket()) {
/* 1982 */       if ((resultSetConcurrency == 1008) || ((!useBufferRowIfPossible) && (!useBufferRowExplicit)))
/*      */       {
/* 1984 */         return unpackBinaryResultSetRow(fields, rowPacket, resultSetConcurrency);
/*      */       }
/*      */       
/*      */ 
/* 1988 */       if (!canReuseRowPacketForBufferRow) {
/* 1989 */         this.reusablePacket = new Buffer(rowPacket.getBufLength());
/*      */       }
/*      */       
/* 1992 */       return new BufferRow(rowPacket, fields, true, getExceptionInterceptor());
/*      */     }
/*      */     
/* 1995 */     rowPacket.setPosition(rowPacket.getPosition() - 1);
/* 1996 */     readServerStatusForResultSets(rowPacket);
/*      */     
/* 1998 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   final ResultSetRow nextRowFast(Field[] fields, int columnCount, boolean isBinaryEncoded, int resultSetConcurrency, boolean useBufferRowIfPossible, boolean useBufferRowExplicit, boolean canReuseRowPacket)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 2007 */       int lengthRead = readFully(this.mysqlInput, this.packetHeaderBuf, 0, 4);
/*      */       
/*      */ 
/* 2010 */       if (lengthRead < 4) {
/* 2011 */         forceClose();
/* 2012 */         throw new RuntimeException(Messages.getString("MysqlIO.43"));
/*      */       }
/*      */       
/* 2015 */       int packetLength = (this.packetHeaderBuf[0] & 0xFF) + ((this.packetHeaderBuf[1] & 0xFF) << 8) + ((this.packetHeaderBuf[2] & 0xFF) << 16);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2020 */       if (packetLength == this.maxThreeBytes) {
/* 2021 */         reuseAndReadPacket(this.reusablePacket, packetLength);
/*      */         
/*      */ 
/* 2024 */         return nextRow(fields, columnCount, isBinaryEncoded, resultSetConcurrency, useBufferRowIfPossible, useBufferRowExplicit, canReuseRowPacket, this.reusablePacket);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2031 */       if (packetLength > this.useBufferRowSizeThreshold) {
/* 2032 */         reuseAndReadPacket(this.reusablePacket, packetLength);
/*      */         
/*      */ 
/* 2035 */         return nextRow(fields, columnCount, isBinaryEncoded, resultSetConcurrency, true, true, false, this.reusablePacket);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2040 */       int remaining = packetLength;
/*      */       
/* 2042 */       boolean firstTime = true;
/*      */       
/* 2044 */       byte[][] rowData = (byte[][])null;
/*      */       
/* 2046 */       for (int i = 0; i < columnCount; i++)
/*      */       {
/* 2048 */         int sw = this.mysqlInput.read() & 0xFF;
/* 2049 */         remaining--;
/*      */         
/* 2051 */         if (firstTime) {
/* 2052 */           if (sw == 255)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/* 2057 */             Buffer errorPacket = new Buffer(packetLength + 4);
/* 2058 */             errorPacket.setPosition(0);
/* 2059 */             errorPacket.writeByte(this.packetHeaderBuf[0]);
/* 2060 */             errorPacket.writeByte(this.packetHeaderBuf[1]);
/* 2061 */             errorPacket.writeByte(this.packetHeaderBuf[2]);
/* 2062 */             errorPacket.writeByte((byte)1);
/* 2063 */             errorPacket.writeByte((byte)sw);
/* 2064 */             readFully(this.mysqlInput, errorPacket.getByteBuffer(), 5, packetLength - 1);
/* 2065 */             errorPacket.setPosition(4);
/* 2066 */             checkErrorPacket(errorPacket);
/*      */           }
/*      */           
/* 2069 */           if ((sw == 254) && (packetLength < 9)) {
/* 2070 */             if (this.use41Extensions) {
/* 2071 */               this.warningCount = (this.mysqlInput.read() & 0xFF | (this.mysqlInput.read() & 0xFF) << 8);
/*      */               
/* 2073 */               remaining -= 2;
/*      */               
/* 2075 */               if (this.warningCount > 0) {
/* 2076 */                 this.hadWarnings = true;
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*      */ 
/* 2082 */               this.oldServerStatus = this.serverStatus;
/*      */               
/* 2084 */               this.serverStatus = (this.mysqlInput.read() & 0xFF | (this.mysqlInput.read() & 0xFF) << 8);
/*      */               
/* 2086 */               checkTransactionState(this.oldServerStatus);
/*      */               
/* 2088 */               remaining -= 2;
/*      */               
/* 2090 */               if (remaining > 0) {
/* 2091 */                 skipFully(this.mysqlInput, remaining);
/*      */               }
/*      */             }
/*      */             
/* 2095 */             return null;
/*      */           }
/*      */           
/* 2098 */           rowData = new byte[columnCount][];
/*      */           
/* 2100 */           firstTime = false;
/*      */         }
/*      */         
/* 2103 */         int len = 0;
/*      */         
/* 2105 */         switch (sw) {
/*      */         case 251: 
/* 2107 */           len = -1;
/* 2108 */           break;
/*      */         
/*      */         case 252: 
/* 2111 */           len = this.mysqlInput.read() & 0xFF | (this.mysqlInput.read() & 0xFF) << 8;
/*      */           
/* 2113 */           remaining -= 2;
/* 2114 */           break;
/*      */         
/*      */         case 253: 
/* 2117 */           len = this.mysqlInput.read() & 0xFF | (this.mysqlInput.read() & 0xFF) << 8 | (this.mysqlInput.read() & 0xFF) << 16;
/*      */           
/*      */ 
/*      */ 
/* 2121 */           remaining -= 3;
/* 2122 */           break;
/*      */         
/*      */         case 254: 
/* 2125 */           len = (int)(this.mysqlInput.read() & 0xFF | (this.mysqlInput.read() & 0xFF) << 8 | (this.mysqlInput.read() & 0xFF) << 16 | (this.mysqlInput.read() & 0xFF) << 24 | (this.mysqlInput.read() & 0xFF) << 32 | (this.mysqlInput.read() & 0xFF) << 40 | (this.mysqlInput.read() & 0xFF) << 48 | (this.mysqlInput.read() & 0xFF) << 56);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2133 */           remaining -= 8;
/* 2134 */           break;
/*      */         
/*      */         default: 
/* 2137 */           len = sw;
/*      */         }
/*      */         
/* 2140 */         if (len == -1) {
/* 2141 */           rowData[i] = null;
/* 2142 */         } else if (len == 0) {
/* 2143 */           rowData[i] = Constants.EMPTY_BYTE_ARRAY;
/*      */         } else {
/* 2145 */           rowData[i] = new byte[len];
/*      */           
/* 2147 */           int bytesRead = readFully(this.mysqlInput, rowData[i], 0, len);
/*      */           
/*      */ 
/* 2150 */           if (bytesRead != len) {
/* 2151 */             throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, new IOException(Messages.getString("MysqlIO.43")), getExceptionInterceptor());
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 2156 */           remaining -= bytesRead;
/*      */         }
/*      */       }
/*      */       
/* 2160 */       if (remaining > 0) {
/* 2161 */         skipFully(this.mysqlInput, remaining);
/*      */       }
/*      */       
/* 2164 */       return new ByteArrayRow(rowData, getExceptionInterceptor());
/*      */     } catch (IOException ioEx) {
/* 2166 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final void quit()
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*      */       try
/*      */       {
/* 2182 */         if (!this.mysqlConnection.isClosed()) {
/*      */           try {
/* 2184 */             this.mysqlConnection.shutdownInput();
/*      */           }
/*      */           catch (UnsupportedOperationException ex) {}
/*      */         }
/*      */       }
/*      */       catch (IOException ioEx) {
/* 2190 */         this.connection.getLog().logWarn("Caught while disconnecting...", ioEx);
/*      */       }
/*      */       
/* 2193 */       Buffer packet = new Buffer(6);
/* 2194 */       this.packetSequence = -1;
/* 2195 */       packet.writeByte((byte)1);
/* 2196 */       send(packet, packet.getPosition());
/*      */     } finally {
/* 2198 */       forceClose();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Buffer getSharedSendPacket()
/*      */   {
/* 2209 */     if (this.sharedSendPacket == null) {
/* 2210 */       this.sharedSendPacket = new Buffer(1024);
/*      */     }
/*      */     
/* 2213 */     return this.sharedSendPacket;
/*      */   }
/*      */   
/*      */   void closeStreamer(RowData streamer) throws SQLException {
/* 2217 */     if (this.streamingData == null) {
/* 2218 */       throw SQLError.createSQLException(Messages.getString("MysqlIO.17") + streamer + Messages.getString("MysqlIO.18"), getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 2222 */     if (streamer != this.streamingData) {
/* 2223 */       throw SQLError.createSQLException(Messages.getString("MysqlIO.19") + streamer + Messages.getString("MysqlIO.20") + Messages.getString("MysqlIO.21") + Messages.getString("MysqlIO.22"), getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2229 */     this.streamingData = null;
/*      */   }
/*      */   
/*      */   boolean tackOnMoreStreamingResults(ResultSetImpl addingTo) throws SQLException {
/* 2233 */     if ((this.serverStatus & 0x8) != 0)
/*      */     {
/* 2235 */       boolean moreRowSetsExist = true;
/* 2236 */       ResultSetImpl currentResultSet = addingTo;
/* 2237 */       boolean firstTime = true;
/*      */       
/* 2239 */       while ((moreRowSetsExist) && (
/* 2240 */         (firstTime) || (!currentResultSet.reallyResult())))
/*      */       {
/*      */ 
/*      */ 
/* 2244 */         firstTime = false;
/*      */         
/* 2246 */         Buffer fieldPacket = checkErrorPacket();
/* 2247 */         fieldPacket.setPosition(0);
/*      */         
/* 2249 */         java.sql.Statement owningStatement = addingTo.getStatement();
/*      */         
/* 2251 */         int maxRows = owningStatement.getMaxRows();
/*      */         
/*      */ 
/*      */ 
/* 2255 */         ResultSetImpl newResultSet = readResultsForQueryOrUpdate((StatementImpl)owningStatement, maxRows, owningStatement.getResultSetType(), owningStatement.getResultSetConcurrency(), true, owningStatement.getConnection().getCatalog(), fieldPacket, addingTo.isBinaryEncoded, -1L, null);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2263 */         currentResultSet.setNextResultSet(newResultSet);
/*      */         
/* 2265 */         currentResultSet = newResultSet;
/*      */         
/* 2267 */         moreRowSetsExist = (this.serverStatus & 0x8) != 0;
/*      */         
/* 2269 */         if ((!currentResultSet.reallyResult()) && (!moreRowSetsExist))
/*      */         {
/* 2271 */           return false;
/*      */         }
/*      */       }
/*      */       
/* 2275 */       return true;
/*      */     }
/*      */     
/* 2278 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   ResultSetImpl readAllResults(StatementImpl callingStatement, int maxRows, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, Buffer resultPacket, boolean isBinaryEncoded, long preSentColumnCount, Field[] metadataFromCache)
/*      */     throws SQLException
/*      */   {
/* 2286 */     resultPacket.setPosition(resultPacket.getPosition() - 1);
/*      */     
/* 2288 */     ResultSetImpl topLevelResultSet = readResultsForQueryOrUpdate(callingStatement, maxRows, resultSetType, resultSetConcurrency, streamResults, catalog, resultPacket, isBinaryEncoded, preSentColumnCount, metadataFromCache);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2293 */     ResultSetImpl currentResultSet = topLevelResultSet;
/*      */     
/* 2295 */     boolean checkForMoreResults = (this.clientParam & 0x20000) != 0L;
/*      */     
/*      */ 
/* 2298 */     boolean serverHasMoreResults = (this.serverStatus & 0x8) != 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2304 */     if ((serverHasMoreResults) && (streamResults))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2309 */       if (topLevelResultSet.getUpdateCount() != -1L) {
/* 2310 */         tackOnMoreStreamingResults(topLevelResultSet);
/*      */       }
/*      */       
/* 2313 */       reclaimLargeReusablePacket();
/*      */       
/* 2315 */       return topLevelResultSet;
/*      */     }
/*      */     
/* 2318 */     boolean moreRowSetsExist = checkForMoreResults & serverHasMoreResults;
/*      */     
/* 2320 */     while (moreRowSetsExist) {
/* 2321 */       Buffer fieldPacket = checkErrorPacket();
/* 2322 */       fieldPacket.setPosition(0);
/*      */       
/* 2324 */       ResultSetImpl newResultSet = readResultsForQueryOrUpdate(callingStatement, maxRows, resultSetType, resultSetConcurrency, streamResults, catalog, fieldPacket, isBinaryEncoded, preSentColumnCount, metadataFromCache);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2329 */       currentResultSet.setNextResultSet(newResultSet);
/*      */       
/* 2331 */       currentResultSet = newResultSet;
/*      */       
/* 2333 */       moreRowSetsExist = (this.serverStatus & 0x8) != 0;
/*      */     }
/*      */     
/* 2336 */     if (!streamResults) {
/* 2337 */       clearInputStream();
/*      */     }
/*      */     
/* 2340 */     reclaimLargeReusablePacket();
/*      */     
/* 2342 */     return topLevelResultSet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void resetMaxBuf()
/*      */   {
/* 2349 */     this.maxAllowedPacket = this.connection.getMaxAllowedPacket();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final Buffer sendCommand(int command, String extraData, Buffer queryPacket, boolean skipCheck, String extraDataCharEncoding, int timeoutMillis)
/*      */     throws SQLException
/*      */   {
/* 2375 */     this.commandCount += 1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2382 */     this.enablePacketDebug = this.connection.getEnablePacketDebug();
/* 2383 */     this.readPacketSequence = 0;
/*      */     
/* 2385 */     int oldTimeout = 0;
/*      */     
/* 2387 */     if (timeoutMillis != 0) {
/*      */       try {
/* 2389 */         oldTimeout = this.mysqlConnection.getSoTimeout();
/* 2390 */         this.mysqlConnection.setSoTimeout(timeoutMillis);
/*      */       } catch (SocketException e) {
/* 2392 */         throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, e, getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 2399 */       checkForOutstandingStreamingData();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2404 */       this.oldServerStatus = this.serverStatus;
/* 2405 */       this.serverStatus = 0;
/* 2406 */       this.hadWarnings = false;
/* 2407 */       this.warningCount = 0;
/*      */       
/* 2409 */       this.queryNoIndexUsed = false;
/* 2410 */       this.queryBadIndexUsed = false;
/* 2411 */       this.serverQueryWasSlow = false;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2417 */       if (this.useCompression) {
/* 2418 */         int bytesLeft = this.mysqlInput.available();
/*      */         
/* 2420 */         if (bytesLeft > 0) {
/* 2421 */           this.mysqlInput.skip(bytesLeft);
/*      */         }
/*      */       }
/*      */       long id;
/*      */       try {
/* 2426 */         clearInputStream();
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2435 */         if (queryPacket == null) {
/* 2436 */           int packLength = 8 + (extraData != null ? extraData.length() : 0) + 2;
/*      */           
/*      */ 
/* 2439 */           if (this.sendPacket == null) {
/* 2440 */             this.sendPacket = new Buffer(packLength);
/*      */           }
/*      */           
/* 2443 */           this.packetSequence = -1;
/* 2444 */           this.readPacketSequence = 0;
/* 2445 */           this.checkPacketSequence = true;
/* 2446 */           this.sendPacket.clear();
/*      */           
/* 2448 */           this.sendPacket.writeByte((byte)command);
/*      */           
/* 2450 */           if ((command == 2) || (command == 5) || (command == 6) || (command == 3) || (command == 22))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/* 2455 */             if (extraDataCharEncoding == null) {
/* 2456 */               this.sendPacket.writeStringNoNull(extraData);
/*      */             } else {
/* 2458 */               this.sendPacket.writeStringNoNull(extraData, extraDataCharEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), this.connection);
/*      */             }
/*      */             
/*      */ 
/*      */           }
/* 2463 */           else if (command == 12) {
/* 2464 */             id = Long.parseLong(extraData);
/* 2465 */             this.sendPacket.writeLong(id);
/*      */           }
/*      */           
/* 2468 */           send(this.sendPacket, this.sendPacket.getPosition());
/*      */         } else {
/* 2470 */           this.packetSequence = -1;
/* 2471 */           send(queryPacket, queryPacket.getPosition());
/*      */         }
/*      */       }
/*      */       catch (SQLException sqlEx) {
/* 2475 */         throw sqlEx;
/*      */       } catch (Exception ex) {
/* 2477 */         throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ex, getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/* 2481 */       Buffer returnPacket = null;
/*      */       
/* 2483 */       if (!skipCheck) {
/* 2484 */         if ((command == 23) || (command == 26))
/*      */         {
/* 2486 */           this.readPacketSequence = 0;
/* 2487 */           this.packetSequenceReset = true;
/*      */         }
/*      */         
/* 2490 */         returnPacket = checkErrorPacket(command);
/*      */       }
/*      */       
/* 2493 */       return returnPacket;
/*      */     } catch (IOException ioEx) {
/* 2495 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     }
/*      */     finally {
/* 2498 */       if (timeoutMillis != 0) {
/*      */         try {
/* 2500 */           this.mysqlConnection.setSoTimeout(oldTimeout);
/*      */         } catch (SocketException e) {
/* 2502 */           throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, e, getExceptionInterceptor());
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/* 2509 */   private int statementExecutionDepth = 0;
/*      */   private boolean useAutoSlowLog;
/*      */   
/*      */   protected boolean shouldIntercept() {
/* 2513 */     return this.statementInterceptors != null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final ResultSetInternalMethods sqlQueryDirect(StatementImpl callingStatement, String query, String characterEncoding, Buffer queryPacket, int maxRows, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, Field[] cachedMetadata)
/*      */     throws Exception
/*      */   {
/* 2540 */     this.statementExecutionDepth += 1;
/*      */     try
/*      */     {
/* 2543 */       if (this.statementInterceptors != null) {
/* 2544 */         ResultSetInternalMethods interceptedResults = invokeStatementInterceptorsPre(query, callingStatement, false);
/*      */         
/*      */ 
/* 2547 */         if (interceptedResults != null) {
/* 2548 */           return interceptedResults;
/*      */         }
/*      */       }
/*      */       
/* 2552 */       long queryStartTime = 0L;
/* 2553 */       long queryEndTime = 0L;
/*      */       
/* 2555 */       String statementComment = this.connection.getStatementComment();
/*      */       
/* 2557 */       if (this.connection.getIncludeThreadNamesAsStatementComment()) {
/* 2558 */         statementComment = (statementComment != null ? statementComment + ", " : "") + "java thread: " + Thread.currentThread().getName();
/*      */       }
/*      */       
/* 2561 */       if (query != null)
/*      */       {
/*      */ 
/*      */ 
/* 2565 */         int packLength = 5 + query.length() * 2 + 2;
/*      */         
/* 2567 */         byte[] commentAsBytes = null;
/*      */         
/* 2569 */         if (statementComment != null) {
/* 2570 */           commentAsBytes = StringUtils.getBytes(statementComment, null, characterEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 2575 */           packLength += commentAsBytes.length;
/* 2576 */           packLength += 6;
/*      */         }
/*      */         
/* 2579 */         if (this.sendPacket == null) {
/* 2580 */           this.sendPacket = new Buffer(packLength);
/*      */         } else {
/* 2582 */           this.sendPacket.clear();
/*      */         }
/*      */         
/* 2585 */         this.sendPacket.writeByte((byte)3);
/*      */         
/* 2587 */         if (commentAsBytes != null) {
/* 2588 */           this.sendPacket.writeBytesNoNull(Constants.SLASH_STAR_SPACE_AS_BYTES);
/* 2589 */           this.sendPacket.writeBytesNoNull(commentAsBytes);
/* 2590 */           this.sendPacket.writeBytesNoNull(Constants.SPACE_STAR_SLASH_SPACE_AS_BYTES);
/*      */         }
/*      */         
/* 2593 */         if (characterEncoding != null) {
/* 2594 */           if (this.platformDbCharsetMatches) {
/* 2595 */             this.sendPacket.writeStringNoNull(query, characterEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), this.connection);
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/* 2600 */           else if (StringUtils.startsWithIgnoreCaseAndWs(query, "LOAD DATA")) {
/* 2601 */             this.sendPacket.writeBytesNoNull(StringUtils.getBytes(query));
/*      */           } else {
/* 2603 */             this.sendPacket.writeStringNoNull(query, characterEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), this.connection);
/*      */ 
/*      */           }
/*      */           
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 2611 */           this.sendPacket.writeStringNoNull(query);
/*      */         }
/*      */         
/* 2614 */         queryPacket = this.sendPacket;
/*      */       }
/*      */       
/* 2617 */       byte[] queryBuf = null;
/* 2618 */       int oldPacketPosition = 0;
/*      */       
/* 2620 */       if (this.needToGrabQueryFromPacket) {
/* 2621 */         queryBuf = queryPacket.getByteBuffer();
/*      */         
/*      */ 
/* 2624 */         oldPacketPosition = queryPacket.getPosition();
/*      */         
/* 2626 */         queryStartTime = getCurrentTimeNanosOrMillis();
/*      */       }
/*      */       
/* 2629 */       if (this.autoGenerateTestcaseScript) {
/* 2630 */         String testcaseQuery = null;
/*      */         
/* 2632 */         if (query != null) {
/* 2633 */           if (statementComment != null) {
/* 2634 */             testcaseQuery = "/* " + statementComment + " */ " + query;
/*      */           } else {
/* 2636 */             testcaseQuery = query;
/*      */           }
/*      */         } else {
/* 2639 */           testcaseQuery = StringUtils.toString(queryBuf, 5, oldPacketPosition - 5);
/*      */         }
/*      */         
/*      */ 
/* 2643 */         StringBuffer debugBuf = new StringBuffer(testcaseQuery.length() + 32);
/* 2644 */         this.connection.generateConnectionCommentBlock(debugBuf);
/* 2645 */         debugBuf.append(testcaseQuery);
/* 2646 */         debugBuf.append(';');
/* 2647 */         this.connection.dumpTestcaseQuery(debugBuf.toString());
/*      */       }
/*      */       
/*      */ 
/* 2651 */       Buffer resultPacket = sendCommand(3, null, queryPacket, false, null, 0);
/*      */       
/*      */ 
/* 2654 */       long fetchBeginTime = 0L;
/* 2655 */       long fetchEndTime = 0L;
/*      */       
/* 2657 */       String profileQueryToLog = null;
/*      */       
/* 2659 */       boolean queryWasSlow = false;
/*      */       
/* 2661 */       if ((this.profileSql) || (this.logSlowQueries)) {
/* 2662 */         queryEndTime = System.currentTimeMillis();
/*      */         
/* 2664 */         boolean shouldExtractQuery = false;
/*      */         
/* 2666 */         if (this.profileSql) {
/* 2667 */           shouldExtractQuery = true;
/* 2668 */         } else if (this.logSlowQueries) {
/* 2669 */           long queryTime = queryEndTime - queryStartTime;
/*      */           
/* 2671 */           boolean logSlow = false;
/*      */           
/* 2673 */           if (!this.useAutoSlowLog) {
/* 2674 */             logSlow = queryTime > this.connection.getSlowQueryThresholdMillis();
/*      */           } else {
/* 2676 */             logSlow = this.connection.isAbonormallyLongQuery(queryTime);
/*      */             
/* 2678 */             this.connection.reportQueryTime(queryTime);
/*      */           }
/*      */           
/* 2681 */           if (logSlow) {
/* 2682 */             shouldExtractQuery = true;
/* 2683 */             queryWasSlow = true;
/*      */           }
/*      */         }
/*      */         
/* 2687 */         if (shouldExtractQuery)
/*      */         {
/* 2689 */           boolean truncated = false;
/*      */           
/* 2691 */           int extractPosition = oldPacketPosition;
/*      */           
/* 2693 */           if (oldPacketPosition > this.connection.getMaxQuerySizeToLog()) {
/* 2694 */             extractPosition = this.connection.getMaxQuerySizeToLog() + 5;
/* 2695 */             truncated = true;
/*      */           }
/*      */           
/* 2698 */           profileQueryToLog = StringUtils.toString(queryBuf, 5, extractPosition - 5);
/*      */           
/*      */ 
/* 2701 */           if (truncated) {
/* 2702 */             profileQueryToLog = profileQueryToLog + Messages.getString("MysqlIO.25");
/*      */           }
/*      */         }
/*      */         
/* 2706 */         fetchBeginTime = queryEndTime;
/*      */       }
/*      */       
/* 2709 */       ResultSetInternalMethods rs = readAllResults(callingStatement, maxRows, resultSetType, resultSetConcurrency, streamResults, catalog, resultPacket, false, -1L, cachedMetadata);
/*      */       
/*      */ 
/*      */ 
/* 2713 */       if ((queryWasSlow) && (!this.serverQueryWasSlow)) {
/* 2714 */         StringBuffer mesgBuf = new StringBuffer(48 + profileQueryToLog.length());
/*      */         
/*      */ 
/* 2717 */         mesgBuf.append(Messages.getString("MysqlIO.SlowQuery", new Object[] { String.valueOf(this.useAutoSlowLog ? " 95% of all queries " : Long.valueOf(this.slowQueryThreshold)), this.queryTimingUnits, Long.valueOf(queryEndTime - queryStartTime) }));
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 2722 */         mesgBuf.append(profileQueryToLog);
/*      */         
/* 2724 */         ProfilerEventHandler eventSink = ProfilerEventHandlerFactory.getInstance(this.connection);
/*      */         
/* 2726 */         eventSink.consumeEvent(new ProfilerEvent((byte)6, "", catalog, this.connection.getId(), callingStatement != null ? callingStatement.getId() : 999, ((ResultSetImpl)rs).resultId, System.currentTimeMillis(), (int)(queryEndTime - queryStartTime), this.queryTimingUnits, null, new Throwable(), mesgBuf.toString()));
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2733 */         if (this.connection.getExplainSlowQueries()) {
/* 2734 */           if (oldPacketPosition < 1048576) {
/* 2735 */             explainSlowQuery(queryPacket.getBytes(5, oldPacketPosition - 5), profileQueryToLog);
/*      */           }
/*      */           else {
/* 2738 */             this.connection.getLog().logWarn(Messages.getString("MysqlIO.28") + 1048576 + Messages.getString("MysqlIO.29"));
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2746 */       if (this.logSlowQueries)
/*      */       {
/* 2748 */         ProfilerEventHandler eventSink = ProfilerEventHandlerFactory.getInstance(this.connection);
/*      */         
/* 2750 */         if ((this.queryBadIndexUsed) && (this.profileSql)) {
/* 2751 */           eventSink.consumeEvent(new ProfilerEvent((byte)6, "", catalog, this.connection.getId(), callingStatement != null ? callingStatement.getId() : 999, ((ResultSetImpl)rs).resultId, System.currentTimeMillis(), queryEndTime - queryStartTime, this.queryTimingUnits, null, new Throwable(), Messages.getString("MysqlIO.33") + profileQueryToLog));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2764 */         if ((this.queryNoIndexUsed) && (this.profileSql)) {
/* 2765 */           eventSink.consumeEvent(new ProfilerEvent((byte)6, "", catalog, this.connection.getId(), callingStatement != null ? callingStatement.getId() : 999, ((ResultSetImpl)rs).resultId, System.currentTimeMillis(), queryEndTime - queryStartTime, this.queryTimingUnits, null, new Throwable(), Messages.getString("MysqlIO.35") + profileQueryToLog));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2778 */         if ((this.serverQueryWasSlow) && (this.profileSql)) {
/* 2779 */           eventSink.consumeEvent(new ProfilerEvent((byte)6, "", catalog, this.connection.getId(), callingStatement != null ? callingStatement.getId() : 999, ((ResultSetImpl)rs).resultId, System.currentTimeMillis(), queryEndTime - queryStartTime, this.queryTimingUnits, null, new Throwable(), Messages.getString("MysqlIO.ServerSlowQuery") + profileQueryToLog));
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2793 */       if (this.profileSql) {
/* 2794 */         fetchEndTime = getCurrentTimeNanosOrMillis();
/*      */         
/* 2796 */         ProfilerEventHandler eventSink = ProfilerEventHandlerFactory.getInstance(this.connection);
/*      */         
/* 2798 */         eventSink.consumeEvent(new ProfilerEvent((byte)3, "", catalog, this.connection.getId(), callingStatement != null ? callingStatement.getId() : 999, ((ResultSetImpl)rs).resultId, System.currentTimeMillis(), queryEndTime - queryStartTime, this.queryTimingUnits, null, new Throwable(), profileQueryToLog));
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2806 */         eventSink.consumeEvent(new ProfilerEvent((byte)5, "", catalog, this.connection.getId(), callingStatement != null ? callingStatement.getId() : 999, ((ResultSetImpl)rs).resultId, System.currentTimeMillis(), fetchEndTime - fetchBeginTime, this.queryTimingUnits, null, new Throwable(), null));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2815 */       if (this.hadWarnings) {
/* 2816 */         scanForAndThrowDataTruncation();
/*      */       }
/*      */       ResultSetInternalMethods interceptedResults;
/* 2819 */       if (this.statementInterceptors != null) {
/* 2820 */         interceptedResults = invokeStatementInterceptorsPost(query, callingStatement, rs, false, null);
/*      */         
/*      */ 
/* 2823 */         if (interceptedResults != null) {
/* 2824 */           rs = interceptedResults;
/*      */         }
/*      */       }
/*      */       
/* 2828 */       return rs;
/*      */     } catch (SQLException sqlEx) {
/* 2830 */       if (this.statementInterceptors != null) {
/* 2831 */         invokeStatementInterceptorsPost(query, callingStatement, null, false, sqlEx);
/*      */       }
/*      */       
/*      */ 
/* 2835 */       if (callingStatement != null) {
/* 2836 */         synchronized (callingStatement.cancelTimeoutMutex) {
/* 2837 */           if (callingStatement.wasCancelled) {
/* 2838 */             SQLException cause = null;
/*      */             
/* 2840 */             if (callingStatement.wasCancelledByTimeout) {
/* 2841 */               cause = new MySQLTimeoutException();
/*      */             } else {
/* 2843 */               cause = new MySQLStatementCancelledException();
/*      */             }
/*      */             
/* 2846 */             callingStatement.resetCancelledState();
/*      */             
/* 2848 */             throw cause;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 2853 */       throw sqlEx;
/*      */     } finally {
/* 2855 */       this.statementExecutionDepth -= 1;
/*      */     }
/*      */   }
/*      */   
/*      */   ResultSetInternalMethods invokeStatementInterceptorsPre(String sql, Statement interceptedStatement, boolean forceExecute) throws SQLException
/*      */   {
/* 2861 */     ResultSetInternalMethods previousResultSet = null;
/*      */     
/* 2863 */     Iterator interceptors = this.statementInterceptors.iterator();
/*      */     
/* 2865 */     while (interceptors.hasNext()) {
/* 2866 */       StatementInterceptorV2 interceptor = (StatementInterceptorV2)interceptors.next();
/*      */       
/*      */ 
/* 2869 */       boolean executeTopLevelOnly = interceptor.executeTopLevelOnly();
/* 2870 */       boolean shouldExecute = ((executeTopLevelOnly) && ((this.statementExecutionDepth == 1) || (forceExecute))) || (!executeTopLevelOnly);
/*      */       
/*      */ 
/* 2873 */       if (shouldExecute) {
/* 2874 */         String sqlToInterceptor = sql;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2881 */         ResultSetInternalMethods interceptedResultSet = interceptor.preProcess(sqlToInterceptor, interceptedStatement, this.connection);
/*      */         
/*      */ 
/*      */ 
/* 2885 */         if (interceptedResultSet != null) {
/* 2886 */           previousResultSet = interceptedResultSet;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2891 */     return previousResultSet;
/*      */   }
/*      */   
/*      */   ResultSetInternalMethods invokeStatementInterceptorsPost(String sql, Statement interceptedStatement, ResultSetInternalMethods originalResultSet, boolean forceExecute, SQLException statementException)
/*      */     throws SQLException
/*      */   {
/* 2897 */     Iterator interceptors = this.statementInterceptors.iterator();
/*      */     
/* 2899 */     while (interceptors.hasNext()) {
/* 2900 */       StatementInterceptorV2 interceptor = (StatementInterceptorV2)interceptors.next();
/*      */       
/*      */ 
/* 2903 */       boolean executeTopLevelOnly = interceptor.executeTopLevelOnly();
/* 2904 */       boolean shouldExecute = ((executeTopLevelOnly) && ((this.statementExecutionDepth == 1) || (forceExecute))) || (!executeTopLevelOnly);
/*      */       
/*      */ 
/* 2907 */       if (shouldExecute) {
/* 2908 */         String sqlToInterceptor = sql;
/*      */         
/* 2910 */         ResultSetInternalMethods interceptedResultSet = interceptor.postProcess(sqlToInterceptor, interceptedStatement, originalResultSet, this.connection, this.warningCount, this.queryNoIndexUsed, this.queryBadIndexUsed, statementException);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 2915 */         if (interceptedResultSet != null) {
/* 2916 */           originalResultSet = interceptedResultSet;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2921 */     return originalResultSet;
/*      */   }
/*      */   
/*      */   private void calculateSlowQueryThreshold() {
/* 2925 */     this.slowQueryThreshold = this.connection.getSlowQueryThresholdMillis();
/*      */     
/* 2927 */     if (this.connection.getUseNanosForElapsedTime()) {
/* 2928 */       long nanosThreshold = this.connection.getSlowQueryThresholdNanos();
/*      */       
/* 2930 */       if (nanosThreshold != 0L) {
/* 2931 */         this.slowQueryThreshold = nanosThreshold;
/*      */       } else {
/* 2933 */         this.slowQueryThreshold *= 1000000L;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected long getCurrentTimeNanosOrMillis() {
/* 2939 */     if (this.useNanosForElapsedTime) {
/* 2940 */       return Util.getCurrentTimeNanosOrMillis();
/*      */     }
/*      */     
/* 2943 */     return System.currentTimeMillis();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   String getHost()
/*      */   {
/* 2952 */     return this.host;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean isVersion(int major, int minor, int subminor)
/*      */   {
/* 2967 */     return (major == getServerMajorVersion()) && (minor == getServerMinorVersion()) && (subminor == getServerSubMinorVersion());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean versionMeetsMinimum(int major, int minor, int subminor)
/*      */   {
/* 2983 */     if (getServerMajorVersion() >= major) {
/* 2984 */       if (getServerMajorVersion() == major) {
/* 2985 */         if (getServerMinorVersion() >= minor) {
/* 2986 */           if (getServerMinorVersion() == minor) {
/* 2987 */             return getServerSubMinorVersion() >= subminor;
/*      */           }
/*      */           
/*      */ 
/* 2991 */           return true;
/*      */         }
/*      */         
/*      */ 
/* 2995 */         return false;
/*      */       }
/*      */       
/*      */ 
/* 2999 */       return true;
/*      */     }
/*      */     
/* 3002 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final String getPacketDumpToLog(Buffer packetToDump, int packetLength)
/*      */   {
/* 3016 */     if (packetLength < 1024) {
/* 3017 */       return packetToDump.dump(packetLength);
/*      */     }
/*      */     
/* 3020 */     StringBuffer packetDumpBuf = new StringBuffer(4096);
/* 3021 */     packetDumpBuf.append(packetToDump.dump(1024));
/* 3022 */     packetDumpBuf.append(Messages.getString("MysqlIO.36"));
/* 3023 */     packetDumpBuf.append(1024);
/* 3024 */     packetDumpBuf.append(Messages.getString("MysqlIO.37"));
/*      */     
/* 3026 */     return packetDumpBuf.toString();
/*      */   }
/*      */   
/*      */   private final int readFully(InputStream in, byte[] b, int off, int len) throws IOException
/*      */   {
/* 3031 */     if (len < 0) {
/* 3032 */       throw new IndexOutOfBoundsException();
/*      */     }
/*      */     
/* 3035 */     int n = 0;
/*      */     
/* 3037 */     while (n < len) {
/* 3038 */       int count = in.read(b, off + n, len - n);
/*      */       
/* 3040 */       if (count < 0) {
/* 3041 */         throw new EOFException(Messages.getString("MysqlIO.EOF", new Object[] { Integer.valueOf(len), Integer.valueOf(n) }));
/*      */       }
/*      */       
/*      */ 
/* 3045 */       n += count;
/*      */     }
/*      */     
/* 3048 */     return n;
/*      */   }
/*      */   
/*      */   private final long skipFully(InputStream in, long len) throws IOException {
/* 3052 */     if (len < 0L) {
/* 3053 */       throw new IOException("Negative skip length not allowed");
/*      */     }
/*      */     
/* 3056 */     long n = 0L;
/*      */     
/* 3058 */     while (n < len) {
/* 3059 */       long count = in.skip(len - n);
/*      */       
/* 3061 */       if (count < 0L) {
/* 3062 */         throw new EOFException(Messages.getString("MysqlIO.EOF", new Object[] { Long.valueOf(len), Long.valueOf(n) }));
/*      */       }
/*      */       
/*      */ 
/* 3066 */       n += count;
/*      */     }
/*      */     
/* 3069 */     return n;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final ResultSetImpl readResultsForQueryOrUpdate(StatementImpl callingStatement, int maxRows, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, Buffer resultPacket, boolean isBinaryEncoded, long preSentColumnCount, Field[] metadataFromCache)
/*      */     throws SQLException
/*      */   {
/* 3097 */     long columnCount = resultPacket.readFieldLength();
/*      */     
/* 3099 */     if (columnCount == 0L)
/* 3100 */       return buildResultSetWithUpdates(callingStatement, resultPacket);
/* 3101 */     if (columnCount == -1L) {
/* 3102 */       String charEncoding = null;
/*      */       
/* 3104 */       if (this.connection.getUseUnicode()) {
/* 3105 */         charEncoding = this.connection.getEncoding();
/*      */       }
/*      */       
/* 3108 */       String fileName = null;
/*      */       
/* 3110 */       if (this.platformDbCharsetMatches) {
/* 3111 */         fileName = charEncoding != null ? resultPacket.readString(charEncoding, getExceptionInterceptor()) : resultPacket.readString();
/*      */       }
/*      */       else
/*      */       {
/* 3115 */         fileName = resultPacket.readString();
/*      */       }
/*      */       
/* 3118 */       return sendFileToServer(callingStatement, fileName);
/*      */     }
/* 3120 */     ResultSetImpl results = getResultSet(callingStatement, columnCount, maxRows, resultSetType, resultSetConcurrency, streamResults, catalog, isBinaryEncoded, metadataFromCache);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 3125 */     return results;
/*      */   }
/*      */   
/*      */   private int alignPacketSize(int a, int l)
/*      */   {
/* 3130 */     return a + l - 1 & (l - 1 ^ 0xFFFFFFFF);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private ResultSetImpl buildResultSetWithRows(StatementImpl callingStatement, String catalog, Field[] fields, RowData rows, int resultSetType, int resultSetConcurrency, boolean isBinaryEncoded)
/*      */     throws SQLException
/*      */   {
/* 3138 */     ResultSetImpl rs = null;
/*      */     
/* 3140 */     switch (resultSetConcurrency) {
/*      */     case 1007: 
/* 3142 */       rs = ResultSetImpl.getInstance(catalog, fields, rows, this.connection, callingStatement, false);
/*      */       
/*      */ 
/* 3145 */       if (isBinaryEncoded) {
/* 3146 */         rs.setBinaryEncoded();
/*      */       }
/*      */       
/*      */ 
/*      */       break;
/*      */     case 1008: 
/* 3152 */       rs = ResultSetImpl.getInstance(catalog, fields, rows, this.connection, callingStatement, true);
/*      */       
/*      */ 
/* 3155 */       break;
/*      */     
/*      */     default: 
/* 3158 */       return ResultSetImpl.getInstance(catalog, fields, rows, this.connection, callingStatement, false);
/*      */     }
/*      */     
/*      */     
/* 3162 */     rs.setResultSetType(resultSetType);
/* 3163 */     rs.setResultSetConcurrency(resultSetConcurrency);
/*      */     
/* 3165 */     return rs;
/*      */   }
/*      */   
/*      */   private ResultSetImpl buildResultSetWithUpdates(StatementImpl callingStatement, Buffer resultPacket)
/*      */     throws SQLException
/*      */   {
/* 3171 */     long updateCount = -1L;
/* 3172 */     long updateID = -1L;
/* 3173 */     String info = null;
/*      */     try
/*      */     {
/* 3176 */       if (this.useNewUpdateCounts) {
/* 3177 */         updateCount = resultPacket.newReadLength();
/* 3178 */         updateID = resultPacket.newReadLength();
/*      */       } else {
/* 3180 */         updateCount = resultPacket.readLength();
/* 3181 */         updateID = resultPacket.readLength();
/*      */       }
/*      */       
/* 3184 */       if (this.use41Extensions)
/*      */       {
/* 3186 */         this.serverStatus = resultPacket.readInt();
/*      */         
/* 3188 */         checkTransactionState(this.oldServerStatus);
/*      */         
/* 3190 */         this.warningCount = resultPacket.readInt();
/*      */         
/* 3192 */         if (this.warningCount > 0) {
/* 3193 */           this.hadWarnings = true;
/*      */         }
/*      */         
/* 3196 */         resultPacket.readByte();
/*      */         
/* 3198 */         setServerSlowQueryFlags();
/*      */       }
/*      */       
/* 3201 */       if (this.connection.isReadInfoMsgEnabled()) {
/* 3202 */         info = resultPacket.readString(this.connection.getErrorMessageEncoding(), getExceptionInterceptor());
/*      */       }
/*      */     } catch (Exception ex) {
/* 3205 */       SQLException sqlEx = SQLError.createSQLException(SQLError.get("S1000"), "S1000", -1, getExceptionInterceptor());
/*      */       
/* 3207 */       sqlEx.initCause(ex);
/*      */       
/* 3209 */       throw sqlEx;
/*      */     }
/*      */     
/* 3212 */     ResultSetInternalMethods updateRs = ResultSetImpl.getInstance(updateCount, updateID, this.connection, callingStatement);
/*      */     
/*      */ 
/* 3215 */     if (info != null) {
/* 3216 */       ((ResultSetImpl)updateRs).setServerInfo(info);
/*      */     }
/*      */     
/* 3219 */     return (ResultSetImpl)updateRs;
/*      */   }
/*      */   
/*      */   private void setServerSlowQueryFlags() {
/* 3223 */     this.queryBadIndexUsed = ((this.serverStatus & 0x10) != 0);
/*      */     
/* 3225 */     this.queryNoIndexUsed = ((this.serverStatus & 0x20) != 0);
/*      */     
/* 3227 */     this.serverQueryWasSlow = ((this.serverStatus & 0x800) != 0);
/*      */   }
/*      */   
/*      */   private void checkForOutstandingStreamingData() throws SQLException
/*      */   {
/* 3232 */     if (this.streamingData != null) {
/* 3233 */       boolean shouldClobber = this.connection.getClobberStreamingResults();
/*      */       
/* 3235 */       if (!shouldClobber) {
/* 3236 */         throw SQLError.createSQLException(Messages.getString("MysqlIO.39") + this.streamingData + Messages.getString("MysqlIO.40") + Messages.getString("MysqlIO.41") + Messages.getString("MysqlIO.42"), getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3244 */       this.streamingData.getOwner().realClose(false);
/*      */       
/*      */ 
/* 3247 */       clearInputStream();
/*      */     }
/*      */   }
/*      */   
/*      */   private Buffer compressPacket(Buffer packet, int offset, int packetLen, int headerLength) throws SQLException
/*      */   {
/* 3253 */     packet.writeLongInt(packetLen - headerLength);
/* 3254 */     packet.writeByte((byte)0);
/*      */     
/* 3256 */     int lengthToWrite = 0;
/* 3257 */     int compressedLength = 0;
/* 3258 */     byte[] bytesToCompress = packet.getByteBuffer();
/* 3259 */     byte[] compressedBytes = null;
/* 3260 */     int offsetWrite = 0;
/*      */     
/* 3262 */     if (packetLen < 50) {
/* 3263 */       lengthToWrite = packetLen;
/* 3264 */       compressedBytes = packet.getByteBuffer();
/* 3265 */       compressedLength = 0;
/* 3266 */       offsetWrite = offset;
/*      */     } else {
/* 3268 */       compressedBytes = new byte[bytesToCompress.length * 2];
/*      */       
/* 3270 */       this.deflater.reset();
/* 3271 */       this.deflater.setInput(bytesToCompress, offset, packetLen);
/* 3272 */       this.deflater.finish();
/*      */       
/* 3274 */       int compLen = this.deflater.deflate(compressedBytes);
/*      */       
/* 3276 */       if (compLen > packetLen) {
/* 3277 */         lengthToWrite = packetLen;
/* 3278 */         compressedBytes = packet.getByteBuffer();
/* 3279 */         compressedLength = 0;
/* 3280 */         offsetWrite = offset;
/*      */       } else {
/* 3282 */         lengthToWrite = compLen;
/* 3283 */         headerLength += 3;
/* 3284 */         compressedLength = packetLen;
/*      */       }
/*      */     }
/*      */     
/* 3288 */     Buffer compressedPacket = new Buffer(packetLen + headerLength);
/*      */     
/* 3290 */     compressedPacket.setPosition(0);
/* 3291 */     compressedPacket.writeLongInt(lengthToWrite);
/* 3292 */     compressedPacket.writeByte(this.packetSequence);
/* 3293 */     compressedPacket.writeLongInt(compressedLength);
/* 3294 */     compressedPacket.writeBytesNoNull(compressedBytes, offsetWrite, lengthToWrite);
/*      */     
/*      */ 
/* 3297 */     return compressedPacket;
/*      */   }
/*      */   
/*      */   private final void readServerStatusForResultSets(Buffer rowPacket) throws SQLException
/*      */   {
/* 3302 */     if (this.use41Extensions) {
/* 3303 */       rowPacket.readByte();
/*      */       
/* 3305 */       this.warningCount = rowPacket.readInt();
/*      */       
/* 3307 */       if (this.warningCount > 0) {
/* 3308 */         this.hadWarnings = true;
/*      */       }
/*      */       
/* 3311 */       this.oldServerStatus = this.serverStatus;
/* 3312 */       this.serverStatus = rowPacket.readInt();
/* 3313 */       checkTransactionState(this.oldServerStatus);
/*      */       
/* 3315 */       setServerSlowQueryFlags();
/*      */     }
/*      */   }
/*      */   
/*      */   private SocketFactory createSocketFactory() throws SQLException {
/*      */     try {
/* 3321 */       if (this.socketFactoryClassName == null) {
/* 3322 */         throw SQLError.createSQLException(Messages.getString("MysqlIO.75"), "08001", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/* 3326 */       return (SocketFactory)Class.forName(this.socketFactoryClassName).newInstance();
/*      */     }
/*      */     catch (Exception ex) {
/* 3329 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("MysqlIO.76") + this.socketFactoryClassName + Messages.getString("MysqlIO.77"), "08001", getExceptionInterceptor());
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 3334 */       sqlEx.initCause(ex);
/*      */       
/* 3336 */       throw sqlEx;
/*      */     }
/*      */   }
/*      */   
/*      */   private void enqueuePacketForDebugging(boolean isPacketBeingSent, boolean isPacketReused, int sendLength, byte[] header, Buffer packet)
/*      */     throws SQLException
/*      */   {
/* 3343 */     if (this.packetDebugRingBuffer.size() + 1 > this.connection.getPacketDebugBufferSize()) {
/* 3344 */       this.packetDebugRingBuffer.removeFirst();
/*      */     }
/*      */     
/* 3347 */     StringBuffer packetDump = null;
/*      */     
/* 3349 */     if (!isPacketBeingSent) {
/* 3350 */       int bytesToDump = Math.min(1024, packet.getBufLength());
/*      */       
/*      */ 
/* 3353 */       Buffer packetToDump = new Buffer(4 + bytesToDump);
/*      */       
/* 3355 */       packetToDump.setPosition(0);
/* 3356 */       packetToDump.writeBytesNoNull(header);
/* 3357 */       packetToDump.writeBytesNoNull(packet.getBytes(0, bytesToDump));
/*      */       
/* 3359 */       String packetPayload = packetToDump.dump(bytesToDump);
/*      */       
/* 3361 */       packetDump = new StringBuffer(96 + packetPayload.length());
/*      */       
/* 3363 */       packetDump.append("Server ");
/*      */       
/* 3365 */       if (isPacketReused) {
/* 3366 */         packetDump.append("(re-used)");
/*      */       } else {
/* 3368 */         packetDump.append("(new)");
/*      */       }
/*      */       
/* 3371 */       packetDump.append(" ");
/* 3372 */       packetDump.append(packet.toSuperString());
/* 3373 */       packetDump.append(" --------------------> Client\n");
/* 3374 */       packetDump.append("\nPacket payload:\n\n");
/* 3375 */       packetDump.append(packetPayload);
/*      */       
/* 3377 */       if (bytesToDump == 1024) {
/* 3378 */         packetDump.append("\nNote: Packet of " + packet.getBufLength() + " bytes truncated to " + 1024 + " bytes.\n");
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 3383 */       int bytesToDump = Math.min(1024, sendLength);
/*      */       
/* 3385 */       String packetPayload = packet.dump(bytesToDump);
/*      */       
/* 3387 */       packetDump = new StringBuffer(68 + packetPayload.length());
/*      */       
/* 3389 */       packetDump.append("Client ");
/* 3390 */       packetDump.append(packet.toSuperString());
/* 3391 */       packetDump.append("--------------------> Server\n");
/* 3392 */       packetDump.append("\nPacket payload:\n\n");
/* 3393 */       packetDump.append(packetPayload);
/*      */       
/* 3395 */       if (bytesToDump == 1024) {
/* 3396 */         packetDump.append("\nNote: Packet of " + sendLength + " bytes truncated to " + 1024 + " bytes.\n");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3402 */     this.packetDebugRingBuffer.addLast(packetDump);
/*      */   }
/*      */   
/*      */ 
/*      */   private RowData readSingleRowSet(long columnCount, int maxRows, int resultSetConcurrency, boolean isBinaryEncoded, Field[] fields)
/*      */     throws SQLException
/*      */   {
/* 3409 */     ArrayList<ResultSetRow> rows = new ArrayList();
/*      */     
/* 3411 */     boolean useBufferRowExplicit = useBufferRowExplicit(fields);
/*      */     
/*      */ 
/* 3414 */     ResultSetRow row = nextRow(fields, (int)columnCount, isBinaryEncoded, resultSetConcurrency, false, useBufferRowExplicit, false, null);
/*      */     
/*      */ 
/* 3417 */     int rowCount = 0;
/*      */     
/* 3419 */     if (row != null) {
/* 3420 */       rows.add(row);
/* 3421 */       rowCount = 1;
/*      */     }
/*      */     
/* 3424 */     while (row != null) {
/* 3425 */       row = nextRow(fields, (int)columnCount, isBinaryEncoded, resultSetConcurrency, false, useBufferRowExplicit, false, null);
/*      */       
/*      */ 
/* 3428 */       if ((row != null) && (
/* 3429 */         (maxRows == -1) || (rowCount < maxRows))) {
/* 3430 */         rows.add(row);
/* 3431 */         rowCount++;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 3436 */     RowData rowData = new RowDataStatic(rows);
/*      */     
/* 3438 */     return rowData;
/*      */   }
/*      */   
/*      */   public static boolean useBufferRowExplicit(Field[] fields) {
/* 3442 */     if (fields == null) {
/* 3443 */       return false;
/*      */     }
/*      */     
/* 3446 */     for (int i = 0; i < fields.length; i++) {
/* 3447 */       switch (fields[i].getSQLType()) {
/*      */       case -4: 
/*      */       case -1: 
/*      */       case 2004: 
/*      */       case 2005: 
/* 3452 */         return true;
/*      */       }
/*      */       
/*      */     }
/* 3456 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void reclaimLargeReusablePacket()
/*      */   {
/* 3463 */     if ((this.reusablePacket != null) && (this.reusablePacket.getCapacity() > 1048576))
/*      */     {
/* 3465 */       this.reusablePacket = new Buffer(1024);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final Buffer reuseAndReadPacket(Buffer reuse)
/*      */     throws SQLException
/*      */   {
/* 3480 */     return reuseAndReadPacket(reuse, -1);
/*      */   }
/*      */   
/*      */   private final Buffer reuseAndReadPacket(Buffer reuse, int existingPacketLength) throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 3487 */       reuse.setWasMultiPacket(false);
/* 3488 */       int packetLength = 0;
/*      */       
/* 3490 */       if (existingPacketLength == -1) {
/* 3491 */         int lengthRead = readFully(this.mysqlInput, this.packetHeaderBuf, 0, 4);
/*      */         
/*      */ 
/* 3494 */         if (lengthRead < 4) {
/* 3495 */           forceClose();
/* 3496 */           throw new IOException(Messages.getString("MysqlIO.43"));
/*      */         }
/*      */         
/* 3499 */         packetLength = (this.packetHeaderBuf[0] & 0xFF) + ((this.packetHeaderBuf[1] & 0xFF) << 8) + ((this.packetHeaderBuf[2] & 0xFF) << 16);
/*      */       }
/*      */       else
/*      */       {
/* 3503 */         packetLength = existingPacketLength;
/*      */       }
/*      */       
/* 3506 */       if (this.traceProtocol) {
/* 3507 */         StringBuffer traceMessageBuf = new StringBuffer();
/*      */         
/* 3509 */         traceMessageBuf.append(Messages.getString("MysqlIO.44"));
/* 3510 */         traceMessageBuf.append(packetLength);
/* 3511 */         traceMessageBuf.append(Messages.getString("MysqlIO.45"));
/* 3512 */         traceMessageBuf.append(StringUtils.dumpAsHex(this.packetHeaderBuf, 4));
/*      */         
/*      */ 
/* 3515 */         this.connection.getLog().logTrace(traceMessageBuf.toString());
/*      */       }
/*      */       
/* 3518 */       byte multiPacketSeq = this.packetHeaderBuf[3];
/*      */       
/* 3520 */       if (!this.packetSequenceReset) {
/* 3521 */         if ((this.enablePacketDebug) && (this.checkPacketSequence)) {
/* 3522 */           checkPacketSequencing(multiPacketSeq);
/*      */         }
/*      */       } else {
/* 3525 */         this.packetSequenceReset = false;
/*      */       }
/*      */       
/* 3528 */       this.readPacketSequence = multiPacketSeq;
/*      */       
/*      */ 
/* 3531 */       reuse.setPosition(0);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3539 */       if (reuse.getByteBuffer().length <= packetLength) {
/* 3540 */         reuse.setByteBuffer(new byte[packetLength + 1]);
/*      */       }
/*      */       
/*      */ 
/* 3544 */       reuse.setBufLength(packetLength);
/*      */       
/*      */ 
/* 3547 */       int numBytesRead = readFully(this.mysqlInput, reuse.getByteBuffer(), 0, packetLength);
/*      */       
/*      */ 
/* 3550 */       if (numBytesRead != packetLength) {
/* 3551 */         throw new IOException("Short read, expected " + packetLength + " bytes, only read " + numBytesRead);
/*      */       }
/*      */       
/*      */ 
/* 3555 */       if (this.traceProtocol) {
/* 3556 */         StringBuffer traceMessageBuf = new StringBuffer();
/*      */         
/* 3558 */         traceMessageBuf.append(Messages.getString("MysqlIO.46"));
/* 3559 */         traceMessageBuf.append(getPacketDumpToLog(reuse, packetLength));
/*      */         
/*      */ 
/* 3562 */         this.connection.getLog().logTrace(traceMessageBuf.toString());
/*      */       }
/*      */       
/* 3565 */       if (this.enablePacketDebug) {
/* 3566 */         enqueuePacketForDebugging(false, true, 0, this.packetHeaderBuf, reuse);
/*      */       }
/*      */       
/*      */ 
/* 3570 */       boolean isMultiPacket = false;
/*      */       
/* 3572 */       if (packetLength == this.maxThreeBytes) {
/* 3573 */         reuse.setPosition(this.maxThreeBytes);
/*      */         
/*      */ 
/* 3576 */         isMultiPacket = true;
/*      */         
/* 3578 */         packetLength = readRemainingMultiPackets(reuse, multiPacketSeq);
/*      */       }
/*      */       
/* 3581 */       if (!isMultiPacket) {
/* 3582 */         reuse.getByteBuffer()[packetLength] = 0;
/*      */       }
/*      */       
/* 3585 */       if (this.connection.getMaintainTimeStats()) {
/* 3586 */         this.lastPacketReceivedTimeMs = System.currentTimeMillis();
/*      */       }
/*      */       
/* 3589 */       return reuse;
/*      */     } catch (IOException ioEx) {
/* 3591 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     }
/*      */     catch (OutOfMemoryError oom)
/*      */     {
/*      */       try {
/* 3596 */         clearInputStream();
/*      */       }
/*      */       finally {}
/*      */     }
/*      */     
/*      */ 
/*      */     label528:
/*      */     
/*      */ 
/*      */     break label528;
/*      */   }
/*      */   
/*      */ 
/*      */   private int readRemainingMultiPackets(Buffer reuse, byte multiPacketSeq)
/*      */     throws IOException, SQLException
/*      */   {
/* 3612 */     int lengthRead = readFully(this.mysqlInput, this.packetHeaderBuf, 0, 4);
/*      */     
/*      */ 
/* 3615 */     if (lengthRead < 4) {
/* 3616 */       forceClose();
/* 3617 */       throw new IOException(Messages.getString("MysqlIO.47"));
/*      */     }
/*      */     
/* 3620 */     int packetLength = (this.packetHeaderBuf[0] & 0xFF) + ((this.packetHeaderBuf[1] & 0xFF) << 8) + ((this.packetHeaderBuf[2] & 0xFF) << 16);
/*      */     
/*      */ 
/*      */ 
/* 3624 */     Buffer multiPacket = new Buffer(packetLength);
/* 3625 */     boolean firstMultiPkt = true;
/*      */     for (;;)
/*      */     {
/* 3628 */       if (!firstMultiPkt) {
/* 3629 */         lengthRead = readFully(this.mysqlInput, this.packetHeaderBuf, 0, 4);
/*      */         
/*      */ 
/* 3632 */         if (lengthRead < 4) {
/* 3633 */           forceClose();
/* 3634 */           throw new IOException(Messages.getString("MysqlIO.48"));
/*      */         }
/*      */         
/*      */ 
/* 3638 */         packetLength = (this.packetHeaderBuf[0] & 0xFF) + ((this.packetHeaderBuf[1] & 0xFF) << 8) + ((this.packetHeaderBuf[2] & 0xFF) << 16);
/*      */       }
/*      */       else
/*      */       {
/* 3642 */         firstMultiPkt = false;
/*      */       }
/*      */       
/* 3645 */       if ((!this.useNewLargePackets) && (packetLength == 1)) {
/* 3646 */         clearInputStream();
/*      */         
/* 3648 */         break; }
/* 3649 */       if (packetLength < this.maxThreeBytes) {
/* 3650 */         byte newPacketSeq = this.packetHeaderBuf[3];
/*      */         
/* 3652 */         if (newPacketSeq != multiPacketSeq + 1) {
/* 3653 */           throw new IOException(Messages.getString("MysqlIO.49"));
/*      */         }
/*      */         
/*      */ 
/* 3657 */         multiPacketSeq = newPacketSeq;
/*      */         
/*      */ 
/* 3660 */         multiPacket.setPosition(0);
/*      */         
/*      */ 
/* 3663 */         multiPacket.setBufLength(packetLength);
/*      */         
/*      */ 
/* 3666 */         byte[] byteBuf = multiPacket.getByteBuffer();
/* 3667 */         int lengthToWrite = packetLength;
/*      */         
/* 3669 */         int bytesRead = readFully(this.mysqlInput, byteBuf, 0, packetLength);
/*      */         
/*      */ 
/* 3672 */         if (bytesRead != lengthToWrite) {
/* 3673 */           throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, SQLError.createSQLException(Messages.getString("MysqlIO.50") + lengthToWrite + Messages.getString("MysqlIO.51") + bytesRead + ".", getExceptionInterceptor()), getExceptionInterceptor());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3683 */         reuse.writeBytesNoNull(byteBuf, 0, lengthToWrite);
/*      */         
/* 3685 */         break;
/*      */       }
/*      */       
/* 3688 */       byte newPacketSeq = this.packetHeaderBuf[3];
/*      */       
/* 3690 */       if (newPacketSeq != multiPacketSeq + 1) {
/* 3691 */         throw new IOException(Messages.getString("MysqlIO.53"));
/*      */       }
/*      */       
/*      */ 
/* 3695 */       multiPacketSeq = newPacketSeq;
/*      */       
/*      */ 
/* 3698 */       multiPacket.setPosition(0);
/*      */       
/*      */ 
/* 3701 */       multiPacket.setBufLength(packetLength);
/*      */       
/*      */ 
/* 3704 */       byte[] byteBuf = multiPacket.getByteBuffer();
/* 3705 */       int lengthToWrite = packetLength;
/*      */       
/* 3707 */       int bytesRead = readFully(this.mysqlInput, byteBuf, 0, packetLength);
/*      */       
/*      */ 
/* 3710 */       if (bytesRead != lengthToWrite) {
/* 3711 */         throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, SQLError.createSQLException(Messages.getString("MysqlIO.54") + lengthToWrite + Messages.getString("MysqlIO.55") + bytesRead + ".", getExceptionInterceptor()), getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3720 */       reuse.writeBytesNoNull(byteBuf, 0, lengthToWrite);
/*      */     }
/*      */     
/* 3723 */     reuse.setPosition(0);
/* 3724 */     reuse.setWasMultiPacket(true);
/* 3725 */     return packetLength;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void checkPacketSequencing(byte multiPacketSeq)
/*      */     throws SQLException
/*      */   {
/* 3734 */     if ((multiPacketSeq == Byte.MIN_VALUE) && (this.readPacketSequence != Byte.MAX_VALUE)) {
/* 3735 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, new IOException("Packets out of order, expected packet # -128, but received packet # " + multiPacketSeq), getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 3741 */     if ((this.readPacketSequence == -1) && (multiPacketSeq != 0)) {
/* 3742 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, new IOException("Packets out of order, expected packet # -1, but received packet # " + multiPacketSeq), getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 3748 */     if ((multiPacketSeq != Byte.MIN_VALUE) && (this.readPacketSequence != -1) && (multiPacketSeq != this.readPacketSequence + 1))
/*      */     {
/* 3750 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, new IOException("Packets out of order, expected packet # " + (this.readPacketSequence + 1) + ", but received packet # " + multiPacketSeq), getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void enableMultiQueries()
/*      */     throws SQLException
/*      */   {
/* 3759 */     Buffer buf = getSharedSendPacket();
/*      */     
/* 3761 */     buf.clear();
/* 3762 */     buf.writeByte((byte)27);
/* 3763 */     buf.writeInt(0);
/* 3764 */     sendCommand(27, null, buf, false, null, 0);
/*      */   }
/*      */   
/*      */   void disableMultiQueries() throws SQLException {
/* 3768 */     Buffer buf = getSharedSendPacket();
/*      */     
/* 3770 */     buf.clear();
/* 3771 */     buf.writeByte((byte)27);
/* 3772 */     buf.writeInt(1);
/* 3773 */     sendCommand(27, null, buf, false, null, 0);
/*      */   }
/*      */   
/*      */   private final void send(Buffer packet, int packetLen) throws SQLException
/*      */   {
/*      */     try {
/* 3779 */       if ((this.maxAllowedPacket > 0) && (packetLen > this.maxAllowedPacket)) {
/* 3780 */         throw new PacketTooBigException(packetLen, this.maxAllowedPacket);
/*      */       }
/*      */       
/* 3783 */       if ((this.serverMajorVersion >= 4) && (packetLen >= this.maxThreeBytes))
/*      */       {
/* 3785 */         sendSplitPackets(packet);
/*      */       } else {
/* 3787 */         this.packetSequence = ((byte)(this.packetSequence + 1));
/*      */         
/* 3789 */         Buffer packetToSend = packet;
/*      */         
/* 3791 */         packetToSend.setPosition(0);
/*      */         
/* 3793 */         if (this.useCompression) {
/* 3794 */           int originalPacketLen = packetLen;
/*      */           
/* 3796 */           packetToSend = compressPacket(packet, 0, packetLen, 4);
/*      */           
/* 3798 */           packetLen = packetToSend.getPosition();
/*      */           
/* 3800 */           if (this.traceProtocol) {
/* 3801 */             StringBuffer traceMessageBuf = new StringBuffer();
/*      */             
/* 3803 */             traceMessageBuf.append(Messages.getString("MysqlIO.57"));
/* 3804 */             traceMessageBuf.append(getPacketDumpToLog(packetToSend, packetLen));
/*      */             
/* 3806 */             traceMessageBuf.append(Messages.getString("MysqlIO.58"));
/* 3807 */             traceMessageBuf.append(getPacketDumpToLog(packet, originalPacketLen));
/*      */             
/*      */ 
/* 3810 */             this.connection.getLog().logTrace(traceMessageBuf.toString());
/*      */           }
/*      */         } else {
/* 3813 */           packetToSend.writeLongInt(packetLen - 4);
/* 3814 */           packetToSend.writeByte(this.packetSequence);
/*      */           
/* 3816 */           if (this.traceProtocol) {
/* 3817 */             StringBuffer traceMessageBuf = new StringBuffer();
/*      */             
/* 3819 */             traceMessageBuf.append(Messages.getString("MysqlIO.59"));
/* 3820 */             traceMessageBuf.append("host: '");
/* 3821 */             traceMessageBuf.append(this.host);
/* 3822 */             traceMessageBuf.append("' threadId: '");
/* 3823 */             traceMessageBuf.append(this.threadId);
/* 3824 */             traceMessageBuf.append("'\n");
/* 3825 */             traceMessageBuf.append(packetToSend.dump(packetLen));
/*      */             
/* 3827 */             this.connection.getLog().logTrace(traceMessageBuf.toString());
/*      */           }
/*      */         }
/*      */         
/*      */ 
/* 3832 */         this.mysqlOutput.write(packetToSend.getByteBuffer(), 0, packetLen);
/*      */         
/* 3834 */         this.mysqlOutput.flush();
/*      */       }
/*      */       
/* 3837 */       if (this.enablePacketDebug) {
/* 3838 */         enqueuePacketForDebugging(true, false, packetLen + 5, this.packetHeaderBuf, packet);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3845 */       if (packet == this.sharedSendPacket) {
/* 3846 */         reclaimLargeSharedSendPacket();
/*      */       }
/*      */       
/* 3849 */       if (this.connection.getMaintainTimeStats()) {
/* 3850 */         this.lastPacketSentTimeMs = System.currentTimeMillis();
/*      */       }
/*      */     } catch (IOException ioEx) {
/* 3853 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final ResultSetImpl sendFileToServer(StatementImpl callingStatement, String fileName)
/*      */     throws SQLException
/*      */   {
/* 3871 */     Buffer filePacket = this.loadFileBufRef == null ? null : (Buffer)this.loadFileBufRef.get();
/*      */     
/*      */ 
/* 3874 */     int bigPacketLength = Math.min(this.connection.getMaxAllowedPacket() - 12, alignPacketSize(this.connection.getMaxAllowedPacket() - 16, 4096) - 12);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 3879 */     int oneMeg = 1048576;
/*      */     
/* 3881 */     int smallerPacketSizeAligned = Math.min(oneMeg - 12, alignPacketSize(oneMeg - 16, 4096) - 12);
/*      */     
/*      */ 
/* 3884 */     int packetLength = Math.min(smallerPacketSizeAligned, bigPacketLength);
/*      */     
/* 3886 */     if (filePacket == null) {
/*      */       try {
/* 3888 */         filePacket = new Buffer(packetLength + 4);
/* 3889 */         this.loadFileBufRef = new SoftReference(filePacket);
/*      */       } catch (OutOfMemoryError oom) {
/* 3891 */         throw SQLError.createSQLException("Could not allocate packet of " + packetLength + " bytes required for LOAD DATA LOCAL INFILE operation." + " Try increasing max heap allocation for JVM or decreasing server variable " + "'max_allowed_packet'", "S1001", getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3899 */     filePacket.clear();
/* 3900 */     send(filePacket, 0);
/*      */     
/* 3902 */     byte[] fileBuf = new byte[packetLength];
/*      */     
/* 3904 */     BufferedInputStream fileIn = null;
/*      */     try
/*      */     {
/* 3907 */       if (!this.connection.getAllowLoadLocalInfile()) {
/* 3908 */         throw SQLError.createSQLException(Messages.getString("MysqlIO.LoadDataLocalNotAllowed"), "S1000", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 3913 */       InputStream hookedStream = null;
/*      */       
/* 3915 */       if (callingStatement != null) {
/* 3916 */         hookedStream = callingStatement.getLocalInfileInputStream();
/*      */       }
/*      */       
/* 3919 */       if (hookedStream != null) {
/* 3920 */         fileIn = new BufferedInputStream(hookedStream);
/* 3921 */       } else if (!this.connection.getAllowUrlInLocalInfile()) {
/* 3922 */         fileIn = new BufferedInputStream(new FileInputStream(fileName));
/*      */ 
/*      */       }
/* 3925 */       else if (fileName.indexOf(':') != -1) {
/*      */         try {
/* 3927 */           URL urlFromFileName = new URL(fileName);
/* 3928 */           fileIn = new BufferedInputStream(urlFromFileName.openStream());
/*      */         }
/*      */         catch (MalformedURLException badUrlEx) {
/* 3931 */           fileIn = new BufferedInputStream(new FileInputStream(fileName));
/*      */         }
/*      */         
/*      */       } else {
/* 3935 */         fileIn = new BufferedInputStream(new FileInputStream(fileName));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 3940 */       int bytesRead = 0;
/*      */       
/* 3942 */       while ((bytesRead = fileIn.read(fileBuf)) != -1) {
/* 3943 */         filePacket.clear();
/* 3944 */         filePacket.writeBytesNoNull(fileBuf, 0, bytesRead);
/* 3945 */         send(filePacket, filePacket.getPosition());
/*      */       }
/*      */     } catch (IOException ioEx) {
/* 3948 */       StringBuffer messageBuf = new StringBuffer(Messages.getString("MysqlIO.60"));
/*      */       
/*      */ 
/* 3951 */       if (!this.connection.getParanoid()) {
/* 3952 */         messageBuf.append("'");
/*      */         
/* 3954 */         if (fileName != null) {
/* 3955 */           messageBuf.append(fileName);
/*      */         }
/*      */         
/* 3958 */         messageBuf.append("'");
/*      */       }
/*      */       
/* 3961 */       messageBuf.append(Messages.getString("MysqlIO.63"));
/*      */       
/* 3963 */       if (!this.connection.getParanoid()) {
/* 3964 */         messageBuf.append(Messages.getString("MysqlIO.64"));
/* 3965 */         messageBuf.append(Util.stackTraceToString(ioEx));
/*      */       }
/*      */       
/* 3968 */       throw SQLError.createSQLException(messageBuf.toString(), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     finally {
/* 3971 */       if (fileIn != null) {
/*      */         try {
/* 3973 */           fileIn.close();
/*      */         } catch (Exception ex) {
/* 3975 */           SQLException sqlEx = SQLError.createSQLException(Messages.getString("MysqlIO.65"), "S1000", getExceptionInterceptor());
/*      */           
/* 3977 */           sqlEx.initCause(ex);
/*      */           
/* 3979 */           throw sqlEx;
/*      */         }
/*      */         
/* 3982 */         fileIn = null;
/*      */       }
/*      */       else {
/* 3985 */         filePacket.clear();
/* 3986 */         send(filePacket, filePacket.getPosition());
/* 3987 */         checkErrorPacket();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 3992 */     filePacket.clear();
/* 3993 */     send(filePacket, filePacket.getPosition());
/*      */     
/* 3995 */     Buffer resultPacket = checkErrorPacket();
/*      */     
/* 3997 */     return buildResultSetWithUpdates(callingStatement, resultPacket);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Buffer checkErrorPacket(int command)
/*      */     throws SQLException
/*      */   {
/* 4012 */     int statusCode = 0;
/* 4013 */     Buffer resultPacket = null;
/* 4014 */     this.serverStatus = 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/* 4021 */       resultPacket = reuseAndReadPacket(this.reusablePacket);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/* 4024 */       throw sqlEx;
/*      */     } catch (Exception fallThru) {
/* 4026 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, fallThru, getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 4030 */     checkErrorPacket(resultPacket);
/*      */     
/* 4032 */     return resultPacket;
/*      */   }
/*      */   
/*      */   private void checkErrorPacket(Buffer resultPacket) throws SQLException
/*      */   {
/* 4037 */     int statusCode = resultPacket.readByte();
/*      */     
/*      */ 
/* 4040 */     if (statusCode == -1)
/*      */     {
/* 4042 */       int errno = 2000;
/*      */       
/* 4044 */       if (this.protocolVersion > 9) {
/* 4045 */         errno = resultPacket.readInt();
/*      */         
/* 4047 */         String xOpen = null;
/*      */         
/* 4049 */         String serverErrorMessage = resultPacket.readString(this.connection.getErrorMessageEncoding(), getExceptionInterceptor());
/*      */         
/*      */ 
/* 4052 */         if (serverErrorMessage.charAt(0) == '#')
/*      */         {
/*      */ 
/* 4055 */           if (serverErrorMessage.length() > 6) {
/* 4056 */             xOpen = serverErrorMessage.substring(1, 6);
/* 4057 */             serverErrorMessage = serverErrorMessage.substring(6);
/*      */             
/* 4059 */             if (xOpen.equals("HY000")) {
/* 4060 */               xOpen = SQLError.mysqlToSqlState(errno, this.connection.getUseSqlStateCodes());
/*      */             }
/*      */           }
/*      */           else {
/* 4064 */             xOpen = SQLError.mysqlToSqlState(errno, this.connection.getUseSqlStateCodes());
/*      */           }
/*      */         }
/*      */         else {
/* 4068 */           xOpen = SQLError.mysqlToSqlState(errno, this.connection.getUseSqlStateCodes());
/*      */         }
/*      */         
/*      */ 
/* 4072 */         clearInputStream();
/*      */         
/* 4074 */         StringBuffer errorBuf = new StringBuffer();
/*      */         
/* 4076 */         String xOpenErrorMessage = SQLError.get(xOpen);
/*      */         
/* 4078 */         if ((!this.connection.getUseOnlyServerErrorMessages()) && 
/* 4079 */           (xOpenErrorMessage != null)) {
/* 4080 */           errorBuf.append(xOpenErrorMessage);
/* 4081 */           errorBuf.append(Messages.getString("MysqlIO.68"));
/*      */         }
/*      */         
/*      */ 
/* 4085 */         errorBuf.append(serverErrorMessage);
/*      */         
/* 4087 */         if ((!this.connection.getUseOnlyServerErrorMessages()) && 
/* 4088 */           (xOpenErrorMessage != null)) {
/* 4089 */           errorBuf.append("\"");
/*      */         }
/*      */         
/*      */ 
/* 4093 */         appendDeadlockStatusInformation(xOpen, errorBuf);
/*      */         
/* 4095 */         if ((xOpen != null) && (xOpen.startsWith("22"))) {
/* 4096 */           throw new MysqlDataTruncation(errorBuf.toString(), 0, true, false, 0, 0, errno);
/*      */         }
/* 4098 */         throw SQLError.createSQLException(errorBuf.toString(), xOpen, errno, false, getExceptionInterceptor(), this.connection);
/*      */       }
/*      */       
/*      */ 
/* 4102 */       String serverErrorMessage = resultPacket.readString(this.connection.getErrorMessageEncoding(), getExceptionInterceptor());
/*      */       
/* 4104 */       clearInputStream();
/*      */       
/* 4106 */       if (serverErrorMessage.indexOf(Messages.getString("MysqlIO.70")) != -1) {
/* 4107 */         throw SQLError.createSQLException(SQLError.get("S0022") + ", " + serverErrorMessage, "S0022", -1, false, getExceptionInterceptor(), this.connection);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4114 */       StringBuffer errorBuf = new StringBuffer(Messages.getString("MysqlIO.72"));
/*      */       
/* 4116 */       errorBuf.append(serverErrorMessage);
/* 4117 */       errorBuf.append("\"");
/*      */       
/* 4119 */       throw SQLError.createSQLException(SQLError.get("S1000") + ", " + errorBuf.toString(), "S1000", -1, false, getExceptionInterceptor(), this.connection);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void appendDeadlockStatusInformation(String xOpen, StringBuffer errorBuf)
/*      */     throws SQLException
/*      */   {
/* 4127 */     if ((this.connection.getIncludeInnodbStatusInDeadlockExceptions()) && (xOpen != null) && ((xOpen.startsWith("40")) || (xOpen.startsWith("41"))) && (this.streamingData == null))
/*      */     {
/*      */ 
/*      */ 
/* 4131 */       ResultSet rs = null;
/*      */       try
/*      */       {
/* 4134 */         rs = sqlQueryDirect(null, "SHOW ENGINE INNODB STATUS", this.connection.getEncoding(), null, -1, 1003, 1007, false, this.connection.getCatalog(), null);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4140 */         if (rs.next()) {
/* 4141 */           errorBuf.append("\n\n");
/* 4142 */           errorBuf.append(rs.getString("Status"));
/*      */         } else {
/* 4144 */           errorBuf.append("\n\n");
/* 4145 */           errorBuf.append(Messages.getString("MysqlIO.NoInnoDBStatusFound"));
/*      */         }
/*      */       }
/*      */       catch (Exception ex) {
/* 4149 */         errorBuf.append("\n\n");
/* 4150 */         errorBuf.append(Messages.getString("MysqlIO.InnoDBStatusFailed"));
/*      */         
/* 4152 */         errorBuf.append("\n\n");
/* 4153 */         errorBuf.append(Util.stackTraceToString(ex));
/*      */       } finally {
/* 4155 */         if (rs != null) {
/* 4156 */           rs.close();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 4161 */     if (this.connection.getIncludeThreadDumpInDeadlockExceptions()) {
/* 4162 */       errorBuf.append("\n\n*** Java threads running at time of deadlock ***\n\n");
/*      */       
/* 4164 */       ThreadMXBean threadMBean = ManagementFactory.getThreadMXBean();
/* 4165 */       long[] threadIds = threadMBean.getAllThreadIds();
/*      */       
/* 4167 */       ThreadInfo[] threads = threadMBean.getThreadInfo(threadIds, Integer.MAX_VALUE);
/*      */       
/* 4169 */       Object activeThreads = new ArrayList();
/*      */       
/* 4171 */       for (ThreadInfo info : threads) {
/* 4172 */         if (info != null) {
/* 4173 */           ((List)activeThreads).add(info);
/*      */         }
/*      */       }
/*      */       
/* 4177 */       for (ThreadInfo threadInfo : (List)activeThreads)
/*      */       {
/*      */ 
/*      */ 
/* 4181 */         errorBuf.append('"');
/* 4182 */         errorBuf.append(threadInfo.getThreadName());
/* 4183 */         errorBuf.append("\" tid=");
/* 4184 */         errorBuf.append(threadInfo.getThreadId());
/* 4185 */         errorBuf.append(" ");
/* 4186 */         errorBuf.append(threadInfo.getThreadState());
/*      */         
/* 4188 */         if (threadInfo.getLockName() != null) {
/* 4189 */           errorBuf.append(" on lock=" + threadInfo.getLockName());
/*      */         }
/* 4191 */         if (threadInfo.isSuspended()) {
/* 4192 */           errorBuf.append(" (suspended)");
/*      */         }
/* 4194 */         if (threadInfo.isInNative()) {
/* 4195 */           errorBuf.append(" (running in native)");
/*      */         }
/*      */         
/* 4198 */         StackTraceElement[] stackTrace = threadInfo.getStackTrace();
/*      */         
/* 4200 */         if (stackTrace.length > 0) {
/* 4201 */           errorBuf.append(" in ");
/* 4202 */           errorBuf.append(stackTrace[0].getClassName());
/* 4203 */           errorBuf.append(".");
/* 4204 */           errorBuf.append(stackTrace[0].getMethodName());
/* 4205 */           errorBuf.append("()");
/*      */         }
/*      */         
/* 4208 */         errorBuf.append("\n");
/*      */         
/* 4210 */         if (threadInfo.getLockOwnerName() != null) {
/* 4211 */           errorBuf.append("\t owned by " + threadInfo.getLockOwnerName() + " Id=" + threadInfo.getLockOwnerId());
/*      */           
/* 4213 */           errorBuf.append("\n");
/*      */         }
/*      */         
/* 4216 */         for (int j = 0; j < stackTrace.length; j++) {
/* 4217 */           StackTraceElement ste = stackTrace[j];
/* 4218 */           errorBuf.append("\tat " + ste.toString());
/* 4219 */           errorBuf.append("\n");
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void sendSplitPackets(Buffer packet)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 4245 */       Buffer headerPacket = this.splitBufRef == null ? null : (Buffer)this.splitBufRef.get();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4253 */       if (headerPacket == null) {
/* 4254 */         headerPacket = new Buffer(this.maxThreeBytes + 4);
/*      */         
/* 4256 */         this.splitBufRef = new SoftReference(headerPacket);
/*      */       }
/*      */       
/* 4259 */       int len = packet.getPosition();
/* 4260 */       int splitSize = this.maxThreeBytes;
/* 4261 */       int originalPacketPos = 4;
/* 4262 */       byte[] origPacketBytes = packet.getByteBuffer();
/* 4263 */       byte[] headerPacketBytes = headerPacket.getByteBuffer();
/*      */       
/* 4265 */       while (len >= this.maxThreeBytes) {
/* 4266 */         this.packetSequence = ((byte)(this.packetSequence + 1));
/*      */         
/* 4268 */         headerPacket.setPosition(0);
/* 4269 */         headerPacket.writeLongInt(splitSize);
/*      */         
/* 4271 */         headerPacket.writeByte(this.packetSequence);
/* 4272 */         System.arraycopy(origPacketBytes, originalPacketPos, headerPacketBytes, 4, splitSize);
/*      */         
/*      */ 
/* 4275 */         int packetLen = splitSize + 4;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4281 */         if (!this.useCompression) {
/* 4282 */           this.mysqlOutput.write(headerPacketBytes, 0, splitSize + 4);
/*      */           
/* 4284 */           this.mysqlOutput.flush();
/*      */         }
/*      */         else
/*      */         {
/* 4288 */           headerPacket.setPosition(0);
/* 4289 */           Buffer packetToSend = compressPacket(headerPacket, 4, splitSize, 4);
/*      */           
/* 4291 */           packetLen = packetToSend.getPosition();
/*      */           
/* 4293 */           this.mysqlOutput.write(packetToSend.getByteBuffer(), 0, packetLen);
/*      */           
/* 4295 */           this.mysqlOutput.flush();
/*      */         }
/*      */         
/* 4298 */         originalPacketPos += splitSize;
/* 4299 */         len -= splitSize;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 4305 */       headerPacket.clear();
/* 4306 */       headerPacket.setPosition(0);
/* 4307 */       headerPacket.writeLongInt(len - 4);
/* 4308 */       this.packetSequence = ((byte)(this.packetSequence + 1));
/* 4309 */       headerPacket.writeByte(this.packetSequence);
/*      */       
/* 4311 */       if (len != 0) {
/* 4312 */         System.arraycopy(origPacketBytes, originalPacketPos, headerPacketBytes, 4, len - 4);
/*      */       }
/*      */       
/*      */ 
/* 4316 */       int packetLen = len - 4;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4322 */       if (!this.useCompression) {
/* 4323 */         this.mysqlOutput.write(headerPacket.getByteBuffer(), 0, len);
/* 4324 */         this.mysqlOutput.flush();
/*      */       }
/*      */       else
/*      */       {
/* 4328 */         headerPacket.setPosition(0);
/* 4329 */         Buffer packetToSend = compressPacket(headerPacket, 4, packetLen, 4);
/*      */         
/* 4331 */         packetLen = packetToSend.getPosition();
/*      */         
/* 4333 */         this.mysqlOutput.write(packetToSend.getByteBuffer(), 0, packetLen);
/*      */         
/* 4335 */         this.mysqlOutput.flush();
/*      */       }
/*      */     } catch (IOException ioEx) {
/* 4338 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */   private void reclaimLargeSharedSendPacket()
/*      */   {
/* 4344 */     if ((this.sharedSendPacket != null) && (this.sharedSendPacket.getCapacity() > 1048576))
/*      */     {
/* 4346 */       this.sharedSendPacket = new Buffer(1024);
/*      */     }
/*      */   }
/*      */   
/*      */   boolean hadWarnings() {
/* 4351 */     return this.hadWarnings;
/*      */   }
/*      */   
/*      */   void scanForAndThrowDataTruncation() throws SQLException {
/* 4355 */     if ((this.streamingData == null) && (versionMeetsMinimum(4, 1, 0)) && (this.connection.getJdbcCompliantTruncation()) && (this.warningCount > 0))
/*      */     {
/* 4357 */       SQLError.convertShowWarningsToSQLWarnings(this.connection, this.warningCount, true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void secureAuth(Buffer packet, int packLength, String user, String password, String database, boolean writeClientParams)
/*      */     throws SQLException
/*      */   {
/* 4378 */     if (packet == null) {
/* 4379 */       packet = new Buffer(packLength);
/*      */     }
/*      */     
/* 4382 */     if (writeClientParams) {
/* 4383 */       if (this.use41Extensions) {
/* 4384 */         if (versionMeetsMinimum(4, 1, 1)) {
/* 4385 */           packet.writeLong(this.clientParam);
/* 4386 */           packet.writeLong(this.maxThreeBytes);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 4391 */           packet.writeByte((byte)8);
/*      */           
/*      */ 
/* 4394 */           packet.writeBytesNoNull(new byte[23]);
/*      */         } else {
/* 4396 */           packet.writeLong(this.clientParam);
/* 4397 */           packet.writeLong(this.maxThreeBytes);
/*      */         }
/*      */       } else {
/* 4400 */         packet.writeInt((int)this.clientParam);
/* 4401 */         packet.writeLongInt(this.maxThreeBytes);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 4406 */     packet.writeString(user, "Cp1252", this.connection);
/*      */     
/* 4408 */     if (password.length() != 0)
/*      */     {
/* 4410 */       packet.writeString("xxxxxxxx", "Cp1252", this.connection);
/*      */     }
/*      */     else {
/* 4413 */       packet.writeString("", "Cp1252", this.connection);
/*      */     }
/*      */     
/* 4416 */     if (this.useConnectWithDb) {
/* 4417 */       packet.writeString(database, "Cp1252", this.connection);
/*      */     }
/*      */     
/* 4420 */     send(packet, packet.getPosition());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4425 */     if (password.length() > 0) {
/* 4426 */       Buffer b = readPacket();
/*      */       
/* 4428 */       b.setPosition(0);
/*      */       
/* 4430 */       byte[] replyAsBytes = b.getByteBuffer();
/*      */       
/* 4432 */       if ((replyAsBytes.length == 25) && (replyAsBytes[0] != 0))
/*      */       {
/* 4434 */         if (replyAsBytes[0] != 42) {
/*      */           try
/*      */           {
/* 4437 */             byte[] buff = Security.passwordHashStage1(password);
/*      */             
/*      */ 
/* 4440 */             byte[] passwordHash = new byte[buff.length];
/* 4441 */             System.arraycopy(buff, 0, passwordHash, 0, buff.length);
/*      */             
/*      */ 
/* 4444 */             passwordHash = Security.passwordHashStage2(passwordHash, replyAsBytes);
/*      */             
/*      */ 
/* 4447 */             byte[] packetDataAfterSalt = new byte[replyAsBytes.length - 5];
/*      */             
/*      */ 
/* 4450 */             System.arraycopy(replyAsBytes, 4, packetDataAfterSalt, 0, replyAsBytes.length - 5);
/*      */             
/*      */ 
/* 4453 */             byte[] mysqlScrambleBuff = new byte[20];
/*      */             
/*      */ 
/* 4456 */             Security.passwordCrypt(packetDataAfterSalt, mysqlScrambleBuff, passwordHash, 20);
/*      */             
/*      */ 
/*      */ 
/* 4460 */             Security.passwordCrypt(mysqlScrambleBuff, buff, buff, 20);
/*      */             
/* 4462 */             Buffer packet2 = new Buffer(25);
/* 4463 */             packet2.writeBytesNoNull(buff);
/*      */             
/* 4465 */             this.packetSequence = ((byte)(this.packetSequence + 1));
/*      */             
/* 4467 */             send(packet2, 24);
/*      */           } catch (NoSuchAlgorithmException nse) {
/* 4469 */             throw SQLError.createSQLException(Messages.getString("MysqlIO.91") + Messages.getString("MysqlIO.92"), "S1000", getExceptionInterceptor());
/*      */           }
/*      */           
/*      */         }
/*      */         else {
/*      */           try
/*      */           {
/* 4476 */             byte[] passwordHash = Security.createKeyFromOldPassword(password);
/*      */             
/*      */ 
/* 4479 */             byte[] netReadPos4 = new byte[replyAsBytes.length - 5];
/*      */             
/* 4481 */             System.arraycopy(replyAsBytes, 4, netReadPos4, 0, replyAsBytes.length - 5);
/*      */             
/*      */ 
/* 4484 */             byte[] mysqlScrambleBuff = new byte[20];
/*      */             
/*      */ 
/* 4487 */             Security.passwordCrypt(netReadPos4, mysqlScrambleBuff, passwordHash, 20);
/*      */             
/*      */ 
/*      */ 
/* 4491 */             String scrambledPassword = Util.scramble(StringUtils.toString(mysqlScrambleBuff), password);
/*      */             
/*      */ 
/* 4494 */             Buffer packet2 = new Buffer(packLength);
/* 4495 */             packet2.writeString(scrambledPassword, "Cp1252", this.connection);
/* 4496 */             this.packetSequence = ((byte)(this.packetSequence + 1));
/*      */             
/* 4498 */             send(packet2, 24);
/*      */           } catch (NoSuchAlgorithmException nse) {
/* 4500 */             throw SQLError.createSQLException(Messages.getString("MysqlIO.93") + Messages.getString("MysqlIO.94"), "S1000", getExceptionInterceptor());
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void secureAuth411(Buffer packet, int packLength, String user, String password, String database, boolean writeClientParams)
/*      */     throws SQLException
/*      */   {
/* 4542 */     if (packet == null) {
/* 4543 */       packet = new Buffer(packLength);
/*      */     }
/*      */     
/* 4546 */     if (writeClientParams) {
/* 4547 */       if (this.use41Extensions) {
/* 4548 */         if (versionMeetsMinimum(4, 1, 1)) {
/* 4549 */           packet.writeLong(this.clientParam);
/* 4550 */           packet.writeLong(this.maxThreeBytes);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 4555 */           packet.writeByte((byte)33);
/*      */           
/*      */ 
/* 4558 */           packet.writeBytesNoNull(new byte[23]);
/*      */         } else {
/* 4560 */           packet.writeLong(this.clientParam);
/* 4561 */           packet.writeLong(this.maxThreeBytes);
/*      */         }
/*      */       } else {
/* 4564 */         packet.writeInt((int)this.clientParam);
/* 4565 */         packet.writeLongInt(this.maxThreeBytes);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 4570 */     packet.writeString(user, "utf-8", this.connection);
/*      */     
/* 4572 */     if (password.length() != 0) {
/* 4573 */       packet.writeByte((byte)20);
/*      */       try
/*      */       {
/* 4576 */         packet.writeBytesNoNull(Security.scramble411(password, this.seed, this.connection));
/*      */       } catch (NoSuchAlgorithmException nse) {
/* 4578 */         throw SQLError.createSQLException(Messages.getString("MysqlIO.95") + Messages.getString("MysqlIO.96"), "S1000", getExceptionInterceptor());
/*      */       }
/*      */       catch (UnsupportedEncodingException e)
/*      */       {
/* 4582 */         throw SQLError.createSQLException(Messages.getString("MysqlIO.95") + Messages.getString("MysqlIO.96"), "S1000", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */     }
/*      */     else
/*      */     {
/* 4588 */       packet.writeByte((byte)0);
/*      */     }
/*      */     
/* 4591 */     if (this.useConnectWithDb) {
/* 4592 */       packet.writeString(database, "utf-8", this.connection);
/*      */     }
/*      */     else {
/* 4595 */       packet.writeByte((byte)0);
/*      */     }
/*      */     
/* 4598 */     send(packet, packet.getPosition());
/*      */     
/* 4600 */     byte savePacketSequence = this.packetSequence++;
/*      */     
/* 4602 */     Buffer reply = checkErrorPacket();
/*      */     
/* 4604 */     if (reply.isLastDataPacket())
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 4609 */       savePacketSequence = (byte)(savePacketSequence + 1);this.packetSequence = savePacketSequence;
/* 4610 */       packet.clear();
/*      */       
/* 4612 */       String seed323 = this.seed.substring(0, 8);
/* 4613 */       packet.writeString(Util.newCrypt(password, seed323));
/* 4614 */       send(packet, packet.getPosition());
/*      */       
/*      */ 
/* 4617 */       checkErrorPacket();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final ResultSetRow unpackBinaryResultSetRow(Field[] fields, Buffer binaryData, int resultSetConcurrency)
/*      */     throws SQLException
/*      */   {
/* 4634 */     int numFields = fields.length;
/*      */     
/* 4636 */     byte[][] unpackedRowData = new byte[numFields][];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4643 */     int nullCount = (numFields + 9) / 8;
/*      */     
/* 4645 */     byte[] nullBitMask = new byte[nullCount];
/*      */     
/* 4647 */     for (int i = 0; i < nullCount; i++) {
/* 4648 */       nullBitMask[i] = binaryData.readByte();
/*      */     }
/*      */     
/* 4651 */     int nullMaskPos = 0;
/* 4652 */     int bit = 4;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4659 */     for (int i = 0; i < numFields; i++) {
/* 4660 */       if ((nullBitMask[nullMaskPos] & bit) != 0) {
/* 4661 */         unpackedRowData[i] = null;
/*      */       }
/* 4663 */       else if (resultSetConcurrency != 1008) {
/* 4664 */         extractNativeEncodedColumn(binaryData, fields, i, unpackedRowData);
/*      */       }
/*      */       else {
/* 4667 */         unpackNativeEncodedColumn(binaryData, fields, i, unpackedRowData);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 4672 */       if ((bit <<= 1 & 0xFF) == 0) {
/* 4673 */         bit = 1;
/*      */         
/* 4675 */         nullMaskPos++;
/*      */       }
/*      */     }
/*      */     
/* 4679 */     return new ByteArrayRow(unpackedRowData, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */   private final void extractNativeEncodedColumn(Buffer binaryData, Field[] fields, int columnIndex, byte[][] unpackedRowData)
/*      */     throws SQLException
/*      */   {
/* 4685 */     Field curField = fields[columnIndex];
/*      */     int length;
/* 4687 */     switch (curField.getMysqlType())
/*      */     {
/*      */     case 6: 
/*      */       break;
/*      */     
/*      */     case 1: 
/* 4693 */       unpackedRowData[columnIndex] = { binaryData.readByte() };
/* 4694 */       break;
/*      */     
/*      */ 
/*      */     case 2: 
/*      */     case 13: 
/* 4699 */       unpackedRowData[columnIndex] = binaryData.getBytes(2);
/* 4700 */       break;
/*      */     
/*      */     case 3: 
/*      */     case 9: 
/* 4704 */       unpackedRowData[columnIndex] = binaryData.getBytes(4);
/* 4705 */       break;
/*      */     
/*      */     case 8: 
/* 4708 */       unpackedRowData[columnIndex] = binaryData.getBytes(8);
/* 4709 */       break;
/*      */     
/*      */     case 4: 
/* 4712 */       unpackedRowData[columnIndex] = binaryData.getBytes(4);
/* 4713 */       break;
/*      */     
/*      */     case 5: 
/* 4716 */       unpackedRowData[columnIndex] = binaryData.getBytes(8);
/* 4717 */       break;
/*      */     
/*      */     case 11: 
/* 4720 */       length = (int)binaryData.readFieldLength();
/*      */       
/* 4722 */       unpackedRowData[columnIndex] = binaryData.getBytes(length);
/*      */       
/* 4724 */       break;
/*      */     
/*      */     case 10: 
/* 4727 */       length = (int)binaryData.readFieldLength();
/*      */       
/* 4729 */       unpackedRowData[columnIndex] = binaryData.getBytes(length);
/*      */       
/* 4731 */       break;
/*      */     case 7: 
/*      */     case 12: 
/* 4734 */       length = (int)binaryData.readFieldLength();
/*      */       
/* 4736 */       unpackedRowData[columnIndex] = binaryData.getBytes(length);
/* 4737 */       break;
/*      */     case 0: 
/*      */     case 15: 
/*      */     case 246: 
/*      */     case 249: 
/*      */     case 250: 
/*      */     case 251: 
/*      */     case 252: 
/*      */     case 253: 
/*      */     case 254: 
/*      */     case 255: 
/* 4748 */       unpackedRowData[columnIndex] = binaryData.readLenByteArray(0);
/*      */       
/* 4750 */       break;
/*      */     case 16: 
/* 4752 */       unpackedRowData[columnIndex] = binaryData.readLenByteArray(0);
/*      */       
/* 4754 */       break;
/*      */     default: 
/* 4756 */       throw SQLError.createSQLException(Messages.getString("MysqlIO.97") + curField.getMysqlType() + Messages.getString("MysqlIO.98") + columnIndex + Messages.getString("MysqlIO.99") + fields.length + Messages.getString("MysqlIO.100"), "S1000", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void unpackNativeEncodedColumn(Buffer binaryData, Field[] fields, int columnIndex, byte[][] unpackedRowData)
/*      */     throws SQLException
/*      */   {
/* 4768 */     Field curField = fields[columnIndex];
/*      */     int length;
/* 4770 */     int hour; int minute; int seconds; int year; int month; int day; int after1000; int after100; switch (curField.getMysqlType())
/*      */     {
/*      */     case 6: 
/*      */       break;
/*      */     
/*      */     case 1: 
/* 4776 */       byte tinyVal = binaryData.readByte();
/*      */       
/* 4778 */       if (!curField.isUnsigned()) {
/* 4779 */         unpackedRowData[columnIndex] = StringUtils.getBytes(String.valueOf(tinyVal));
/*      */       }
/*      */       else {
/* 4782 */         short unsignedTinyVal = (short)(tinyVal & 0xFF);
/*      */         
/* 4784 */         unpackedRowData[columnIndex] = StringUtils.getBytes(String.valueOf(unsignedTinyVal));
/*      */       }
/*      */       
/*      */ 
/* 4788 */       break;
/*      */     
/*      */ 
/*      */     case 2: 
/*      */     case 13: 
/* 4793 */       short shortVal = (short)binaryData.readInt();
/*      */       
/* 4795 */       if (!curField.isUnsigned()) {
/* 4796 */         unpackedRowData[columnIndex] = StringUtils.getBytes(String.valueOf(shortVal));
/*      */       }
/*      */       else {
/* 4799 */         int unsignedShortVal = shortVal & 0xFFFF;
/*      */         
/* 4801 */         unpackedRowData[columnIndex] = StringUtils.getBytes(String.valueOf(unsignedShortVal));
/*      */       }
/*      */       
/*      */ 
/* 4805 */       break;
/*      */     
/*      */ 
/*      */     case 3: 
/*      */     case 9: 
/* 4810 */       int intVal = (int)binaryData.readLong();
/*      */       
/* 4812 */       if (!curField.isUnsigned()) {
/* 4813 */         unpackedRowData[columnIndex] = StringUtils.getBytes(String.valueOf(intVal));
/*      */       }
/*      */       else {
/* 4816 */         long longVal = intVal & 0xFFFFFFFF;
/*      */         
/* 4818 */         unpackedRowData[columnIndex] = StringUtils.getBytes(String.valueOf(longVal));
/*      */       }
/*      */       
/*      */ 
/* 4822 */       break;
/*      */     
/*      */ 
/*      */     case 8: 
/* 4826 */       long longVal = binaryData.readLongLong();
/*      */       
/* 4828 */       if (!curField.isUnsigned()) {
/* 4829 */         unpackedRowData[columnIndex] = StringUtils.getBytes(String.valueOf(longVal));
/*      */       }
/*      */       else {
/* 4832 */         BigInteger asBigInteger = ResultSetImpl.convertLongToUlong(longVal);
/*      */         
/* 4834 */         unpackedRowData[columnIndex] = StringUtils.getBytes(asBigInteger.toString());
/*      */       }
/*      */       
/*      */ 
/* 4838 */       break;
/*      */     
/*      */ 
/*      */     case 4: 
/* 4842 */       float floatVal = Float.intBitsToFloat(binaryData.readIntAsLong());
/*      */       
/* 4844 */       unpackedRowData[columnIndex] = StringUtils.getBytes(String.valueOf(floatVal));
/*      */       
/*      */ 
/* 4847 */       break;
/*      */     
/*      */ 
/*      */     case 5: 
/* 4851 */       double doubleVal = Double.longBitsToDouble(binaryData.readLongLong());
/*      */       
/* 4853 */       unpackedRowData[columnIndex] = StringUtils.getBytes(String.valueOf(doubleVal));
/*      */       
/*      */ 
/* 4856 */       break;
/*      */     
/*      */ 
/*      */     case 11: 
/* 4860 */       length = (int)binaryData.readFieldLength();
/*      */       
/* 4862 */       hour = 0;
/* 4863 */       minute = 0;
/* 4864 */       seconds = 0;
/*      */       
/* 4866 */       if (length != 0) {
/* 4867 */         binaryData.readByte();
/* 4868 */         binaryData.readLong();
/* 4869 */         hour = binaryData.readByte();
/* 4870 */         minute = binaryData.readByte();
/* 4871 */         seconds = binaryData.readByte();
/*      */         
/* 4873 */         if (length > 8) {
/* 4874 */           binaryData.readLong();
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 4879 */       byte[] timeAsBytes = new byte[8];
/*      */       
/* 4881 */       timeAsBytes[0] = ((byte)Character.forDigit(hour / 10, 10));
/* 4882 */       timeAsBytes[1] = ((byte)Character.forDigit(hour % 10, 10));
/*      */       
/* 4884 */       timeAsBytes[2] = 58;
/*      */       
/* 4886 */       timeAsBytes[3] = ((byte)Character.forDigit(minute / 10, 10));
/*      */       
/* 4888 */       timeAsBytes[4] = ((byte)Character.forDigit(minute % 10, 10));
/*      */       
/*      */ 
/* 4891 */       timeAsBytes[5] = 58;
/*      */       
/* 4893 */       timeAsBytes[6] = ((byte)Character.forDigit(seconds / 10, 10));
/*      */       
/* 4895 */       timeAsBytes[7] = ((byte)Character.forDigit(seconds % 10, 10));
/*      */       
/*      */ 
/* 4898 */       unpackedRowData[columnIndex] = timeAsBytes;
/*      */       
/*      */ 
/* 4901 */       break;
/*      */     
/*      */     case 10: 
/* 4904 */       length = (int)binaryData.readFieldLength();
/*      */       
/* 4906 */       year = 0;
/* 4907 */       month = 0;
/* 4908 */       day = 0;
/*      */       
/* 4910 */       hour = 0;
/* 4911 */       minute = 0;
/* 4912 */       seconds = 0;
/*      */       
/* 4914 */       if (length != 0) {
/* 4915 */         year = binaryData.readInt();
/* 4916 */         month = binaryData.readByte();
/* 4917 */         day = binaryData.readByte();
/*      */       }
/*      */       
/* 4920 */       if ((year == 0) && (month == 0) && (day == 0)) {
/* 4921 */         if ("convertToNull".equals(this.connection.getZeroDateTimeBehavior()))
/*      */         {
/* 4923 */           unpackedRowData[columnIndex] = null;
/*      */         }
/*      */         else {
/* 4926 */           if ("exception".equals(this.connection.getZeroDateTimeBehavior()))
/*      */           {
/* 4928 */             throw SQLError.createSQLException("Value '0000-00-00' can not be represented as java.sql.Date", "S1009", getExceptionInterceptor());
/*      */           }
/*      */           
/*      */ 
/* 4932 */           year = 1;
/* 4933 */           month = 1;
/* 4934 */           day = 1;
/*      */         }
/*      */       }
/*      */       else {
/* 4938 */         byte[] dateAsBytes = new byte[10];
/*      */         
/* 4940 */         dateAsBytes[0] = ((byte)Character.forDigit(year / 1000, 10));
/*      */         
/*      */ 
/* 4943 */         after1000 = year % 1000;
/*      */         
/* 4945 */         dateAsBytes[1] = ((byte)Character.forDigit(after1000 / 100, 10));
/*      */         
/*      */ 
/* 4948 */         after100 = after1000 % 100;
/*      */         
/* 4950 */         dateAsBytes[2] = ((byte)Character.forDigit(after100 / 10, 10));
/*      */         
/* 4952 */         dateAsBytes[3] = ((byte)Character.forDigit(after100 % 10, 10));
/*      */         
/*      */ 
/* 4955 */         dateAsBytes[4] = 45;
/*      */         
/* 4957 */         dateAsBytes[5] = ((byte)Character.forDigit(month / 10, 10));
/*      */         
/* 4959 */         dateAsBytes[6] = ((byte)Character.forDigit(month % 10, 10));
/*      */         
/*      */ 
/* 4962 */         dateAsBytes[7] = 45;
/*      */         
/* 4964 */         dateAsBytes[8] = ((byte)Character.forDigit(day / 10, 10));
/* 4965 */         dateAsBytes[9] = ((byte)Character.forDigit(day % 10, 10));
/*      */         
/* 4967 */         unpackedRowData[columnIndex] = dateAsBytes;
/*      */       }
/*      */       
/* 4970 */       break;
/*      */     
/*      */     case 7: 
/*      */     case 12: 
/* 4974 */       length = (int)binaryData.readFieldLength();
/*      */       
/* 4976 */       year = 0;
/* 4977 */       month = 0;
/* 4978 */       day = 0;
/*      */       
/* 4980 */       hour = 0;
/* 4981 */       minute = 0;
/* 4982 */       seconds = 0;
/*      */       
/* 4984 */       int nanos = 0;
/*      */       
/* 4986 */       if (length != 0) {
/* 4987 */         year = binaryData.readInt();
/* 4988 */         month = binaryData.readByte();
/* 4989 */         day = binaryData.readByte();
/*      */         
/* 4991 */         if (length > 4) {
/* 4992 */           hour = binaryData.readByte();
/* 4993 */           minute = binaryData.readByte();
/* 4994 */           seconds = binaryData.readByte();
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5002 */       if ((year == 0) && (month == 0) && (day == 0)) {
/* 5003 */         if ("convertToNull".equals(this.connection.getZeroDateTimeBehavior()))
/*      */         {
/* 5005 */           unpackedRowData[columnIndex] = null;
/*      */         }
/*      */         else {
/* 5008 */           if ("exception".equals(this.connection.getZeroDateTimeBehavior()))
/*      */           {
/* 5010 */             throw SQLError.createSQLException("Value '0000-00-00' can not be represented as java.sql.Timestamp", "S1009", getExceptionInterceptor());
/*      */           }
/*      */           
/*      */ 
/* 5014 */           year = 1;
/* 5015 */           month = 1;
/* 5016 */           day = 1;
/*      */         }
/*      */       }
/*      */       else {
/* 5020 */         int stringLength = 19;
/*      */         
/* 5022 */         byte[] nanosAsBytes = StringUtils.getBytes(Integer.toString(nanos));
/*      */         
/* 5024 */         stringLength += 1 + nanosAsBytes.length;
/*      */         
/* 5026 */         byte[] datetimeAsBytes = new byte[stringLength];
/*      */         
/* 5028 */         datetimeAsBytes[0] = ((byte)Character.forDigit(year / 1000, 10));
/*      */         
/*      */ 
/* 5031 */         after1000 = year % 1000;
/*      */         
/* 5033 */         datetimeAsBytes[1] = ((byte)Character.forDigit(after1000 / 100, 10));
/*      */         
/*      */ 
/* 5036 */         after100 = after1000 % 100;
/*      */         
/* 5038 */         datetimeAsBytes[2] = ((byte)Character.forDigit(after100 / 10, 10));
/*      */         
/* 5040 */         datetimeAsBytes[3] = ((byte)Character.forDigit(after100 % 10, 10));
/*      */         
/*      */ 
/* 5043 */         datetimeAsBytes[4] = 45;
/*      */         
/* 5045 */         datetimeAsBytes[5] = ((byte)Character.forDigit(month / 10, 10));
/*      */         
/* 5047 */         datetimeAsBytes[6] = ((byte)Character.forDigit(month % 10, 10));
/*      */         
/*      */ 
/* 5050 */         datetimeAsBytes[7] = 45;
/*      */         
/* 5052 */         datetimeAsBytes[8] = ((byte)Character.forDigit(day / 10, 10));
/*      */         
/* 5054 */         datetimeAsBytes[9] = ((byte)Character.forDigit(day % 10, 10));
/*      */         
/*      */ 
/* 5057 */         datetimeAsBytes[10] = 32;
/*      */         
/* 5059 */         datetimeAsBytes[11] = ((byte)Character.forDigit(hour / 10, 10));
/*      */         
/* 5061 */         datetimeAsBytes[12] = ((byte)Character.forDigit(hour % 10, 10));
/*      */         
/*      */ 
/* 5064 */         datetimeAsBytes[13] = 58;
/*      */         
/* 5066 */         datetimeAsBytes[14] = ((byte)Character.forDigit(minute / 10, 10));
/*      */         
/* 5068 */         datetimeAsBytes[15] = ((byte)Character.forDigit(minute % 10, 10));
/*      */         
/*      */ 
/* 5071 */         datetimeAsBytes[16] = 58;
/*      */         
/* 5073 */         datetimeAsBytes[17] = ((byte)Character.forDigit(seconds / 10, 10));
/*      */         
/* 5075 */         datetimeAsBytes[18] = ((byte)Character.forDigit(seconds % 10, 10));
/*      */         
/*      */ 
/* 5078 */         datetimeAsBytes[19] = 46;
/*      */         
/* 5080 */         int nanosOffset = 20;
/*      */         
/* 5082 */         for (int j = 0; j < nanosAsBytes.length; j++) {
/* 5083 */           datetimeAsBytes[(nanosOffset + j)] = nanosAsBytes[j];
/*      */         }
/*      */         
/* 5086 */         unpackedRowData[columnIndex] = datetimeAsBytes;
/*      */       }
/*      */       
/* 5089 */       break;
/*      */     
/*      */     case 0: 
/*      */     case 15: 
/*      */     case 16: 
/*      */     case 246: 
/*      */     case 249: 
/*      */     case 250: 
/*      */     case 251: 
/*      */     case 252: 
/*      */     case 253: 
/*      */     case 254: 
/* 5101 */       unpackedRowData[columnIndex] = binaryData.readLenByteArray(0);
/*      */       
/* 5103 */       break;
/*      */     
/*      */     default: 
/* 5106 */       throw SQLError.createSQLException(Messages.getString("MysqlIO.97") + curField.getMysqlType() + Messages.getString("MysqlIO.98") + columnIndex + Messages.getString("MysqlIO.99") + fields.length + Messages.getString("MysqlIO.100"), "S1000", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void negotiateSSLConnection(String user, String password, String database, int packLength)
/*      */     throws SQLException
/*      */   {
/* 5129 */     if (!ExportControlled.enabled()) {
/* 5130 */       throw new ConnectionFeatureNotAvailableException(this.connection, this.lastPacketSentTimeMs, null);
/*      */     }
/*      */     
/*      */ 
/* 5134 */     if ((this.serverCapabilities & 0x8000) != 0) {
/* 5135 */       this.clientParam |= 0x8000;
/*      */     }
/*      */     
/* 5138 */     this.clientParam |= 0x800;
/*      */     
/* 5140 */     Buffer packet = new Buffer(packLength);
/*      */     
/* 5142 */     if (this.use41Extensions) {
/* 5143 */       packet.writeLong(this.clientParam);
/*      */     } else {
/* 5145 */       packet.writeInt((int)this.clientParam);
/*      */     }
/*      */     
/* 5148 */     send(packet, packet.getPosition());
/*      */     
/* 5150 */     ExportControlled.transformSocketToSSLSocket(this);
/*      */   }
/*      */   
/*      */   protected int getServerStatus() {
/* 5154 */     return this.serverStatus;
/*      */   }
/*      */   
/*      */   protected List fetchRowsViaCursor(List fetchedRows, long statementId, Field[] columnTypes, int fetchSize, boolean useBufferRowExplicit)
/*      */     throws SQLException
/*      */   {
/* 5160 */     if (fetchedRows == null) {
/* 5161 */       fetchedRows = new ArrayList(fetchSize);
/*      */     } else {
/* 5163 */       fetchedRows.clear();
/*      */     }
/*      */     
/* 5166 */     this.sharedSendPacket.clear();
/*      */     
/* 5168 */     this.sharedSendPacket.writeByte((byte)28);
/* 5169 */     this.sharedSendPacket.writeLong(statementId);
/* 5170 */     this.sharedSendPacket.writeLong(fetchSize);
/*      */     
/* 5172 */     sendCommand(28, null, this.sharedSendPacket, true, null, 0);
/*      */     
/*      */ 
/* 5175 */     ResultSetRow row = null;
/*      */     
/*      */ 
/* 5178 */     while ((row = nextRow(columnTypes, columnTypes.length, true, 1007, false, useBufferRowExplicit, false, null)) != null) {
/* 5179 */       fetchedRows.add(row);
/*      */     }
/*      */     
/* 5182 */     return fetchedRows;
/*      */   }
/*      */   
/*      */   protected long getThreadId() {
/* 5186 */     return this.threadId;
/*      */   }
/*      */   
/*      */   protected boolean useNanosForElapsedTime() {
/* 5190 */     return this.useNanosForElapsedTime;
/*      */   }
/*      */   
/*      */   protected long getSlowQueryThreshold() {
/* 5194 */     return this.slowQueryThreshold;
/*      */   }
/*      */   
/*      */   protected String getQueryTimingUnits() {
/* 5198 */     return this.queryTimingUnits;
/*      */   }
/*      */   
/*      */   protected int getCommandCount() {
/* 5202 */     return this.commandCount;
/*      */   }
/*      */   
/*      */   private void checkTransactionState(int oldStatus) throws SQLException {
/* 5206 */     boolean previouslyInTrans = (oldStatus & 0x1) != 0;
/* 5207 */     boolean currentlyInTrans = (this.serverStatus & 0x1) != 0;
/*      */     
/* 5209 */     if ((previouslyInTrans) && (!currentlyInTrans)) {
/* 5210 */       this.connection.transactionCompleted();
/* 5211 */     } else if ((!previouslyInTrans) && (currentlyInTrans)) {
/* 5212 */       this.connection.transactionBegun();
/*      */     }
/*      */   }
/*      */   
/*      */   protected void setStatementInterceptors(List statementInterceptors) {
/* 5217 */     this.statementInterceptors = statementInterceptors;
/*      */   }
/*      */   
/*      */   protected ExceptionInterceptor getExceptionInterceptor() {
/* 5221 */     return this.exceptionInterceptor;
/*      */   }
/*      */ }


/* Location:              C:\Users\Static\Desktop\G10_Prototype_Server.jar!\mysql-connector-java-5.1.19-bin.jar!\com\mysql\jdbc\MysqlIO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */