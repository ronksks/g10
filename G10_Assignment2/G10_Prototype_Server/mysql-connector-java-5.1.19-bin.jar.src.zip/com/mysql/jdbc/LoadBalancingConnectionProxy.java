/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.InvocationHandler;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Proxy;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class LoadBalancingConnectionProxy
/*      */   implements InvocationHandler, PingTarget
/*      */ {
/*      */   private static Method getLocalTimeMethod;
/*   67 */   private long totalPhysicalConnections = 0L;
/*   68 */   private long activePhysicalConnections = 0L;
/*   69 */   private String hostToRemove = null;
/*   70 */   private long lastUsed = 0L;
/*   71 */   private long transactionCount = 0L;
/*   72 */   private ConnectionGroup connectionGroup = null;
/*   73 */   private String closedReason = null;
/*      */   
/*      */   public static final String BLACKLIST_TIMEOUT_PROPERTY_KEY = "loadBalanceBlacklistTimeout";
/*      */   
/*      */   protected MySQLConnection currentConn;
/*      */   
/*      */   protected List<String> hostList;
/*      */   
/*      */   protected Map<String, ConnectionImpl> liveConnections;
/*      */   
/*      */   private Map<ConnectionImpl, String> connectionsToHostsMap;
/*      */   
/*      */   private long[] responseTimes;
/*      */   
/*      */   private Map<String, Integer> hostsToListIndexMap;
/*      */   
/*      */   protected class ConnectionErrorFiringInvocationHandler
/*      */     implements InvocationHandler
/*      */   {
/*   92 */     Object invokeOn = null;
/*      */     
/*      */     public ConnectionErrorFiringInvocationHandler(Object toInvokeOn) {
/*   95 */       this.invokeOn = toInvokeOn;
/*      */     }
/*      */     
/*      */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
/*      */     {
/*  100 */       Object result = null;
/*      */       try
/*      */       {
/*  103 */         result = method.invoke(this.invokeOn, args);
/*      */         
/*  105 */         if (result != null) {
/*  106 */           result = LoadBalancingConnectionProxy.this.proxyIfInterfaceIsJdbc(result, result.getClass());
/*      */         }
/*      */       } catch (InvocationTargetException e) {
/*  109 */         LoadBalancingConnectionProxy.this.dealWithInvocationException(e);
/*      */       }
/*      */       
/*  112 */       return result;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  128 */   private boolean inTransaction = false;
/*      */   
/*  130 */   private long transactionStartTime = 0L;
/*      */   
/*      */   private Properties localProps;
/*      */   
/*  134 */   private boolean isClosed = false;
/*      */   
/*      */   private BalanceStrategy balancer;
/*      */   
/*      */   private int retriesAllDown;
/*      */   
/*      */   private static Map<String, Long> globalBlacklist;
/*      */   
/*  142 */   private int globalBlacklistTimeout = 0;
/*      */   
/*  144 */   private long connectionGroupProxyID = 0L;
/*      */   
/*      */   private LoadBalanceExceptionChecker exceptionChecker;
/*      */   
/*  148 */   private Map<Class, Boolean> jdbcInterfacesForProxyCache = new HashMap();
/*      */   
/*  150 */   private MySQLConnection thisAsConnection = null;
/*      */   
/*  152 */   private int autoCommitSwapThreshold = 0;
/*      */   private static Constructor JDBC_4_LB_CONNECTION_CTOR;
/*      */   
/*      */   static
/*      */   {
/*      */     try
/*      */     {
/*   79 */       getLocalTimeMethod = System.class.getMethod("nanoTime", new Class[0]);
/*      */     }
/*      */     catch (SecurityException e) {}catch (NoSuchMethodException e) {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  140 */     globalBlacklist = new HashMap();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  157 */     if (Util.isJdbc4()) {
/*      */       try {
/*  159 */         JDBC_4_LB_CONNECTION_CTOR = Class.forName("com.mysql.jdbc.JDBC4LoadBalancedMySQLConnection").getConstructor(new Class[] { LoadBalancingConnectionProxy.class });
/*      */       }
/*      */       catch (SecurityException e)
/*      */       {
/*  163 */         throw new RuntimeException(e);
/*      */       } catch (NoSuchMethodException e) {
/*  165 */         throw new RuntimeException(e);
/*      */       } catch (ClassNotFoundException e) {
/*  167 */         throw new RuntimeException(e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   LoadBalancingConnectionProxy(List<String> hosts, Properties props)
/*      */     throws SQLException
/*      */   {
/*  189 */     String group = props.getProperty("loadBalanceConnectionGroup", null);
/*      */     
/*  191 */     boolean enableJMX = false;
/*  192 */     String enableJMXAsString = props.getProperty("loadBalanceEnableJMX", "false");
/*      */     try
/*      */     {
/*  195 */       enableJMX = Boolean.parseBoolean(enableJMXAsString);
/*      */     } catch (Exception e) {
/*  197 */       throw SQLError.createSQLException(Messages.getString("LoadBalancingConnectionProxy.badValueForLoadBalanceEnableJMX", new Object[] { enableJMXAsString }), "S1009", null);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  203 */     if (group != null) {
/*  204 */       this.connectionGroup = ConnectionGroupManager.getConnectionGroupInstance(group);
/*  205 */       if (enableJMX) {
/*  206 */         ConnectionGroupManager.registerJmx();
/*      */       }
/*  208 */       this.connectionGroupProxyID = this.connectionGroup.registerConnectionProxy(this, hosts);
/*  209 */       hosts = new ArrayList(this.connectionGroup.getInitialHosts());
/*      */     }
/*      */     
/*  212 */     this.hostList = hosts;
/*      */     
/*  214 */     int numHosts = this.hostList.size();
/*      */     
/*  216 */     this.liveConnections = new HashMap(numHosts);
/*  217 */     this.connectionsToHostsMap = new HashMap(numHosts);
/*  218 */     this.responseTimes = new long[numHosts];
/*  219 */     this.hostsToListIndexMap = new HashMap(numHosts);
/*      */     
/*  221 */     this.localProps = ((Properties)props.clone());
/*  222 */     this.localProps.remove("HOST");
/*  223 */     this.localProps.remove("PORT");
/*      */     
/*  225 */     for (int i = 0; i < numHosts; i++) {
/*  226 */       this.hostsToListIndexMap.put(this.hostList.get(i), Integer.valueOf(i));
/*  227 */       this.localProps.remove("HOST." + (i + 1));
/*      */       
/*  229 */       this.localProps.remove("PORT." + (i + 1));
/*      */     }
/*      */     
/*      */ 
/*  233 */     this.localProps.remove("NUM_HOSTS");
/*  234 */     this.localProps.setProperty("useLocalSessionState", "true");
/*      */     
/*  236 */     String strategy = this.localProps.getProperty("loadBalanceStrategy", "random");
/*      */     
/*      */ 
/*  239 */     String lbExceptionChecker = this.localProps.getProperty("loadBalanceExceptionChecker", "com.mysql.jdbc.StandardLoadBalanceExceptionChecker");
/*      */     
/*      */ 
/*      */ 
/*  243 */     String retriesAllDownAsString = this.localProps.getProperty("retriesAllDown", "120");
/*      */     
/*      */     try
/*      */     {
/*  247 */       this.retriesAllDown = Integer.parseInt(retriesAllDownAsString);
/*      */     } catch (NumberFormatException nfe) {
/*  249 */       throw SQLError.createSQLException(Messages.getString("LoadBalancingConnectionProxy.badValueForRetriesAllDown", new Object[] { retriesAllDownAsString }), "S1009", null);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  254 */     String blacklistTimeoutAsString = this.localProps.getProperty("loadBalanceBlacklistTimeout", "0");
/*      */     
/*      */     try
/*      */     {
/*  258 */       this.globalBlacklistTimeout = Integer.parseInt(blacklistTimeoutAsString);
/*      */     }
/*      */     catch (NumberFormatException nfe) {
/*  261 */       throw SQLError.createSQLException(Messages.getString("LoadBalancingConnectionProxy.badValueForLoadBalanceBlacklistTimeout", new Object[] { retriesAllDownAsString }), "S1009", null);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  270 */     if ("random".equals(strategy)) {
/*  271 */       this.balancer = ((BalanceStrategy)Util.loadExtensions(null, props, "com.mysql.jdbc.RandomBalanceStrategy", "InvalidLoadBalanceStrategy", null).get(0));
/*      */ 
/*      */     }
/*  274 */     else if ("bestResponseTime".equals(strategy)) {
/*  275 */       this.balancer = ((BalanceStrategy)Util.loadExtensions(null, props, "com.mysql.jdbc.BestResponseTimeBalanceStrategy", "InvalidLoadBalanceStrategy", null).get(0));
/*      */     }
/*      */     else
/*      */     {
/*  279 */       this.balancer = ((BalanceStrategy)Util.loadExtensions(null, props, strategy, "InvalidLoadBalanceStrategy", null).get(0));
/*      */     }
/*      */     
/*      */ 
/*  283 */     String autoCommitSwapThresholdAsString = props.getProperty("loadBalanceAutoCommitStatementThreshold", "0");
/*      */     try
/*      */     {
/*  286 */       this.autoCommitSwapThreshold = Integer.parseInt(autoCommitSwapThresholdAsString);
/*      */     } catch (NumberFormatException nfe) {
/*  288 */       throw SQLError.createSQLException(Messages.getString("LoadBalancingConnectionProxy.badValueForLoadBalanceAutoCommitStatementThreshold", new Object[] { autoCommitSwapThresholdAsString }), "S1009", null);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  294 */     String autoCommitSwapRegex = props.getProperty("loadBalanceAutoCommitStatementRegex", "");
/*  295 */     if (!"".equals(autoCommitSwapRegex)) {
/*      */       try {
/*  297 */         "".matches(autoCommitSwapRegex);
/*      */       } catch (Exception e) {
/*  299 */         throw SQLError.createSQLException(Messages.getString("LoadBalancingConnectionProxy.badValueForLoadBalanceAutoCommitStatementRegex", new Object[] { autoCommitSwapRegex }), "S1009", null);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  306 */     if (this.autoCommitSwapThreshold > 0) {
/*  307 */       String statementInterceptors = this.localProps.getProperty("statementInterceptors");
/*  308 */       if (statementInterceptors == null) {
/*  309 */         this.localProps.setProperty("statementInterceptors", "com.mysql.jdbc.LoadBalancedAutoCommitInterceptor");
/*  310 */       } else if (statementInterceptors.length() > 0) {
/*  311 */         this.localProps.setProperty("statementInterceptors", statementInterceptors + ",com.mysql.jdbc.LoadBalancedAutoCommitInterceptor");
/*      */       }
/*  313 */       props.setProperty("statementInterceptors", this.localProps.getProperty("statementInterceptors"));
/*      */     }
/*      */     
/*  316 */     this.balancer.init(null, props);
/*      */     
/*      */ 
/*  319 */     this.exceptionChecker = ((LoadBalanceExceptionChecker)Util.loadExtensions(null, props, lbExceptionChecker, "InvalidLoadBalanceExceptionChecker", null).get(0));
/*      */     
/*  321 */     this.exceptionChecker.init(null, props);
/*      */     
/*  323 */     if ((Util.isJdbc4()) || (JDBC_4_LB_CONNECTION_CTOR != null)) {
/*  324 */       this.thisAsConnection = ((MySQLConnection)Util.handleNewInstance(JDBC_4_LB_CONNECTION_CTOR, new Object[] { this }, null));
/*      */     }
/*      */     else {
/*  327 */       this.thisAsConnection = new LoadBalancedMySQLConnection(this);
/*      */     }
/*  329 */     pickNewConnection();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized ConnectionImpl createConnectionForHost(String hostPortSpec)
/*      */     throws SQLException
/*      */   {
/*  344 */     Properties connProps = (Properties)this.localProps.clone();
/*      */     
/*  346 */     String[] hostPortPair = NonRegisteringDriver.parseHostPortPair(hostPortSpec);
/*      */     
/*  348 */     String hostName = hostPortPair[0];
/*  349 */     String portNumber = hostPortPair[1];
/*  350 */     String dbName = connProps.getProperty("DBNAME");
/*      */     
/*      */ 
/*  353 */     if (hostName == null) {
/*  354 */       throw new SQLException("Could not find a hostname to start a connection to");
/*      */     }
/*      */     
/*  357 */     if (portNumber == null) {
/*  358 */       portNumber = "3306";
/*      */     }
/*      */     
/*  361 */     connProps.setProperty("HOST", hostName);
/*  362 */     connProps.setProperty("PORT", portNumber);
/*      */     
/*  364 */     connProps.setProperty("HOST.1", hostName);
/*      */     
/*  366 */     connProps.setProperty("PORT.1", portNumber);
/*      */     
/*  368 */     connProps.setProperty("NUM_HOSTS", "1");
/*  369 */     connProps.setProperty("roundRobinLoadBalance", "false");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  376 */     ConnectionImpl conn = (ConnectionImpl)ConnectionImpl.getInstance(hostName, Integer.parseInt(portNumber), connProps, dbName, "jdbc:mysql://" + hostName + ":" + portNumber + "/");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  382 */     this.liveConnections.put(hostPortSpec, conn);
/*  383 */     this.connectionsToHostsMap.put(conn, hostPortSpec);
/*      */     
/*      */ 
/*  386 */     this.activePhysicalConnections += 1L;
/*  387 */     this.totalPhysicalConnections += 1L;
/*      */     
/*  389 */     conn.setProxy(this.thisAsConnection);
/*      */     
/*  391 */     return conn;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void dealWithInvocationException(InvocationTargetException e)
/*      */     throws SQLException, Throwable, InvocationTargetException
/*      */   {
/*  402 */     Throwable t = e.getTargetException();
/*      */     
/*  404 */     if (t != null) {
/*  405 */       if (((t instanceof SQLException)) && (shouldExceptionTriggerFailover((SQLException)t))) {
/*  406 */         invalidateCurrentConnection();
/*  407 */         pickNewConnection();
/*      */       }
/*      */       
/*  410 */       throw t;
/*      */     }
/*      */     
/*  413 */     throw e;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   synchronized void invalidateCurrentConnection()
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  423 */       if (!this.currentConn.isClosed()) {
/*  424 */         this.currentConn.close();
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*  429 */       if (isGlobalBlacklistEnabled()) {
/*  430 */         addToGlobalBlacklist((String)this.connectionsToHostsMap.get(this.currentConn));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  435 */       this.liveConnections.remove(this.connectionsToHostsMap.get(this.currentConn));
/*      */       
/*  437 */       Object mappedHost = this.connectionsToHostsMap.remove(this.currentConn);
/*      */       
/*  439 */       if ((mappedHost != null) && (this.hostsToListIndexMap.containsKey(mappedHost)))
/*      */       {
/*  441 */         int hostIndex = ((Integer)this.hostsToListIndexMap.get(mappedHost)).intValue();
/*      */         
/*      */ 
/*  444 */         synchronized (this.responseTimes) {
/*  445 */           this.responseTimes[hostIndex] = 0L;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void closeAllConnections() {
/*  452 */     synchronized (this)
/*      */     {
/*  454 */       Iterator<ConnectionImpl> allConnections = this.liveConnections.values().iterator();
/*      */       
/*  456 */       while (allConnections.hasNext()) {
/*      */         try {
/*  458 */           this.activePhysicalConnections -= 1L;
/*  459 */           ((ConnectionImpl)allConnections.next()).close();
/*      */         }
/*      */         catch (SQLException e) {}
/*      */       }
/*      */       
/*  464 */       if (!this.isClosed) {
/*  465 */         this.balancer.destroy();
/*  466 */         if (this.connectionGroup != null) {
/*  467 */           this.connectionGroup.closeConnectionProxy(this);
/*      */         }
/*      */       }
/*      */       
/*  471 */       this.liveConnections.clear();
/*  472 */       this.connectionsToHostsMap.clear();
/*      */     }
/*      */   }
/*      */   
/*      */   public Object invoke(Object proxy, Method method, Object[] args)
/*      */     throws Throwable
/*      */   {
/*  479 */     return invoke(proxy, method, args, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized Object invoke(Object proxy, Method method, Object[] args, boolean swapAtTransactionBoundary)
/*      */     throws Throwable
/*      */   {
/*  490 */     String methodName = method.getName();
/*      */     
/*  492 */     if ("getLoadBalanceSafeProxy".equals(methodName)) {
/*  493 */       return this.currentConn;
/*      */     }
/*      */     
/*  496 */     if (("equals".equals(methodName)) && (args.length == 1)) {
/*  497 */       if ((args[0] instanceof Proxy)) {
/*  498 */         return Boolean.valueOf(((Proxy)args[0]).equals(this));
/*      */       }
/*  500 */       return Boolean.valueOf(equals(args[0]));
/*      */     }
/*      */     
/*  503 */     if ("hashCode".equals(methodName)) {
/*  504 */       return Integer.valueOf(hashCode());
/*      */     }
/*      */     
/*  507 */     if ("close".equals(methodName)) {
/*  508 */       closeAllConnections();
/*      */       
/*  510 */       this.isClosed = true;
/*  511 */       this.closedReason = "Connection explicitly closed.";
/*      */       
/*  513 */       return null;
/*      */     }
/*      */     
/*  516 */     if ("isClosed".equals(methodName)) {
/*  517 */       return Boolean.valueOf(this.isClosed);
/*      */     }
/*      */     
/*  520 */     if (this.isClosed) {
/*  521 */       String reason = "No operations allowed after connection closed.";
/*  522 */       if (this.closedReason != null) {
/*  523 */         reason = reason + "  " + this.closedReason;
/*      */       }
/*  525 */       throw SQLError.createSQLException(reason, "08003", null);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  534 */     if (!this.inTransaction) {
/*  535 */       this.inTransaction = true;
/*  536 */       this.transactionStartTime = getLocalTimeBestResolution();
/*  537 */       this.transactionCount += 1L;
/*      */     }
/*      */     
/*  540 */     Object result = null;
/*      */     try
/*      */     {
/*  543 */       this.lastUsed = System.currentTimeMillis();
/*  544 */       result = method.invoke(this.thisAsConnection, args);
/*      */       
/*  546 */       if (result != null) {
/*  547 */         if ((result instanceof Statement)) {
/*  548 */           ((Statement)result).setPingTarget(this);
/*      */         }
/*      */         
/*  551 */         result = proxyIfInterfaceIsJdbc(result, result.getClass());
/*      */       }
/*      */     } catch (InvocationTargetException e) {
/*  554 */       dealWithInvocationException(e);
/*      */     } finally {
/*  556 */       if ((swapAtTransactionBoundary) && (("commit".equals(methodName)) || ("rollback".equals(methodName)))) {
/*  557 */         this.inTransaction = false;
/*      */         
/*      */ 
/*  560 */         String host = (String)this.connectionsToHostsMap.get(this.currentConn);
/*      */         
/*      */ 
/*      */ 
/*  564 */         if (host != null) {
/*  565 */           synchronized (this.responseTimes) {
/*  566 */             int hostIndex = ((Integer)this.hostsToListIndexMap.get(host)).intValue();
/*      */             
/*      */ 
/*  569 */             if (hostIndex < this.responseTimes.length) {
/*  570 */               this.responseTimes[hostIndex] = (getLocalTimeBestResolution() - this.transactionStartTime);
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*  575 */         pickNewConnection();
/*      */       }
/*      */     }
/*      */     
/*  579 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void pickNewConnection()
/*      */     throws SQLException
/*      */   {
/*  589 */     if (this.currentConn == null) {
/*  590 */       this.currentConn = this.balancer.pickConnection(this, Collections.unmodifiableList(this.hostList), Collections.unmodifiableMap(this.liveConnections), (long[])this.responseTimes.clone(), this.retriesAllDown);
/*      */       
/*      */ 
/*      */ 
/*  594 */       return;
/*      */     }
/*      */     
/*  597 */     if (this.currentConn.isClosed()) {
/*  598 */       invalidateCurrentConnection();
/*      */     }
/*      */     
/*  601 */     int pingTimeout = this.currentConn.getLoadBalancePingTimeout();
/*  602 */     boolean pingBeforeReturn = this.currentConn.getLoadBalanceValidateConnectionOnSwapServer();
/*      */     
/*  604 */     int hostsTried = 0; for (int hostsToTry = this.hostList.size(); hostsTried <= hostsToTry; hostsTried++) {
/*      */       try {
/*  606 */         ConnectionImpl newConn = this.balancer.pickConnection(this, Collections.unmodifiableList(this.hostList), Collections.unmodifiableMap(this.liveConnections), (long[])this.responseTimes.clone(), this.retriesAllDown);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  612 */         if (this.currentConn != null) {
/*  613 */           if (pingBeforeReturn) {
/*  614 */             if (pingTimeout == 0) {
/*  615 */               newConn.ping();
/*      */             } else {
/*  617 */               newConn.pingInternal(true, pingTimeout);
/*      */             }
/*      */           }
/*      */           
/*  621 */           syncSessionState(this.currentConn, newConn);
/*      */         }
/*      */         
/*  624 */         this.currentConn = newConn;
/*  625 */         return;
/*      */       }
/*      */       catch (SQLException e) {
/*  628 */         if (shouldExceptionTriggerFailover(e))
/*      */         {
/*      */ 
/*  631 */           invalidateCurrentConnection();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  637 */     this.isClosed = true;
/*  638 */     this.closedReason = "Connection closed after inability to pick valid new connection during fail-over.";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Object proxyIfInterfaceIsJdbc(Object toProxy, Class clazz)
/*      */   {
/*  653 */     if (isInterfaceJdbc(clazz))
/*      */     {
/*  655 */       Class[] interfacesToProxy = getAllInterfacesToProxy(clazz);
/*      */       
/*  657 */       return Proxy.newProxyInstance(toProxy.getClass().getClassLoader(), interfacesToProxy, createConnectionProxy(toProxy));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  662 */     return toProxy;
/*      */   }
/*      */   
/*  665 */   private Map<Class, Class[]> allInterfacesToProxy = new HashMap();
/*      */   
/*      */   private Class[] getAllInterfacesToProxy(Class clazz) {
/*  668 */     Class[] interfacesToProxy = (Class[])this.allInterfacesToProxy.get(clazz);
/*      */     
/*  670 */     if (interfacesToProxy != null) {
/*  671 */       return interfacesToProxy;
/*      */     }
/*      */     
/*  674 */     List<Class> interfaces = new LinkedList();
/*      */     
/*  676 */     Class superClass = clazz;
/*      */     
/*  678 */     while (!superClass.equals(Object.class)) {
/*  679 */       Class[] declared = superClass.getInterfaces();
/*      */       
/*  681 */       for (int i = 0; i < declared.length; i++) {
/*  682 */         interfaces.add(declared[i]);
/*      */       }
/*      */       
/*  685 */       superClass = superClass.getSuperclass();
/*      */     }
/*      */     
/*  688 */     interfacesToProxy = new Class[interfaces.size()];
/*  689 */     interfaces.toArray(interfacesToProxy);
/*      */     
/*  691 */     this.allInterfacesToProxy.put(clazz, interfacesToProxy);
/*      */     
/*  693 */     return interfacesToProxy;
/*      */   }
/*      */   
/*      */   private boolean isInterfaceJdbc(Class clazz)
/*      */   {
/*  698 */     if (this.jdbcInterfacesForProxyCache.containsKey(clazz)) {
/*  699 */       return ((Boolean)this.jdbcInterfacesForProxyCache.get(clazz)).booleanValue();
/*      */     }
/*      */     
/*  702 */     Class[] interfaces = clazz.getInterfaces();
/*      */     
/*  704 */     for (int i = 0; i < interfaces.length; i++) {
/*  705 */       String packageName = interfaces[i].getPackage().getName();
/*      */       
/*  707 */       if (("java.sql".equals(packageName)) || ("javax.sql".equals(packageName)) || ("com.mysql.jdbc".equals(packageName)))
/*      */       {
/*      */ 
/*  710 */         this.jdbcInterfacesForProxyCache.put(clazz, Boolean.valueOf(true));
/*      */         
/*  712 */         return true;
/*      */       }
/*      */       
/*  715 */       if (isInterfaceJdbc(interfaces[i])) {
/*  716 */         this.jdbcInterfacesForProxyCache.put(clazz, Boolean.valueOf(true));
/*      */         
/*  718 */         return true;
/*      */       }
/*      */     }
/*      */     
/*  722 */     this.jdbcInterfacesForProxyCache.put(clazz, Boolean.valueOf(false));
/*  723 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   protected ConnectionErrorFiringInvocationHandler createConnectionProxy(Object toProxy)
/*      */   {
/*  729 */     return new ConnectionErrorFiringInvocationHandler(toProxy);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static long getLocalTimeBestResolution()
/*      */   {
/*  737 */     if (getLocalTimeMethod != null) {
/*      */       try {
/*  739 */         return ((Long)getLocalTimeMethod.invoke(null, (Object[])null)).longValue();
/*      */       }
/*      */       catch (IllegalArgumentException e) {}catch (IllegalAccessException e) {}catch (InvocationTargetException e) {}
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  750 */     return System.currentTimeMillis();
/*      */   }
/*      */   
/*      */   public synchronized void doPing() throws SQLException {
/*  754 */     SQLException se = null;
/*  755 */     boolean foundHost = false;
/*  756 */     int pingTimeout = this.currentConn.getLoadBalancePingTimeout();
/*  757 */     Iterator<String> i; synchronized (this) {
/*  758 */       for (i = this.hostList.iterator(); i.hasNext();) {
/*  759 */         String host = (String)i.next();
/*  760 */         ConnectionImpl conn = (ConnectionImpl)this.liveConnections.get(host);
/*  761 */         if (conn != null)
/*      */         {
/*      */           try
/*      */           {
/*  765 */             if (pingTimeout == 0) {
/*  766 */               conn.ping();
/*      */             } else {
/*  768 */               conn.pingInternal(true, pingTimeout);
/*      */             }
/*  770 */             foundHost = true;
/*      */           } catch (SQLException e) {
/*  772 */             this.activePhysicalConnections -= 1L;
/*      */             
/*      */ 
/*  775 */             if (host.equals(this.connectionsToHostsMap.get(this.currentConn)))
/*      */             {
/*      */ 
/*      */ 
/*  779 */               closeAllConnections();
/*  780 */               this.isClosed = true;
/*  781 */               this.closedReason = "Connection closed because ping of current connection failed.";
/*  782 */               throw e;
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*  787 */             if (e.getMessage().equals(Messages.getString("Connection.exceededConnectionLifetime")))
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  793 */               if (se == null) {
/*  794 */                 se = e;
/*      */               }
/*      */             }
/*      */             else {
/*  798 */               se = e;
/*  799 */               if (isGlobalBlacklistEnabled()) {
/*  800 */                 addToGlobalBlacklist(host);
/*      */               }
/*      */             }
/*      */             
/*  804 */             this.liveConnections.remove(this.connectionsToHostsMap.get(conn));
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  810 */     if (!foundHost) {
/*  811 */       closeAllConnections();
/*  812 */       this.isClosed = true;
/*  813 */       this.closedReason = "Connection closed due to inability to ping any active connections.";
/*      */       
/*  815 */       if (se != null) {
/*  816 */         throw se;
/*      */       }
/*      */       
/*      */ 
/*  820 */       ((ConnectionImpl)this.currentConn).throwConnectionClosedException();
/*      */     }
/*      */   }
/*      */   
/*      */   public void addToGlobalBlacklist(String host, long timeout)
/*      */   {
/*  826 */     if (isGlobalBlacklistEnabled()) {
/*  827 */       synchronized (globalBlacklist) {
/*  828 */         globalBlacklist.put(host, Long.valueOf(timeout));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void addToGlobalBlacklist(String host) {
/*  834 */     addToGlobalBlacklist(host, System.currentTimeMillis() + this.globalBlacklistTimeout);
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean isGlobalBlacklistEnabled()
/*      */   {
/*  840 */     return this.globalBlacklistTimeout > 0;
/*      */   }
/*      */   
/*      */   public synchronized Map<String, Long> getGlobalBlacklist() {
/*  844 */     if (!isGlobalBlacklistEnabled()) {
/*  845 */       String localHostToRemove = this.hostToRemove;
/*      */       
/*  847 */       if (this.hostToRemove != null) {
/*  848 */         HashMap<String, Long> fakedBlacklist = new HashMap();
/*  849 */         fakedBlacklist.put(localHostToRemove, Long.valueOf(System.currentTimeMillis() + 5000L));
/*  850 */         return fakedBlacklist;
/*      */       }
/*      */       
/*  853 */       return new HashMap(1);
/*      */     }
/*      */     
/*      */ 
/*  857 */     Map<String, Long> blacklistClone = new HashMap(globalBlacklist.size());
/*      */     
/*      */ 
/*  860 */     synchronized (globalBlacklist) {
/*  861 */       blacklistClone.putAll(globalBlacklist);
/*      */     }
/*  863 */     Set<String> keys = blacklistClone.keySet();
/*      */     
/*      */ 
/*  866 */     keys.retainAll(this.hostList);
/*      */     
/*      */ 
/*  869 */     for (Object i = keys.iterator(); ((Iterator)i).hasNext();) {
/*  870 */       String host = (String)((Iterator)i).next();
/*      */       
/*      */ 
/*  873 */       Long timeout = (Long)globalBlacklist.get(host);
/*  874 */       if ((timeout != null) && (timeout.longValue() < System.currentTimeMillis()))
/*      */       {
/*      */ 
/*  877 */         synchronized (globalBlacklist) {
/*  878 */           globalBlacklist.remove(host);
/*      */         }
/*  880 */         ((Iterator)i).remove();
/*      */       }
/*      */     }
/*      */     
/*  884 */     if (keys.size() == this.hostList.size())
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  890 */       return new HashMap(1);
/*      */     }
/*      */     
/*  893 */     return blacklistClone;
/*      */   }
/*      */   
/*      */   public boolean shouldExceptionTriggerFailover(SQLException ex) {
/*  897 */     return this.exceptionChecker.shouldExceptionTriggerFailover(ex);
/*      */   }
/*      */   
/*      */   public void removeHostWhenNotInUse(String host)
/*      */     throws SQLException
/*      */   {
/*  903 */     int timeBetweenChecks = 1000;
/*  904 */     long timeBeforeHardFail = 15000L;
/*      */     
/*  906 */     synchronized (this) {
/*  907 */       addToGlobalBlacklist(host, timeBeforeHardFail + 1000L);
/*      */       
/*  909 */       long cur = System.currentTimeMillis();
/*      */       
/*  911 */       while (System.currentTimeMillis() - timeBeforeHardFail < cur)
/*      */       {
/*  913 */         this.hostToRemove = host;
/*      */         
/*  915 */         if (!host.equals(this.currentConn.getHost())) {
/*  916 */           removeHost(host);
/*  917 */           return;
/*      */         }
/*      */       }
/*      */     }
/*      */     try
/*      */     {
/*  923 */       Thread.sleep(timeBetweenChecks);
/*      */     }
/*      */     catch (InterruptedException e) {}
/*      */     
/*      */ 
/*  928 */     removeHost(host);
/*      */   }
/*      */   
/*      */   public synchronized void removeHost(String host) throws SQLException
/*      */   {
/*  933 */     if (this.connectionGroup != null) {
/*  934 */       if ((this.connectionGroup.getInitialHosts().size() == 1) && (this.connectionGroup.getInitialHosts().contains(host)))
/*      */       {
/*  936 */         throw SQLError.createSQLException("Cannot remove only configured host.", null);
/*      */       }
/*      */       
/*      */ 
/*  940 */       this.hostToRemove = host;
/*      */       
/*  942 */       if (host.equals(this.currentConn.getHost())) {
/*  943 */         closeAllConnections();
/*      */       } else {
/*  945 */         this.connectionsToHostsMap.remove(this.liveConnections.remove(host));
/*      */         
/*  947 */         Integer idx = (Integer)this.hostsToListIndexMap.remove(host);
/*  948 */         long[] newResponseTimes = new long[this.responseTimes.length - 1];
/*  949 */         int newIdx = 0;
/*  950 */         for (Iterator<String> i = this.hostList.iterator(); i.hasNext(); newIdx++) {
/*  951 */           String copyHost = (String)i.next();
/*  952 */           if ((idx != null) && (idx.intValue() < this.responseTimes.length))
/*      */           {
/*  954 */             newResponseTimes[newIdx] = this.responseTimes[idx.intValue()];
/*      */             
/*  956 */             this.hostsToListIndexMap.put(copyHost, Integer.valueOf(newIdx));
/*      */           }
/*      */         }
/*      */         
/*  960 */         this.responseTimes = newResponseTimes;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized boolean addHost(String host)
/*      */   {
/*  968 */     if (this.hostsToListIndexMap.containsKey(host)) {
/*  969 */       return false;
/*      */     }
/*      */     
/*  972 */     long[] newResponseTimes = new long[this.responseTimes.length + 1];
/*      */     
/*  974 */     for (int i = 0; i < this.responseTimes.length; i++) {
/*  975 */       newResponseTimes[i] = this.responseTimes[i];
/*      */     }
/*      */     
/*  978 */     this.responseTimes = newResponseTimes;
/*  979 */     this.hostList.add(host);
/*  980 */     this.hostsToListIndexMap.put(host, Integer.valueOf(this.responseTimes.length - 1));
/*      */     
/*      */ 
/*  983 */     return true;
/*      */   }
/*      */   
/*      */   public synchronized long getLastUsed() {
/*  987 */     return this.lastUsed;
/*      */   }
/*      */   
/*      */   public synchronized boolean inTransaction() {
/*  991 */     return this.inTransaction;
/*      */   }
/*      */   
/*      */   public synchronized long getTransactionCount() {
/*  995 */     return this.transactionCount;
/*      */   }
/*      */   
/*      */   public synchronized long getActivePhysicalConnectionCount() {
/*  999 */     return this.activePhysicalConnections;
/*      */   }
/*      */   
/*      */   public synchronized long getTotalPhysicalConnectionCount() {
/* 1003 */     return this.totalPhysicalConnections;
/*      */   }
/*      */   
/*      */   public synchronized long getConnectionGroupProxyID() {
/* 1007 */     return this.connectionGroupProxyID;
/*      */   }
/*      */   
/*      */   public synchronized String getCurrentActiveHost() {
/* 1011 */     MySQLConnection c = this.currentConn;
/* 1012 */     if (c != null) {
/* 1013 */       Object o = this.connectionsToHostsMap.get(c);
/* 1014 */       if (o != null) {
/* 1015 */         return o.toString();
/*      */       }
/*      */     }
/* 1018 */     return null;
/*      */   }
/*      */   
/*      */   public synchronized long getCurrentTransactionDuration()
/*      */   {
/* 1023 */     if ((this.inTransaction) && (this.transactionStartTime > 0L)) {
/* 1024 */       return getLocalTimeBestResolution() - this.transactionStartTime;
/*      */     }
/*      */     
/* 1027 */     return 0L;
/*      */   }
/*      */   
/*      */   protected void syncSessionState(Connection initial, Connection target) throws SQLException
/*      */   {
/* 1032 */     if ((initial == null) || (target == null)) {
/* 1033 */       return;
/*      */     }
/* 1035 */     target.setAutoCommit(initial.getAutoCommit());
/* 1036 */     target.setCatalog(initial.getCatalog());
/* 1037 */     target.setTransactionIsolation(initial.getTransactionIsolation());
/* 1038 */     target.setReadOnly(initial.isReadOnly());
/*      */   }
/*      */ }


/* Location:              C:\Users\Static\Desktop\G10_Prototype_Server.jar!\mysql-connector-java-5.1.19-bin.jar!\com\mysql\jdbc\LoadBalancingConnectionProxy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */