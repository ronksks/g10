/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.sql.Date;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.TimeZone;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class ResultSetRow
/*      */ {
/*      */   protected ExceptionInterceptor exceptionInterceptor;
/*      */   protected Field[] metadata;
/*      */   
/*      */   protected ResultSetRow(ExceptionInterceptor exceptionInterceptor)
/*      */   {
/*   54 */     this.exceptionInterceptor = exceptionInterceptor;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void closeOpenStreams();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract InputStream getBinaryInputStream(int paramInt)
/*      */     throws SQLException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract byte[] getColumnValue(int paramInt)
/*      */     throws SQLException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final Date getDateFast(int columnIndex, byte[] dateAsBytes, int offset, int length, MySQLConnection conn, ResultSetImpl rs, Calendar targetCalendar)
/*      */     throws SQLException
/*      */   {
/*   98 */     int year = 0;
/*   99 */     int month = 0;
/*  100 */     int day = 0;
/*      */     try
/*      */     {
/*  103 */       if (dateAsBytes == null) {
/*  104 */         return null;
/*      */       }
/*      */       
/*  107 */       boolean allZeroDate = true;
/*      */       
/*  109 */       boolean onlyTimePresent = false;
/*      */       
/*  111 */       for (int i = 0; i < length; i++) {
/*  112 */         if (dateAsBytes[(offset + i)] == 58) {
/*  113 */           onlyTimePresent = true;
/*  114 */           break;
/*      */         }
/*      */       }
/*      */       
/*  118 */       for (int i = 0; i < length; i++) {
/*  119 */         byte b = dateAsBytes[(offset + i)];
/*      */         
/*  121 */         if ((b == 32) || (b == 45) || (b == 47)) {
/*  122 */           onlyTimePresent = false;
/*      */         }
/*      */         
/*  125 */         if ((b != 48) && (b != 32) && (b != 58) && (b != 45) && (b != 47) && (b != 46))
/*      */         {
/*  127 */           allZeroDate = false;
/*      */           
/*  129 */           break;
/*      */         }
/*      */       }
/*      */       
/*  133 */       if ((!onlyTimePresent) && (allZeroDate))
/*      */       {
/*  135 */         if ("convertToNull".equals(conn.getZeroDateTimeBehavior()))
/*      */         {
/*      */ 
/*  138 */           return null; }
/*  139 */         if ("exception".equals(conn.getZeroDateTimeBehavior()))
/*      */         {
/*  141 */           throw SQLError.createSQLException("Value '" + StringUtils.toString(dateAsBytes) + "' can not be represented as java.sql.Date", "S1009", this.exceptionInterceptor);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  149 */         return rs.fastDateCreate(targetCalendar, 1, 1, 1);
/*      */       }
/*  151 */       if (this.metadata[columnIndex].getMysqlType() == 7)
/*      */       {
/*  153 */         switch (length) {
/*      */         case 19: 
/*      */         case 21: 
/*      */         case 29: 
/*  157 */           year = StringUtils.getInt(dateAsBytes, offset + 0, offset + 4);
/*      */           
/*  159 */           month = StringUtils.getInt(dateAsBytes, offset + 5, offset + 7);
/*      */           
/*  161 */           day = StringUtils.getInt(dateAsBytes, offset + 8, offset + 10);
/*      */           
/*      */ 
/*  164 */           return rs.fastDateCreate(targetCalendar, year, month, day);
/*      */         
/*      */ 
/*      */         case 8: 
/*      */         case 14: 
/*  169 */           year = StringUtils.getInt(dateAsBytes, offset + 0, offset + 4);
/*      */           
/*  171 */           month = StringUtils.getInt(dateAsBytes, offset + 4, offset + 6);
/*      */           
/*  173 */           day = StringUtils.getInt(dateAsBytes, offset + 6, offset + 8);
/*      */           
/*      */ 
/*  176 */           return rs.fastDateCreate(targetCalendar, year, month, day);
/*      */         
/*      */ 
/*      */         case 6: 
/*      */         case 10: 
/*      */         case 12: 
/*  182 */           year = StringUtils.getInt(dateAsBytes, offset + 0, offset + 2);
/*      */           
/*      */ 
/*  185 */           if (year <= 69) {
/*  186 */             year += 100;
/*      */           }
/*      */           
/*  189 */           month = StringUtils.getInt(dateAsBytes, offset + 2, offset + 4);
/*      */           
/*  191 */           day = StringUtils.getInt(dateAsBytes, offset + 4, offset + 6);
/*      */           
/*      */ 
/*  194 */           return rs.fastDateCreate(targetCalendar, year + 1900, month, day);
/*      */         
/*      */ 
/*      */         case 4: 
/*  198 */           year = StringUtils.getInt(dateAsBytes, offset + 0, offset + 4);
/*      */           
/*      */ 
/*  201 */           if (year <= 69) {
/*  202 */             year += 100;
/*      */           }
/*      */           
/*  205 */           month = StringUtils.getInt(dateAsBytes, offset + 2, offset + 4);
/*      */           
/*      */ 
/*  208 */           return rs.fastDateCreate(targetCalendar, year + 1900, month, 1);
/*      */         
/*      */ 
/*      */         case 2: 
/*  212 */           year = StringUtils.getInt(dateAsBytes, offset + 0, offset + 2);
/*      */           
/*      */ 
/*  215 */           if (year <= 69) {
/*  216 */             year += 100;
/*      */           }
/*      */           
/*  219 */           return rs.fastDateCreate(targetCalendar, year + 1900, 1, 1);
/*      */         }
/*      */         
/*      */         
/*  223 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_Date", new Object[] { StringUtils.toString(dateAsBytes), Integer.valueOf(columnIndex + 1) }), "S1009", this.exceptionInterceptor);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  234 */       if (this.metadata[columnIndex].getMysqlType() == 13)
/*      */       {
/*  236 */         if ((length == 2) || (length == 1)) {
/*  237 */           year = StringUtils.getInt(dateAsBytes, offset, offset + length);
/*      */           
/*      */ 
/*  240 */           if (year <= 69) {
/*  241 */             year += 100;
/*      */           }
/*      */           
/*  244 */           year += 1900;
/*      */         } else {
/*  246 */           year = StringUtils.getInt(dateAsBytes, offset + 0, offset + 4);
/*      */         }
/*      */         
/*      */ 
/*  250 */         return rs.fastDateCreate(targetCalendar, year, 1, 1); }
/*  251 */       if (this.metadata[columnIndex].getMysqlType() == 11) {
/*  252 */         return rs.fastDateCreate(targetCalendar, 1970, 1, 1);
/*      */       }
/*  254 */       if (length < 10) {
/*  255 */         if (length == 8) {
/*  256 */           return rs.fastDateCreate(targetCalendar, 1970, 1, 1);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  261 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_Date", new Object[] { StringUtils.toString(dateAsBytes), Integer.valueOf(columnIndex + 1) }), "S1009", this.exceptionInterceptor);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  273 */       if (length != 18) {
/*  274 */         year = StringUtils.getInt(dateAsBytes, offset + 0, offset + 4);
/*      */         
/*  276 */         month = StringUtils.getInt(dateAsBytes, offset + 5, offset + 7);
/*      */         
/*  278 */         day = StringUtils.getInt(dateAsBytes, offset + 8, offset + 10);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  283 */         StringTokenizer st = new StringTokenizer(StringUtils.toString(dateAsBytes, offset, length, "ISO8859_1"), "- ");
/*      */         
/*      */ 
/*  286 */         year = Integer.parseInt(st.nextToken());
/*  287 */         month = Integer.parseInt(st.nextToken());
/*  288 */         day = Integer.parseInt(st.nextToken());
/*      */       }
/*      */       
/*      */ 
/*  292 */       return rs.fastDateCreate(targetCalendar, year, month, day);
/*      */     } catch (SQLException sqlEx) {
/*  294 */       throw sqlEx;
/*      */     } catch (Exception e) {
/*  296 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_Date", new Object[] { StringUtils.toString(dateAsBytes), Integer.valueOf(columnIndex + 1) }), "S1009", this.exceptionInterceptor);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  301 */       sqlEx.initCause(e);
/*      */       
/*  303 */       throw sqlEx;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract Date getDateFast(int paramInt, MySQLConnection paramMySQLConnection, ResultSetImpl paramResultSetImpl, Calendar paramCalendar)
/*      */     throws SQLException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract int getInt(int paramInt)
/*      */     throws SQLException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract long getLong(int paramInt)
/*      */     throws SQLException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Date getNativeDate(int columnIndex, byte[] bits, int offset, int length, MySQLConnection conn, ResultSetImpl rs, Calendar cal)
/*      */     throws SQLException
/*      */   {
/*  338 */     int year = 0;
/*  339 */     int month = 0;
/*  340 */     int day = 0;
/*      */     
/*  342 */     if (length != 0) {
/*  343 */       year = bits[(offset + 0)] & 0xFF | (bits[(offset + 1)] & 0xFF) << 8;
/*      */       
/*  345 */       month = bits[(offset + 2)];
/*  346 */       day = bits[(offset + 3)];
/*      */     }
/*      */     
/*  349 */     if ((length == 0) || ((year == 0) && (month == 0) && (day == 0))) {
/*  350 */       if ("convertToNull".equals(conn.getZeroDateTimeBehavior()))
/*      */       {
/*  352 */         return null; }
/*  353 */       if ("exception".equals(conn.getZeroDateTimeBehavior()))
/*      */       {
/*  355 */         throw SQLError.createSQLException("Value '0000-00-00' can not be represented as java.sql.Date", "S1009", this.exceptionInterceptor);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  361 */       year = 1;
/*  362 */       month = 1;
/*  363 */       day = 1;
/*      */     }
/*      */     
/*  366 */     if (!rs.useLegacyDatetimeCode) {
/*  367 */       return TimeUtil.fastDateCreate(year, month, day, cal);
/*      */     }
/*      */     
/*  370 */     return rs.fastDateCreate(cal == null ? rs.getCalendarInstanceForSessionOrNew() : cal, year, month, day);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public abstract Date getNativeDate(int paramInt, MySQLConnection paramMySQLConnection, ResultSetImpl paramResultSetImpl, Calendar paramCalendar)
/*      */     throws SQLException;
/*      */   
/*      */ 
/*      */   protected Object getNativeDateTimeValue(int columnIndex, byte[] bits, int offset, int length, Calendar targetCalendar, int jdbcType, int mysqlType, TimeZone tz, boolean rollForward, MySQLConnection conn, ResultSetImpl rs)
/*      */     throws SQLException
/*      */   {
/*  382 */     int year = 0;
/*  383 */     int month = 0;
/*  384 */     int day = 0;
/*      */     
/*  386 */     int hour = 0;
/*  387 */     int minute = 0;
/*  388 */     int seconds = 0;
/*      */     
/*  390 */     int nanos = 0;
/*      */     
/*  392 */     if (bits == null)
/*      */     {
/*  394 */       return null;
/*      */     }
/*      */     
/*  397 */     Calendar sessionCalendar = conn.getUseJDBCCompliantTimezoneShift() ? conn.getUtcCalendar() : rs.getCalendarInstanceForSessionOrNew();
/*      */     
/*      */ 
/*      */ 
/*  401 */     boolean populatedFromDateTimeValue = false;
/*      */     
/*  403 */     switch (mysqlType) {
/*      */     case 7: 
/*      */     case 12: 
/*  406 */       populatedFromDateTimeValue = true;
/*      */       
/*  408 */       if (length != 0) {
/*  409 */         year = bits[(offset + 0)] & 0xFF | (bits[(offset + 1)] & 0xFF) << 8;
/*      */         
/*  411 */         month = bits[(offset + 2)];
/*  412 */         day = bits[(offset + 3)];
/*      */         
/*  414 */         if (length > 4) {
/*  415 */           hour = bits[(offset + 4)];
/*  416 */           minute = bits[(offset + 5)];
/*  417 */           seconds = bits[(offset + 6)];
/*      */         }
/*      */         
/*  420 */         if (length > 7)
/*      */         {
/*  422 */           nanos = (bits[(offset + 7)] & 0xFF | (bits[(offset + 8)] & 0xFF) << 8 | (bits[(offset + 9)] & 0xFF) << 16 | (bits[(offset + 10)] & 0xFF) << 24) * 1000;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       break;
/*      */     case 10: 
/*  430 */       populatedFromDateTimeValue = true;
/*      */       
/*  432 */       if (bits.length != 0) {
/*  433 */         year = bits[(offset + 0)] & 0xFF | (bits[(offset + 1)] & 0xFF) << 8;
/*      */         
/*  435 */         month = bits[(offset + 2)];
/*  436 */         day = bits[(offset + 3)];
/*      */       }
/*      */       
/*      */       break;
/*      */     case 11: 
/*  441 */       populatedFromDateTimeValue = true;
/*      */       
/*  443 */       if (bits.length != 0)
/*      */       {
/*      */ 
/*  446 */         hour = bits[(offset + 5)];
/*  447 */         minute = bits[(offset + 6)];
/*  448 */         seconds = bits[(offset + 7)];
/*      */       }
/*      */       
/*  451 */       year = 1970;
/*  452 */       month = 1;
/*  453 */       day = 1;
/*      */       
/*  455 */       break;
/*      */     case 8: case 9: default: 
/*  457 */       populatedFromDateTimeValue = false;
/*      */     }
/*      */     
/*  460 */     switch (jdbcType) {
/*      */     case 92: 
/*  462 */       if (populatedFromDateTimeValue) {
/*  463 */         if (!rs.useLegacyDatetimeCode) {
/*  464 */           return TimeUtil.fastTimeCreate(hour, minute, seconds, targetCalendar, this.exceptionInterceptor);
/*      */         }
/*      */         
/*  467 */         Time time = TimeUtil.fastTimeCreate(rs.getCalendarInstanceForSessionOrNew(), hour, minute, seconds, this.exceptionInterceptor);
/*      */         
/*      */ 
/*      */ 
/*  471 */         Time adjustedTime = TimeUtil.changeTimezone(conn, sessionCalendar, targetCalendar, time, conn.getServerTimezoneTZ(), tz, rollForward);
/*      */         
/*      */ 
/*      */ 
/*  475 */         return adjustedTime;
/*      */       }
/*      */       
/*  478 */       return rs.getNativeTimeViaParseConversion(columnIndex + 1, targetCalendar, tz, rollForward);
/*      */     
/*      */ 
/*      */     case 91: 
/*  482 */       if (populatedFromDateTimeValue) {
/*  483 */         if ((year == 0) && (month == 0) && (day == 0)) {
/*  484 */           if ("convertToNull".equals(conn.getZeroDateTimeBehavior()))
/*      */           {
/*      */ 
/*  487 */             return null; }
/*  488 */           if ("exception".equals(conn.getZeroDateTimeBehavior()))
/*      */           {
/*  490 */             throw new SQLException("Value '0000-00-00' can not be represented as java.sql.Date", "S1009");
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*  495 */           year = 1;
/*  496 */           month = 1;
/*  497 */           day = 1;
/*      */         }
/*      */         
/*  500 */         if (!rs.useLegacyDatetimeCode) {
/*  501 */           return TimeUtil.fastDateCreate(year, month, day, targetCalendar);
/*      */         }
/*      */         
/*  504 */         return rs.fastDateCreate(rs.getCalendarInstanceForSessionOrNew(), year, month, day);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  510 */       return rs.getNativeDateViaParseConversion(columnIndex + 1);
/*      */     case 93: 
/*  512 */       if (populatedFromDateTimeValue) {
/*  513 */         if ((year == 0) && (month == 0) && (day == 0)) {
/*  514 */           if ("convertToNull".equals(conn.getZeroDateTimeBehavior()))
/*      */           {
/*      */ 
/*  517 */             return null; }
/*  518 */           if ("exception".equals(conn.getZeroDateTimeBehavior()))
/*      */           {
/*  520 */             throw new SQLException("Value '0000-00-00' can not be represented as java.sql.Timestamp", "S1009");
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*  525 */           year = 1;
/*  526 */           month = 1;
/*  527 */           day = 1;
/*      */         }
/*      */         
/*  530 */         if (!rs.useLegacyDatetimeCode) {
/*  531 */           return TimeUtil.fastTimestampCreate(tz, year, month, day, hour, minute, seconds, nanos);
/*      */         }
/*      */         
/*      */ 
/*  535 */         Timestamp ts = rs.fastTimestampCreate(rs.getCalendarInstanceForSessionOrNew(), year, month, day, hour, minute, seconds, nanos);
/*      */         
/*      */ 
/*      */ 
/*  539 */         Timestamp adjustedTs = TimeUtil.changeTimezone(conn, sessionCalendar, targetCalendar, ts, conn.getServerTimezoneTZ(), tz, rollForward);
/*      */         
/*      */ 
/*      */ 
/*  543 */         return adjustedTs;
/*      */       }
/*      */       
/*  546 */       return rs.getNativeTimestampViaParseConversion(columnIndex + 1, targetCalendar, tz, rollForward);
/*      */     }
/*      */     
/*      */     
/*  550 */     throw new SQLException("Internal error - conversion method doesn't support this type", "S1000");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public abstract Object getNativeDateTimeValue(int paramInt1, Calendar paramCalendar, int paramInt2, int paramInt3, TimeZone paramTimeZone, boolean paramBoolean, MySQLConnection paramMySQLConnection, ResultSetImpl paramResultSetImpl)
/*      */     throws SQLException;
/*      */   
/*      */ 
/*      */ 
/*      */   protected double getNativeDouble(byte[] bits, int offset)
/*      */   {
/*  562 */     long valueAsLong = bits[(offset + 0)] & 0xFF | (bits[(offset + 1)] & 0xFF) << 8 | (bits[(offset + 2)] & 0xFF) << 16 | (bits[(offset + 3)] & 0xFF) << 24 | (bits[(offset + 4)] & 0xFF) << 32 | (bits[(offset + 5)] & 0xFF) << 40 | (bits[(offset + 6)] & 0xFF) << 48 | (bits[(offset + 7)] & 0xFF) << 56;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  571 */     return Double.longBitsToDouble(valueAsLong);
/*      */   }
/*      */   
/*      */   public abstract double getNativeDouble(int paramInt) throws SQLException;
/*      */   
/*      */   protected float getNativeFloat(byte[] bits, int offset) {
/*  577 */     int asInt = bits[(offset + 0)] & 0xFF | (bits[(offset + 1)] & 0xFF) << 8 | (bits[(offset + 2)] & 0xFF) << 16 | (bits[(offset + 3)] & 0xFF) << 24;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  582 */     return Float.intBitsToFloat(asInt);
/*      */   }
/*      */   
/*      */   public abstract float getNativeFloat(int paramInt) throws SQLException;
/*      */   
/*      */   protected int getNativeInt(byte[] bits, int offset)
/*      */   {
/*  589 */     int valueAsInt = bits[(offset + 0)] & 0xFF | (bits[(offset + 1)] & 0xFF) << 8 | (bits[(offset + 2)] & 0xFF) << 16 | (bits[(offset + 3)] & 0xFF) << 24;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  594 */     return valueAsInt;
/*      */   }
/*      */   
/*      */   public abstract int getNativeInt(int paramInt) throws SQLException;
/*      */   
/*      */   protected long getNativeLong(byte[] bits, int offset) {
/*  600 */     long valueAsLong = bits[(offset + 0)] & 0xFF | (bits[(offset + 1)] & 0xFF) << 8 | (bits[(offset + 2)] & 0xFF) << 16 | (bits[(offset + 3)] & 0xFF) << 24 | (bits[(offset + 4)] & 0xFF) << 32 | (bits[(offset + 5)] & 0xFF) << 40 | (bits[(offset + 6)] & 0xFF) << 48 | (bits[(offset + 7)] & 0xFF) << 56;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  609 */     return valueAsLong;
/*      */   }
/*      */   
/*      */   public abstract long getNativeLong(int paramInt) throws SQLException;
/*      */   
/*      */   protected short getNativeShort(byte[] bits, int offset) {
/*  615 */     short asShort = (short)(bits[(offset + 0)] & 0xFF | (bits[(offset + 1)] & 0xFF) << 8);
/*      */     
/*  617 */     return asShort;
/*      */   }
/*      */   
/*      */ 
/*      */   public abstract short getNativeShort(int paramInt)
/*      */     throws SQLException;
/*      */   
/*      */   protected Time getNativeTime(int columnIndex, byte[] bits, int offset, int length, Calendar targetCalendar, TimeZone tz, boolean rollForward, MySQLConnection conn, ResultSetImpl rs)
/*      */     throws SQLException
/*      */   {
/*  627 */     int hour = 0;
/*  628 */     int minute = 0;
/*  629 */     int seconds = 0;
/*      */     
/*  631 */     if (length != 0)
/*      */     {
/*      */ 
/*  634 */       hour = bits[(offset + 5)];
/*  635 */       minute = bits[(offset + 6)];
/*  636 */       seconds = bits[(offset + 7)];
/*      */     }
/*      */     
/*  639 */     if (!rs.useLegacyDatetimeCode) {
/*  640 */       return TimeUtil.fastTimeCreate(hour, minute, seconds, targetCalendar, this.exceptionInterceptor);
/*      */     }
/*      */     
/*  643 */     Calendar sessionCalendar = rs.getCalendarInstanceForSessionOrNew();
/*      */     
/*  645 */     synchronized (sessionCalendar) {
/*  646 */       Time time = TimeUtil.fastTimeCreate(sessionCalendar, hour, minute, seconds, this.exceptionInterceptor);
/*      */       
/*      */ 
/*  649 */       Time adjustedTime = TimeUtil.changeTimezone(conn, sessionCalendar, targetCalendar, time, conn.getServerTimezoneTZ(), tz, rollForward);
/*      */       
/*      */ 
/*      */ 
/*  653 */       return adjustedTime;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public abstract Time getNativeTime(int paramInt, Calendar paramCalendar, TimeZone paramTimeZone, boolean paramBoolean, MySQLConnection paramMySQLConnection, ResultSetImpl paramResultSetImpl)
/*      */     throws SQLException;
/*      */   
/*      */   protected Timestamp getNativeTimestamp(byte[] bits, int offset, int length, Calendar targetCalendar, TimeZone tz, boolean rollForward, MySQLConnection conn, ResultSetImpl rs)
/*      */     throws SQLException
/*      */   {
/*  664 */     int year = 0;
/*  665 */     int month = 0;
/*  666 */     int day = 0;
/*      */     
/*  668 */     int hour = 0;
/*  669 */     int minute = 0;
/*  670 */     int seconds = 0;
/*      */     
/*  672 */     int nanos = 0;
/*      */     
/*  674 */     if (length != 0) {
/*  675 */       year = bits[(offset + 0)] & 0xFF | (bits[(offset + 1)] & 0xFF) << 8;
/*  676 */       month = bits[(offset + 2)];
/*  677 */       day = bits[(offset + 3)];
/*      */       
/*  679 */       if (length > 4) {
/*  680 */         hour = bits[(offset + 4)];
/*  681 */         minute = bits[(offset + 5)];
/*  682 */         seconds = bits[(offset + 6)];
/*      */       }
/*      */       
/*  685 */       if (length > 7)
/*      */       {
/*  687 */         nanos = (bits[(offset + 7)] & 0xFF | (bits[(offset + 8)] & 0xFF) << 8 | (bits[(offset + 9)] & 0xFF) << 16 | (bits[(offset + 10)] & 0xFF) << 24) * 1000;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  693 */     if ((length == 0) || ((year == 0) && (month == 0) && (day == 0))) {
/*  694 */       if ("convertToNull".equals(conn.getZeroDateTimeBehavior()))
/*      */       {
/*      */ 
/*  697 */         return null; }
/*  698 */       if ("exception".equals(conn.getZeroDateTimeBehavior()))
/*      */       {
/*  700 */         throw SQLError.createSQLException("Value '0000-00-00' can not be represented as java.sql.Timestamp", "S1009", this.exceptionInterceptor);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  706 */       year = 1;
/*  707 */       month = 1;
/*  708 */       day = 1;
/*      */     }
/*      */     
/*  711 */     if (!rs.useLegacyDatetimeCode) {
/*  712 */       return TimeUtil.fastTimestampCreate(tz, year, month, day, hour, minute, seconds, nanos);
/*      */     }
/*      */     
/*      */ 
/*  716 */     Calendar sessionCalendar = conn.getUseJDBCCompliantTimezoneShift() ? conn.getUtcCalendar() : rs.getCalendarInstanceForSessionOrNew();
/*      */     
/*      */ 
/*      */ 
/*  720 */     synchronized (sessionCalendar) {
/*  721 */       Timestamp ts = rs.fastTimestampCreate(sessionCalendar, year, month, day, hour, minute, seconds, nanos);
/*      */       
/*      */ 
/*  724 */       Timestamp adjustedTs = TimeUtil.changeTimezone(conn, sessionCalendar, targetCalendar, ts, conn.getServerTimezoneTZ(), tz, rollForward);
/*      */       
/*      */ 
/*      */ 
/*  728 */       return adjustedTs;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract Timestamp getNativeTimestamp(int paramInt, Calendar paramCalendar, TimeZone paramTimeZone, boolean paramBoolean, MySQLConnection paramMySQLConnection, ResultSetImpl paramResultSetImpl)
/*      */     throws SQLException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract Reader getReader(int paramInt)
/*      */     throws SQLException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract String getString(int paramInt, String paramString, MySQLConnection paramMySQLConnection)
/*      */     throws SQLException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getString(String encoding, MySQLConnection conn, byte[] value, int offset, int length)
/*      */     throws SQLException
/*      */   {
/*  782 */     String stringVal = null;
/*      */     
/*  784 */     if ((conn != null) && (conn.getUseUnicode())) {
/*      */       try {
/*  786 */         if (encoding == null) {
/*  787 */           stringVal = StringUtils.toString(value);
/*      */         } else {
/*  789 */           SingleByteCharsetConverter converter = conn.getCharsetConverter(encoding);
/*      */           
/*      */ 
/*  792 */           if (converter != null) {
/*  793 */             stringVal = converter.toString(value, offset, length);
/*      */           } else {
/*  795 */             stringVal = StringUtils.toString(value, offset, length, encoding);
/*      */           }
/*      */         }
/*      */       } catch (UnsupportedEncodingException E) {
/*  799 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Unsupported_character_encoding____101") + encoding + "'.", "0S100", this.exceptionInterceptor);
/*      */ 
/*      */       }
/*      */       
/*      */     }
/*      */     else
/*      */     {
/*  806 */       stringVal = StringUtils.toAsciiString(value, offset, length);
/*      */     }
/*      */     
/*  809 */     return stringVal;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   protected Time getTimeFast(int columnIndex, byte[] timeAsBytes, int offset, int length, Calendar targetCalendar, TimeZone tz, boolean rollForward, MySQLConnection conn, ResultSetImpl rs)
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: iconst_0
/*      */     //   1: istore 10
/*      */     //   3: iconst_0
/*      */     //   4: istore 11
/*      */     //   6: iconst_0
/*      */     //   7: istore 12
/*      */     //   9: aload_2
/*      */     //   10: ifnonnull +5 -> 15
/*      */     //   13: aconst_null
/*      */     //   14: areturn
/*      */     //   15: iconst_1
/*      */     //   16: istore 13
/*      */     //   18: iconst_0
/*      */     //   19: istore 14
/*      */     //   21: iconst_0
/*      */     //   22: istore 15
/*      */     //   24: iload 15
/*      */     //   26: iload 4
/*      */     //   28: if_icmpge +26 -> 54
/*      */     //   31: aload_2
/*      */     //   32: iload_3
/*      */     //   33: iload 15
/*      */     //   35: iadd
/*      */     //   36: baload
/*      */     //   37: bipush 58
/*      */     //   39: if_icmpne +9 -> 48
/*      */     //   42: iconst_1
/*      */     //   43: istore 14
/*      */     //   45: goto +9 -> 54
/*      */     //   48: iinc 15 1
/*      */     //   51: goto -27 -> 24
/*      */     //   54: iconst_0
/*      */     //   55: istore 15
/*      */     //   57: iload 15
/*      */     //   59: iload 4
/*      */     //   61: if_icmpge +89 -> 150
/*      */     //   64: aload_2
/*      */     //   65: iload_3
/*      */     //   66: iload 15
/*      */     //   68: iadd
/*      */     //   69: baload
/*      */     //   70: istore 16
/*      */     //   72: iload 16
/*      */     //   74: bipush 32
/*      */     //   76: if_icmpeq +17 -> 93
/*      */     //   79: iload 16
/*      */     //   81: bipush 45
/*      */     //   83: if_icmpeq +10 -> 93
/*      */     //   86: iload 16
/*      */     //   88: bipush 47
/*      */     //   90: if_icmpne +6 -> 96
/*      */     //   93: iconst_0
/*      */     //   94: istore 14
/*      */     //   96: iload 16
/*      */     //   98: bipush 48
/*      */     //   100: if_icmpeq +44 -> 144
/*      */     //   103: iload 16
/*      */     //   105: bipush 32
/*      */     //   107: if_icmpeq +37 -> 144
/*      */     //   110: iload 16
/*      */     //   112: bipush 58
/*      */     //   114: if_icmpeq +30 -> 144
/*      */     //   117: iload 16
/*      */     //   119: bipush 45
/*      */     //   121: if_icmpeq +23 -> 144
/*      */     //   124: iload 16
/*      */     //   126: bipush 47
/*      */     //   128: if_icmpeq +16 -> 144
/*      */     //   131: iload 16
/*      */     //   133: bipush 46
/*      */     //   135: if_icmpeq +9 -> 144
/*      */     //   138: iconst_0
/*      */     //   139: istore 13
/*      */     //   141: goto +9 -> 150
/*      */     //   144: iinc 15 1
/*      */     //   147: goto -90 -> 57
/*      */     //   150: iload 14
/*      */     //   152: ifne +88 -> 240
/*      */     //   155: iload 13
/*      */     //   157: ifeq +83 -> 240
/*      */     //   160: ldc 3
/*      */     //   162: aload 8
/*      */     //   164: invokeinterface 4 1 0
/*      */     //   169: invokevirtual 5	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   172: ifeq +5 -> 177
/*      */     //   175: aconst_null
/*      */     //   176: areturn
/*      */     //   177: ldc 6
/*      */     //   179: aload 8
/*      */     //   181: invokeinterface 4 1 0
/*      */     //   186: invokevirtual 5	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   189: ifeq +40 -> 229
/*      */     //   192: new 7	java/lang/StringBuilder
/*      */     //   195: dup
/*      */     //   196: invokespecial 8	java/lang/StringBuilder:<init>	()V
/*      */     //   199: ldc 9
/*      */     //   201: invokevirtual 10	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   204: aload_2
/*      */     //   205: invokestatic 11	com/mysql/jdbc/StringUtils:toString	([B)Ljava/lang/String;
/*      */     //   208: invokevirtual 10	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   211: ldc 65
/*      */     //   213: invokevirtual 10	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   216: invokevirtual 13	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   219: ldc 14
/*      */     //   221: aload_0
/*      */     //   222: getfield 2	com/mysql/jdbc/ResultSetRow:exceptionInterceptor	Lcom/mysql/jdbc/ExceptionInterceptor;
/*      */     //   225: invokestatic 15	com/mysql/jdbc/SQLError:createSQLException	(Ljava/lang/String;Ljava/lang/String;Lcom/mysql/jdbc/ExceptionInterceptor;)Ljava/sql/SQLException;
/*      */     //   228: athrow
/*      */     //   229: aload 9
/*      */     //   231: aload 5
/*      */     //   233: iconst_0
/*      */     //   234: iconst_0
/*      */     //   235: iconst_0
/*      */     //   236: invokevirtual 66	com/mysql/jdbc/ResultSetImpl:fastTimeCreate	(Ljava/util/Calendar;III)Ljava/sql/Time;
/*      */     //   239: areturn
/*      */     //   240: aload_0
/*      */     //   241: getfield 17	com/mysql/jdbc/ResultSetRow:metadata	[Lcom/mysql/jdbc/Field;
/*      */     //   244: iload_1
/*      */     //   245: aaload
/*      */     //   246: astore 15
/*      */     //   248: aload 15
/*      */     //   250: invokevirtual 18	com/mysql/jdbc/Field:getMysqlType	()I
/*      */     //   253: bipush 7
/*      */     //   255: if_icmpne +306 -> 561
/*      */     //   258: iload 4
/*      */     //   260: tableswitch	default:+203->463, 10:+169->429, 11:+203->463, 12:+113->373, 13:+203->463, 14:+113->373, 15:+203->463, 16:+203->463, 17:+203->463, 18:+203->463, 19:+56->316
/*      */     //   316: aload_2
/*      */     //   317: iload_3
/*      */     //   318: iload 4
/*      */     //   320: iadd
/*      */     //   321: bipush 8
/*      */     //   323: isub
/*      */     //   324: iload_3
/*      */     //   325: iload 4
/*      */     //   327: iadd
/*      */     //   328: bipush 6
/*      */     //   330: isub
/*      */     //   331: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   334: istore 10
/*      */     //   336: aload_2
/*      */     //   337: iload_3
/*      */     //   338: iload 4
/*      */     //   340: iadd
/*      */     //   341: iconst_5
/*      */     //   342: isub
/*      */     //   343: iload_3
/*      */     //   344: iload 4
/*      */     //   346: iadd
/*      */     //   347: iconst_3
/*      */     //   348: isub
/*      */     //   349: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   352: istore 11
/*      */     //   354: aload_2
/*      */     //   355: iload_3
/*      */     //   356: iload 4
/*      */     //   358: iadd
/*      */     //   359: iconst_2
/*      */     //   360: isub
/*      */     //   361: iload_3
/*      */     //   362: iload 4
/*      */     //   364: iadd
/*      */     //   365: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   368: istore 12
/*      */     //   370: goto +142 -> 512
/*      */     //   373: aload_2
/*      */     //   374: iload_3
/*      */     //   375: iload 4
/*      */     //   377: iadd
/*      */     //   378: bipush 6
/*      */     //   380: isub
/*      */     //   381: iload_3
/*      */     //   382: iload 4
/*      */     //   384: iadd
/*      */     //   385: iconst_4
/*      */     //   386: isub
/*      */     //   387: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   390: istore 10
/*      */     //   392: aload_2
/*      */     //   393: iload_3
/*      */     //   394: iload 4
/*      */     //   396: iadd
/*      */     //   397: iconst_4
/*      */     //   398: isub
/*      */     //   399: iload_3
/*      */     //   400: iload 4
/*      */     //   402: iadd
/*      */     //   403: iconst_2
/*      */     //   404: isub
/*      */     //   405: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   408: istore 11
/*      */     //   410: aload_2
/*      */     //   411: iload_3
/*      */     //   412: iload 4
/*      */     //   414: iadd
/*      */     //   415: iconst_2
/*      */     //   416: isub
/*      */     //   417: iload_3
/*      */     //   418: iload 4
/*      */     //   420: iadd
/*      */     //   421: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   424: istore 12
/*      */     //   426: goto +86 -> 512
/*      */     //   429: aload_2
/*      */     //   430: iload_3
/*      */     //   431: bipush 6
/*      */     //   433: iadd
/*      */     //   434: iload_3
/*      */     //   435: bipush 8
/*      */     //   437: iadd
/*      */     //   438: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   441: istore 10
/*      */     //   443: aload_2
/*      */     //   444: iload_3
/*      */     //   445: bipush 8
/*      */     //   447: iadd
/*      */     //   448: iload_3
/*      */     //   449: bipush 10
/*      */     //   451: iadd
/*      */     //   452: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   455: istore 11
/*      */     //   457: iconst_0
/*      */     //   458: istore 12
/*      */     //   460: goto +52 -> 512
/*      */     //   463: new 7	java/lang/StringBuilder
/*      */     //   466: dup
/*      */     //   467: invokespecial 8	java/lang/StringBuilder:<init>	()V
/*      */     //   470: ldc 67
/*      */     //   472: invokestatic 61	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   475: invokevirtual 10	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   478: iload_1
/*      */     //   479: iconst_1
/*      */     //   480: iadd
/*      */     //   481: invokevirtual 68	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*      */     //   484: ldc 69
/*      */     //   486: invokevirtual 10	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   489: aload 15
/*      */     //   491: invokevirtual 70	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*      */     //   494: ldc 71
/*      */     //   496: invokevirtual 10	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   499: invokevirtual 13	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   502: ldc 14
/*      */     //   504: aload_0
/*      */     //   505: getfield 2	com/mysql/jdbc/ResultSetRow:exceptionInterceptor	Lcom/mysql/jdbc/ExceptionInterceptor;
/*      */     //   508: invokestatic 15	com/mysql/jdbc/SQLError:createSQLException	(Ljava/lang/String;Ljava/lang/String;Lcom/mysql/jdbc/ExceptionInterceptor;)Ljava/sql/SQLException;
/*      */     //   511: athrow
/*      */     //   512: new 72	java/sql/SQLWarning
/*      */     //   515: dup
/*      */     //   516: new 7	java/lang/StringBuilder
/*      */     //   519: dup
/*      */     //   520: invokespecial 8	java/lang/StringBuilder:<init>	()V
/*      */     //   523: ldc 73
/*      */     //   525: invokestatic 61	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   528: invokevirtual 10	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   531: iload_1
/*      */     //   532: invokevirtual 68	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*      */     //   535: ldc 69
/*      */     //   537: invokevirtual 10	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   540: aload 15
/*      */     //   542: invokevirtual 70	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*      */     //   545: ldc 71
/*      */     //   547: invokevirtual 10	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   550: invokevirtual 13	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   553: invokespecial 74	java/sql/SQLWarning:<init>	(Ljava/lang/String;)V
/*      */     //   556: astore 16
/*      */     //   558: goto +236 -> 794
/*      */     //   561: aload 15
/*      */     //   563: invokevirtual 18	com/mysql/jdbc/Field:getMysqlType	()I
/*      */     //   566: bipush 12
/*      */     //   568: if_icmpne +96 -> 664
/*      */     //   571: aload_2
/*      */     //   572: iload_3
/*      */     //   573: bipush 11
/*      */     //   575: iadd
/*      */     //   576: iload_3
/*      */     //   577: bipush 13
/*      */     //   579: iadd
/*      */     //   580: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   583: istore 10
/*      */     //   585: aload_2
/*      */     //   586: iload_3
/*      */     //   587: bipush 14
/*      */     //   589: iadd
/*      */     //   590: iload_3
/*      */     //   591: bipush 16
/*      */     //   593: iadd
/*      */     //   594: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   597: istore 11
/*      */     //   599: aload_2
/*      */     //   600: iload_3
/*      */     //   601: bipush 17
/*      */     //   603: iadd
/*      */     //   604: iload_3
/*      */     //   605: bipush 19
/*      */     //   607: iadd
/*      */     //   608: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   611: istore 12
/*      */     //   613: new 72	java/sql/SQLWarning
/*      */     //   616: dup
/*      */     //   617: new 7	java/lang/StringBuilder
/*      */     //   620: dup
/*      */     //   621: invokespecial 8	java/lang/StringBuilder:<init>	()V
/*      */     //   624: ldc 75
/*      */     //   626: invokestatic 61	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   629: invokevirtual 10	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   632: iload_1
/*      */     //   633: iconst_1
/*      */     //   634: iadd
/*      */     //   635: invokevirtual 68	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*      */     //   638: ldc 69
/*      */     //   640: invokevirtual 10	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   643: aload 15
/*      */     //   645: invokevirtual 70	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*      */     //   648: ldc 71
/*      */     //   650: invokevirtual 10	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   653: invokevirtual 13	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   656: invokespecial 74	java/sql/SQLWarning:<init>	(Ljava/lang/String;)V
/*      */     //   659: astore 16
/*      */     //   661: goto +133 -> 794
/*      */     //   664: aload 15
/*      */     //   666: invokevirtual 18	com/mysql/jdbc/Field:getMysqlType	()I
/*      */     //   669: bipush 10
/*      */     //   671: if_icmpne +13 -> 684
/*      */     //   674: aload 9
/*      */     //   676: aconst_null
/*      */     //   677: iconst_0
/*      */     //   678: iconst_0
/*      */     //   679: iconst_0
/*      */     //   680: invokevirtual 66	com/mysql/jdbc/ResultSetImpl:fastTimeCreate	(Ljava/util/Calendar;III)Ljava/sql/Time;
/*      */     //   683: areturn
/*      */     //   684: iload 4
/*      */     //   686: iconst_5
/*      */     //   687: if_icmpeq +59 -> 746
/*      */     //   690: iload 4
/*      */     //   692: bipush 8
/*      */     //   694: if_icmpeq +52 -> 746
/*      */     //   697: new 7	java/lang/StringBuilder
/*      */     //   700: dup
/*      */     //   701: invokespecial 8	java/lang/StringBuilder:<init>	()V
/*      */     //   704: ldc 76
/*      */     //   706: invokestatic 61	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   709: invokevirtual 10	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   712: aload_2
/*      */     //   713: invokestatic 11	com/mysql/jdbc/StringUtils:toString	([B)Ljava/lang/String;
/*      */     //   716: invokevirtual 10	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   719: ldc 77
/*      */     //   721: invokestatic 61	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   724: invokevirtual 10	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   727: iload_1
/*      */     //   728: iconst_1
/*      */     //   729: iadd
/*      */     //   730: invokevirtual 68	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*      */     //   733: invokevirtual 13	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   736: ldc 14
/*      */     //   738: aload_0
/*      */     //   739: getfield 2	com/mysql/jdbc/ResultSetRow:exceptionInterceptor	Lcom/mysql/jdbc/ExceptionInterceptor;
/*      */     //   742: invokestatic 15	com/mysql/jdbc/SQLError:createSQLException	(Ljava/lang/String;Ljava/lang/String;Lcom/mysql/jdbc/ExceptionInterceptor;)Ljava/sql/SQLException;
/*      */     //   745: athrow
/*      */     //   746: aload_2
/*      */     //   747: iload_3
/*      */     //   748: iconst_0
/*      */     //   749: iadd
/*      */     //   750: iload_3
/*      */     //   751: iconst_2
/*      */     //   752: iadd
/*      */     //   753: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   756: istore 10
/*      */     //   758: aload_2
/*      */     //   759: iload_3
/*      */     //   760: iconst_3
/*      */     //   761: iadd
/*      */     //   762: iload_3
/*      */     //   763: iconst_5
/*      */     //   764: iadd
/*      */     //   765: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   768: istore 11
/*      */     //   770: iload 4
/*      */     //   772: iconst_5
/*      */     //   773: if_icmpne +7 -> 780
/*      */     //   776: iconst_0
/*      */     //   777: goto +15 -> 792
/*      */     //   780: aload_2
/*      */     //   781: iload_3
/*      */     //   782: bipush 6
/*      */     //   784: iadd
/*      */     //   785: iload_3
/*      */     //   786: bipush 8
/*      */     //   788: iadd
/*      */     //   789: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   792: istore 12
/*      */     //   794: aload 9
/*      */     //   796: invokevirtual 37	com/mysql/jdbc/ResultSetImpl:getCalendarInstanceForSessionOrNew	()Ljava/util/Calendar;
/*      */     //   799: astore 16
/*      */     //   801: aload 9
/*      */     //   803: getfield 35	com/mysql/jdbc/ResultSetImpl:useLegacyDatetimeCode	Z
/*      */     //   806: ifne +17 -> 823
/*      */     //   809: aload 9
/*      */     //   811: aload 5
/*      */     //   813: iload 10
/*      */     //   815: iload 11
/*      */     //   817: iload 12
/*      */     //   819: invokevirtual 66	com/mysql/jdbc/ResultSetImpl:fastTimeCreate	(Ljava/util/Calendar;III)Ljava/sql/Time;
/*      */     //   822: areturn
/*      */     //   823: aload 16
/*      */     //   825: dup
/*      */     //   826: astore 17
/*      */     //   828: monitorenter
/*      */     //   829: aload 8
/*      */     //   831: aload 16
/*      */     //   833: aload 5
/*      */     //   835: aload 9
/*      */     //   837: aload 16
/*      */     //   839: iload 10
/*      */     //   841: iload 11
/*      */     //   843: iload 12
/*      */     //   845: invokevirtual 66	com/mysql/jdbc/ResultSetImpl:fastTimeCreate	(Ljava/util/Calendar;III)Ljava/sql/Time;
/*      */     //   848: aload 8
/*      */     //   850: invokeinterface 42 1 0
/*      */     //   855: aload 6
/*      */     //   857: iload 7
/*      */     //   859: invokestatic 43	com/mysql/jdbc/TimeUtil:changeTimezone	(Lcom/mysql/jdbc/MySQLConnection;Ljava/util/Calendar;Ljava/util/Calendar;Ljava/sql/Time;Ljava/util/TimeZone;Ljava/util/TimeZone;Z)Ljava/sql/Time;
/*      */     //   862: aload 17
/*      */     //   864: monitorexit
/*      */     //   865: areturn
/*      */     //   866: astore 18
/*      */     //   868: aload 17
/*      */     //   870: monitorexit
/*      */     //   871: aload 18
/*      */     //   873: athrow
/*      */     //   874: astore 13
/*      */     //   876: aload 13
/*      */     //   878: invokevirtual 79	java/lang/RuntimeException:toString	()Ljava/lang/String;
/*      */     //   881: ldc 14
/*      */     //   883: aload_0
/*      */     //   884: getfield 2	com/mysql/jdbc/ResultSetRow:exceptionInterceptor	Lcom/mysql/jdbc/ExceptionInterceptor;
/*      */     //   887: invokestatic 15	com/mysql/jdbc/SQLError:createSQLException	(Ljava/lang/String;Ljava/lang/String;Lcom/mysql/jdbc/ExceptionInterceptor;)Ljava/sql/SQLException;
/*      */     //   890: astore 14
/*      */     //   892: aload 14
/*      */     //   894: aload 13
/*      */     //   896: invokevirtual 33	java/sql/SQLException:initCause	(Ljava/lang/Throwable;)Ljava/lang/Throwable;
/*      */     //   899: pop
/*      */     //   900: aload 14
/*      */     //   902: athrow
/*      */     // Line number table:
/*      */     //   Java source line #817	-> byte code offset #0
/*      */     //   Java source line #818	-> byte code offset #3
/*      */     //   Java source line #819	-> byte code offset #6
/*      */     //   Java source line #823	-> byte code offset #9
/*      */     //   Java source line #824	-> byte code offset #13
/*      */     //   Java source line #827	-> byte code offset #15
/*      */     //   Java source line #828	-> byte code offset #18
/*      */     //   Java source line #830	-> byte code offset #21
/*      */     //   Java source line #831	-> byte code offset #31
/*      */     //   Java source line #832	-> byte code offset #42
/*      */     //   Java source line #833	-> byte code offset #45
/*      */     //   Java source line #830	-> byte code offset #48
/*      */     //   Java source line #837	-> byte code offset #54
/*      */     //   Java source line #838	-> byte code offset #64
/*      */     //   Java source line #840	-> byte code offset #72
/*      */     //   Java source line #841	-> byte code offset #93
/*      */     //   Java source line #844	-> byte code offset #96
/*      */     //   Java source line #846	-> byte code offset #138
/*      */     //   Java source line #848	-> byte code offset #141
/*      */     //   Java source line #837	-> byte code offset #144
/*      */     //   Java source line #852	-> byte code offset #150
/*      */     //   Java source line #853	-> byte code offset #160
/*      */     //   Java source line #855	-> byte code offset #175
/*      */     //   Java source line #856	-> byte code offset #177
/*      */     //   Java source line #858	-> byte code offset #192
/*      */     //   Java source line #866	-> byte code offset #229
/*      */     //   Java source line #869	-> byte code offset #240
/*      */     //   Java source line #871	-> byte code offset #248
/*      */     //   Java source line #873	-> byte code offset #258
/*      */     //   Java source line #876	-> byte code offset #316
/*      */     //   Java source line #878	-> byte code offset #336
/*      */     //   Java source line #880	-> byte code offset #354
/*      */     //   Java source line #884	-> byte code offset #370
/*      */     //   Java source line #887	-> byte code offset #373
/*      */     //   Java source line #889	-> byte code offset #392
/*      */     //   Java source line #891	-> byte code offset #410
/*      */     //   Java source line #895	-> byte code offset #426
/*      */     //   Java source line #898	-> byte code offset #429
/*      */     //   Java source line #900	-> byte code offset #443
/*      */     //   Java source line #902	-> byte code offset #457
/*      */     //   Java source line #905	-> byte code offset #460
/*      */     //   Java source line #908	-> byte code offset #463
/*      */     //   Java source line #918	-> byte code offset #512
/*      */     //   Java source line #927	-> byte code offset #558
/*      */     //   Java source line #928	-> byte code offset #571
/*      */     //   Java source line #929	-> byte code offset #585
/*      */     //   Java source line #930	-> byte code offset #599
/*      */     //   Java source line #932	-> byte code offset #613
/*      */     //   Java source line #942	-> byte code offset #661
/*      */     //   Java source line #943	-> byte code offset #674
/*      */     //   Java source line #948	-> byte code offset #684
/*      */     //   Java source line #949	-> byte code offset #697
/*      */     //   Java source line #957	-> byte code offset #746
/*      */     //   Java source line #958	-> byte code offset #758
/*      */     //   Java source line #959	-> byte code offset #770
/*      */     //   Java source line #963	-> byte code offset #794
/*      */     //   Java source line #965	-> byte code offset #801
/*      */     //   Java source line #966	-> byte code offset #809
/*      */     //   Java source line #969	-> byte code offset #823
/*      */     //   Java source line #970	-> byte code offset #829
/*      */     //   Java source line #974	-> byte code offset #866
/*      */     //   Java source line #975	-> byte code offset #874
/*      */     //   Java source line #976	-> byte code offset #876
/*      */     //   Java source line #978	-> byte code offset #892
/*      */     //   Java source line #980	-> byte code offset #900
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	903	0	this	ResultSetRow
/*      */     //   0	903	1	columnIndex	int
/*      */     //   0	903	2	timeAsBytes	byte[]
/*      */     //   0	903	3	offset	int
/*      */     //   0	903	4	length	int
/*      */     //   0	903	5	targetCalendar	Calendar
/*      */     //   0	903	6	tz	TimeZone
/*      */     //   0	903	7	rollForward	boolean
/*      */     //   0	903	8	conn	MySQLConnection
/*      */     //   0	903	9	rs	ResultSetImpl
/*      */     //   1	839	10	hr	int
/*      */     //   4	838	11	min	int
/*      */     //   7	837	12	sec	int
/*      */     //   16	140	13	allZeroTime	boolean
/*      */     //   874	21	13	ex	RuntimeException
/*      */     //   19	132	14	onlyTimePresent	boolean
/*      */     //   890	11	14	sqlEx	SQLException
/*      */     //   22	27	15	i	int
/*      */     //   55	90	15	i	int
/*      */     //   246	419	15	timeColField	Field
/*      */     //   70	62	16	b	byte
/*      */     //   556	3	16	precisionLost	java.sql.SQLWarning
/*      */     //   659	3	16	precisionLost	java.sql.SQLWarning
/*      */     //   799	39	16	sessionCalendar	Calendar
/*      */     //   826	43	17	Ljava/lang/Object;	Object
/*      */     //   866	6	18	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   829	865	866	finally
/*      */     //   866	871	866	finally
/*      */     //   9	14	874	java/lang/RuntimeException
/*      */     //   15	176	874	java/lang/RuntimeException
/*      */     //   177	239	874	java/lang/RuntimeException
/*      */     //   240	683	874	java/lang/RuntimeException
/*      */     //   684	822	874	java/lang/RuntimeException
/*      */     //   823	865	874	java/lang/RuntimeException
/*      */     //   866	874	874	java/lang/RuntimeException
/*      */   }
/*      */   
/*      */   public abstract Time getTimeFast(int paramInt, Calendar paramCalendar, TimeZone paramTimeZone, boolean paramBoolean, MySQLConnection paramMySQLConnection, ResultSetImpl paramResultSetImpl)
/*      */     throws SQLException;
/*      */   
/*      */   /* Error */
/*      */   protected Timestamp getTimestampFast(int columnIndex, byte[] timestampAsBytes, int offset, int length, Calendar targetCalendar, TimeZone tz, boolean rollForward, MySQLConnection conn, ResultSetImpl rs)
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload 8
/*      */     //   2: invokeinterface 38 1 0
/*      */     //   7: ifeq +13 -> 20
/*      */     //   10: aload 8
/*      */     //   12: invokeinterface 39 1 0
/*      */     //   17: goto +8 -> 25
/*      */     //   20: aload 9
/*      */     //   22: invokevirtual 37	com/mysql/jdbc/ResultSetImpl:getCalendarInstanceForSessionOrNew	()Ljava/util/Calendar;
/*      */     //   25: astore 10
/*      */     //   27: aload 10
/*      */     //   29: dup
/*      */     //   30: astore 11
/*      */     //   32: monitorenter
/*      */     //   33: iconst_1
/*      */     //   34: istore 12
/*      */     //   36: iconst_0
/*      */     //   37: istore 13
/*      */     //   39: iconst_0
/*      */     //   40: istore 14
/*      */     //   42: iload 14
/*      */     //   44: iload 4
/*      */     //   46: if_icmpge +26 -> 72
/*      */     //   49: aload_2
/*      */     //   50: iload_3
/*      */     //   51: iload 14
/*      */     //   53: iadd
/*      */     //   54: baload
/*      */     //   55: bipush 58
/*      */     //   57: if_icmpne +9 -> 66
/*      */     //   60: iconst_1
/*      */     //   61: istore 13
/*      */     //   63: goto +9 -> 72
/*      */     //   66: iinc 14 1
/*      */     //   69: goto -27 -> 42
/*      */     //   72: iconst_0
/*      */     //   73: istore 14
/*      */     //   75: iload 14
/*      */     //   77: iload 4
/*      */     //   79: if_icmpge +89 -> 168
/*      */     //   82: aload_2
/*      */     //   83: iload_3
/*      */     //   84: iload 14
/*      */     //   86: iadd
/*      */     //   87: baload
/*      */     //   88: istore 15
/*      */     //   90: iload 15
/*      */     //   92: bipush 32
/*      */     //   94: if_icmpeq +17 -> 111
/*      */     //   97: iload 15
/*      */     //   99: bipush 45
/*      */     //   101: if_icmpeq +10 -> 111
/*      */     //   104: iload 15
/*      */     //   106: bipush 47
/*      */     //   108: if_icmpne +6 -> 114
/*      */     //   111: iconst_0
/*      */     //   112: istore 13
/*      */     //   114: iload 15
/*      */     //   116: bipush 48
/*      */     //   118: if_icmpeq +44 -> 162
/*      */     //   121: iload 15
/*      */     //   123: bipush 32
/*      */     //   125: if_icmpeq +37 -> 162
/*      */     //   128: iload 15
/*      */     //   130: bipush 58
/*      */     //   132: if_icmpeq +30 -> 162
/*      */     //   135: iload 15
/*      */     //   137: bipush 45
/*      */     //   139: if_icmpeq +23 -> 162
/*      */     //   142: iload 15
/*      */     //   144: bipush 47
/*      */     //   146: if_icmpeq +16 -> 162
/*      */     //   149: iload 15
/*      */     //   151: bipush 46
/*      */     //   153: if_icmpeq +9 -> 162
/*      */     //   156: iconst_0
/*      */     //   157: istore 12
/*      */     //   159: goto +9 -> 168
/*      */     //   162: iinc 14 1
/*      */     //   165: goto -90 -> 75
/*      */     //   168: iload 13
/*      */     //   170: ifne +121 -> 291
/*      */     //   173: iload 12
/*      */     //   175: ifeq +116 -> 291
/*      */     //   178: ldc 3
/*      */     //   180: aload 8
/*      */     //   182: invokeinterface 4 1 0
/*      */     //   187: invokevirtual 5	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   190: ifeq +8 -> 198
/*      */     //   193: aconst_null
/*      */     //   194: aload 11
/*      */     //   196: monitorexit
/*      */     //   197: areturn
/*      */     //   198: ldc 6
/*      */     //   200: aload 8
/*      */     //   202: invokeinterface 4 1 0
/*      */     //   207: invokevirtual 5	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   210: ifeq +40 -> 250
/*      */     //   213: new 7	java/lang/StringBuilder
/*      */     //   216: dup
/*      */     //   217: invokespecial 8	java/lang/StringBuilder:<init>	()V
/*      */     //   220: ldc 9
/*      */     //   222: invokevirtual 10	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   225: aload_2
/*      */     //   226: invokestatic 11	com/mysql/jdbc/StringUtils:toString	([B)Ljava/lang/String;
/*      */     //   229: invokevirtual 10	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   232: ldc 80
/*      */     //   234: invokevirtual 10	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   237: invokevirtual 13	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   240: ldc 14
/*      */     //   242: aload_0
/*      */     //   243: getfield 2	com/mysql/jdbc/ResultSetRow:exceptionInterceptor	Lcom/mysql/jdbc/ExceptionInterceptor;
/*      */     //   246: invokestatic 15	com/mysql/jdbc/SQLError:createSQLException	(Ljava/lang/String;Ljava/lang/String;Lcom/mysql/jdbc/ExceptionInterceptor;)Ljava/sql/SQLException;
/*      */     //   249: athrow
/*      */     //   250: aload 9
/*      */     //   252: getfield 35	com/mysql/jdbc/ResultSetImpl:useLegacyDatetimeCode	Z
/*      */     //   255: ifne +19 -> 274
/*      */     //   258: aload 6
/*      */     //   260: iconst_1
/*      */     //   261: iconst_1
/*      */     //   262: iconst_1
/*      */     //   263: iconst_0
/*      */     //   264: iconst_0
/*      */     //   265: iconst_0
/*      */     //   266: iconst_0
/*      */     //   267: invokestatic 48	com/mysql/jdbc/TimeUtil:fastTimestampCreate	(Ljava/util/TimeZone;IIIIIII)Ljava/sql/Timestamp;
/*      */     //   270: aload 11
/*      */     //   272: monitorexit
/*      */     //   273: areturn
/*      */     //   274: aload 9
/*      */     //   276: aconst_null
/*      */     //   277: iconst_1
/*      */     //   278: iconst_1
/*      */     //   279: iconst_1
/*      */     //   280: iconst_0
/*      */     //   281: iconst_0
/*      */     //   282: iconst_0
/*      */     //   283: iconst_0
/*      */     //   284: invokevirtual 49	com/mysql/jdbc/ResultSetImpl:fastTimestampCreate	(Ljava/util/Calendar;IIIIIII)Ljava/sql/Timestamp;
/*      */     //   287: aload 11
/*      */     //   289: monitorexit
/*      */     //   290: areturn
/*      */     //   291: aload_0
/*      */     //   292: getfield 17	com/mysql/jdbc/ResultSetRow:metadata	[Lcom/mysql/jdbc/Field;
/*      */     //   295: iload_1
/*      */     //   296: aaload
/*      */     //   297: invokevirtual 18	com/mysql/jdbc/Field:getMysqlType	()I
/*      */     //   300: bipush 13
/*      */     //   302: if_icmpne +75 -> 377
/*      */     //   305: aload 9
/*      */     //   307: getfield 35	com/mysql/jdbc/ResultSetImpl:useLegacyDatetimeCode	Z
/*      */     //   310: ifne +24 -> 334
/*      */     //   313: aload 6
/*      */     //   315: aload_2
/*      */     //   316: iload_3
/*      */     //   317: iconst_4
/*      */     //   318: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   321: iconst_1
/*      */     //   322: iconst_1
/*      */     //   323: iconst_0
/*      */     //   324: iconst_0
/*      */     //   325: iconst_0
/*      */     //   326: iconst_0
/*      */     //   327: invokestatic 48	com/mysql/jdbc/TimeUtil:fastTimestampCreate	(Ljava/util/TimeZone;IIIIIII)Ljava/sql/Timestamp;
/*      */     //   330: aload 11
/*      */     //   332: monitorexit
/*      */     //   333: areturn
/*      */     //   334: aload 8
/*      */     //   336: aload 10
/*      */     //   338: aload 5
/*      */     //   340: aload 9
/*      */     //   342: aload 10
/*      */     //   344: aload_2
/*      */     //   345: iload_3
/*      */     //   346: iconst_4
/*      */     //   347: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   350: iconst_1
/*      */     //   351: iconst_1
/*      */     //   352: iconst_0
/*      */     //   353: iconst_0
/*      */     //   354: iconst_0
/*      */     //   355: iconst_0
/*      */     //   356: invokevirtual 49	com/mysql/jdbc/ResultSetImpl:fastTimestampCreate	(Ljava/util/Calendar;IIIIIII)Ljava/sql/Timestamp;
/*      */     //   359: aload 8
/*      */     //   361: invokeinterface 42 1 0
/*      */     //   366: aload 6
/*      */     //   368: iload 7
/*      */     //   370: invokestatic 50	com/mysql/jdbc/TimeUtil:changeTimezone	(Lcom/mysql/jdbc/MySQLConnection;Ljava/util/Calendar;Ljava/util/Calendar;Ljava/sql/Timestamp;Ljava/util/TimeZone;Ljava/util/TimeZone;Z)Ljava/sql/Timestamp;
/*      */     //   373: aload 11
/*      */     //   375: monitorexit
/*      */     //   376: areturn
/*      */     //   377: aload_2
/*      */     //   378: iload_3
/*      */     //   379: iload 4
/*      */     //   381: iadd
/*      */     //   382: iconst_1
/*      */     //   383: isub
/*      */     //   384: baload
/*      */     //   385: bipush 46
/*      */     //   387: if_icmpne +6 -> 393
/*      */     //   390: iinc 4 -1
/*      */     //   393: iconst_0
/*      */     //   394: istore 14
/*      */     //   396: iconst_0
/*      */     //   397: istore 15
/*      */     //   399: iconst_0
/*      */     //   400: istore 16
/*      */     //   402: iconst_0
/*      */     //   403: istore 17
/*      */     //   405: iconst_0
/*      */     //   406: istore 18
/*      */     //   408: iconst_0
/*      */     //   409: istore 19
/*      */     //   411: iconst_0
/*      */     //   412: istore 20
/*      */     //   414: iload 4
/*      */     //   416: tableswitch	default:+1002->1418, 2:+961->1377, 3:+1002->1418, 4:+917->1333, 5:+1002->1418, 6:+857->1273, 7:+1002->1418, 8:+713->1129, 9:+1002->1418, 10:+522->938, 11:+1002->1418, 12:+420->836, 13:+1002->1418, 14:+336->752, 15:+1002->1418, 16:+1002->1418, 17:+1002->1418, 18:+1002->1418, 19:+128->544, 20:+128->544, 21:+128->544, 22:+128->544, 23:+128->544, 24:+128->544, 25:+128->544, 26:+128->544, 27:+1002->1418, 28:+1002->1418, 29:+128->544
/*      */     //   544: aload_2
/*      */     //   545: iload_3
/*      */     //   546: iconst_0
/*      */     //   547: iadd
/*      */     //   548: iload_3
/*      */     //   549: iconst_4
/*      */     //   550: iadd
/*      */     //   551: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   554: istore 14
/*      */     //   556: aload_2
/*      */     //   557: iload_3
/*      */     //   558: iconst_5
/*      */     //   559: iadd
/*      */     //   560: iload_3
/*      */     //   561: bipush 7
/*      */     //   563: iadd
/*      */     //   564: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   567: istore 15
/*      */     //   569: aload_2
/*      */     //   570: iload_3
/*      */     //   571: bipush 8
/*      */     //   573: iadd
/*      */     //   574: iload_3
/*      */     //   575: bipush 10
/*      */     //   577: iadd
/*      */     //   578: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   581: istore 16
/*      */     //   583: aload_2
/*      */     //   584: iload_3
/*      */     //   585: bipush 11
/*      */     //   587: iadd
/*      */     //   588: iload_3
/*      */     //   589: bipush 13
/*      */     //   591: iadd
/*      */     //   592: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   595: istore 17
/*      */     //   597: aload_2
/*      */     //   598: iload_3
/*      */     //   599: bipush 14
/*      */     //   601: iadd
/*      */     //   602: iload_3
/*      */     //   603: bipush 16
/*      */     //   605: iadd
/*      */     //   606: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   609: istore 18
/*      */     //   611: aload_2
/*      */     //   612: iload_3
/*      */     //   613: bipush 17
/*      */     //   615: iadd
/*      */     //   616: iload_3
/*      */     //   617: bipush 19
/*      */     //   619: iadd
/*      */     //   620: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   623: istore 19
/*      */     //   625: iconst_0
/*      */     //   626: istore 20
/*      */     //   628: iload 4
/*      */     //   630: bipush 19
/*      */     //   632: if_icmple +834 -> 1466
/*      */     //   635: iconst_m1
/*      */     //   636: istore 21
/*      */     //   638: iconst_0
/*      */     //   639: istore 22
/*      */     //   641: iload 22
/*      */     //   643: iload 4
/*      */     //   645: if_icmpge +24 -> 669
/*      */     //   648: aload_2
/*      */     //   649: iload_3
/*      */     //   650: iload 22
/*      */     //   652: iadd
/*      */     //   653: baload
/*      */     //   654: bipush 46
/*      */     //   656: if_icmpne +7 -> 663
/*      */     //   659: iload 22
/*      */     //   661: istore 21
/*      */     //   663: iinc 22 1
/*      */     //   666: goto -25 -> 641
/*      */     //   669: iload 21
/*      */     //   671: iconst_m1
/*      */     //   672: if_icmpeq +77 -> 749
/*      */     //   675: iload 21
/*      */     //   677: iconst_2
/*      */     //   678: iadd
/*      */     //   679: iload 4
/*      */     //   681: if_icmpgt +60 -> 741
/*      */     //   684: aload_2
/*      */     //   685: iload_3
/*      */     //   686: iload 21
/*      */     //   688: iadd
/*      */     //   689: iconst_1
/*      */     //   690: iadd
/*      */     //   691: iload_3
/*      */     //   692: iload 4
/*      */     //   694: iadd
/*      */     //   695: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   698: istore 20
/*      */     //   700: iload 4
/*      */     //   702: iload 21
/*      */     //   704: iconst_1
/*      */     //   705: iadd
/*      */     //   706: isub
/*      */     //   707: istore 22
/*      */     //   709: iload 22
/*      */     //   711: bipush 9
/*      */     //   713: if_icmpge +25 -> 738
/*      */     //   716: ldc2_w 81
/*      */     //   719: bipush 9
/*      */     //   721: iload 22
/*      */     //   723: isub
/*      */     //   724: i2d
/*      */     //   725: invokestatic 83	java/lang/Math:pow	(DD)D
/*      */     //   728: d2i
/*      */     //   729: istore 23
/*      */     //   731: iload 20
/*      */     //   733: iload 23
/*      */     //   735: imul
/*      */     //   736: istore 20
/*      */     //   738: goto +11 -> 749
/*      */     //   741: new 84	java/lang/IllegalArgumentException
/*      */     //   744: dup
/*      */     //   745: invokespecial 85	java/lang/IllegalArgumentException:<init>	()V
/*      */     //   748: athrow
/*      */     //   749: goto +717 -> 1466
/*      */     //   752: aload_2
/*      */     //   753: iload_3
/*      */     //   754: iconst_0
/*      */     //   755: iadd
/*      */     //   756: iload_3
/*      */     //   757: iconst_4
/*      */     //   758: iadd
/*      */     //   759: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   762: istore 14
/*      */     //   764: aload_2
/*      */     //   765: iload_3
/*      */     //   766: iconst_4
/*      */     //   767: iadd
/*      */     //   768: iload_3
/*      */     //   769: bipush 6
/*      */     //   771: iadd
/*      */     //   772: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   775: istore 15
/*      */     //   777: aload_2
/*      */     //   778: iload_3
/*      */     //   779: bipush 6
/*      */     //   781: iadd
/*      */     //   782: iload_3
/*      */     //   783: bipush 8
/*      */     //   785: iadd
/*      */     //   786: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   789: istore 16
/*      */     //   791: aload_2
/*      */     //   792: iload_3
/*      */     //   793: bipush 8
/*      */     //   795: iadd
/*      */     //   796: iload_3
/*      */     //   797: bipush 10
/*      */     //   799: iadd
/*      */     //   800: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   803: istore 17
/*      */     //   805: aload_2
/*      */     //   806: iload_3
/*      */     //   807: bipush 10
/*      */     //   809: iadd
/*      */     //   810: iload_3
/*      */     //   811: bipush 12
/*      */     //   813: iadd
/*      */     //   814: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   817: istore 18
/*      */     //   819: aload_2
/*      */     //   820: iload_3
/*      */     //   821: bipush 12
/*      */     //   823: iadd
/*      */     //   824: iload_3
/*      */     //   825: bipush 14
/*      */     //   827: iadd
/*      */     //   828: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   831: istore 19
/*      */     //   833: goto +633 -> 1466
/*      */     //   836: aload_2
/*      */     //   837: iload_3
/*      */     //   838: iconst_0
/*      */     //   839: iadd
/*      */     //   840: iload_3
/*      */     //   841: iconst_2
/*      */     //   842: iadd
/*      */     //   843: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   846: istore 14
/*      */     //   848: iload 14
/*      */     //   850: bipush 69
/*      */     //   852: if_icmpgt +10 -> 862
/*      */     //   855: iload 14
/*      */     //   857: bipush 100
/*      */     //   859: iadd
/*      */     //   860: istore 14
/*      */     //   862: wide
/*      */     //   868: aload_2
/*      */     //   869: iload_3
/*      */     //   870: iconst_2
/*      */     //   871: iadd
/*      */     //   872: iload_3
/*      */     //   873: iconst_4
/*      */     //   874: iadd
/*      */     //   875: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   878: istore 15
/*      */     //   880: aload_2
/*      */     //   881: iload_3
/*      */     //   882: iconst_4
/*      */     //   883: iadd
/*      */     //   884: iload_3
/*      */     //   885: bipush 6
/*      */     //   887: iadd
/*      */     //   888: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   891: istore 16
/*      */     //   893: aload_2
/*      */     //   894: iload_3
/*      */     //   895: bipush 6
/*      */     //   897: iadd
/*      */     //   898: iload_3
/*      */     //   899: bipush 8
/*      */     //   901: iadd
/*      */     //   902: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   905: istore 17
/*      */     //   907: aload_2
/*      */     //   908: iload_3
/*      */     //   909: bipush 8
/*      */     //   911: iadd
/*      */     //   912: iload_3
/*      */     //   913: bipush 10
/*      */     //   915: iadd
/*      */     //   916: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   919: istore 18
/*      */     //   921: aload_2
/*      */     //   922: iload_3
/*      */     //   923: bipush 10
/*      */     //   925: iadd
/*      */     //   926: iload_3
/*      */     //   927: bipush 12
/*      */     //   929: iadd
/*      */     //   930: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   933: istore 19
/*      */     //   935: goto +531 -> 1466
/*      */     //   938: iconst_0
/*      */     //   939: istore 21
/*      */     //   941: iconst_0
/*      */     //   942: istore 22
/*      */     //   944: iload 22
/*      */     //   946: iload 4
/*      */     //   948: if_icmpge +26 -> 974
/*      */     //   951: aload_2
/*      */     //   952: iload_3
/*      */     //   953: iload 22
/*      */     //   955: iadd
/*      */     //   956: baload
/*      */     //   957: bipush 45
/*      */     //   959: if_icmpne +9 -> 968
/*      */     //   962: iconst_1
/*      */     //   963: istore 21
/*      */     //   965: goto +9 -> 974
/*      */     //   968: iinc 22 1
/*      */     //   971: goto -27 -> 944
/*      */     //   974: aload_0
/*      */     //   975: getfield 17	com/mysql/jdbc/ResultSetRow:metadata	[Lcom/mysql/jdbc/Field;
/*      */     //   978: iload_1
/*      */     //   979: aaload
/*      */     //   980: invokevirtual 18	com/mysql/jdbc/Field:getMysqlType	()I
/*      */     //   983: bipush 10
/*      */     //   985: if_icmpeq +8 -> 993
/*      */     //   988: iload 21
/*      */     //   990: ifeq +51 -> 1041
/*      */     //   993: aload_2
/*      */     //   994: iload_3
/*      */     //   995: iconst_0
/*      */     //   996: iadd
/*      */     //   997: iload_3
/*      */     //   998: iconst_4
/*      */     //   999: iadd
/*      */     //   1000: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   1003: istore 14
/*      */     //   1005: aload_2
/*      */     //   1006: iload_3
/*      */     //   1007: iconst_5
/*      */     //   1008: iadd
/*      */     //   1009: iload_3
/*      */     //   1010: bipush 7
/*      */     //   1012: iadd
/*      */     //   1013: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   1016: istore 15
/*      */     //   1018: aload_2
/*      */     //   1019: iload_3
/*      */     //   1020: bipush 8
/*      */     //   1022: iadd
/*      */     //   1023: iload_3
/*      */     //   1024: bipush 10
/*      */     //   1026: iadd
/*      */     //   1027: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   1030: istore 16
/*      */     //   1032: iconst_0
/*      */     //   1033: istore 17
/*      */     //   1035: iconst_0
/*      */     //   1036: istore 18
/*      */     //   1038: goto +428 -> 1466
/*      */     //   1041: aload_2
/*      */     //   1042: iload_3
/*      */     //   1043: iconst_0
/*      */     //   1044: iadd
/*      */     //   1045: iload_3
/*      */     //   1046: iconst_2
/*      */     //   1047: iadd
/*      */     //   1048: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   1051: istore 14
/*      */     //   1053: iload 14
/*      */     //   1055: bipush 69
/*      */     //   1057: if_icmpgt +10 -> 1067
/*      */     //   1060: iload 14
/*      */     //   1062: bipush 100
/*      */     //   1064: iadd
/*      */     //   1065: istore 14
/*      */     //   1067: aload_2
/*      */     //   1068: iload_3
/*      */     //   1069: iconst_2
/*      */     //   1070: iadd
/*      */     //   1071: iload_3
/*      */     //   1072: iconst_4
/*      */     //   1073: iadd
/*      */     //   1074: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   1077: istore 15
/*      */     //   1079: aload_2
/*      */     //   1080: iload_3
/*      */     //   1081: iconst_4
/*      */     //   1082: iadd
/*      */     //   1083: iload_3
/*      */     //   1084: bipush 6
/*      */     //   1086: iadd
/*      */     //   1087: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   1090: istore 16
/*      */     //   1092: aload_2
/*      */     //   1093: iload_3
/*      */     //   1094: bipush 6
/*      */     //   1096: iadd
/*      */     //   1097: iload_3
/*      */     //   1098: bipush 8
/*      */     //   1100: iadd
/*      */     //   1101: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   1104: istore 17
/*      */     //   1106: aload_2
/*      */     //   1107: iload_3
/*      */     //   1108: bipush 8
/*      */     //   1110: iadd
/*      */     //   1111: iload_3
/*      */     //   1112: bipush 10
/*      */     //   1114: iadd
/*      */     //   1115: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   1118: istore 18
/*      */     //   1120: wide
/*      */     //   1126: goto +340 -> 1466
/*      */     //   1129: iconst_0
/*      */     //   1130: istore 21
/*      */     //   1132: iconst_0
/*      */     //   1133: istore 22
/*      */     //   1135: iload 22
/*      */     //   1137: iload 4
/*      */     //   1139: if_icmpge +26 -> 1165
/*      */     //   1142: aload_2
/*      */     //   1143: iload_3
/*      */     //   1144: iload 22
/*      */     //   1146: iadd
/*      */     //   1147: baload
/*      */     //   1148: bipush 58
/*      */     //   1150: if_icmpne +9 -> 1159
/*      */     //   1153: iconst_1
/*      */     //   1154: istore 21
/*      */     //   1156: goto +9 -> 1165
/*      */     //   1159: iinc 22 1
/*      */     //   1162: goto -27 -> 1135
/*      */     //   1165: iload 21
/*      */     //   1167: ifeq +55 -> 1222
/*      */     //   1170: aload_2
/*      */     //   1171: iload_3
/*      */     //   1172: iconst_0
/*      */     //   1173: iadd
/*      */     //   1174: iload_3
/*      */     //   1175: iconst_2
/*      */     //   1176: iadd
/*      */     //   1177: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   1180: istore 17
/*      */     //   1182: aload_2
/*      */     //   1183: iload_3
/*      */     //   1184: iconst_3
/*      */     //   1185: iadd
/*      */     //   1186: iload_3
/*      */     //   1187: iconst_5
/*      */     //   1188: iadd
/*      */     //   1189: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   1192: istore 18
/*      */     //   1194: aload_2
/*      */     //   1195: iload_3
/*      */     //   1196: bipush 6
/*      */     //   1198: iadd
/*      */     //   1199: iload_3
/*      */     //   1200: bipush 8
/*      */     //   1202: iadd
/*      */     //   1203: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   1206: istore 19
/*      */     //   1208: sipush 1970
/*      */     //   1211: istore 14
/*      */     //   1213: iconst_1
/*      */     //   1214: istore 15
/*      */     //   1216: iconst_1
/*      */     //   1217: istore 16
/*      */     //   1219: goto +247 -> 1466
/*      */     //   1222: aload_2
/*      */     //   1223: iload_3
/*      */     //   1224: iconst_0
/*      */     //   1225: iadd
/*      */     //   1226: iload_3
/*      */     //   1227: iconst_4
/*      */     //   1228: iadd
/*      */     //   1229: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   1232: istore 14
/*      */     //   1234: aload_2
/*      */     //   1235: iload_3
/*      */     //   1236: iconst_4
/*      */     //   1237: iadd
/*      */     //   1238: iload_3
/*      */     //   1239: bipush 6
/*      */     //   1241: iadd
/*      */     //   1242: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   1245: istore 15
/*      */     //   1247: aload_2
/*      */     //   1248: iload_3
/*      */     //   1249: bipush 6
/*      */     //   1251: iadd
/*      */     //   1252: iload_3
/*      */     //   1253: bipush 8
/*      */     //   1255: iadd
/*      */     //   1256: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   1259: istore 16
/*      */     //   1261: wide
/*      */     //   1267: iinc 15 -1
/*      */     //   1270: goto +196 -> 1466
/*      */     //   1273: aload_2
/*      */     //   1274: iload_3
/*      */     //   1275: iconst_0
/*      */     //   1276: iadd
/*      */     //   1277: iload_3
/*      */     //   1278: iconst_2
/*      */     //   1279: iadd
/*      */     //   1280: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   1283: istore 14
/*      */     //   1285: iload 14
/*      */     //   1287: bipush 69
/*      */     //   1289: if_icmpgt +10 -> 1299
/*      */     //   1292: iload 14
/*      */     //   1294: bipush 100
/*      */     //   1296: iadd
/*      */     //   1297: istore 14
/*      */     //   1299: wide
/*      */     //   1305: aload_2
/*      */     //   1306: iload_3
/*      */     //   1307: iconst_2
/*      */     //   1308: iadd
/*      */     //   1309: iload_3
/*      */     //   1310: iconst_4
/*      */     //   1311: iadd
/*      */     //   1312: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   1315: istore 15
/*      */     //   1317: aload_2
/*      */     //   1318: iload_3
/*      */     //   1319: iconst_4
/*      */     //   1320: iadd
/*      */     //   1321: iload_3
/*      */     //   1322: bipush 6
/*      */     //   1324: iadd
/*      */     //   1325: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   1328: istore 16
/*      */     //   1330: goto +136 -> 1466
/*      */     //   1333: aload_2
/*      */     //   1334: iload_3
/*      */     //   1335: iconst_0
/*      */     //   1336: iadd
/*      */     //   1337: iload_3
/*      */     //   1338: iconst_2
/*      */     //   1339: iadd
/*      */     //   1340: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   1343: istore 14
/*      */     //   1345: iload 14
/*      */     //   1347: bipush 69
/*      */     //   1349: if_icmpgt +10 -> 1359
/*      */     //   1352: iload 14
/*      */     //   1354: bipush 100
/*      */     //   1356: iadd
/*      */     //   1357: istore 14
/*      */     //   1359: aload_2
/*      */     //   1360: iload_3
/*      */     //   1361: iconst_2
/*      */     //   1362: iadd
/*      */     //   1363: iload_3
/*      */     //   1364: iconst_4
/*      */     //   1365: iadd
/*      */     //   1366: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   1369: istore 15
/*      */     //   1371: iconst_1
/*      */     //   1372: istore 16
/*      */     //   1374: goto +92 -> 1466
/*      */     //   1377: aload_2
/*      */     //   1378: iload_3
/*      */     //   1379: iconst_0
/*      */     //   1380: iadd
/*      */     //   1381: iload_3
/*      */     //   1382: iconst_2
/*      */     //   1383: iadd
/*      */     //   1384: invokestatic 19	com/mysql/jdbc/StringUtils:getInt	([BII)I
/*      */     //   1387: istore 14
/*      */     //   1389: iload 14
/*      */     //   1391: bipush 69
/*      */     //   1393: if_icmpgt +10 -> 1403
/*      */     //   1396: iload 14
/*      */     //   1398: bipush 100
/*      */     //   1400: iadd
/*      */     //   1401: istore 14
/*      */     //   1403: wide
/*      */     //   1409: iconst_1
/*      */     //   1410: istore 15
/*      */     //   1412: iconst_1
/*      */     //   1413: istore 16
/*      */     //   1415: goto +51 -> 1466
/*      */     //   1418: new 31	java/sql/SQLException
/*      */     //   1421: dup
/*      */     //   1422: new 7	java/lang/StringBuilder
/*      */     //   1425: dup
/*      */     //   1426: invokespecial 8	java/lang/StringBuilder:<init>	()V
/*      */     //   1429: ldc 86
/*      */     //   1431: invokevirtual 10	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   1434: aload_2
/*      */     //   1435: invokestatic 11	com/mysql/jdbc/StringUtils:toString	([B)Ljava/lang/String;
/*      */     //   1438: invokevirtual 10	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   1441: ldc 87
/*      */     //   1443: invokevirtual 10	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   1446: iload_1
/*      */     //   1447: iconst_1
/*      */     //   1448: iadd
/*      */     //   1449: invokevirtual 68	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*      */     //   1452: ldc 88
/*      */     //   1454: invokevirtual 10	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   1457: invokevirtual 13	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   1460: ldc 14
/*      */     //   1462: invokespecial 45	java/sql/SQLException:<init>	(Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   1465: athrow
/*      */     //   1466: aload 9
/*      */     //   1468: getfield 35	com/mysql/jdbc/ResultSetImpl:useLegacyDatetimeCode	Z
/*      */     //   1471: ifne +26 -> 1497
/*      */     //   1474: aload 6
/*      */     //   1476: iload 14
/*      */     //   1478: iload 15
/*      */     //   1480: iload 16
/*      */     //   1482: iload 17
/*      */     //   1484: iload 18
/*      */     //   1486: iload 19
/*      */     //   1488: iload 20
/*      */     //   1490: invokestatic 48	com/mysql/jdbc/TimeUtil:fastTimestampCreate	(Ljava/util/TimeZone;IIIIIII)Ljava/sql/Timestamp;
/*      */     //   1493: aload 11
/*      */     //   1495: monitorexit
/*      */     //   1496: areturn
/*      */     //   1497: aload 8
/*      */     //   1499: aload 10
/*      */     //   1501: aload 5
/*      */     //   1503: aload 9
/*      */     //   1505: aload 10
/*      */     //   1507: iload 14
/*      */     //   1509: iload 15
/*      */     //   1511: iload 16
/*      */     //   1513: iload 17
/*      */     //   1515: iload 18
/*      */     //   1517: iload 19
/*      */     //   1519: iload 20
/*      */     //   1521: invokevirtual 49	com/mysql/jdbc/ResultSetImpl:fastTimestampCreate	(Ljava/util/Calendar;IIIIIII)Ljava/sql/Timestamp;
/*      */     //   1524: aload 8
/*      */     //   1526: invokeinterface 42 1 0
/*      */     //   1531: aload 6
/*      */     //   1533: iload 7
/*      */     //   1535: invokestatic 50	com/mysql/jdbc/TimeUtil:changeTimezone	(Lcom/mysql/jdbc/MySQLConnection;Ljava/util/Calendar;Ljava/util/Calendar;Ljava/sql/Timestamp;Ljava/util/TimeZone;Ljava/util/TimeZone;Z)Ljava/sql/Timestamp;
/*      */     //   1538: aload 11
/*      */     //   1540: monitorexit
/*      */     //   1541: areturn
/*      */     //   1542: astore 24
/*      */     //   1544: aload 11
/*      */     //   1546: monitorexit
/*      */     //   1547: aload 24
/*      */     //   1549: athrow
/*      */     //   1550: astore 10
/*      */     //   1552: new 7	java/lang/StringBuilder
/*      */     //   1555: dup
/*      */     //   1556: invokespecial 8	java/lang/StringBuilder:<init>	()V
/*      */     //   1559: ldc 89
/*      */     //   1561: invokevirtual 10	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   1564: aload_0
/*      */     //   1565: iload_1
/*      */     //   1566: ldc 25
/*      */     //   1568: aload 8
/*      */     //   1570: invokevirtual 90	com/mysql/jdbc/ResultSetRow:getString	(ILjava/lang/String;Lcom/mysql/jdbc/MySQLConnection;)Ljava/lang/String;
/*      */     //   1573: invokevirtual 10	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   1576: ldc 91
/*      */     //   1578: invokevirtual 10	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   1581: iload_1
/*      */     //   1582: iconst_1
/*      */     //   1583: iadd
/*      */     //   1584: invokevirtual 68	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*      */     //   1587: ldc 92
/*      */     //   1589: invokevirtual 10	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   1592: invokevirtual 13	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   1595: ldc 14
/*      */     //   1597: aload_0
/*      */     //   1598: getfield 2	com/mysql/jdbc/ResultSetRow:exceptionInterceptor	Lcom/mysql/jdbc/ExceptionInterceptor;
/*      */     //   1601: invokestatic 15	com/mysql/jdbc/SQLError:createSQLException	(Ljava/lang/String;Ljava/lang/String;Lcom/mysql/jdbc/ExceptionInterceptor;)Ljava/sql/SQLException;
/*      */     //   1604: astore 11
/*      */     //   1606: aload 11
/*      */     //   1608: aload 10
/*      */     //   1610: invokevirtual 33	java/sql/SQLException:initCause	(Ljava/lang/Throwable;)Ljava/lang/Throwable;
/*      */     //   1613: pop
/*      */     //   1614: aload 11
/*      */     //   1616: athrow
/*      */     // Line number table:
/*      */     //   Java source line #994	-> byte code offset #0
/*      */     //   Java source line #998	-> byte code offset #27
/*      */     //   Java source line #999	-> byte code offset #33
/*      */     //   Java source line #1001	-> byte code offset #36
/*      */     //   Java source line #1003	-> byte code offset #39
/*      */     //   Java source line #1004	-> byte code offset #49
/*      */     //   Java source line #1005	-> byte code offset #60
/*      */     //   Java source line #1006	-> byte code offset #63
/*      */     //   Java source line #1003	-> byte code offset #66
/*      */     //   Java source line #1010	-> byte code offset #72
/*      */     //   Java source line #1011	-> byte code offset #82
/*      */     //   Java source line #1013	-> byte code offset #90
/*      */     //   Java source line #1014	-> byte code offset #111
/*      */     //   Java source line #1017	-> byte code offset #114
/*      */     //   Java source line #1019	-> byte code offset #156
/*      */     //   Java source line #1021	-> byte code offset #159
/*      */     //   Java source line #1010	-> byte code offset #162
/*      */     //   Java source line #1025	-> byte code offset #168
/*      */     //   Java source line #1027	-> byte code offset #178
/*      */     //   Java source line #1030	-> byte code offset #193
/*      */     //   Java source line #1031	-> byte code offset #198
/*      */     //   Java source line #1033	-> byte code offset #213
/*      */     //   Java source line #1041	-> byte code offset #250
/*      */     //   Java source line #1042	-> byte code offset #258
/*      */     //   Java source line #1046	-> byte code offset #274
/*      */     //   Java source line #1048	-> byte code offset #291
/*      */     //   Java source line #1050	-> byte code offset #305
/*      */     //   Java source line #1051	-> byte code offset #313
/*      */     //   Java source line #1056	-> byte code offset #334
/*      */     //   Java source line #1063	-> byte code offset #377
/*      */     //   Java source line #1064	-> byte code offset #390
/*      */     //   Java source line #1069	-> byte code offset #393
/*      */     //   Java source line #1070	-> byte code offset #396
/*      */     //   Java source line #1071	-> byte code offset #399
/*      */     //   Java source line #1072	-> byte code offset #402
/*      */     //   Java source line #1073	-> byte code offset #405
/*      */     //   Java source line #1074	-> byte code offset #408
/*      */     //   Java source line #1075	-> byte code offset #411
/*      */     //   Java source line #1077	-> byte code offset #414
/*      */     //   Java source line #1087	-> byte code offset #544
/*      */     //   Java source line #1089	-> byte code offset #556
/*      */     //   Java source line #1091	-> byte code offset #569
/*      */     //   Java source line #1093	-> byte code offset #583
/*      */     //   Java source line #1095	-> byte code offset #597
/*      */     //   Java source line #1097	-> byte code offset #611
/*      */     //   Java source line #1100	-> byte code offset #625
/*      */     //   Java source line #1102	-> byte code offset #628
/*      */     //   Java source line #1103	-> byte code offset #635
/*      */     //   Java source line #1105	-> byte code offset #638
/*      */     //   Java source line #1106	-> byte code offset #648
/*      */     //   Java source line #1107	-> byte code offset #659
/*      */     //   Java source line #1105	-> byte code offset #663
/*      */     //   Java source line #1111	-> byte code offset #669
/*      */     //   Java source line #1112	-> byte code offset #675
/*      */     //   Java source line #1113	-> byte code offset #684
/*      */     //   Java source line #1117	-> byte code offset #700
/*      */     //   Java source line #1119	-> byte code offset #709
/*      */     //   Java source line #1120	-> byte code offset #716
/*      */     //   Java source line #1121	-> byte code offset #731
/*      */     //   Java source line #1123	-> byte code offset #738
/*      */     //   Java source line #1124	-> byte code offset #741
/*      */     //   Java source line #1132	-> byte code offset #749
/*      */     //   Java source line #1138	-> byte code offset #752
/*      */     //   Java source line #1140	-> byte code offset #764
/*      */     //   Java source line #1142	-> byte code offset #777
/*      */     //   Java source line #1144	-> byte code offset #791
/*      */     //   Java source line #1146	-> byte code offset #805
/*      */     //   Java source line #1148	-> byte code offset #819
/*      */     //   Java source line #1151	-> byte code offset #833
/*      */     //   Java source line #1155	-> byte code offset #836
/*      */     //   Java source line #1158	-> byte code offset #848
/*      */     //   Java source line #1159	-> byte code offset #855
/*      */     //   Java source line #1162	-> byte code offset #862
/*      */     //   Java source line #1164	-> byte code offset #868
/*      */     //   Java source line #1166	-> byte code offset #880
/*      */     //   Java source line #1168	-> byte code offset #893
/*      */     //   Java source line #1170	-> byte code offset #907
/*      */     //   Java source line #1172	-> byte code offset #921
/*      */     //   Java source line #1175	-> byte code offset #935
/*      */     //   Java source line #1179	-> byte code offset #938
/*      */     //   Java source line #1181	-> byte code offset #941
/*      */     //   Java source line #1182	-> byte code offset #951
/*      */     //   Java source line #1183	-> byte code offset #962
/*      */     //   Java source line #1184	-> byte code offset #965
/*      */     //   Java source line #1181	-> byte code offset #968
/*      */     //   Java source line #1188	-> byte code offset #974
/*      */     //   Java source line #1190	-> byte code offset #993
/*      */     //   Java source line #1192	-> byte code offset #1005
/*      */     //   Java source line #1194	-> byte code offset #1018
/*      */     //   Java source line #1196	-> byte code offset #1032
/*      */     //   Java source line #1197	-> byte code offset #1035
/*      */     //   Java source line #1199	-> byte code offset #1041
/*      */     //   Java source line #1202	-> byte code offset #1053
/*      */     //   Java source line #1203	-> byte code offset #1060
/*      */     //   Java source line #1206	-> byte code offset #1067
/*      */     //   Java source line #1208	-> byte code offset #1079
/*      */     //   Java source line #1210	-> byte code offset #1092
/*      */     //   Java source line #1212	-> byte code offset #1106
/*      */     //   Java source line #1215	-> byte code offset #1120
/*      */     //   Java source line #1218	-> byte code offset #1126
/*      */     //   Java source line #1222	-> byte code offset #1129
/*      */     //   Java source line #1224	-> byte code offset #1132
/*      */     //   Java source line #1225	-> byte code offset #1142
/*      */     //   Java source line #1226	-> byte code offset #1153
/*      */     //   Java source line #1227	-> byte code offset #1156
/*      */     //   Java source line #1224	-> byte code offset #1159
/*      */     //   Java source line #1231	-> byte code offset #1165
/*      */     //   Java source line #1232	-> byte code offset #1170
/*      */     //   Java source line #1234	-> byte code offset #1182
/*      */     //   Java source line #1236	-> byte code offset #1194
/*      */     //   Java source line #1239	-> byte code offset #1208
/*      */     //   Java source line #1240	-> byte code offset #1213
/*      */     //   Java source line #1241	-> byte code offset #1216
/*      */     //   Java source line #1243	-> byte code offset #1219
/*      */     //   Java source line #1246	-> byte code offset #1222
/*      */     //   Java source line #1248	-> byte code offset #1234
/*      */     //   Java source line #1250	-> byte code offset #1247
/*      */     //   Java source line #1253	-> byte code offset #1261
/*      */     //   Java source line #1254	-> byte code offset #1267
/*      */     //   Java source line #1256	-> byte code offset #1270
/*      */     //   Java source line #1260	-> byte code offset #1273
/*      */     //   Java source line #1263	-> byte code offset #1285
/*      */     //   Java source line #1264	-> byte code offset #1292
/*      */     //   Java source line #1267	-> byte code offset #1299
/*      */     //   Java source line #1269	-> byte code offset #1305
/*      */     //   Java source line #1271	-> byte code offset #1317
/*      */     //   Java source line #1274	-> byte code offset #1330
/*      */     //   Java source line #1278	-> byte code offset #1333
/*      */     //   Java source line #1281	-> byte code offset #1345
/*      */     //   Java source line #1282	-> byte code offset #1352
/*      */     //   Java source line #1285	-> byte code offset #1359
/*      */     //   Java source line #1288	-> byte code offset #1371
/*      */     //   Java source line #1290	-> byte code offset #1374
/*      */     //   Java source line #1294	-> byte code offset #1377
/*      */     //   Java source line #1297	-> byte code offset #1389
/*      */     //   Java source line #1298	-> byte code offset #1396
/*      */     //   Java source line #1301	-> byte code offset #1403
/*      */     //   Java source line #1302	-> byte code offset #1409
/*      */     //   Java source line #1303	-> byte code offset #1412
/*      */     //   Java source line #1305	-> byte code offset #1415
/*      */     //   Java source line #1309	-> byte code offset #1418
/*      */     //   Java source line #1317	-> byte code offset #1466
/*      */     //   Java source line #1318	-> byte code offset #1474
/*      */     //   Java source line #1324	-> byte code offset #1497
/*      */     //   Java source line #1333	-> byte code offset #1542
/*      */     //   Java source line #1334	-> byte code offset #1550
/*      */     //   Java source line #1335	-> byte code offset #1552
/*      */     //   Java source line #1339	-> byte code offset #1606
/*      */     //   Java source line #1341	-> byte code offset #1614
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	1617	0	this	ResultSetRow
/*      */     //   0	1617	1	columnIndex	int
/*      */     //   0	1617	2	timestampAsBytes	byte[]
/*      */     //   0	1617	3	offset	int
/*      */     //   0	1617	4	length	int
/*      */     //   0	1617	5	targetCalendar	Calendar
/*      */     //   0	1617	6	tz	TimeZone
/*      */     //   0	1617	7	rollForward	boolean
/*      */     //   0	1617	8	conn	MySQLConnection
/*      */     //   0	1617	9	rs	ResultSetImpl
/*      */     //   25	1481	10	sessionCalendar	Calendar
/*      */     //   1550	59	10	e	RuntimeException
/*      */     //   1604	11	11	sqlEx	SQLException
/*      */     //   34	140	12	allZeroTimestamp	boolean
/*      */     //   37	132	13	onlyTimePresent	boolean
/*      */     //   40	27	14	i	int
/*      */     //   73	90	14	i	int
/*      */     //   394	1114	14	year	int
/*      */     //   88	62	15	b	byte
/*      */     //   397	1113	15	month	int
/*      */     //   400	1112	16	day	int
/*      */     //   403	1111	17	hour	int
/*      */     //   406	1110	18	minutes	int
/*      */     //   409	1109	19	seconds	int
/*      */     //   412	1108	20	nanos	int
/*      */     //   636	67	21	decimalIndex	int
/*      */     //   939	50	21	hasDash	boolean
/*      */     //   1130	36	21	hasColon	boolean
/*      */     //   639	25	22	i	int
/*      */     //   707	15	22	numDigits	int
/*      */     //   942	27	22	i	int
/*      */     //   1133	27	22	i	int
/*      */     //   729	5	23	factor	int
/*      */     //   1542	6	24	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   33	197	1542	finally
/*      */     //   198	273	1542	finally
/*      */     //   274	290	1542	finally
/*      */     //   291	333	1542	finally
/*      */     //   334	376	1542	finally
/*      */     //   377	1496	1542	finally
/*      */     //   1497	1541	1542	finally
/*      */     //   1542	1547	1542	finally
/*      */     //   0	197	1550	java/lang/RuntimeException
/*      */     //   198	273	1550	java/lang/RuntimeException
/*      */     //   274	290	1550	java/lang/RuntimeException
/*      */     //   291	333	1550	java/lang/RuntimeException
/*      */     //   334	376	1550	java/lang/RuntimeException
/*      */     //   377	1496	1550	java/lang/RuntimeException
/*      */     //   1497	1541	1550	java/lang/RuntimeException
/*      */     //   1542	1550	1550	java/lang/RuntimeException
/*      */   }
/*      */   
/*      */   public abstract Timestamp getTimestampFast(int paramInt, Calendar paramCalendar, TimeZone paramTimeZone, boolean paramBoolean, MySQLConnection paramMySQLConnection, ResultSetImpl paramResultSetImpl)
/*      */     throws SQLException;
/*      */   
/*      */   public abstract boolean isFloatingPointNumber(int paramInt)
/*      */     throws SQLException;
/*      */   
/*      */   public abstract boolean isNull(int paramInt)
/*      */     throws SQLException;
/*      */   
/*      */   public abstract long length(int paramInt)
/*      */     throws SQLException;
/*      */   
/*      */   public abstract void setColumnValue(int paramInt, byte[] paramArrayOfByte)
/*      */     throws SQLException;
/*      */   
/*      */   public ResultSetRow setMetadata(Field[] f)
/*      */     throws SQLException
/*      */   {
/* 1409 */     this.metadata = f;
/*      */     
/* 1411 */     return this;
/*      */   }
/*      */   
/*      */   public abstract int getBytesSize();
/*      */ }


/* Location:              C:\Users\Static\Desktop\G10_Prototype_Server.jar!\mysql-connector-java-5.1.19-bin.jar!\com\mysql\jdbc\ResultSetRow.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */