/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SingleByteCharsetConverter
/*     */ {
/*     */   private static final int BYTE_RANGE = 256;
/*  45 */   private static byte[] allBytes = new byte['Ā'];
/*  46 */   private static final Map CONVERTER_MAP = new HashMap();
/*     */   
/*  48 */   private static final byte[] EMPTY_BYTE_ARRAY = new byte[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  53 */   private static byte[] unknownCharsMap = new byte[65536];
/*     */   
/*     */   static {
/*  56 */     for (int i = -128; i <= 127; i++) {
/*  57 */       allBytes[(i - -128)] = ((byte)i);
/*     */     }
/*     */     
/*  60 */     for (int i = 0; i < unknownCharsMap.length; i++) {
/*  61 */       unknownCharsMap[i] = 63;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized SingleByteCharsetConverter getInstance(String encodingName, Connection conn)
/*     */     throws UnsupportedEncodingException, SQLException
/*     */   {
/*  82 */     SingleByteCharsetConverter instance = (SingleByteCharsetConverter)CONVERTER_MAP.get(encodingName);
/*     */     
/*     */ 
/*  85 */     if (instance == null) {
/*  86 */       instance = initCharset(encodingName);
/*     */     }
/*     */     
/*  89 */     return instance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SingleByteCharsetConverter initCharset(String javaEncodingName)
/*     */     throws UnsupportedEncodingException, SQLException
/*     */   {
/*     */     try
/*     */     {
/* 105 */       if (CharsetMapping.isMultibyteCharset(javaEncodingName)) {
/* 106 */         return null;
/*     */       }
/*     */     } catch (RuntimeException ex) {
/* 109 */       SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", null);
/* 110 */       sqlEx.initCause(ex);
/* 111 */       throw sqlEx;
/*     */     }
/*     */     
/* 114 */     SingleByteCharsetConverter converter = new SingleByteCharsetConverter(javaEncodingName);
/*     */     
/*     */ 
/* 117 */     CONVERTER_MAP.put(javaEncodingName, converter);
/*     */     
/* 119 */     return converter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String toStringDefaultEncoding(byte[] buffer, int startPos, int length)
/*     */   {
/* 139 */     return new String(buffer, startPos, length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 145 */   private char[] byteToChars = new char['Ā'];
/*     */   
/* 147 */   private byte[] charToByteMap = new byte[65536];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private SingleByteCharsetConverter(String encodingName)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 159 */     String allBytesString = new String(allBytes, 0, 256, encodingName);
/*     */     
/* 161 */     int allBytesLen = allBytesString.length();
/*     */     
/* 163 */     System.arraycopy(unknownCharsMap, 0, this.charToByteMap, 0, this.charToByteMap.length);
/*     */     
/*     */ 
/* 166 */     for (int i = 0; (i < 256) && (i < allBytesLen); i++) {
/* 167 */       char c = allBytesString.charAt(i);
/* 168 */       this.byteToChars[i] = c;
/* 169 */       this.charToByteMap[c] = allBytes[i];
/*     */     }
/*     */   }
/*     */   
/*     */   public final byte[] toBytes(char[] c) {
/* 174 */     if (c == null) {
/* 175 */       return null;
/*     */     }
/*     */     
/* 178 */     int length = c.length;
/* 179 */     byte[] bytes = new byte[length];
/*     */     
/* 181 */     for (int i = 0; i < length; i++) {
/* 182 */       bytes[i] = this.charToByteMap[c[i]];
/*     */     }
/*     */     
/* 185 */     return bytes;
/*     */   }
/*     */   
/*     */   public final byte[] toBytesWrapped(char[] c, char beginWrap, char endWrap) {
/* 189 */     if (c == null) {
/* 190 */       return null;
/*     */     }
/*     */     
/* 193 */     int length = c.length + 2;
/* 194 */     int charLength = c.length;
/*     */     
/* 196 */     byte[] bytes = new byte[length];
/* 197 */     bytes[0] = this.charToByteMap[beginWrap];
/*     */     
/* 199 */     for (int i = 0; i < charLength; i++) {
/* 200 */       bytes[(i + 1)] = this.charToByteMap[c[i]];
/*     */     }
/*     */     
/* 203 */     bytes[(length - 1)] = this.charToByteMap[endWrap];
/*     */     
/* 205 */     return bytes;
/*     */   }
/*     */   
/*     */   public final byte[] toBytes(char[] chars, int offset, int length) {
/* 209 */     if (chars == null) {
/* 210 */       return null;
/*     */     }
/*     */     
/* 213 */     if (length == 0) {
/* 214 */       return EMPTY_BYTE_ARRAY;
/*     */     }
/*     */     
/* 217 */     byte[] bytes = new byte[length];
/*     */     
/* 219 */     for (int i = 0; i < length; i++) {
/* 220 */       bytes[i] = this.charToByteMap[chars[(i + offset)]];
/*     */     }
/*     */     
/* 223 */     return bytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final byte[] toBytes(String s)
/*     */   {
/* 234 */     if (s == null) {
/* 235 */       return null;
/*     */     }
/*     */     
/* 238 */     int length = s.length();
/* 239 */     byte[] bytes = new byte[length];
/*     */     
/* 241 */     for (int i = 0; i < length; i++) {
/* 242 */       bytes[i] = this.charToByteMap[s.charAt(i)];
/*     */     }
/*     */     
/* 245 */     return bytes;
/*     */   }
/*     */   
/*     */   public final byte[] toBytesWrapped(String s, char beginWrap, char endWrap) {
/* 249 */     if (s == null) {
/* 250 */       return null;
/*     */     }
/*     */     
/* 253 */     int stringLength = s.length();
/*     */     
/* 255 */     int length = stringLength + 2;
/*     */     
/* 257 */     byte[] bytes = new byte[length];
/*     */     
/* 259 */     bytes[0] = this.charToByteMap[beginWrap];
/*     */     
/* 261 */     for (int i = 0; i < stringLength; i++) {
/* 262 */       bytes[(i + 1)] = this.charToByteMap[s.charAt(i)];
/*     */     }
/*     */     
/* 265 */     bytes[(length - 1)] = this.charToByteMap[endWrap];
/*     */     
/* 267 */     return bytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final byte[] toBytes(String s, int offset, int length)
/*     */   {
/* 283 */     if (s == null) {
/* 284 */       return null;
/*     */     }
/*     */     
/* 287 */     if (length == 0) {
/* 288 */       return EMPTY_BYTE_ARRAY;
/*     */     }
/*     */     
/* 291 */     byte[] bytes = new byte[length];
/*     */     
/* 293 */     for (int i = 0; i < length; i++) {
/* 294 */       char c = s.charAt(i + offset);
/* 295 */       bytes[i] = this.charToByteMap[c];
/*     */     }
/*     */     
/* 298 */     return bytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String toString(byte[] buffer)
/*     */   {
/* 310 */     return toString(buffer, 0, buffer.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String toString(byte[] buffer, int startPos, int length)
/*     */   {
/* 326 */     char[] charArray = new char[length];
/* 327 */     int readpoint = startPos;
/*     */     
/* 329 */     for (int i = 0; i < length; i++) {
/* 330 */       charArray[i] = this.byteToChars[(buffer[readpoint] - Byte.MIN_VALUE)];
/* 331 */       readpoint++;
/*     */     }
/*     */     
/* 334 */     return new String(charArray);
/*     */   }
/*     */ }


/* Location:              C:\Users\Static\Desktop\G10_Prototype_Server.jar!\mysql-connector-java-5.1.19-bin.jar!\com\mysql\jdbc\SingleByteCharsetConverter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */