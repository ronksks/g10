/*    */ package com.mysql.jdbc;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DocsConnectionPropsHelper
/*    */   extends ConnectionPropertiesImpl
/*    */ {
/*    */   public static void main(String[] args)
/*    */     throws Exception
/*    */   {
/* 18 */     System.out.println(new DocsConnectionPropsHelper().exposeAsXml());
/*    */   }
/*    */ }


/* Location:              C:\Users\Static\Desktop\G10_Prototype_Server.jar!\mysql-connector-java-5.1.19-bin.jar!\com\mysql\jdbc\DocsConnectionPropsHelper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */