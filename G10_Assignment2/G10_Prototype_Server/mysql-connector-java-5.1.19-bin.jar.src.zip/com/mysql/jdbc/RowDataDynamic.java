/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*     */ import com.mysql.jdbc.profiler.ProfilerEventHandler;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RowDataDynamic
/*     */   implements RowData
/*     */ {
/*     */   private int columnCount;
/*     */   private Field[] metadata;
/*     */   
/*     */   class OperationNotSupportedException
/*     */     extends SQLException
/*     */   {
/*     */     OperationNotSupportedException()
/*     */     {
/*  43 */       super("S1009");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  52 */   private int index = -1;
/*     */   
/*     */   private MysqlIO io;
/*     */   
/*  56 */   private boolean isAfterEnd = false;
/*     */   
/*  58 */   private boolean noMoreRows = false;
/*     */   
/*  60 */   private boolean isBinaryEncoded = false;
/*     */   
/*     */   private ResultSetRow nextRow;
/*     */   
/*     */   private ResultSetImpl owner;
/*     */   
/*  66 */   private boolean streamerClosed = false;
/*     */   
/*  68 */   private boolean wasEmpty = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean useBufferRowExplicit;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean moreResultsExisted;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ExceptionInterceptor exceptionInterceptor;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RowDataDynamic(MysqlIO io, int colCount, Field[] fields, boolean isBinaryEncoded)
/*     */     throws SQLException
/*     */   {
/*  92 */     this.io = io;
/*  93 */     this.columnCount = colCount;
/*  94 */     this.isBinaryEncoded = isBinaryEncoded;
/*  95 */     this.metadata = fields;
/*  96 */     this.exceptionInterceptor = this.io.getExceptionInterceptor();
/*  97 */     this.useBufferRowExplicit = MysqlIO.useBufferRowExplicit(this.metadata);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addRow(ResultSetRow row)
/*     */     throws SQLException
/*     */   {
/* 109 */     notSupported();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void afterLast()
/*     */     throws SQLException
/*     */   {
/* 119 */     notSupported();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void beforeFirst()
/*     */     throws SQLException
/*     */   {
/* 129 */     notSupported();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void beforeLast()
/*     */     throws SQLException
/*     */   {
/* 139 */     notSupported();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws SQLException
/*     */   {
/* 154 */     Object mutex = this;
/*     */     
/* 156 */     MySQLConnection conn = null;
/*     */     
/* 158 */     if (this.owner != null) {
/* 159 */       conn = this.owner.connection;
/*     */       
/* 161 */       if (conn != null) {
/* 162 */         mutex = conn;
/*     */       }
/*     */     }
/*     */     
/* 166 */     boolean hadMore = false;
/* 167 */     int howMuchMore = 0;
/*     */     
/* 169 */     synchronized (mutex)
/*     */     {
/* 171 */       while (next() != null) {
/* 172 */         hadMore = true;
/* 173 */         howMuchMore++;
/*     */         
/* 175 */         if (howMuchMore % 100 == 0) {
/* 176 */           Thread.yield();
/*     */         }
/*     */       }
/*     */       
/* 180 */       if (conn != null) {
/* 181 */         if ((!conn.getClobberStreamingResults()) && (conn.getNetTimeoutForStreamingResults() > 0))
/*     */         {
/* 183 */           String oldValue = conn.getServerVariable("net_write_timeout");
/*     */           
/*     */ 
/* 186 */           if ((oldValue == null) || (oldValue.length() == 0)) {
/* 187 */             oldValue = "60";
/*     */           }
/*     */           
/* 190 */           this.io.clearInputStream();
/*     */           
/* 192 */           Statement stmt = null;
/*     */           try
/*     */           {
/* 195 */             stmt = conn.createStatement();
/* 196 */             ((StatementImpl)stmt).executeSimpleNonQuery(conn, "SET net_write_timeout=" + oldValue);
/*     */           } finally {
/* 198 */             if (stmt != null) {
/* 199 */               stmt.close();
/*     */             }
/*     */           }
/*     */         }
/*     */         
/* 204 */         if ((conn.getUseUsageAdvisor()) && 
/* 205 */           (hadMore))
/*     */         {
/* 207 */           ProfilerEventHandler eventSink = ProfilerEventHandlerFactory.getInstance(conn);
/*     */           
/*     */ 
/* 210 */           eventSink.consumeEvent(new ProfilerEvent((byte)0, "", this.owner.owningStatement == null ? "N/A" : this.owner.owningStatement.currentCatalog, this.owner.connectionId, this.owner.owningStatement == null ? -1 : this.owner.owningStatement.getId(), -1, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, null, Messages.getString("RowDataDynamic.2") + howMuchMore + Messages.getString("RowDataDynamic.3") + Messages.getString("RowDataDynamic.4") + Messages.getString("RowDataDynamic.5") + Messages.getString("RowDataDynamic.6") + this.owner.pointOfOrigin));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 241 */     this.metadata = null;
/* 242 */     this.owner = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResultSetRow getAt(int ind)
/*     */     throws SQLException
/*     */   {
/* 255 */     notSupported();
/*     */     
/* 257 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCurrentRowNumber()
/*     */     throws SQLException
/*     */   {
/* 268 */     notSupported();
/*     */     
/* 270 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ResultSetInternalMethods getOwner()
/*     */   {
/* 277 */     return this.owner;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasNext()
/*     */     throws SQLException
/*     */   {
/* 288 */     boolean hasNext = this.nextRow != null;
/*     */     
/* 290 */     if ((!hasNext) && (!this.streamerClosed)) {
/* 291 */       this.io.closeStreamer(this);
/* 292 */       this.streamerClosed = true;
/*     */     }
/*     */     
/* 295 */     return hasNext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAfterLast()
/*     */     throws SQLException
/*     */   {
/* 306 */     return this.isAfterEnd;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isBeforeFirst()
/*     */     throws SQLException
/*     */   {
/* 317 */     return this.index < 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDynamic()
/*     */   {
/* 329 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */     throws SQLException
/*     */   {
/* 340 */     notSupported();
/*     */     
/* 342 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFirst()
/*     */     throws SQLException
/*     */   {
/* 353 */     notSupported();
/*     */     
/* 355 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isLast()
/*     */     throws SQLException
/*     */   {
/* 366 */     notSupported();
/*     */     
/* 368 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void moveRowRelative(int rows)
/*     */     throws SQLException
/*     */   {
/* 380 */     notSupported();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResultSetRow next()
/*     */     throws SQLException
/*     */   {
/* 393 */     nextRecord();
/*     */     
/* 395 */     if ((this.nextRow == null) && (!this.streamerClosed) && (!this.moreResultsExisted)) {
/* 396 */       this.io.closeStreamer(this);
/* 397 */       this.streamerClosed = true;
/*     */     }
/*     */     
/* 400 */     if ((this.nextRow != null) && 
/* 401 */       (this.index != Integer.MAX_VALUE)) {
/* 402 */       this.index += 1;
/*     */     }
/*     */     
/*     */ 
/* 406 */     return this.nextRow;
/*     */   }
/*     */   
/*     */   private void nextRecord() throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 413 */       if (!this.noMoreRows) {
/* 414 */         this.nextRow = this.io.nextRow(this.metadata, this.columnCount, this.isBinaryEncoded, 1007, true, this.useBufferRowExplicit, true, null);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 419 */         if (this.nextRow == null) {
/* 420 */           this.noMoreRows = true;
/* 421 */           this.isAfterEnd = true;
/* 422 */           this.moreResultsExisted = this.io.tackOnMoreStreamingResults(this.owner);
/*     */           
/* 424 */           if (this.index == -1) {
/* 425 */             this.wasEmpty = true;
/*     */           }
/*     */         }
/*     */       } else {
/* 429 */         this.isAfterEnd = true;
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/* 432 */       if ((sqlEx instanceof StreamingNotifiable)) {
/* 433 */         ((StreamingNotifiable)sqlEx).setWasStreamingResults();
/*     */       }
/*     */       
/*     */ 
/* 437 */       throw sqlEx;
/*     */     } catch (Exception ex) {
/* 439 */       String exceptionType = ex.getClass().getName();
/* 440 */       String exceptionMessage = ex.getMessage();
/*     */       
/* 442 */       exceptionMessage = exceptionMessage + Messages.getString("RowDataDynamic.7");
/* 443 */       exceptionMessage = exceptionMessage + Util.stackTraceToString(ex);
/*     */       
/* 445 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("RowDataDynamic.8") + exceptionType + Messages.getString("RowDataDynamic.9") + exceptionMessage, "S1000", this.exceptionInterceptor);
/*     */       
/*     */ 
/*     */ 
/* 449 */       sqlEx.initCause(ex);
/*     */       
/* 451 */       throw sqlEx;
/*     */     }
/*     */   }
/*     */   
/*     */   private void notSupported() throws SQLException {
/* 456 */     throw new OperationNotSupportedException();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeRow(int ind)
/*     */     throws SQLException
/*     */   {
/* 468 */     notSupported();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCurrentRow(int rowNumber)
/*     */     throws SQLException
/*     */   {
/* 480 */     notSupported();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setOwner(ResultSetImpl rs)
/*     */   {
/* 487 */     this.owner = rs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int size()
/*     */   {
/* 496 */     return -1;
/*     */   }
/*     */   
/*     */   public boolean wasEmpty() {
/* 500 */     return this.wasEmpty;
/*     */   }
/*     */   
/*     */   public void setMetadata(Field[] metadata) {
/* 504 */     this.metadata = metadata;
/*     */   }
/*     */ }


/* Location:              C:\Users\Static\Desktop\G10_Prototype_Server.jar!\mysql-connector-java-5.1.19-bin.jar!\com\mysql\jdbc\RowDataDynamic.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */