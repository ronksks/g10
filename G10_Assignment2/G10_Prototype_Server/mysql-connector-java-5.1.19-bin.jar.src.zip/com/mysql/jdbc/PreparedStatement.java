/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.exceptions.MySQLStatementCancelledException;
/*      */ import com.mysql.jdbc.exceptions.MySQLTimeoutException;
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import com.mysql.jdbc.profiler.ProfilerEventHandler;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.StringReader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.net.URL;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.CharBuffer;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.CharsetEncoder;
/*      */ import java.sql.Array;
/*      */ import java.sql.BatchUpdateException;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.ParameterMetaData;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.DateFormat;
/*      */ import java.text.ParsePosition;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.TimeZone;
/*      */ import java.util.Timer;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PreparedStatement
/*      */   extends StatementImpl
/*      */   implements java.sql.PreparedStatement
/*      */ {
/*      */   private static final Constructor JDBC_4_PSTMT_2_ARG_CTOR;
/*      */   private static final Constructor JDBC_4_PSTMT_3_ARG_CTOR;
/*      */   private static final Constructor JDBC_4_PSTMT_4_ARG_CTOR;
/*      */   
/*      */   static
/*      */   {
/*   96 */     if (Util.isJdbc4()) {
/*      */       try {
/*   98 */         JDBC_4_PSTMT_2_ARG_CTOR = Class.forName("com.mysql.jdbc.JDBC4PreparedStatement").getConstructor(new Class[] { MySQLConnection.class, String.class });
/*      */         
/*      */ 
/*      */ 
/*  102 */         JDBC_4_PSTMT_3_ARG_CTOR = Class.forName("com.mysql.jdbc.JDBC4PreparedStatement").getConstructor(new Class[] { MySQLConnection.class, String.class, String.class });
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  107 */         JDBC_4_PSTMT_4_ARG_CTOR = Class.forName("com.mysql.jdbc.JDBC4PreparedStatement").getConstructor(new Class[] { MySQLConnection.class, String.class, String.class, ParseInfo.class });
/*      */ 
/*      */       }
/*      */       catch (SecurityException e)
/*      */       {
/*      */ 
/*  113 */         throw new RuntimeException(e);
/*      */       } catch (NoSuchMethodException e) {
/*  115 */         throw new RuntimeException(e);
/*      */       } catch (ClassNotFoundException e) {
/*  117 */         throw new RuntimeException(e);
/*      */       }
/*      */     } else {
/*  120 */       JDBC_4_PSTMT_2_ARG_CTOR = null;
/*  121 */       JDBC_4_PSTMT_3_ARG_CTOR = null;
/*  122 */       JDBC_4_PSTMT_4_ARG_CTOR = null;
/*      */     }
/*      */   }
/*      */   
/*      */   public class BatchParams {
/*  127 */     public boolean[] isNull = null;
/*      */     
/*  129 */     public boolean[] isStream = null;
/*      */     
/*  131 */     public InputStream[] parameterStreams = null;
/*      */     
/*  133 */     public byte[][] parameterStrings = (byte[][])null;
/*      */     
/*  135 */     public int[] streamLengths = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     BatchParams(byte[][] strings, InputStream[] streams, boolean[] isStreamFlags, int[] lengths, boolean[] isNullFlags)
/*      */     {
/*  142 */       this.parameterStrings = new byte[strings.length][];
/*  143 */       this.parameterStreams = new InputStream[streams.length];
/*  144 */       this.isStream = new boolean[isStreamFlags.length];
/*  145 */       this.streamLengths = new int[lengths.length];
/*  146 */       this.isNull = new boolean[isNullFlags.length];
/*  147 */       System.arraycopy(strings, 0, this.parameterStrings, 0, strings.length);
/*      */       
/*  149 */       System.arraycopy(streams, 0, this.parameterStreams, 0, streams.length);
/*      */       
/*  151 */       System.arraycopy(isStreamFlags, 0, this.isStream, 0, isStreamFlags.length);
/*      */       
/*  153 */       System.arraycopy(lengths, 0, this.streamLengths, 0, lengths.length);
/*  154 */       System.arraycopy(isNullFlags, 0, this.isNull, 0, isNullFlags.length);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   class EndPoint
/*      */   {
/*      */     int begin;
/*      */     int end;
/*      */     
/*      */     EndPoint(int b, int e)
/*      */     {
/*  166 */       this.begin = b;
/*  167 */       this.end = e;
/*      */     }
/*      */   }
/*      */   
/*      */   class ParseInfo {
/*  172 */     char firstStmtChar = '\000';
/*      */     
/*  174 */     boolean foundLimitClause = false;
/*      */     
/*  176 */     boolean foundLoadData = false;
/*      */     
/*  178 */     long lastUsed = 0L;
/*      */     
/*  180 */     int statementLength = 0;
/*      */     
/*  182 */     int statementStartPos = 0;
/*      */     
/*  184 */     boolean canRewriteAsMultiValueInsert = false;
/*      */     
/*  186 */     byte[][] staticSql = (byte[][])null;
/*      */     
/*  188 */     boolean isOnDuplicateKeyUpdate = false;
/*      */     
/*  190 */     int locationOfOnDuplicateKeyUpdate = -1;
/*      */     
/*      */     String valuesClause;
/*      */     
/*  194 */     boolean parametersInDuplicateKeyClause = false;
/*      */     
/*      */     private ParseInfo batchHead;
/*      */     
/*      */     private ParseInfo batchValues;
/*      */     
/*      */     private ParseInfo batchODKUClause;
/*      */     
/*      */     ParseInfo(String sql, MySQLConnection conn, DatabaseMetaData dbmd, String encoding, SingleByteCharsetConverter converter)
/*      */       throws SQLException
/*      */     {
/*  205 */       this(sql, conn, dbmd, encoding, converter, true);
/*      */     }
/*      */     
/*      */     public ParseInfo(String sql, MySQLConnection conn, DatabaseMetaData dbmd, String encoding, SingleByteCharsetConverter converter, boolean buildRewriteInfo) throws SQLException
/*      */     {
/*      */       try
/*      */       {
/*  212 */         if (sql == null) {
/*  213 */           throw SQLError.createSQLException(Messages.getString("PreparedStatement.61"), "S1009", PreparedStatement.this.getExceptionInterceptor());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  218 */         this.locationOfOnDuplicateKeyUpdate = PreparedStatement.this.getOnDuplicateKeyLocation(sql);
/*  219 */         this.isOnDuplicateKeyUpdate = (this.locationOfOnDuplicateKeyUpdate != -1);
/*      */         
/*  221 */         this.lastUsed = System.currentTimeMillis();
/*      */         
/*  223 */         quotedIdentifierString = dbmd.getIdentifierQuoteString();
/*      */         
/*  225 */         char quotedIdentifierChar = '\000';
/*      */         
/*  227 */         if ((quotedIdentifierString != null) && (!quotedIdentifierString.equals(" ")) && (quotedIdentifierString.length() > 0))
/*      */         {
/*      */ 
/*  230 */           quotedIdentifierChar = quotedIdentifierString.charAt(0);
/*      */         }
/*      */         
/*  233 */         this.statementLength = sql.length();
/*      */         
/*  235 */         ArrayList endpointList = new ArrayList();
/*  236 */         boolean inQuotes = false;
/*  237 */         char quoteChar = '\000';
/*  238 */         boolean inQuotedId = false;
/*  239 */         int lastParmEnd = 0;
/*      */         
/*      */ 
/*  242 */         int stopLookingForLimitClause = this.statementLength - 5;
/*      */         
/*  244 */         this.foundLimitClause = false;
/*      */         
/*  246 */         boolean noBackslashEscapes = PreparedStatement.this.connection.isNoBackslashEscapesSet();
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  252 */         this.statementStartPos = PreparedStatement.this.findStartOfStatement(sql);
/*      */         
/*  254 */         for (int i = this.statementStartPos; i < this.statementLength; i++) {
/*  255 */           char c = sql.charAt(i);
/*      */           
/*  257 */           if ((this.firstStmtChar == 0) && (Character.isLetter(c)))
/*      */           {
/*      */ 
/*  260 */             this.firstStmtChar = Character.toUpperCase(c);
/*      */           }
/*      */           
/*  263 */           if ((!noBackslashEscapes) && (c == '\\') && (i < this.statementLength - 1))
/*      */           {
/*  265 */             i++;
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/*  271 */             if ((!inQuotes) && (quotedIdentifierChar != 0) && (c == quotedIdentifierChar))
/*      */             {
/*  273 */               inQuotedId = !inQuotedId;
/*  274 */             } else if (!inQuotedId)
/*      */             {
/*      */ 
/*  277 */               if (inQuotes) {
/*  278 */                 if (((c == '\'') || (c == '"')) && (c == quoteChar)) {
/*  279 */                   if ((i < this.statementLength - 1) && (sql.charAt(i + 1) == quoteChar)) {
/*  280 */                     i++;
/*  281 */                     continue;
/*      */                   }
/*      */                   
/*  284 */                   inQuotes = !inQuotes;
/*  285 */                   quoteChar = '\000';
/*  286 */                 } else if (((c == '\'') || (c == '"')) && (c == quoteChar)) {
/*  287 */                   inQuotes = !inQuotes;
/*  288 */                   quoteChar = '\000';
/*      */                 }
/*      */               } else {
/*  291 */                 if ((c == '#') || ((c == '-') && (i + 1 < this.statementLength) && (sql.charAt(i + 1) == '-')))
/*      */                 {
/*      */ 
/*      */ 
/*      */ 
/*  296 */                   int endOfStmt = this.statementLength - 1;
/*  298 */                   for (; 
/*  298 */                       i < endOfStmt; i++) {
/*  299 */                     c = sql.charAt(i);
/*      */                     
/*  301 */                     if ((c == '\r') || (c == '\n')) {
/*      */                       break;
/*      */                     }
/*      */                   }
/*      */                 }
/*      */                 
/*  307 */                 if ((c == '/') && (i + 1 < this.statementLength))
/*      */                 {
/*  309 */                   char cNext = sql.charAt(i + 1);
/*      */                   
/*  311 */                   if (cNext == '*') {
/*  312 */                     i += 2;
/*      */                     
/*  314 */                     for (int j = i; j < this.statementLength; j++) {
/*  315 */                       i++;
/*  316 */                       cNext = sql.charAt(j);
/*      */                       
/*  318 */                       if ((cNext == '*') && (j + 1 < this.statementLength) && 
/*  319 */                         (sql.charAt(j + 1) == '/')) {
/*  320 */                         i++;
/*      */                         
/*  322 */                         if (i >= this.statementLength) break;
/*  323 */                         c = sql.charAt(i); break;
/*      */                       }
/*      */                       
/*      */                     }
/*      */                     
/*      */                   }
/*      */                   
/*      */                 }
/*  331 */                 else if ((c == '\'') || (c == '"')) {
/*  332 */                   inQuotes = true;
/*  333 */                   quoteChar = c;
/*      */                 }
/*      */               }
/*      */             }
/*      */             
/*  338 */             if ((c == '?') && (!inQuotes) && (!inQuotedId)) {
/*  339 */               endpointList.add(new int[] { lastParmEnd, i });
/*  340 */               lastParmEnd = i + 1;
/*      */               
/*  342 */               if ((this.isOnDuplicateKeyUpdate) && (i > this.locationOfOnDuplicateKeyUpdate)) {
/*  343 */                 this.parametersInDuplicateKeyClause = true;
/*      */               }
/*      */             }
/*      */             
/*  347 */             if ((!inQuotes) && (i < stopLookingForLimitClause) && (
/*  348 */               (c == 'L') || (c == 'l'))) {
/*  349 */               char posI1 = sql.charAt(i + 1);
/*      */               
/*  351 */               if ((posI1 == 'I') || (posI1 == 'i')) {
/*  352 */                 char posM = sql.charAt(i + 2);
/*      */                 
/*  354 */                 if ((posM == 'M') || (posM == 'm')) {
/*  355 */                   char posI2 = sql.charAt(i + 3);
/*      */                   
/*  357 */                   if ((posI2 == 'I') || (posI2 == 'i')) {
/*  358 */                     char posT = sql.charAt(i + 4);
/*      */                     
/*  360 */                     if ((posT == 'T') || (posT == 't')) {
/*  361 */                       this.foundLimitClause = true;
/*      */                     }
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*  370 */         if (this.firstStmtChar == 'L') {
/*  371 */           if (StringUtils.startsWithIgnoreCaseAndWs(sql, "LOAD DATA")) {
/*  372 */             this.foundLoadData = true;
/*      */           } else {
/*  374 */             this.foundLoadData = false;
/*      */           }
/*      */         } else {
/*  377 */           this.foundLoadData = false;
/*      */         }
/*      */         
/*  380 */         endpointList.add(new int[] { lastParmEnd, this.statementLength });
/*  381 */         this.staticSql = new byte[endpointList.size()][];
/*  382 */         char[] asCharArray = sql.toCharArray();
/*      */         
/*  384 */         for (i = 0; i < this.staticSql.length; i++) {
/*  385 */           int[] ep = (int[])endpointList.get(i);
/*  386 */           int end = ep[1];
/*  387 */           int begin = ep[0];
/*  388 */           int len = end - begin;
/*      */           
/*  390 */           if (this.foundLoadData) {
/*  391 */             String temp = new String(asCharArray, begin, len);
/*  392 */             this.staticSql[i] = StringUtils.getBytes(temp);
/*  393 */           } else if (encoding == null) {
/*  394 */             byte[] buf = new byte[len];
/*      */             
/*  396 */             for (int j = 0; j < len; j++) {
/*  397 */               buf[j] = ((byte)sql.charAt(begin + j));
/*      */             }
/*      */             
/*  400 */             this.staticSql[i] = buf;
/*      */           }
/*  402 */           else if (converter != null) {
/*  403 */             this.staticSql[i] = StringUtils.getBytes(sql, converter, encoding, PreparedStatement.this.connection.getServerCharacterEncoding(), begin, len, PreparedStatement.this.connection.parserKnowsUnicode(), PreparedStatement.this.getExceptionInterceptor());
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*  408 */             String temp = new String(asCharArray, begin, len);
/*      */             
/*  410 */             this.staticSql[i] = StringUtils.getBytes(temp, encoding, PreparedStatement.this.connection.getServerCharacterEncoding(), PreparedStatement.this.connection.parserKnowsUnicode(), conn, PreparedStatement.this.getExceptionInterceptor());
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (StringIndexOutOfBoundsException oobEx)
/*      */       {
/*      */         String quotedIdentifierString;
/*      */         
/*  418 */         SQLException sqlEx = new SQLException("Parse error for " + sql);
/*  419 */         sqlEx.initCause(oobEx);
/*      */         
/*  421 */         throw sqlEx;
/*      */       }
/*      */       
/*      */ 
/*  425 */       if (buildRewriteInfo) {
/*  426 */         this.canRewriteAsMultiValueInsert = ((PreparedStatement.canRewrite(sql, this.isOnDuplicateKeyUpdate, this.locationOfOnDuplicateKeyUpdate, this.statementStartPos)) && (!this.parametersInDuplicateKeyClause));
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  431 */         if ((this.canRewriteAsMultiValueInsert) && (conn.getRewriteBatchedStatements()))
/*      */         {
/*  433 */           buildRewriteBatchedParams(sql, conn, dbmd, encoding, converter);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private void buildRewriteBatchedParams(String sql, MySQLConnection conn, DatabaseMetaData metadata, String encoding, SingleByteCharsetConverter converter)
/*      */       throws SQLException
/*      */     {
/*  448 */       this.valuesClause = extractValuesClause(sql);
/*  449 */       String odkuClause = this.isOnDuplicateKeyUpdate ? sql.substring(this.locationOfOnDuplicateKeyUpdate) : null;
/*      */       
/*      */ 
/*  452 */       String headSql = null;
/*      */       
/*  454 */       if (this.isOnDuplicateKeyUpdate) {
/*  455 */         headSql = sql.substring(0, this.locationOfOnDuplicateKeyUpdate);
/*      */       } else {
/*  457 */         headSql = sql;
/*      */       }
/*      */       
/*  460 */       this.batchHead = new ParseInfo(PreparedStatement.this, headSql, conn, metadata, encoding, converter, false);
/*      */       
/*  462 */       this.batchValues = new ParseInfo(PreparedStatement.this, "," + this.valuesClause, conn, metadata, encoding, converter, false);
/*      */       
/*  464 */       this.batchODKUClause = null;
/*      */       
/*  466 */       if ((odkuClause != null) && (odkuClause.length() > 0)) {
/*  467 */         this.batchODKUClause = new ParseInfo(PreparedStatement.this, "," + this.valuesClause + " " + odkuClause, conn, metadata, encoding, converter, false);
/*      */       }
/*      */     }
/*      */     
/*      */     private String extractValuesClause(String sql)
/*      */       throws SQLException
/*      */     {
/*  474 */       String quoteCharStr = PreparedStatement.this.connection.getMetaData().getIdentifierQuoteString();
/*      */       
/*      */ 
/*  477 */       int indexOfValues = -1;
/*  478 */       int valuesSearchStart = this.statementStartPos;
/*      */       
/*  480 */       while (indexOfValues == -1) {
/*  481 */         if (quoteCharStr.length() > 0) {
/*  482 */           indexOfValues = StringUtils.indexOfIgnoreCaseRespectQuotes(valuesSearchStart, PreparedStatement.this.originalSql, "VALUES", quoteCharStr.charAt(0), false);
/*      */         }
/*      */         else
/*      */         {
/*  486 */           indexOfValues = StringUtils.indexOfIgnoreCase(valuesSearchStart, PreparedStatement.this.originalSql, "VALUES");
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  491 */         if (indexOfValues <= 0)
/*      */           break;
/*  493 */         char c = PreparedStatement.this.originalSql.charAt(indexOfValues - 1);
/*  494 */         if ((!Character.isWhitespace(c)) && (c != ')') && (c != '`')) {
/*  495 */           valuesSearchStart = indexOfValues + 6;
/*  496 */           indexOfValues = -1;
/*      */         }
/*      */         else {
/*  499 */           c = PreparedStatement.this.originalSql.charAt(indexOfValues + 6);
/*  500 */           if ((!Character.isWhitespace(c)) && (c != '(')) {
/*  501 */             valuesSearchStart = indexOfValues + 6;
/*  502 */             indexOfValues = -1;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  510 */       if (indexOfValues == -1) {
/*  511 */         return null;
/*      */       }
/*      */       
/*  514 */       int indexOfFirstParen = sql.indexOf('(', indexOfValues + 6);
/*      */       
/*  516 */       if (indexOfFirstParen == -1) {
/*  517 */         return null;
/*      */       }
/*      */       
/*  520 */       int endOfValuesClause = sql.lastIndexOf(')');
/*      */       
/*  522 */       if (endOfValuesClause == -1) {
/*  523 */         return null;
/*      */       }
/*      */       
/*  526 */       if (this.isOnDuplicateKeyUpdate) {
/*  527 */         endOfValuesClause = this.locationOfOnDuplicateKeyUpdate - 1;
/*      */       }
/*      */       
/*  530 */       return sql.substring(indexOfFirstParen, endOfValuesClause + 1);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     synchronized ParseInfo getParseInfoForBatch(int numBatch)
/*      */     {
/*  537 */       PreparedStatement.AppendingBatchVisitor apv = new PreparedStatement.AppendingBatchVisitor(PreparedStatement.this);
/*  538 */       buildInfoForBatch(numBatch, apv);
/*      */       
/*  540 */       ParseInfo batchParseInfo = new ParseInfo(PreparedStatement.this, apv.getStaticSqlStrings(), this.firstStmtChar, this.foundLimitClause, this.foundLoadData, this.isOnDuplicateKeyUpdate, this.locationOfOnDuplicateKeyUpdate, this.statementLength, this.statementStartPos);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  546 */       return batchParseInfo;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     String getSqlForBatch(int numBatch)
/*      */       throws UnsupportedEncodingException
/*      */     {
/*  555 */       ParseInfo batchInfo = getParseInfoForBatch(numBatch);
/*      */       
/*  557 */       return getSqlForBatch(batchInfo);
/*      */     }
/*      */     
/*      */ 
/*      */     String getSqlForBatch(ParseInfo batchInfo)
/*      */       throws UnsupportedEncodingException
/*      */     {
/*  564 */       int size = 0;
/*  565 */       byte[][] sqlStrings = batchInfo.staticSql;
/*  566 */       int sqlStringsLength = sqlStrings.length;
/*      */       
/*  568 */       for (int i = 0; i < sqlStringsLength; i++) {
/*  569 */         size += sqlStrings[i].length;
/*  570 */         size++;
/*      */       }
/*      */       
/*  573 */       StringBuffer buf = new StringBuffer(size);
/*      */       
/*  575 */       for (int i = 0; i < sqlStringsLength - 1; i++) {
/*  576 */         buf.append(StringUtils.toString(sqlStrings[i], PreparedStatement.this.charEncoding));
/*  577 */         buf.append("?");
/*      */       }
/*      */       
/*  580 */       buf.append(StringUtils.toString(sqlStrings[(sqlStringsLength - 1)]));
/*      */       
/*  582 */       return buf.toString();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private void buildInfoForBatch(int numBatch, PreparedStatement.BatchVisitor visitor)
/*      */     {
/*  594 */       byte[][] headStaticSql = this.batchHead.staticSql;
/*  595 */       int headStaticSqlLength = headStaticSql.length;
/*      */       
/*  597 */       if (headStaticSqlLength > 1) {
/*  598 */         for (int i = 0; i < headStaticSqlLength - 1; i++) {
/*  599 */           visitor.append(headStaticSql[i]).increment();
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  604 */       byte[] endOfHead = headStaticSql[(headStaticSqlLength - 1)];
/*  605 */       byte[][] valuesStaticSql = this.batchValues.staticSql;
/*  606 */       byte[] beginOfValues = valuesStaticSql[0];
/*      */       
/*  608 */       visitor.merge(endOfHead, beginOfValues).increment();
/*      */       
/*  610 */       int numValueRepeats = numBatch - 1;
/*      */       
/*  612 */       if (this.batchODKUClause != null) {
/*  613 */         numValueRepeats--;
/*      */       }
/*      */       
/*  616 */       int valuesStaticSqlLength = valuesStaticSql.length;
/*  617 */       byte[] endOfValues = valuesStaticSql[(valuesStaticSqlLength - 1)];
/*      */       
/*  619 */       for (int i = 0; i < numValueRepeats; i++) {
/*  620 */         for (int j = 1; j < valuesStaticSqlLength - 1; j++) {
/*  621 */           visitor.append(valuesStaticSql[j]).increment();
/*      */         }
/*  623 */         visitor.merge(endOfValues, beginOfValues).increment();
/*      */       }
/*      */       
/*  626 */       if (this.batchODKUClause != null) {
/*  627 */         byte[][] batchOdkuStaticSql = this.batchODKUClause.staticSql;
/*  628 */         byte[] beginOfOdku = batchOdkuStaticSql[0];
/*  629 */         visitor.decrement().merge(endOfValues, beginOfOdku).increment();
/*      */         
/*  631 */         int batchOdkuStaticSqlLength = batchOdkuStaticSql.length;
/*      */         
/*  633 */         if (numBatch > 1) {
/*  634 */           for (int i = 1; i < batchOdkuStaticSqlLength; i++) {
/*  635 */             visitor.append(batchOdkuStaticSql[i]).increment();
/*      */           }
/*      */           
/*      */         } else {
/*  639 */           visitor.decrement().append(batchOdkuStaticSql[(batchOdkuStaticSqlLength - 1)]);
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  644 */         visitor.decrement().append(this.staticSql[(this.staticSql.length - 1)]);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private ParseInfo(byte[][] staticSql, char firstStmtChar, boolean foundLimitClause, boolean foundLoadData, boolean isOnDuplicateKeyUpdate, int locationOfOnDuplicateKeyUpdate, int statementLength, int statementStartPos)
/*      */     {
/*  653 */       this.firstStmtChar = firstStmtChar;
/*  654 */       this.foundLimitClause = foundLimitClause;
/*  655 */       this.foundLoadData = foundLoadData;
/*  656 */       this.isOnDuplicateKeyUpdate = isOnDuplicateKeyUpdate;
/*  657 */       this.locationOfOnDuplicateKeyUpdate = locationOfOnDuplicateKeyUpdate;
/*  658 */       this.statementLength = statementLength;
/*  659 */       this.statementStartPos = statementStartPos;
/*  660 */       this.staticSql = staticSql;
/*      */     }
/*      */   }
/*      */   
/*      */   static abstract interface BatchVisitor { public abstract BatchVisitor increment();
/*      */     
/*      */     public abstract BatchVisitor decrement();
/*      */     
/*      */     public abstract BatchVisitor append(byte[] paramArrayOfByte);
/*      */     
/*      */     public abstract BatchVisitor merge(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
/*      */   }
/*      */   
/*      */   class AppendingBatchVisitor implements PreparedStatement.BatchVisitor { AppendingBatchVisitor() {}
/*      */     
/*  675 */     LinkedList statementComponents = new LinkedList();
/*      */     
/*      */     public PreparedStatement.BatchVisitor append(byte[] values) {
/*  678 */       this.statementComponents.addLast(values);
/*      */       
/*  680 */       return this;
/*      */     }
/*      */     
/*      */     public PreparedStatement.BatchVisitor increment()
/*      */     {
/*  685 */       return this;
/*      */     }
/*      */     
/*      */     public PreparedStatement.BatchVisitor decrement() {
/*  689 */       this.statementComponents.removeLast();
/*      */       
/*  691 */       return this;
/*      */     }
/*      */     
/*      */     public PreparedStatement.BatchVisitor merge(byte[] front, byte[] back) {
/*  695 */       int mergedLength = front.length + back.length;
/*  696 */       byte[] merged = new byte[mergedLength];
/*  697 */       System.arraycopy(front, 0, merged, 0, front.length);
/*  698 */       System.arraycopy(back, 0, merged, front.length, back.length);
/*  699 */       this.statementComponents.addLast(merged);
/*  700 */       return this;
/*      */     }
/*      */     
/*      */     public byte[][] getStaticSqlStrings() {
/*  704 */       byte[][] asBytes = new byte[this.statementComponents.size()][];
/*  705 */       this.statementComponents.toArray(asBytes);
/*      */       
/*  707 */       return asBytes;
/*      */     }
/*      */     
/*      */     public String toString() {
/*  711 */       StringBuffer buf = new StringBuffer();
/*  712 */       Iterator iter = this.statementComponents.iterator();
/*  713 */       while (iter.hasNext()) {
/*  714 */         buf.append(StringUtils.toString((byte[])iter.next()));
/*      */       }
/*      */       
/*  717 */       return buf.toString();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*  722 */   private static final byte[] HEX_DIGITS = { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static int readFully(Reader reader, char[] buf, int length)
/*      */     throws IOException
/*      */   {
/*  745 */     int numCharsRead = 0;
/*      */     
/*  747 */     while (numCharsRead < length) {
/*  748 */       int count = reader.read(buf, numCharsRead, length - numCharsRead);
/*      */       
/*  750 */       if (count < 0) {
/*      */         break;
/*      */       }
/*      */       
/*  754 */       numCharsRead += count;
/*      */     }
/*      */     
/*  757 */     return numCharsRead;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  766 */   protected boolean batchHasPlainStatements = false;
/*      */   
/*  768 */   private DatabaseMetaData dbmd = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  774 */   protected char firstCharOfStmt = '\000';
/*      */   
/*      */ 
/*  777 */   protected boolean hasLimitClause = false;
/*      */   
/*      */ 
/*  780 */   protected boolean isLoadDataQuery = false;
/*      */   
/*  782 */   private boolean[] isNull = null;
/*      */   
/*  784 */   private boolean[] isStream = null;
/*      */   
/*  786 */   protected int numberOfExecutions = 0;
/*      */   
/*      */ 
/*  789 */   protected String originalSql = null;
/*      */   
/*      */ 
/*      */   protected int parameterCount;
/*      */   
/*      */   protected MysqlParameterMetadata parameterMetaData;
/*      */   
/*  796 */   private InputStream[] parameterStreams = null;
/*      */   
/*  798 */   private byte[][] parameterValues = (byte[][])null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  804 */   protected int[] parameterTypes = null;
/*      */   
/*      */   protected ParseInfo parseInfo;
/*      */   
/*      */   private java.sql.ResultSetMetaData pstmtResultMetaData;
/*      */   
/*  810 */   private byte[][] staticSqlStrings = (byte[][])null;
/*      */   
/*  812 */   private byte[] streamConvertBuf = null;
/*      */   
/*  814 */   private int[] streamLengths = null;
/*      */   
/*  816 */   private SimpleDateFormat tsdf = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  821 */   protected boolean useTrueBoolean = false;
/*      */   
/*      */   protected boolean usingAnsiMode;
/*      */   
/*      */   protected String batchedValuesClause;
/*      */   
/*      */   private boolean doPingInstead;
/*      */   
/*      */   private SimpleDateFormat ddf;
/*      */   private SimpleDateFormat tdf;
/*  831 */   private boolean compensateForOnDuplicateKeyUpdate = false;
/*      */   
/*      */ 
/*      */   private CharsetEncoder charsetEncoder;
/*      */   
/*      */ 
/*  837 */   private int batchCommandIndex = -1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean serverSupportsFracSecs;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static PreparedStatement getInstance(MySQLConnection conn, String catalog)
/*      */     throws SQLException
/*      */   {
/*  850 */     if (!Util.isJdbc4()) {
/*  851 */       return new PreparedStatement(conn, catalog);
/*      */     }
/*      */     
/*  854 */     return (PreparedStatement)Util.handleNewInstance(JDBC_4_PSTMT_2_ARG_CTOR, new Object[] { conn, catalog }, conn.getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static PreparedStatement getInstance(MySQLConnection conn, String sql, String catalog)
/*      */     throws SQLException
/*      */   {
/*  867 */     if (!Util.isJdbc4()) {
/*  868 */       return new PreparedStatement(conn, sql, catalog);
/*      */     }
/*      */     
/*  871 */     return (PreparedStatement)Util.handleNewInstance(JDBC_4_PSTMT_3_ARG_CTOR, new Object[] { conn, sql, catalog }, conn.getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static PreparedStatement getInstance(MySQLConnection conn, String sql, String catalog, ParseInfo cachedParseInfo)
/*      */     throws SQLException
/*      */   {
/*  884 */     if (!Util.isJdbc4()) {
/*  885 */       return new PreparedStatement(conn, sql, catalog, cachedParseInfo);
/*      */     }
/*      */     
/*  888 */     return (PreparedStatement)Util.handleNewInstance(JDBC_4_PSTMT_4_ARG_CTOR, new Object[] { conn, sql, catalog, cachedParseInfo }, conn.getExceptionInterceptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PreparedStatement(MySQLConnection conn, String catalog)
/*      */     throws SQLException
/*      */   {
/*  906 */     super(conn, catalog);
/*      */     
/*  908 */     detectFractionalSecondsSupport();
/*  909 */     this.compensateForOnDuplicateKeyUpdate = this.connection.getCompensateOnDuplicateKeyUpdateCounts();
/*      */   }
/*      */   
/*      */   protected void detectFractionalSecondsSupport() throws SQLException {
/*  913 */     this.serverSupportsFracSecs = ((this.connection != null) && (this.connection.versionMeetsMinimum(5, 6, 4)));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PreparedStatement(MySQLConnection conn, String sql, String catalog)
/*      */     throws SQLException
/*      */   {
/*  932 */     super(conn, catalog);
/*      */     
/*  934 */     if (sql == null) {
/*  935 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.0"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*  939 */     detectFractionalSecondsSupport();
/*  940 */     this.originalSql = sql;
/*      */     
/*  942 */     if (this.originalSql.startsWith("/* ping */")) {
/*  943 */       this.doPingInstead = true;
/*      */     } else {
/*  945 */       this.doPingInstead = false;
/*      */     }
/*      */     
/*  948 */     this.dbmd = this.connection.getMetaData();
/*      */     
/*  950 */     this.useTrueBoolean = this.connection.versionMeetsMinimum(3, 21, 23);
/*      */     
/*  952 */     this.parseInfo = new ParseInfo(sql, this.connection, this.dbmd, this.charEncoding, this.charConverter);
/*      */     
/*      */ 
/*  955 */     initializeFromParseInfo();
/*      */     
/*  957 */     this.compensateForOnDuplicateKeyUpdate = this.connection.getCompensateOnDuplicateKeyUpdateCounts();
/*      */     
/*  959 */     if (conn.getRequiresEscapingEncoder()) {
/*  960 */       this.charsetEncoder = Charset.forName(conn.getEncoding()).newEncoder();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PreparedStatement(MySQLConnection conn, String sql, String catalog, ParseInfo cachedParseInfo)
/*      */     throws SQLException
/*      */   {
/*  980 */     super(conn, catalog);
/*      */     
/*  982 */     if (sql == null) {
/*  983 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.1"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*  987 */     detectFractionalSecondsSupport();
/*  988 */     this.originalSql = sql;
/*      */     
/*  990 */     this.dbmd = this.connection.getMetaData();
/*      */     
/*  992 */     this.useTrueBoolean = this.connection.versionMeetsMinimum(3, 21, 23);
/*      */     
/*  994 */     this.parseInfo = cachedParseInfo;
/*      */     
/*  996 */     this.usingAnsiMode = (!this.connection.useAnsiQuotedIdentifiers());
/*      */     
/*  998 */     initializeFromParseInfo();
/*      */     
/* 1000 */     this.compensateForOnDuplicateKeyUpdate = this.connection.getCompensateOnDuplicateKeyUpdateCounts();
/*      */     
/* 1002 */     if (conn.getRequiresEscapingEncoder()) {
/* 1003 */       this.charsetEncoder = Charset.forName(conn.getEncoding()).newEncoder();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void addBatch()
/*      */     throws SQLException
/*      */   {
/* 1015 */     if (this.batchedArgs == null) {
/* 1016 */       this.batchedArgs = new ArrayList();
/*      */     }
/*      */     
/* 1019 */     for (int i = 0; i < this.parameterValues.length; i++) {
/* 1020 */       checkAllParametersSet(this.parameterValues[i], this.parameterStreams[i], i);
/*      */     }
/*      */     
/*      */ 
/* 1024 */     this.batchedArgs.add(new BatchParams(this.parameterValues, this.parameterStreams, this.isStream, this.streamLengths, this.isNull));
/*      */   }
/*      */   
/*      */   public synchronized void addBatch(String sql)
/*      */     throws SQLException
/*      */   {
/* 1030 */     this.batchHasPlainStatements = true;
/*      */     
/* 1032 */     super.addBatch(sql);
/*      */   }
/*      */   
/*      */   protected String asSql() throws SQLException {
/* 1036 */     return asSql(false);
/*      */   }
/*      */   
/*      */   protected synchronized String asSql(boolean quoteStreamsAndUnknowns) throws SQLException {
/* 1040 */     if (this.isClosed) {
/* 1041 */       return "statement has been closed, no further internal information available";
/*      */     }
/*      */     
/* 1044 */     StringBuffer buf = new StringBuffer();
/*      */     try
/*      */     {
/* 1047 */       int realParameterCount = this.parameterCount + getParameterIndexOffset();
/* 1048 */       Object batchArg = null;
/* 1049 */       if (this.batchCommandIndex != -1) {
/* 1050 */         batchArg = this.batchedArgs.get(this.batchCommandIndex);
/*      */       }
/* 1052 */       for (int i = 0; i < realParameterCount; i++) {
/* 1053 */         if (this.charEncoding != null) {
/* 1054 */           buf.append(StringUtils.toString(this.staticSqlStrings[i], this.charEncoding));
/*      */         }
/*      */         else {
/* 1057 */           buf.append(StringUtils.toString(this.staticSqlStrings[i]));
/*      */         }
/*      */         
/* 1060 */         byte[] val = null;
/* 1061 */         if ((batchArg != null) && ((batchArg instanceof String))) {
/* 1062 */           buf.append((String)batchArg);
/*      */         }
/*      */         else {
/* 1065 */           if (this.batchCommandIndex == -1) {
/* 1066 */             val = this.parameterValues[i];
/*      */           } else {
/* 1068 */             val = ((BatchParams)batchArg).parameterStrings[i];
/*      */           }
/* 1070 */           boolean isStreamParam = false;
/* 1071 */           if (this.batchCommandIndex == -1) {
/* 1072 */             isStreamParam = this.isStream[i];
/*      */           } else {
/* 1074 */             isStreamParam = ((BatchParams)batchArg).isStream[i];
/*      */           }
/* 1076 */           if ((val == null) && (!isStreamParam)) {
/* 1077 */             if (quoteStreamsAndUnknowns) {
/* 1078 */               buf.append("'");
/*      */             }
/*      */             
/* 1081 */             buf.append("** NOT SPECIFIED **");
/*      */             
/* 1083 */             if (quoteStreamsAndUnknowns) {
/* 1084 */               buf.append("'");
/*      */             }
/* 1086 */           } else if (isStreamParam) {
/* 1087 */             if (quoteStreamsAndUnknowns) {
/* 1088 */               buf.append("'");
/*      */             }
/*      */             
/* 1091 */             buf.append("** STREAM DATA **");
/*      */             
/* 1093 */             if (quoteStreamsAndUnknowns) {
/* 1094 */               buf.append("'");
/*      */             }
/*      */           }
/* 1097 */           else if (this.charConverter != null) {
/* 1098 */             buf.append(this.charConverter.toString(val));
/*      */           }
/* 1100 */           else if (this.charEncoding != null) {
/* 1101 */             buf.append(new String(val, this.charEncoding));
/*      */           } else {
/* 1103 */             buf.append(StringUtils.toAsciiString(val));
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1109 */       if (this.charEncoding != null) {
/* 1110 */         buf.append(StringUtils.toString(this.staticSqlStrings[(this.parameterCount + getParameterIndexOffset())], this.charEncoding));
/*      */       }
/*      */       else
/*      */       {
/* 1114 */         buf.append(StringUtils.toAsciiString(this.staticSqlStrings[(this.parameterCount + getParameterIndexOffset())]));
/*      */       }
/*      */     }
/*      */     catch (UnsupportedEncodingException uue)
/*      */     {
/* 1119 */       throw new RuntimeException(Messages.getString("PreparedStatement.32") + this.charEncoding + Messages.getString("PreparedStatement.33"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1125 */     return buf.toString();
/*      */   }
/*      */   
/*      */   public synchronized void clearBatch() throws SQLException {
/* 1129 */     this.batchHasPlainStatements = false;
/*      */     
/* 1131 */     super.clearBatch();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void clearParameters()
/*      */     throws SQLException
/*      */   {
/* 1145 */     checkClosed();
/*      */     
/* 1147 */     for (int i = 0; i < this.parameterValues.length; i++) {
/* 1148 */       this.parameterValues[i] = null;
/* 1149 */       this.parameterStreams[i] = null;
/* 1150 */       this.isStream[i] = false;
/* 1151 */       this.isNull[i] = false;
/* 1152 */       this.parameterTypes[i] = 0;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void close()
/*      */     throws SQLException
/*      */   {
/* 1163 */     realClose(true, true);
/*      */   }
/*      */   
/*      */   private final void escapeblockFast(byte[] buf, Buffer packet, int size) throws SQLException
/*      */   {
/* 1168 */     int lastwritten = 0;
/*      */     
/* 1170 */     for (int i = 0; i < size; i++) {
/* 1171 */       byte b = buf[i];
/*      */       
/* 1173 */       if (b == 0)
/*      */       {
/* 1175 */         if (i > lastwritten) {
/* 1176 */           packet.writeBytesNoNull(buf, lastwritten, i - lastwritten);
/*      */         }
/*      */         
/*      */ 
/* 1180 */         packet.writeByte((byte)92);
/* 1181 */         packet.writeByte((byte)48);
/* 1182 */         lastwritten = i + 1;
/*      */       }
/* 1184 */       else if ((b == 92) || (b == 39) || ((!this.usingAnsiMode) && (b == 34)))
/*      */       {
/*      */ 
/* 1187 */         if (i > lastwritten) {
/* 1188 */           packet.writeBytesNoNull(buf, lastwritten, i - lastwritten);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1193 */         packet.writeByte((byte)92);
/* 1194 */         lastwritten = i;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1200 */     if (lastwritten < size) {
/* 1201 */       packet.writeBytesNoNull(buf, lastwritten, size - lastwritten);
/*      */     }
/*      */   }
/*      */   
/*      */   private final void escapeblockFast(byte[] buf, ByteArrayOutputStream bytesOut, int size)
/*      */   {
/* 1207 */     int lastwritten = 0;
/*      */     
/* 1209 */     for (int i = 0; i < size; i++) {
/* 1210 */       byte b = buf[i];
/*      */       
/* 1212 */       if (b == 0)
/*      */       {
/* 1214 */         if (i > lastwritten) {
/* 1215 */           bytesOut.write(buf, lastwritten, i - lastwritten);
/*      */         }
/*      */         
/*      */ 
/* 1219 */         bytesOut.write(92);
/* 1220 */         bytesOut.write(48);
/* 1221 */         lastwritten = i + 1;
/*      */       }
/* 1223 */       else if ((b == 92) || (b == 39) || ((!this.usingAnsiMode) && (b == 34)))
/*      */       {
/*      */ 
/* 1226 */         if (i > lastwritten) {
/* 1227 */           bytesOut.write(buf, lastwritten, i - lastwritten);
/*      */         }
/*      */         
/*      */ 
/* 1231 */         bytesOut.write(92);
/* 1232 */         lastwritten = i;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1238 */     if (lastwritten < size) {
/* 1239 */       bytesOut.write(buf, lastwritten, size - lastwritten);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized boolean checkReadOnlySafeStatement()
/*      */     throws SQLException
/*      */   {
/* 1250 */     return (!this.connection.isReadOnly()) || (this.firstCharOfStmt == 'S');
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean execute()
/*      */     throws SQLException
/*      */   {
/* 1265 */     checkClosed();
/*      */     
/* 1267 */     MySQLConnection locallyScopedConn = this.connection;
/*      */     
/* 1269 */     if (!checkReadOnlySafeStatement()) {
/* 1270 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.20") + Messages.getString("PreparedStatement.21"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1275 */     ResultSetInternalMethods rs = null;
/*      */     
/* 1277 */     CachedResultSetMetaData cachedMetadata = null;
/*      */     
/* 1279 */     synchronized (locallyScopedConn) {
/* 1280 */       this.lastQueryIsOnDupKeyUpdate = false;
/* 1281 */       if (this.retrieveGeneratedKeys)
/* 1282 */         this.lastQueryIsOnDupKeyUpdate = containsOnDuplicateKeyUpdateInSQL();
/* 1283 */       boolean doStreaming = createStreamingResultSet();
/*      */       
/* 1285 */       clearWarnings();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1295 */       if ((doStreaming) && (this.connection.getNetTimeoutForStreamingResults() > 0))
/*      */       {
/* 1297 */         executeSimpleNonQuery(locallyScopedConn, "SET net_write_timeout=" + this.connection.getNetTimeoutForStreamingResults());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1303 */       this.batchedGeneratedKeys = null;
/*      */       
/* 1305 */       Buffer sendPacket = fillSendPacket();
/*      */       
/* 1307 */       String oldCatalog = null;
/*      */       
/* 1309 */       if (!locallyScopedConn.getCatalog().equals(this.currentCatalog)) {
/* 1310 */         oldCatalog = locallyScopedConn.getCatalog();
/* 1311 */         locallyScopedConn.setCatalog(this.currentCatalog);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1317 */       if (locallyScopedConn.getCacheResultSetMetadata()) {
/* 1318 */         cachedMetadata = locallyScopedConn.getCachedMetaData(this.originalSql);
/*      */       }
/*      */       
/* 1321 */       Field[] metadataFromCache = null;
/*      */       
/* 1323 */       if (cachedMetadata != null) {
/* 1324 */         metadataFromCache = cachedMetadata.fields;
/*      */       }
/*      */       
/* 1327 */       boolean oldInfoMsgState = false;
/*      */       
/* 1329 */       if (this.retrieveGeneratedKeys) {
/* 1330 */         oldInfoMsgState = locallyScopedConn.isReadInfoMsgEnabled();
/* 1331 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1343 */       if (locallyScopedConn.useMaxRows()) {
/* 1344 */         int rowLimit = -1;
/*      */         
/* 1346 */         if (this.firstCharOfStmt == 'S') {
/* 1347 */           if (this.hasLimitClause) {
/* 1348 */             rowLimit = this.maxRows;
/*      */           }
/* 1350 */           else if (this.maxRows <= 0) {
/* 1351 */             executeSimpleNonQuery(locallyScopedConn, "SET OPTION SQL_SELECT_LIMIT=DEFAULT");
/*      */           }
/*      */           else {
/* 1354 */             executeSimpleNonQuery(locallyScopedConn, "SET OPTION SQL_SELECT_LIMIT=" + this.maxRows);
/*      */           }
/*      */           
/*      */ 
/*      */         }
/*      */         else {
/* 1360 */           executeSimpleNonQuery(locallyScopedConn, "SET OPTION SQL_SELECT_LIMIT=DEFAULT");
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1365 */         rs = executeInternal(rowLimit, sendPacket, doStreaming, this.firstCharOfStmt == 'S', metadataFromCache, false);
/*      */       }
/*      */       else
/*      */       {
/* 1369 */         rs = executeInternal(-1, sendPacket, doStreaming, this.firstCharOfStmt == 'S', metadataFromCache, false);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1374 */       if (cachedMetadata != null) {
/* 1375 */         locallyScopedConn.initializeResultsMetadataFromCache(this.originalSql, cachedMetadata, this.results);
/*      */ 
/*      */       }
/* 1378 */       else if ((rs.reallyResult()) && (locallyScopedConn.getCacheResultSetMetadata())) {
/* 1379 */         locallyScopedConn.initializeResultsMetadataFromCache(this.originalSql, null, rs);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1384 */       if (this.retrieveGeneratedKeys) {
/* 1385 */         locallyScopedConn.setReadInfoMsgEnabled(oldInfoMsgState);
/* 1386 */         rs.setFirstCharOfQuery(this.firstCharOfStmt);
/*      */       }
/*      */       
/* 1389 */       if (oldCatalog != null) {
/* 1390 */         locallyScopedConn.setCatalog(oldCatalog);
/*      */       }
/*      */       
/* 1393 */       if (rs != null) {
/* 1394 */         this.lastInsertId = rs.getUpdateID();
/*      */         
/* 1396 */         this.results = rs;
/*      */       }
/*      */     }
/*      */     
/* 1400 */     return (rs != null) && (rs.reallyResult());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized int[] executeBatch()
/*      */     throws SQLException
/*      */   {
/* 1418 */     checkClosed();
/*      */     
/* 1420 */     if (this.connection.isReadOnly()) {
/* 1421 */       throw new SQLException(Messages.getString("PreparedStatement.25") + Messages.getString("PreparedStatement.26"), "S1009");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1426 */     synchronized (this.connection) {
/* 1427 */       if ((this.batchedArgs == null) || (this.batchedArgs.size() == 0)) {
/* 1428 */         return new int[0];
/*      */       }
/*      */       
/*      */ 
/* 1432 */       int batchTimeout = this.timeoutInMillis;
/* 1433 */       this.timeoutInMillis = 0;
/*      */       
/* 1435 */       resetCancelledState();
/*      */       try
/*      */       {
/* 1438 */         statementBegins();
/*      */         
/* 1440 */         clearWarnings();
/*      */         
/* 1442 */         if ((!this.batchHasPlainStatements) && (this.connection.getRewriteBatchedStatements()))
/*      */         {
/*      */ 
/*      */ 
/* 1446 */           if (canRewriteAsMultiValueInsertAtSqlLevel()) {
/* 1447 */             arrayOfInt = executeBatchedInserts(batchTimeout);jsr 83;return arrayOfInt;
/*      */           }
/*      */           
/* 1450 */           if ((this.connection.versionMeetsMinimum(4, 1, 0)) && (!this.batchHasPlainStatements) && (this.batchedArgs != null) && (this.batchedArgs.size() > 3))
/*      */           {
/*      */ 
/*      */ 
/* 1454 */             arrayOfInt = executePreparedBatchAsMultiStatement(batchTimeout);jsr 28;return arrayOfInt;
/*      */           }
/*      */         }
/*      */         
/* 1458 */         int[] arrayOfInt = executeBatchSerially(batchTimeout);jsr 15;return arrayOfInt;
/*      */       } finally {
/* 1460 */         jsr 6; } localObject2 = returnAddress;this.statementExecuting.set(false);
/*      */       
/* 1462 */       clearBatch();ret;
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean canRewriteAsMultiValueInsertAtSqlLevel() throws SQLException
/*      */   {
/* 1468 */     return this.parseInfo.canRewriteAsMultiValueInsert;
/*      */   }
/*      */   
/*      */   protected int getLocationOfOnDuplicateKeyUpdate() {
/* 1472 */     return this.parseInfo.locationOfOnDuplicateKeyUpdate;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private synchronized String generateMultiStatementForBatch(int numBatches)
/*      */   {
/* 1675 */     StringBuffer newStatementSql = new StringBuffer((this.originalSql.length() + 1) * numBatches);
/*      */     
/*      */ 
/* 1678 */     newStatementSql.append(this.originalSql);
/*      */     
/* 1680 */     for (int i = 0; i < numBatches - 1; i++) {
/* 1681 */       newStatementSql.append(';');
/* 1682 */       newStatementSql.append(this.originalSql);
/*      */     }
/*      */     
/* 1685 */     return newStatementSql.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getValuesClause()
/*      */     throws SQLException
/*      */   {
/* 1847 */     return this.parseInfo.valuesClause;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized int computeBatchSize(int numBatchedArgs)
/*      */     throws SQLException
/*      */   {
/* 1859 */     long[] combinedValues = computeMaxParameterSetSizeAndBatchSize(numBatchedArgs);
/*      */     
/* 1861 */     long maxSizeOfParameterSet = combinedValues[0];
/* 1862 */     long sizeOfEntireBatch = combinedValues[1];
/*      */     
/* 1864 */     int maxAllowedPacket = this.connection.getMaxAllowedPacket();
/*      */     
/* 1866 */     if (sizeOfEntireBatch < maxAllowedPacket - this.originalSql.length()) {
/* 1867 */       return numBatchedArgs;
/*      */     }
/*      */     
/* 1870 */     return (int)Math.max(1L, (maxAllowedPacket - this.originalSql.length()) / maxSizeOfParameterSet);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized long[] computeMaxParameterSetSizeAndBatchSize(int numBatchedArgs)
/*      */     throws SQLException
/*      */   {
/* 1879 */     long sizeOfEntireBatch = 0L;
/* 1880 */     long maxSizeOfParameterSet = 0L;
/*      */     
/* 1882 */     for (int i = 0; i < numBatchedArgs; i++) {
/* 1883 */       BatchParams paramArg = (BatchParams)this.batchedArgs.get(i);
/*      */       
/*      */ 
/* 1886 */       boolean[] isNullBatch = paramArg.isNull;
/* 1887 */       boolean[] isStreamBatch = paramArg.isStream;
/*      */       
/* 1889 */       long sizeOfParameterSet = 0L;
/*      */       
/* 1891 */       for (int j = 0; j < isNullBatch.length; j++) {
/* 1892 */         if (isNullBatch[j] == 0)
/*      */         {
/* 1894 */           if (isStreamBatch[j] != 0) {
/* 1895 */             int streamLength = paramArg.streamLengths[j];
/*      */             
/* 1897 */             if (streamLength != -1) {
/* 1898 */               sizeOfParameterSet += streamLength * 2;
/*      */             } else {
/* 1900 */               int paramLength = paramArg.parameterStrings[j].length;
/* 1901 */               sizeOfParameterSet += paramLength;
/*      */             }
/*      */           } else {
/* 1904 */             sizeOfParameterSet += paramArg.parameterStrings[j].length;
/*      */           }
/*      */         } else {
/* 1907 */           sizeOfParameterSet += 4L;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1919 */       if (getValuesClause() != null) {
/* 1920 */         sizeOfParameterSet += getValuesClause().length() + 1;
/*      */       } else {
/* 1922 */         sizeOfParameterSet += this.originalSql.length() + 1;
/*      */       }
/*      */       
/* 1925 */       sizeOfEntireBatch += sizeOfParameterSet;
/*      */       
/* 1927 */       if (sizeOfParameterSet > maxSizeOfParameterSet) {
/* 1928 */         maxSizeOfParameterSet = sizeOfParameterSet;
/*      */       }
/*      */     }
/*      */     
/* 1932 */     return new long[] { maxSizeOfParameterSet, sizeOfEntireBatch };
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized int[] executeBatchSerially(int batchTimeout)
/*      */     throws SQLException
/*      */   {
/* 1945 */     MySQLConnection locallyScopedConn = this.connection;
/*      */     
/* 1947 */     if (locallyScopedConn == null) {
/* 1948 */       checkClosed();
/*      */     }
/*      */     
/* 1951 */     int[] updateCounts = null;
/*      */     
/* 1953 */     if (this.batchedArgs != null) {
/* 1954 */       int nbrCommands = this.batchedArgs.size();
/* 1955 */       updateCounts = new int[nbrCommands];
/*      */       
/* 1957 */       for (int i = 0; i < nbrCommands; i++) {
/* 1958 */         updateCounts[i] = -3;
/*      */       }
/*      */       
/* 1961 */       SQLException sqlEx = null;
/*      */       
/* 1963 */       StatementImpl.CancelTask timeoutTask = null;
/*      */       try
/*      */       {
/* 1966 */         if ((locallyScopedConn.getEnableQueryTimeouts()) && (batchTimeout != 0) && (locallyScopedConn.versionMeetsMinimum(5, 0, 0)))
/*      */         {
/*      */ 
/* 1969 */           timeoutTask = new StatementImpl.CancelTask(this, this);
/* 1970 */           locallyScopedConn.getCancelTimer().schedule(timeoutTask, batchTimeout);
/*      */         }
/*      */         
/*      */ 
/* 1974 */         if (this.retrieveGeneratedKeys) {
/* 1975 */           this.batchedGeneratedKeys = new ArrayList(nbrCommands);
/*      */         }
/*      */         
/* 1978 */         for (this.batchCommandIndex = 0; this.batchCommandIndex < nbrCommands; this.batchCommandIndex += 1) {
/* 1979 */           Object arg = this.batchedArgs.get(this.batchCommandIndex);
/*      */           
/* 1981 */           if ((arg instanceof String)) {
/* 1982 */             updateCounts[this.batchCommandIndex] = executeUpdate((String)arg);
/*      */           } else {
/* 1984 */             BatchParams paramArg = (BatchParams)arg;
/*      */             try
/*      */             {
/* 1987 */               updateCounts[this.batchCommandIndex] = executeUpdate(paramArg.parameterStrings, paramArg.parameterStreams, paramArg.isStream, paramArg.streamLengths, paramArg.isNull, true);
/*      */               
/*      */ 
/*      */ 
/*      */ 
/* 1992 */               if (this.retrieveGeneratedKeys) {
/* 1993 */                 ResultSet rs = null;
/*      */                 try
/*      */                 {
/* 1996 */                   if (containsOnDuplicateKeyUpdateInSQL()) {
/* 1997 */                     rs = getGeneratedKeysInternal(1);
/*      */                   } else {
/* 1999 */                     rs = getGeneratedKeysInternal();
/*      */                   }
/* 2001 */                   while (rs.next()) {
/* 2002 */                     this.batchedGeneratedKeys.add(new ByteArrayRow(new byte[][] { rs.getBytes(1) }, getExceptionInterceptor()));
/*      */                   }
/*      */                 }
/*      */                 finally {
/* 2006 */                   if (rs != null) {
/* 2007 */                     rs.close();
/*      */                   }
/*      */                 }
/*      */               }
/*      */             } catch (SQLException ex) {
/* 2012 */               updateCounts[this.batchCommandIndex] = -3;
/*      */               
/* 2014 */               if ((this.continueBatchOnError) && (!(ex instanceof MySQLTimeoutException)) && (!(ex instanceof MySQLStatementCancelledException)) && (!hasDeadlockOrTimeoutRolledBackTx(ex)))
/*      */               {
/*      */ 
/*      */ 
/* 2018 */                 sqlEx = ex;
/*      */               } else {
/* 2020 */                 int[] newUpdateCounts = new int[this.batchCommandIndex];
/* 2021 */                 System.arraycopy(updateCounts, 0, newUpdateCounts, 0, this.batchCommandIndex);
/*      */                 
/*      */ 
/* 2024 */                 Object batchUpdateException = new BatchUpdateException(ex.getMessage(), ex.getSQLState(), ex.getErrorCode(), newUpdateCounts);
/*      */                 
/*      */ 
/* 2027 */                 ((SQLException)batchUpdateException).initCause(ex);
/* 2028 */                 throw ((Throwable)batchUpdateException);
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */         
/* 2034 */         if (sqlEx != null) {
/* 2035 */           SQLException batchUpdateException = new BatchUpdateException(sqlEx.getMessage(), sqlEx.getSQLState(), sqlEx.getErrorCode(), updateCounts);
/*      */           
/* 2037 */           batchUpdateException.initCause(sqlEx);
/* 2038 */           throw batchUpdateException;
/*      */         }
/*      */       } catch (NullPointerException npe) {
/*      */         try {
/* 2042 */           checkClosed();
/*      */         } catch (SQLException connectionClosedEx) {
/* 2044 */           updateCounts[this.batchCommandIndex] = -3;
/*      */           
/* 2046 */           int[] newUpdateCounts = new int[this.batchCommandIndex];
/*      */           
/* 2048 */           System.arraycopy(updateCounts, 0, newUpdateCounts, 0, this.batchCommandIndex);
/*      */           
/*      */ 
/* 2051 */           throw new BatchUpdateException(connectionClosedEx.getMessage(), connectionClosedEx.getSQLState(), connectionClosedEx.getErrorCode(), newUpdateCounts);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 2056 */         throw npe;
/*      */       } finally {
/* 2058 */         this.batchCommandIndex = -1;
/*      */         
/* 2060 */         if (timeoutTask != null) {
/* 2061 */           timeoutTask.cancel();
/* 2062 */           locallyScopedConn.getCancelTimer().purge();
/*      */         }
/*      */         
/* 2065 */         resetCancelledState();
/*      */       }
/*      */     }
/*      */     
/* 2069 */     return updateCounts != null ? updateCounts : new int[0];
/*      */   }
/*      */   
/*      */   public String getDateTime(String pattern)
/*      */   {
/* 2074 */     SimpleDateFormat sdf = new SimpleDateFormat(pattern);
/* 2075 */     return sdf.format(new java.util.Date());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized ResultSetInternalMethods executeInternal(int maxRowsToRetrieve, Buffer sendPacket, boolean createStreamingResultSet, boolean queryIsSelectOnly, Field[] metadataFromCache, boolean isBatch)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 2105 */       resetCancelledState();
/*      */       
/* 2107 */       MySQLConnection locallyScopedConnection = this.connection;
/*      */       
/* 2109 */       this.numberOfExecutions += 1;
/*      */       
/* 2111 */       if (this.doPingInstead) {
/* 2112 */         doPingInstead();
/*      */         
/* 2114 */         return this.results;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2119 */       StatementImpl.CancelTask timeoutTask = null;
/*      */       ResultSetInternalMethods rs;
/*      */       try {
/* 2122 */         if ((locallyScopedConnection.getEnableQueryTimeouts()) && (this.timeoutInMillis != 0) && (locallyScopedConnection.versionMeetsMinimum(5, 0, 0)))
/*      */         {
/*      */ 
/* 2125 */           timeoutTask = new StatementImpl.CancelTask(this, this);
/* 2126 */           locallyScopedConnection.getCancelTimer().schedule(timeoutTask, this.timeoutInMillis);
/*      */         }
/*      */         
/*      */ 
/* 2130 */         if (!isBatch) {
/* 2131 */           statementBegins();
/*      */         }
/*      */         
/* 2134 */         rs = locallyScopedConnection.execSQL(this, null, maxRowsToRetrieve, sendPacket, this.resultSetType, this.resultSetConcurrency, createStreamingResultSet, this.currentCatalog, metadataFromCache, isBatch);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 2139 */         if (timeoutTask != null) {
/* 2140 */           timeoutTask.cancel();
/*      */           
/* 2142 */           locallyScopedConnection.getCancelTimer().purge();
/*      */           
/* 2144 */           if (timeoutTask.caughtWhileCancelling != null) {
/* 2145 */             throw timeoutTask.caughtWhileCancelling;
/*      */           }
/*      */           
/* 2148 */           timeoutTask = null;
/*      */         }
/*      */         
/* 2151 */         synchronized (this.cancelTimeoutMutex) {
/* 2152 */           if (this.wasCancelled) {
/* 2153 */             SQLException cause = null;
/*      */             
/* 2155 */             if (this.wasCancelledByTimeout) {
/* 2156 */               cause = new MySQLTimeoutException();
/*      */             } else {
/* 2158 */               cause = new MySQLStatementCancelledException();
/*      */             }
/*      */             
/* 2161 */             resetCancelledState();
/*      */             
/* 2163 */             throw cause;
/*      */           }
/*      */         }
/*      */       } finally {
/* 2167 */         if (!isBatch) {
/* 2168 */           this.statementExecuting.set(false);
/*      */         }
/*      */         
/* 2171 */         if (timeoutTask != null) {
/* 2172 */           timeoutTask.cancel();
/* 2173 */           locallyScopedConnection.getCancelTimer().purge();
/*      */         }
/*      */       }
/*      */       
/* 2177 */       return rs;
/*      */     } catch (NullPointerException npe) {
/* 2179 */       checkClosed();
/*      */       
/*      */ 
/*      */ 
/* 2183 */       throw npe;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized ResultSet executeQuery()
/*      */     throws SQLException
/*      */   {
/* 2197 */     checkClosed();
/*      */     
/* 2199 */     MySQLConnection locallyScopedConn = this.connection;
/*      */     
/* 2201 */     checkForDml(this.originalSql, this.firstCharOfStmt);
/*      */     
/* 2203 */     CachedResultSetMetaData cachedMetadata = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2209 */     synchronized (locallyScopedConn) {
/* 2210 */       clearWarnings();
/*      */       
/* 2212 */       boolean doStreaming = createStreamingResultSet();
/*      */       
/* 2214 */       this.batchedGeneratedKeys = null;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2224 */       if ((doStreaming) && (this.connection.getNetTimeoutForStreamingResults() > 0))
/*      */       {
/*      */ 
/* 2227 */         Statement stmt = null;
/*      */         try
/*      */         {
/* 2230 */           stmt = this.connection.createStatement();
/*      */           
/* 2232 */           ((StatementImpl)stmt).executeSimpleNonQuery(this.connection, "SET net_write_timeout=" + this.connection.getNetTimeoutForStreamingResults());
/*      */         }
/*      */         finally {
/* 2235 */           if (stmt != null) {
/* 2236 */             stmt.close();
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 2241 */       Buffer sendPacket = fillSendPacket();
/*      */       
/* 2243 */       if ((this.results != null) && 
/* 2244 */         (!this.connection.getHoldResultsOpenOverStatementClose()) && 
/* 2245 */         (!this.holdResultsOpenOverClose)) {
/* 2246 */         this.results.realClose(false);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2251 */       String oldCatalog = null;
/*      */       
/* 2253 */       if (!locallyScopedConn.getCatalog().equals(this.currentCatalog)) {
/* 2254 */         oldCatalog = locallyScopedConn.getCatalog();
/* 2255 */         locallyScopedConn.setCatalog(this.currentCatalog);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2261 */       if (locallyScopedConn.getCacheResultSetMetadata()) {
/* 2262 */         cachedMetadata = locallyScopedConn.getCachedMetaData(this.originalSql);
/*      */       }
/*      */       
/* 2265 */       Field[] metadataFromCache = null;
/*      */       
/* 2267 */       if (cachedMetadata != null) {
/* 2268 */         metadataFromCache = cachedMetadata.fields;
/*      */       }
/*      */       
/* 2271 */       if (locallyScopedConn.useMaxRows())
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2278 */         if (this.hasLimitClause) {
/* 2279 */           this.results = executeInternal(this.maxRows, sendPacket, createStreamingResultSet(), true, metadataFromCache, false);
/*      */         }
/*      */         else
/*      */         {
/* 2283 */           if (this.maxRows <= 0) {
/* 2284 */             executeSimpleNonQuery(locallyScopedConn, "SET OPTION SQL_SELECT_LIMIT=DEFAULT");
/*      */           }
/*      */           else {
/* 2287 */             executeSimpleNonQuery(locallyScopedConn, "SET OPTION SQL_SELECT_LIMIT=" + this.maxRows);
/*      */           }
/*      */           
/*      */ 
/* 2291 */           this.results = executeInternal(-1, sendPacket, doStreaming, true, metadataFromCache, false);
/*      */           
/*      */ 
/*      */ 
/* 2295 */           if (oldCatalog != null) {
/* 2296 */             this.connection.setCatalog(oldCatalog);
/*      */           }
/*      */         }
/*      */       } else {
/* 2300 */         this.results = executeInternal(-1, sendPacket, doStreaming, true, metadataFromCache, false);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2305 */       if (oldCatalog != null) {
/* 2306 */         locallyScopedConn.setCatalog(oldCatalog);
/*      */       }
/*      */       
/* 2309 */       if (cachedMetadata != null) {
/* 2310 */         locallyScopedConn.initializeResultsMetadataFromCache(this.originalSql, cachedMetadata, this.results);
/*      */ 
/*      */       }
/* 2313 */       else if (locallyScopedConn.getCacheResultSetMetadata()) {
/* 2314 */         locallyScopedConn.initializeResultsMetadataFromCache(this.originalSql, null, this.results);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2320 */     this.lastInsertId = this.results.getUpdateID();
/*      */     
/* 2322 */     return this.results;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int executeUpdate()
/*      */     throws SQLException
/*      */   {
/* 2337 */     return executeUpdate(true, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized int executeUpdate(boolean clearBatchedGeneratedKeysAndWarnings, boolean isBatch)
/*      */     throws SQLException
/*      */   {
/* 2347 */     if (clearBatchedGeneratedKeysAndWarnings) {
/* 2348 */       clearWarnings();
/* 2349 */       this.batchedGeneratedKeys = null;
/*      */     }
/*      */     
/* 2352 */     return executeUpdate(this.parameterValues, this.parameterStreams, this.isStream, this.streamLengths, this.isNull, isBatch);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized int executeUpdate(byte[][] batchedParameterStrings, InputStream[] batchedParameterStreams, boolean[] batchedIsStream, int[] batchedStreamLengths, boolean[] batchedIsNull, boolean isReallyBatch)
/*      */     throws SQLException
/*      */   {
/* 2380 */     checkClosed();
/*      */     
/* 2382 */     MySQLConnection locallyScopedConn = this.connection;
/*      */     
/* 2384 */     if (locallyScopedConn.isReadOnly()) {
/* 2385 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.34") + Messages.getString("PreparedStatement.35"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2390 */     if ((this.firstCharOfStmt == 'S') && (isSelectQuery()))
/*      */     {
/* 2392 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.37"), "01S03", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 2396 */     if ((this.results != null) && 
/* 2397 */       (!locallyScopedConn.getHoldResultsOpenOverStatementClose())) {
/* 2398 */       this.results.realClose(false);
/*      */     }
/*      */     
/*      */ 
/* 2402 */     ResultSetInternalMethods rs = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2407 */     synchronized (locallyScopedConn) {
/* 2408 */       Buffer sendPacket = fillSendPacket(batchedParameterStrings, batchedParameterStreams, batchedIsStream, batchedStreamLengths);
/*      */       
/*      */ 
/*      */ 
/* 2412 */       String oldCatalog = null;
/*      */       
/* 2414 */       if (!locallyScopedConn.getCatalog().equals(this.currentCatalog)) {
/* 2415 */         oldCatalog = locallyScopedConn.getCatalog();
/* 2416 */         locallyScopedConn.setCatalog(this.currentCatalog);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2422 */       if (locallyScopedConn.useMaxRows()) {
/* 2423 */         executeSimpleNonQuery(locallyScopedConn, "SET OPTION SQL_SELECT_LIMIT=DEFAULT");
/*      */       }
/*      */       
/*      */ 
/* 2427 */       boolean oldInfoMsgState = false;
/*      */       
/* 2429 */       if (this.retrieveGeneratedKeys) {
/* 2430 */         oldInfoMsgState = locallyScopedConn.isReadInfoMsgEnabled();
/* 2431 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */       }
/*      */       
/* 2434 */       rs = executeInternal(-1, sendPacket, false, false, null, isReallyBatch);
/*      */       
/*      */ 
/* 2437 */       if (this.retrieveGeneratedKeys) {
/* 2438 */         locallyScopedConn.setReadInfoMsgEnabled(oldInfoMsgState);
/* 2439 */         rs.setFirstCharOfQuery(this.firstCharOfStmt);
/*      */       }
/*      */       
/* 2442 */       if (oldCatalog != null) {
/* 2443 */         locallyScopedConn.setCatalog(oldCatalog);
/*      */       }
/*      */     }
/*      */     
/* 2447 */     this.results = rs;
/*      */     
/* 2449 */     this.updateCount = rs.getUpdateCount();
/*      */     
/* 2451 */     if ((containsOnDuplicateKeyUpdateInSQL()) && (this.compensateForOnDuplicateKeyUpdate))
/*      */     {
/* 2453 */       if ((this.updateCount == 2L) || (this.updateCount == 0L)) {
/* 2454 */         this.updateCount = 1L;
/*      */       }
/*      */     }
/*      */     
/* 2458 */     int truncatedUpdateCount = 0;
/*      */     
/* 2460 */     if (this.updateCount > 2147483647L) {
/* 2461 */       truncatedUpdateCount = Integer.MAX_VALUE;
/*      */     } else {
/* 2463 */       truncatedUpdateCount = (int)this.updateCount;
/*      */     }
/*      */     
/* 2466 */     this.lastInsertId = rs.getUpdateID();
/*      */     
/* 2468 */     return truncatedUpdateCount;
/*      */   }
/*      */   
/*      */   protected boolean containsOnDuplicateKeyUpdateInSQL() {
/* 2472 */     return this.parseInfo.isOnDuplicateKeyUpdate;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized Buffer fillSendPacket()
/*      */     throws SQLException
/*      */   {
/* 2487 */     return fillSendPacket(this.parameterValues, this.parameterStreams, this.isStream, this.streamLengths);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized Buffer fillSendPacket(byte[][] batchedParameterStrings, InputStream[] batchedParameterStreams, boolean[] batchedIsStream, int[] batchedStreamLengths)
/*      */     throws SQLException
/*      */   {
/* 2511 */     Buffer sendPacket = this.connection.getIO().getSharedSendPacket();
/*      */     
/* 2513 */     sendPacket.clear();
/*      */     
/* 2515 */     sendPacket.writeByte((byte)3);
/*      */     
/* 2517 */     boolean useStreamLengths = this.connection.getUseStreamLengthsInPrepStmts();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2524 */     int ensurePacketSize = 0;
/*      */     
/* 2526 */     String statementComment = this.connection.getStatementComment();
/*      */     
/* 2528 */     byte[] commentAsBytes = null;
/*      */     
/* 2530 */     if (statementComment != null) {
/* 2531 */       if (this.charConverter != null) {
/* 2532 */         commentAsBytes = this.charConverter.toBytes(statementComment);
/*      */       } else {
/* 2534 */         commentAsBytes = StringUtils.getBytes(statementComment, this.charConverter, this.charEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2540 */       ensurePacketSize += commentAsBytes.length;
/* 2541 */       ensurePacketSize += 6;
/*      */     }
/*      */     
/* 2544 */     for (int i = 0; i < batchedParameterStrings.length; i++) {
/* 2545 */       if ((batchedIsStream[i] != 0) && (useStreamLengths)) {
/* 2546 */         ensurePacketSize += batchedStreamLengths[i];
/*      */       }
/*      */     }
/*      */     
/* 2550 */     if (ensurePacketSize != 0) {
/* 2551 */       sendPacket.ensureCapacity(ensurePacketSize);
/*      */     }
/*      */     
/* 2554 */     if (commentAsBytes != null) {
/* 2555 */       sendPacket.writeBytesNoNull(Constants.SLASH_STAR_SPACE_AS_BYTES);
/* 2556 */       sendPacket.writeBytesNoNull(commentAsBytes);
/* 2557 */       sendPacket.writeBytesNoNull(Constants.SPACE_STAR_SLASH_SPACE_AS_BYTES);
/*      */     }
/*      */     
/* 2560 */     for (int i = 0; i < batchedParameterStrings.length; i++) {
/* 2561 */       checkAllParametersSet(batchedParameterStrings[i], batchedParameterStreams[i], i);
/*      */       
/*      */ 
/* 2564 */       sendPacket.writeBytesNoNull(this.staticSqlStrings[i]);
/*      */       
/* 2566 */       if (batchedIsStream[i] != 0) {
/* 2567 */         streamToBytes(sendPacket, batchedParameterStreams[i], true, batchedStreamLengths[i], useStreamLengths);
/*      */       }
/*      */       else {
/* 2570 */         sendPacket.writeBytesNoNull(batchedParameterStrings[i]);
/*      */       }
/*      */     }
/*      */     
/* 2574 */     sendPacket.writeBytesNoNull(this.staticSqlStrings[batchedParameterStrings.length]);
/*      */     
/*      */ 
/* 2577 */     return sendPacket;
/*      */   }
/*      */   
/*      */   private void checkAllParametersSet(byte[] parameterString, InputStream parameterStream, int columnIndex) throws SQLException
/*      */   {
/* 2582 */     if ((parameterString == null) && (parameterStream == null))
/*      */     {
/*      */ 
/* 2585 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.40") + (columnIndex + 1), "07001", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized PreparedStatement prepareBatchedInsertSQL(MySQLConnection localConn, int numBatches)
/*      */     throws SQLException
/*      */   {
/* 2595 */     PreparedStatement pstmt = new PreparedStatement(localConn, "Rewritten batch of: " + this.originalSql, this.currentCatalog, this.parseInfo.getParseInfoForBatch(numBatches));
/* 2596 */     pstmt.setRetrieveGeneratedKeys(this.retrieveGeneratedKeys);
/* 2597 */     pstmt.rewrittenBatchSize = numBatches;
/*      */     
/* 2599 */     return pstmt;
/*      */   }
/*      */   
/* 2602 */   protected int rewrittenBatchSize = 0;
/*      */   
/*      */   public int getRewrittenBatchSize() {
/* 2605 */     return this.rewrittenBatchSize;
/*      */   }
/*      */   
/*      */   public synchronized String getNonRewrittenSql() {
/* 2609 */     int indexOfBatch = this.originalSql.indexOf(" of: ");
/*      */     
/* 2611 */     if (indexOfBatch != -1) {
/* 2612 */       return this.originalSql.substring(indexOfBatch + 5);
/*      */     }
/*      */     
/* 2615 */     return this.originalSql;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized byte[] getBytesRepresentation(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 2632 */     if (this.isStream[parameterIndex] != 0) {
/* 2633 */       return streamToBytes(this.parameterStreams[parameterIndex], false, this.streamLengths[parameterIndex], this.connection.getUseStreamLengthsInPrepStmts());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2638 */     byte[] parameterVal = this.parameterValues[parameterIndex];
/*      */     
/* 2640 */     if (parameterVal == null) {
/* 2641 */       return null;
/*      */     }
/*      */     
/* 2644 */     if ((parameterVal[0] == 39) && (parameterVal[(parameterVal.length - 1)] == 39))
/*      */     {
/* 2646 */       byte[] valNoQuotes = new byte[parameterVal.length - 2];
/* 2647 */       System.arraycopy(parameterVal, 1, valNoQuotes, 0, parameterVal.length - 2);
/*      */       
/*      */ 
/* 2650 */       return valNoQuotes;
/*      */     }
/*      */     
/* 2653 */     return parameterVal;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized byte[] getBytesRepresentationForBatch(int parameterIndex, int commandIndex)
/*      */     throws SQLException
/*      */   {
/* 2665 */     Object batchedArg = this.batchedArgs.get(commandIndex);
/* 2666 */     if ((batchedArg instanceof String)) {
/*      */       try {
/* 2668 */         return StringUtils.getBytes((String)batchedArg, this.charEncoding);
/*      */       }
/*      */       catch (UnsupportedEncodingException uue) {
/* 2671 */         throw new RuntimeException(Messages.getString("PreparedStatement.32") + this.charEncoding + Messages.getString("PreparedStatement.33"));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2678 */     BatchParams params = (BatchParams)batchedArg;
/* 2679 */     if (params.isStream[parameterIndex] != 0) {
/* 2680 */       return streamToBytes(params.parameterStreams[parameterIndex], false, params.streamLengths[parameterIndex], this.connection.getUseStreamLengthsInPrepStmts());
/*      */     }
/*      */     
/* 2683 */     byte[] parameterVal = params.parameterStrings[parameterIndex];
/* 2684 */     if (parameterVal == null) {
/* 2685 */       return null;
/*      */     }
/* 2687 */     if ((parameterVal[0] == 39) && (parameterVal[(parameterVal.length - 1)] == 39))
/*      */     {
/* 2689 */       byte[] valNoQuotes = new byte[parameterVal.length - 2];
/* 2690 */       System.arraycopy(parameterVal, 1, valNoQuotes, 0, parameterVal.length - 2);
/*      */       
/*      */ 
/* 2693 */       return valNoQuotes;
/*      */     }
/*      */     
/* 2696 */     return parameterVal;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final String getDateTimePattern(String dt, boolean toTime)
/*      */     throws Exception
/*      */   {
/* 2706 */     int dtLength = dt != null ? dt.length() : 0;
/*      */     
/* 2708 */     if ((dtLength >= 8) && (dtLength <= 10)) {
/* 2709 */       int dashCount = 0;
/* 2710 */       boolean isDateOnly = true;
/*      */       
/* 2712 */       for (int i = 0; i < dtLength; i++) {
/* 2713 */         char c = dt.charAt(i);
/*      */         
/* 2715 */         if ((!Character.isDigit(c)) && (c != '-')) {
/* 2716 */           isDateOnly = false;
/*      */           
/* 2718 */           break;
/*      */         }
/*      */         
/* 2721 */         if (c == '-') {
/* 2722 */           dashCount++;
/*      */         }
/*      */       }
/*      */       
/* 2726 */       if ((isDateOnly) && (dashCount == 2)) {
/* 2727 */         return "yyyy-MM-dd";
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2734 */     boolean colonsOnly = true;
/*      */     
/* 2736 */     for (int i = 0; i < dtLength; i++) {
/* 2737 */       char c = dt.charAt(i);
/*      */       
/* 2739 */       if ((!Character.isDigit(c)) && (c != ':')) {
/* 2740 */         colonsOnly = false;
/*      */         
/* 2742 */         break;
/*      */       }
/*      */     }
/*      */     
/* 2746 */     if (colonsOnly) {
/* 2747 */       return "HH:mm:ss";
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2756 */     StringReader reader = new StringReader(dt + " ");
/* 2757 */     ArrayList vec = new ArrayList();
/* 2758 */     ArrayList vecRemovelist = new ArrayList();
/* 2759 */     Object[] nv = new Object[3];
/*      */     
/* 2761 */     nv[0] = Character.valueOf('y');
/* 2762 */     nv[1] = new StringBuffer();
/* 2763 */     nv[2] = Integer.valueOf(0);
/* 2764 */     vec.add(nv);
/*      */     
/* 2766 */     if (toTime) {
/* 2767 */       nv = new Object[3];
/* 2768 */       nv[0] = Character.valueOf('h');
/* 2769 */       nv[1] = new StringBuffer();
/* 2770 */       nv[2] = Integer.valueOf(0);
/* 2771 */       vec.add(nv);
/*      */     }
/*      */     int z;
/* 2774 */     while ((z = reader.read()) != -1) {
/* 2775 */       char separator = (char)z;
/* 2776 */       int maxvecs = vec.size();
/*      */       
/* 2778 */       for (int count = 0; count < maxvecs; count++) {
/* 2779 */         Object[] v = (Object[])vec.get(count);
/* 2780 */         int n = ((Integer)v[2]).intValue();
/* 2781 */         char c = getSuccessor(((Character)v[0]).charValue(), n);
/*      */         
/* 2783 */         if (!Character.isLetterOrDigit(separator)) {
/* 2784 */           if ((c == ((Character)v[0]).charValue()) && (c != 'S')) {
/* 2785 */             vecRemovelist.add(v);
/*      */           } else {
/* 2787 */             ((StringBuffer)v[1]).append(separator);
/*      */             
/* 2789 */             if ((c == 'X') || (c == 'Y')) {
/* 2790 */               v[2] = Integer.valueOf(4);
/*      */             }
/*      */           }
/*      */         } else {
/* 2794 */           if (c == 'X') {
/* 2795 */             c = 'y';
/* 2796 */             nv = new Object[3];
/* 2797 */             nv[1] = new StringBuffer(((StringBuffer)v[1]).toString()).append('M');
/*      */             
/* 2799 */             nv[0] = Character.valueOf('M');
/* 2800 */             nv[2] = Integer.valueOf(1);
/* 2801 */             vec.add(nv);
/* 2802 */           } else if (c == 'Y') {
/* 2803 */             c = 'M';
/* 2804 */             nv = new Object[3];
/* 2805 */             nv[1] = new StringBuffer(((StringBuffer)v[1]).toString()).append('d');
/*      */             
/* 2807 */             nv[0] = Character.valueOf('d');
/* 2808 */             nv[2] = Integer.valueOf(1);
/* 2809 */             vec.add(nv);
/*      */           }
/*      */           
/* 2812 */           ((StringBuffer)v[1]).append(c);
/*      */           
/* 2814 */           if (c == ((Character)v[0]).charValue()) {
/* 2815 */             v[2] = Integer.valueOf(n + 1);
/*      */           } else {
/* 2817 */             v[0] = Character.valueOf(c);
/* 2818 */             v[2] = Integer.valueOf(1);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 2823 */       int size = vecRemovelist.size();
/*      */       
/* 2825 */       for (int i = 0; i < size; i++) {
/* 2826 */         Object[] v = (Object[])vecRemovelist.get(i);
/* 2827 */         vec.remove(v);
/*      */       }
/*      */       
/* 2830 */       vecRemovelist.clear();
/*      */     }
/*      */     
/* 2833 */     int size = vec.size();
/*      */     
/* 2835 */     for (int i = 0; i < size; i++) {
/* 2836 */       Object[] v = (Object[])vec.get(i);
/* 2837 */       char c = ((Character)v[0]).charValue();
/* 2838 */       int n = ((Integer)v[2]).intValue();
/*      */       
/* 2840 */       boolean bk = getSuccessor(c, n) != c;
/* 2841 */       boolean atEnd = ((c == 's') || (c == 'm') || ((c == 'h') && (toTime))) && (bk);
/* 2842 */       boolean finishesAtDate = (bk) && (c == 'd') && (!toTime);
/* 2843 */       boolean containsEnd = ((StringBuffer)v[1]).toString().indexOf('W') != -1;
/*      */       
/*      */ 
/* 2846 */       if (((!atEnd) && (!finishesAtDate)) || (containsEnd)) {
/* 2847 */         vecRemovelist.add(v);
/*      */       }
/*      */     }
/*      */     
/* 2851 */     size = vecRemovelist.size();
/*      */     
/* 2853 */     for (int i = 0; i < size; i++) {
/* 2854 */       vec.remove(vecRemovelist.get(i));
/*      */     }
/*      */     
/* 2857 */     vecRemovelist.clear();
/* 2858 */     Object[] v = (Object[])vec.get(0);
/*      */     
/* 2860 */     StringBuffer format = (StringBuffer)v[1];
/* 2861 */     format.setLength(format.length() - 1);
/*      */     
/* 2863 */     return format.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized java.sql.ResultSetMetaData getMetaData()
/*      */     throws SQLException
/*      */   {
/* 2889 */     if (!isSelectQuery()) {
/* 2890 */       return null;
/*      */     }
/*      */     
/* 2893 */     PreparedStatement mdStmt = null;
/* 2894 */     ResultSet mdRs = null;
/*      */     
/* 2896 */     if (this.pstmtResultMetaData == null) {
/*      */       try {
/* 2898 */         mdStmt = new PreparedStatement(this.connection, this.originalSql, this.currentCatalog, this.parseInfo);
/*      */         
/*      */ 
/* 2901 */         mdStmt.setMaxRows(1);
/*      */         
/* 2903 */         int paramCount = this.parameterValues.length;
/*      */         
/* 2905 */         for (int i = 1; i <= paramCount; i++) {
/* 2906 */           mdStmt.setString(i, "");
/*      */         }
/*      */         
/* 2909 */         boolean hadResults = mdStmt.execute();
/*      */         
/* 2911 */         if (hadResults) {
/* 2912 */           mdRs = mdStmt.getResultSet();
/*      */           
/* 2914 */           this.pstmtResultMetaData = mdRs.getMetaData();
/*      */         } else {
/* 2916 */           this.pstmtResultMetaData = new ResultSetMetaData(new Field[0], this.connection.getUseOldAliasMetadataBehavior(), getExceptionInterceptor());
/*      */         }
/*      */       }
/*      */       finally
/*      */       {
/* 2921 */         SQLException sqlExRethrow = null;
/*      */         
/* 2923 */         if (mdRs != null) {
/*      */           try {
/* 2925 */             mdRs.close();
/*      */           } catch (SQLException sqlEx) {
/* 2927 */             sqlExRethrow = sqlEx;
/*      */           }
/*      */           
/* 2930 */           mdRs = null;
/*      */         }
/*      */         
/* 2933 */         if (mdStmt != null) {
/*      */           try {
/* 2935 */             mdStmt.close();
/*      */           } catch (SQLException sqlEx) {
/* 2937 */             sqlExRethrow = sqlEx;
/*      */           }
/*      */           
/* 2940 */           mdStmt = null;
/*      */         }
/*      */         
/* 2943 */         if (sqlExRethrow != null) {
/* 2944 */           throw sqlExRethrow;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2949 */     return this.pstmtResultMetaData;
/*      */   }
/*      */   
/*      */   protected synchronized boolean isSelectQuery() {
/* 2953 */     return StringUtils.startsWithIgnoreCaseAndWs(StringUtils.stripComments(this.originalSql, "'\"", "'\"", true, false, true, true), "SELECT");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized ParameterMetaData getParameterMetaData()
/*      */     throws SQLException
/*      */   {
/* 2964 */     if (this.parameterMetaData == null) {
/* 2965 */       if (this.connection.getGenerateSimpleParameterMetadata()) {
/* 2966 */         this.parameterMetaData = new MysqlParameterMetadata(this.parameterCount);
/*      */       } else {
/* 2968 */         this.parameterMetaData = new MysqlParameterMetadata(null, this.parameterCount, getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2973 */     return this.parameterMetaData;
/*      */   }
/*      */   
/*      */   ParseInfo getParseInfo() {
/* 2977 */     return this.parseInfo;
/*      */   }
/*      */   
/*      */   private final char getSuccessor(char c, int n) {
/* 2981 */     return (c == 's') && (n < 2) ? 's' : c == 'm' ? 's' : (c == 'm') && (n < 2) ? 'm' : c == 'H' ? 'm' : (c == 'H') && (n < 2) ? 'H' : c == 'd' ? 'H' : (c == 'd') && (n < 2) ? 'd' : c == 'M' ? 'd' : (c == 'M') && (n < 3) ? 'M' : (c == 'M') && (n == 2) ? 'Y' : c == 'y' ? 'M' : (c == 'y') && (n < 4) ? 'y' : (c == 'y') && (n == 2) ? 'X' : 'W';
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void hexEscapeBlock(byte[] buf, Buffer packet, int size)
/*      */     throws SQLException
/*      */   {
/* 3007 */     for (int i = 0; i < size; i++) {
/* 3008 */       byte b = buf[i];
/* 3009 */       int lowBits = (b & 0xFF) / 16;
/* 3010 */       int highBits = (b & 0xFF) % 16;
/*      */       
/* 3012 */       packet.writeByte(HEX_DIGITS[lowBits]);
/* 3013 */       packet.writeByte(HEX_DIGITS[highBits]);
/*      */     }
/*      */   }
/*      */   
/*      */   private synchronized void initializeFromParseInfo() throws SQLException {
/* 3018 */     this.staticSqlStrings = this.parseInfo.staticSql;
/* 3019 */     this.hasLimitClause = this.parseInfo.foundLimitClause;
/* 3020 */     this.isLoadDataQuery = this.parseInfo.foundLoadData;
/* 3021 */     this.firstCharOfStmt = this.parseInfo.firstStmtChar;
/*      */     
/* 3023 */     this.parameterCount = (this.staticSqlStrings.length - 1);
/*      */     
/* 3025 */     this.parameterValues = new byte[this.parameterCount][];
/* 3026 */     this.parameterStreams = new InputStream[this.parameterCount];
/* 3027 */     this.isStream = new boolean[this.parameterCount];
/* 3028 */     this.streamLengths = new int[this.parameterCount];
/* 3029 */     this.isNull = new boolean[this.parameterCount];
/* 3030 */     this.parameterTypes = new int[this.parameterCount];
/*      */     
/* 3032 */     clearParameters();
/*      */     
/* 3034 */     for (int j = 0; j < this.parameterCount; j++) {
/* 3035 */       this.isStream[j] = false;
/*      */     }
/*      */   }
/*      */   
/*      */   synchronized boolean isNull(int paramIndex) {
/* 3040 */     return this.isNull[paramIndex];
/*      */   }
/*      */   
/*      */   private final int readblock(InputStream i, byte[] b) throws SQLException {
/*      */     try {
/* 3045 */       return i.read(b);
/*      */     } catch (Throwable ex) {
/* 3047 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("PreparedStatement.56") + ex.getClass().getName(), "S1000", getExceptionInterceptor());
/*      */       
/* 3049 */       sqlEx.initCause(ex);
/*      */       
/* 3051 */       throw sqlEx;
/*      */     }
/*      */   }
/*      */   
/*      */   private final int readblock(InputStream i, byte[] b, int length) throws SQLException
/*      */   {
/*      */     try {
/* 3058 */       int lengthToRead = length;
/*      */       
/* 3060 */       if (lengthToRead > b.length) {
/* 3061 */         lengthToRead = b.length;
/*      */       }
/*      */       
/* 3064 */       return i.read(b, 0, lengthToRead);
/*      */     } catch (Throwable ex) {
/* 3066 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("PreparedStatement.56") + ex.getClass().getName(), "S1000", getExceptionInterceptor());
/*      */       
/* 3068 */       sqlEx.initCause(ex);
/*      */       
/* 3070 */       throw sqlEx;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void realClose(boolean calledExplicitly, boolean closeOpenResults)
/*      */     throws SQLException
/*      */   {
/* 3085 */     if ((this.useUsageAdvisor) && 
/* 3086 */       (this.numberOfExecutions <= 1)) {
/* 3087 */       String message = Messages.getString("PreparedStatement.43");
/*      */       
/* 3089 */       this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", this.currentCatalog, this.connectionId, getId(), -1, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, message));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3098 */     super.realClose(calledExplicitly, closeOpenResults);
/*      */     
/* 3100 */     this.dbmd = null;
/* 3101 */     this.originalSql = null;
/* 3102 */     this.staticSqlStrings = ((byte[][])null);
/* 3103 */     this.parameterValues = ((byte[][])null);
/* 3104 */     this.parameterStreams = null;
/* 3105 */     this.isStream = null;
/* 3106 */     this.streamLengths = null;
/* 3107 */     this.isNull = null;
/* 3108 */     this.streamConvertBuf = null;
/* 3109 */     this.parameterTypes = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setArray(int i, Array x)
/*      */     throws SQLException
/*      */   {
/* 3126 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAsciiStream(int parameterIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 3153 */     if (x == null) {
/* 3154 */       setNull(parameterIndex, 12);
/*      */     } else {
/* 3156 */       setBinaryStream(parameterIndex, x, length);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBigDecimal(int parameterIndex, BigDecimal x)
/*      */     throws SQLException
/*      */   {
/* 3174 */     if (x == null) {
/* 3175 */       setNull(parameterIndex, 3);
/*      */     } else {
/* 3177 */       setInternal(parameterIndex, StringUtils.fixDecimalExponent(StringUtils.consistentToString(x)));
/*      */       
/*      */ 
/* 3180 */       this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 3;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setBinaryStream(int parameterIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 3206 */     if (x == null) {
/* 3207 */       setNull(parameterIndex, -2);
/*      */     } else {
/* 3209 */       int parameterIndexOffset = getParameterIndexOffset();
/*      */       
/* 3211 */       if ((parameterIndex < 1) || (parameterIndex > this.staticSqlStrings.length))
/*      */       {
/* 3213 */         throw SQLError.createSQLException(Messages.getString("PreparedStatement.2") + parameterIndex + Messages.getString("PreparedStatement.3") + this.staticSqlStrings.length + Messages.getString("PreparedStatement.4"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 3218 */       if ((parameterIndexOffset == -1) && (parameterIndex == 1)) {
/* 3219 */         throw SQLError.createSQLException("Can't set IN parameter for return value of stored function call.", "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 3224 */       this.parameterStreams[(parameterIndex - 1 + parameterIndexOffset)] = x;
/* 3225 */       this.isStream[(parameterIndex - 1 + parameterIndexOffset)] = true;
/* 3226 */       this.streamLengths[(parameterIndex - 1 + parameterIndexOffset)] = length;
/* 3227 */       this.isNull[(parameterIndex - 1 + parameterIndexOffset)] = false;
/* 3228 */       this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 2004;
/*      */     }
/*      */   }
/*      */   
/*      */   public void setBlob(int parameterIndex, InputStream inputStream, long length) throws SQLException
/*      */   {
/* 3234 */     setBinaryStream(parameterIndex, inputStream, (int)length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBlob(int i, Blob x)
/*      */     throws SQLException
/*      */   {
/* 3249 */     if (x == null) {
/* 3250 */       setNull(i, 2004);
/*      */     } else {
/* 3252 */       ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
/*      */       
/* 3254 */       bytesOut.write(39);
/* 3255 */       escapeblockFast(x.getBytes(1L, (int)x.length()), bytesOut, (int)x.length());
/*      */       
/* 3257 */       bytesOut.write(39);
/*      */       
/* 3259 */       setInternal(i, bytesOut.toByteArray());
/*      */       
/* 3261 */       this.parameterTypes[(i - 1 + getParameterIndexOffset())] = 2004;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBoolean(int parameterIndex, boolean x)
/*      */     throws SQLException
/*      */   {
/* 3278 */     if (this.useTrueBoolean) {
/* 3279 */       setInternal(parameterIndex, x ? "1" : "0");
/*      */     } else {
/* 3281 */       setInternal(parameterIndex, x ? "'t'" : "'f'");
/*      */       
/* 3283 */       this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 16;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setByte(int parameterIndex, byte x)
/*      */     throws SQLException
/*      */   {
/* 3300 */     setInternal(parameterIndex, String.valueOf(x));
/*      */     
/* 3302 */     this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = -6;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBytes(int parameterIndex, byte[] x)
/*      */     throws SQLException
/*      */   {
/* 3319 */     setBytes(parameterIndex, x, true, true);
/*      */     
/* 3321 */     if (x != null) {
/* 3322 */       this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = -2;
/*      */     }
/*      */   }
/*      */   
/*      */   protected synchronized void setBytes(int parameterIndex, byte[] x, boolean checkForIntroducer, boolean escapeForMBChars)
/*      */     throws SQLException
/*      */   {
/* 3329 */     if (x == null) {
/* 3330 */       setNull(parameterIndex, -2);
/*      */     } else {
/* 3332 */       String connectionEncoding = this.connection.getEncoding();
/*      */       try
/*      */       {
/* 3335 */         if ((this.connection.isNoBackslashEscapesSet()) || ((escapeForMBChars) && (this.connection.getUseUnicode()) && (connectionEncoding != null) && (CharsetMapping.isMultibyteCharset(connectionEncoding))))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3343 */           ByteArrayOutputStream bOut = new ByteArrayOutputStream(x.length * 2 + 3);
/*      */           
/* 3345 */           bOut.write(120);
/* 3346 */           bOut.write(39);
/*      */           
/* 3348 */           for (int i = 0; i < x.length; i++) {
/* 3349 */             int lowBits = (x[i] & 0xFF) / 16;
/* 3350 */             int highBits = (x[i] & 0xFF) % 16;
/*      */             
/* 3352 */             bOut.write(HEX_DIGITS[lowBits]);
/* 3353 */             bOut.write(HEX_DIGITS[highBits]);
/*      */           }
/*      */           
/* 3356 */           bOut.write(39);
/*      */           
/* 3358 */           setInternal(parameterIndex, bOut.toByteArray());
/*      */           
/* 3360 */           return;
/*      */         }
/*      */       } catch (SQLException ex) {
/* 3363 */         throw ex;
/*      */       } catch (RuntimeException ex) {
/* 3365 */         SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", null);
/* 3366 */         sqlEx.initCause(ex);
/* 3367 */         throw sqlEx;
/*      */       }
/*      */       
/*      */ 
/* 3371 */       int numBytes = x.length;
/*      */       
/* 3373 */       int pad = 2;
/*      */       
/* 3375 */       boolean needsIntroducer = (checkForIntroducer) && (this.connection.versionMeetsMinimum(4, 1, 0));
/*      */       
/*      */ 
/* 3378 */       if (needsIntroducer) {
/* 3379 */         pad += 7;
/*      */       }
/*      */       
/* 3382 */       ByteArrayOutputStream bOut = new ByteArrayOutputStream(numBytes + pad);
/*      */       
/*      */ 
/* 3385 */       if (needsIntroducer) {
/* 3386 */         bOut.write(95);
/* 3387 */         bOut.write(98);
/* 3388 */         bOut.write(105);
/* 3389 */         bOut.write(110);
/* 3390 */         bOut.write(97);
/* 3391 */         bOut.write(114);
/* 3392 */         bOut.write(121);
/*      */       }
/* 3394 */       bOut.write(39);
/*      */       
/* 3396 */       for (int i = 0; i < numBytes; i++) {
/* 3397 */         byte b = x[i];
/*      */         
/* 3399 */         switch (b) {
/*      */         case 0: 
/* 3401 */           bOut.write(92);
/* 3402 */           bOut.write(48);
/*      */           
/* 3404 */           break;
/*      */         
/*      */         case 10: 
/* 3407 */           bOut.write(92);
/* 3408 */           bOut.write(110);
/*      */           
/* 3410 */           break;
/*      */         
/*      */         case 13: 
/* 3413 */           bOut.write(92);
/* 3414 */           bOut.write(114);
/*      */           
/* 3416 */           break;
/*      */         
/*      */         case 92: 
/* 3419 */           bOut.write(92);
/* 3420 */           bOut.write(92);
/*      */           
/* 3422 */           break;
/*      */         
/*      */         case 39: 
/* 3425 */           bOut.write(92);
/* 3426 */           bOut.write(39);
/*      */           
/* 3428 */           break;
/*      */         
/*      */         case 34: 
/* 3431 */           bOut.write(92);
/* 3432 */           bOut.write(34);
/*      */           
/* 3434 */           break;
/*      */         
/*      */         case 26: 
/* 3437 */           bOut.write(92);
/* 3438 */           bOut.write(90);
/*      */           
/* 3440 */           break;
/*      */         
/*      */         default: 
/* 3443 */           bOut.write(b);
/*      */         }
/*      */         
/*      */       }
/* 3447 */       bOut.write(39);
/*      */       
/* 3449 */       setInternal(parameterIndex, bOut.toByteArray());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setBytesNoEscape(int parameterIndex, byte[] parameterAsBytes)
/*      */     throws SQLException
/*      */   {
/* 3467 */     byte[] parameterWithQuotes = new byte[parameterAsBytes.length + 2];
/* 3468 */     parameterWithQuotes[0] = 39;
/* 3469 */     System.arraycopy(parameterAsBytes, 0, parameterWithQuotes, 1, parameterAsBytes.length);
/*      */     
/* 3471 */     parameterWithQuotes[(parameterAsBytes.length + 1)] = 39;
/*      */     
/* 3473 */     setInternal(parameterIndex, parameterWithQuotes);
/*      */   }
/*      */   
/*      */   protected void setBytesNoEscapeNoQuotes(int parameterIndex, byte[] parameterAsBytes) throws SQLException
/*      */   {
/* 3478 */     setInternal(parameterIndex, parameterAsBytes);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setCharacterStream(int parameterIndex, Reader reader, int length)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 3506 */       if (reader == null) {
/* 3507 */         setNull(parameterIndex, -1);
/*      */       } else {
/* 3509 */         char[] c = null;
/* 3510 */         int len = 0;
/*      */         
/* 3512 */         boolean useLength = this.connection.getUseStreamLengthsInPrepStmts();
/*      */         
/*      */ 
/* 3515 */         String forcedEncoding = this.connection.getClobCharacterEncoding();
/*      */         
/* 3517 */         if ((useLength) && (length != -1)) {
/* 3518 */           c = new char[length];
/*      */           
/* 3520 */           int numCharsRead = readFully(reader, c, length);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 3525 */           if (forcedEncoding == null) {
/* 3526 */             setString(parameterIndex, new String(c, 0, numCharsRead));
/*      */           } else {
/*      */             try {
/* 3529 */               setBytes(parameterIndex, StringUtils.getBytes(new String(c, 0, numCharsRead), forcedEncoding));
/*      */             }
/*      */             catch (UnsupportedEncodingException uee)
/*      */             {
/* 3533 */               throw SQLError.createSQLException("Unsupported character encoding " + forcedEncoding, "S1009", getExceptionInterceptor());
/*      */             }
/*      */           }
/*      */         }
/*      */         else {
/* 3538 */           c = new char['က'];
/*      */           
/* 3540 */           StringBuffer buf = new StringBuffer();
/*      */           
/* 3542 */           while ((len = reader.read(c)) != -1) {
/* 3543 */             buf.append(c, 0, len);
/*      */           }
/*      */           
/* 3546 */           if (forcedEncoding == null) {
/* 3547 */             setString(parameterIndex, buf.toString());
/*      */           } else {
/*      */             try {
/* 3550 */               setBytes(parameterIndex, StringUtils.getBytes(buf.toString(), forcedEncoding));
/*      */             }
/*      */             catch (UnsupportedEncodingException uee) {
/* 3553 */               throw SQLError.createSQLException("Unsupported character encoding " + forcedEncoding, "S1009", getExceptionInterceptor());
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/* 3559 */         this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 2005;
/*      */       }
/*      */     } catch (IOException ioEx) {
/* 3562 */       throw SQLError.createSQLException(ioEx.toString(), "S1000", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setClob(int i, Clob x)
/*      */     throws SQLException
/*      */   {
/* 3579 */     if (x == null) {
/* 3580 */       setNull(i, 2005);
/*      */     }
/*      */     else {
/* 3583 */       String forcedEncoding = this.connection.getClobCharacterEncoding();
/*      */       
/* 3585 */       if (forcedEncoding == null) {
/* 3586 */         setString(i, x.getSubString(1L, (int)x.length()));
/*      */       } else {
/*      */         try {
/* 3589 */           setBytes(i, StringUtils.getBytes(x.getSubString(1L, (int)x.length()), forcedEncoding));
/*      */         }
/*      */         catch (UnsupportedEncodingException uee) {
/* 3592 */           throw SQLError.createSQLException("Unsupported character encoding " + forcedEncoding, "S1009", getExceptionInterceptor());
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 3597 */       this.parameterTypes[(i - 1 + getParameterIndexOffset())] = 2005;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDate(int parameterIndex, java.sql.Date x)
/*      */     throws SQLException
/*      */   {
/* 3615 */     setDate(parameterIndex, x, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDate(int parameterIndex, java.sql.Date x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 3634 */     if (x == null) {
/* 3635 */       setNull(parameterIndex, 91);
/*      */     } else {
/* 3637 */       checkClosed();
/*      */       
/* 3639 */       if (!this.useLegacyDatetimeCode) {
/* 3640 */         newSetDateInternal(parameterIndex, x, cal);
/*      */       }
/*      */       else
/*      */       {
/* 3644 */         SimpleDateFormat dateFormatter = new SimpleDateFormat("''yyyy-MM-dd''", Locale.US);
/*      */         
/* 3646 */         setInternal(parameterIndex, dateFormatter.format(x));
/*      */         
/* 3648 */         this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 91;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setDouble(int parameterIndex, double x)
/*      */     throws SQLException
/*      */   {
/* 3667 */     if ((!this.connection.getAllowNanAndInf()) && ((x == Double.POSITIVE_INFINITY) || (x == Double.NEGATIVE_INFINITY) || (Double.isNaN(x))))
/*      */     {
/*      */ 
/* 3670 */       throw SQLError.createSQLException("'" + x + "' is not a valid numeric or approximate numeric value", "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 3676 */     setInternal(parameterIndex, StringUtils.fixDecimalExponent(String.valueOf(x)));
/*      */     
/*      */ 
/* 3679 */     this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 8;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFloat(int parameterIndex, float x)
/*      */     throws SQLException
/*      */   {
/* 3695 */     setInternal(parameterIndex, StringUtils.fixDecimalExponent(String.valueOf(x)));
/*      */     
/*      */ 
/* 3698 */     this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 6;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setInt(int parameterIndex, int x)
/*      */     throws SQLException
/*      */   {
/* 3714 */     setInternal(parameterIndex, String.valueOf(x));
/*      */     
/* 3716 */     this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 4;
/*      */   }
/*      */   
/*      */   protected final synchronized void setInternal(int paramIndex, byte[] val) throws SQLException
/*      */   {
/* 3721 */     if (this.isClosed) {
/* 3722 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.48"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 3726 */     int parameterIndexOffset = getParameterIndexOffset();
/*      */     
/* 3728 */     checkBounds(paramIndex, parameterIndexOffset);
/*      */     
/* 3730 */     this.isStream[(paramIndex - 1 + parameterIndexOffset)] = false;
/* 3731 */     this.isNull[(paramIndex - 1 + parameterIndexOffset)] = false;
/* 3732 */     this.parameterStreams[(paramIndex - 1 + parameterIndexOffset)] = null;
/* 3733 */     this.parameterValues[(paramIndex - 1 + parameterIndexOffset)] = val;
/*      */   }
/*      */   
/*      */   private synchronized void checkBounds(int paramIndex, int parameterIndexOffset) throws SQLException
/*      */   {
/* 3738 */     if (paramIndex < 1) {
/* 3739 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.49") + paramIndex + Messages.getString("PreparedStatement.50"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/* 3743 */     if (paramIndex > this.parameterCount) {
/* 3744 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.51") + paramIndex + Messages.getString("PreparedStatement.52") + this.parameterValues.length + Messages.getString("PreparedStatement.53"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3749 */     if ((parameterIndexOffset == -1) && (paramIndex == 1)) {
/* 3750 */       throw SQLError.createSQLException("Can't set IN parameter for return value of stored function call.", "S1009", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */   protected final synchronized void setInternal(int paramIndex, String val)
/*      */     throws SQLException
/*      */   {
/* 3757 */     checkClosed();
/*      */     
/* 3759 */     byte[] parameterAsBytes = null;
/*      */     
/* 3761 */     if (this.charConverter != null) {
/* 3762 */       parameterAsBytes = this.charConverter.toBytes(val);
/*      */     } else {
/* 3764 */       parameterAsBytes = StringUtils.getBytes(val, this.charConverter, this.charEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 3770 */     setInternal(paramIndex, parameterAsBytes);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLong(int parameterIndex, long x)
/*      */     throws SQLException
/*      */   {
/* 3786 */     setInternal(parameterIndex, String.valueOf(x));
/*      */     
/* 3788 */     this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = -5;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setNull(int parameterIndex, int sqlType)
/*      */     throws SQLException
/*      */   {
/* 3808 */     setInternal(parameterIndex, "null");
/* 3809 */     this.isNull[(parameterIndex - 1 + getParameterIndexOffset())] = true;
/*      */     
/* 3811 */     this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNull(int parameterIndex, int sqlType, String arg)
/*      */     throws SQLException
/*      */   {
/* 3833 */     setNull(parameterIndex, sqlType);
/*      */     
/* 3835 */     this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 0;
/*      */   }
/*      */   
/*      */   private void setNumericObject(int parameterIndex, Object parameterObj, int targetSqlType, int scale) throws SQLException {
/*      */     Number parameterAsNum;
/*      */     Number parameterAsNum;
/* 3841 */     if ((parameterObj instanceof Boolean)) {
/* 3842 */       parameterAsNum = ((Boolean)parameterObj).booleanValue() ? Integer.valueOf(1) : Integer.valueOf(0);
/*      */ 
/*      */     }
/* 3845 */     else if ((parameterObj instanceof String)) { Number parameterAsNum;
/* 3846 */       switch (targetSqlType) {
/*      */       case -7:  Number parameterAsNum;
/* 3848 */         if (("1".equals((String)parameterObj)) || ("0".equals((String)parameterObj)))
/*      */         {
/* 3850 */           parameterAsNum = Integer.valueOf((String)parameterObj);
/*      */         } else {
/* 3852 */           boolean parameterAsBoolean = "true".equalsIgnoreCase((String)parameterObj);
/*      */           
/*      */ 
/* 3855 */           parameterAsNum = parameterAsBoolean ? Integer.valueOf(1) : Integer.valueOf(0);
/*      */         }
/*      */         
/*      */ 
/* 3859 */         break;
/*      */       
/*      */       case -6: 
/*      */       case 4: 
/*      */       case 5: 
/* 3864 */         parameterAsNum = Integer.valueOf((String)parameterObj);
/*      */         
/*      */ 
/* 3867 */         break;
/*      */       
/*      */       case -5: 
/* 3870 */         parameterAsNum = Long.valueOf((String)parameterObj);
/*      */         
/*      */ 
/* 3873 */         break;
/*      */       
/*      */       case 7: 
/* 3876 */         parameterAsNum = Float.valueOf((String)parameterObj);
/*      */         
/*      */ 
/* 3879 */         break;
/*      */       
/*      */       case 6: 
/*      */       case 8: 
/* 3883 */         parameterAsNum = Double.valueOf((String)parameterObj);
/*      */         
/*      */ 
/* 3886 */         break;
/*      */       case -4: case -3: case -2: 
/*      */       case -1: case 0: 
/*      */       case 1: case 2: 
/*      */       case 3: default: 
/* 3891 */         parameterAsNum = new BigDecimal((String)parameterObj);break;
/*      */       }
/*      */     }
/*      */     else {
/* 3895 */       parameterAsNum = (Number)parameterObj;
/*      */     }
/*      */     
/* 3898 */     switch (targetSqlType) {
/*      */     case -7: 
/*      */     case -6: 
/*      */     case 4: 
/*      */     case 5: 
/* 3903 */       setInt(parameterIndex, parameterAsNum.intValue());
/*      */       
/* 3905 */       break;
/*      */     
/*      */     case -5: 
/* 3908 */       setLong(parameterIndex, parameterAsNum.longValue());
/*      */       
/* 3910 */       break;
/*      */     
/*      */     case 7: 
/* 3913 */       setFloat(parameterIndex, parameterAsNum.floatValue());
/*      */       
/* 3915 */       break;
/*      */     
/*      */     case 6: 
/*      */     case 8: 
/* 3919 */       setDouble(parameterIndex, parameterAsNum.doubleValue());
/*      */       
/* 3921 */       break;
/*      */     
/*      */ 
/*      */     case 2: 
/*      */     case 3: 
/* 3926 */       if ((parameterAsNum instanceof BigDecimal)) {
/* 3927 */         BigDecimal scaledBigDecimal = null;
/*      */         try
/*      */         {
/* 3930 */           scaledBigDecimal = ((BigDecimal)parameterAsNum).setScale(scale);
/*      */         }
/*      */         catch (ArithmeticException ex) {
/*      */           try {
/* 3934 */             scaledBigDecimal = ((BigDecimal)parameterAsNum).setScale(scale, 4);
/*      */           }
/*      */           catch (ArithmeticException arEx)
/*      */           {
/* 3938 */             throw SQLError.createSQLException("Can't set scale of '" + scale + "' for DECIMAL argument '" + parameterAsNum + "'", "S1009", getExceptionInterceptor());
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3947 */         setBigDecimal(parameterIndex, scaledBigDecimal);
/* 3948 */       } else if ((parameterAsNum instanceof BigInteger)) {
/* 3949 */         setBigDecimal(parameterIndex, new BigDecimal((BigInteger)parameterAsNum, scale));
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/* 3955 */         setBigDecimal(parameterIndex, new BigDecimal(parameterAsNum.doubleValue()));
/*      */       }
/*      */       
/*      */       break;
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */   public synchronized void setObject(int parameterIndex, Object parameterObj)
/*      */     throws SQLException
/*      */   {
/* 3966 */     if (parameterObj == null) {
/* 3967 */       setNull(parameterIndex, 1111);
/*      */     }
/* 3969 */     else if ((parameterObj instanceof Byte)) {
/* 3970 */       setInt(parameterIndex, ((Byte)parameterObj).intValue());
/* 3971 */     } else if ((parameterObj instanceof String)) {
/* 3972 */       setString(parameterIndex, (String)parameterObj);
/* 3973 */     } else if ((parameterObj instanceof BigDecimal)) {
/* 3974 */       setBigDecimal(parameterIndex, (BigDecimal)parameterObj);
/* 3975 */     } else if ((parameterObj instanceof Short)) {
/* 3976 */       setShort(parameterIndex, ((Short)parameterObj).shortValue());
/* 3977 */     } else if ((parameterObj instanceof Integer)) {
/* 3978 */       setInt(parameterIndex, ((Integer)parameterObj).intValue());
/* 3979 */     } else if ((parameterObj instanceof Long)) {
/* 3980 */       setLong(parameterIndex, ((Long)parameterObj).longValue());
/* 3981 */     } else if ((parameterObj instanceof Float)) {
/* 3982 */       setFloat(parameterIndex, ((Float)parameterObj).floatValue());
/* 3983 */     } else if ((parameterObj instanceof Double)) {
/* 3984 */       setDouble(parameterIndex, ((Double)parameterObj).doubleValue());
/* 3985 */     } else if ((parameterObj instanceof byte[])) {
/* 3986 */       setBytes(parameterIndex, (byte[])parameterObj);
/* 3987 */     } else if ((parameterObj instanceof java.sql.Date)) {
/* 3988 */       setDate(parameterIndex, (java.sql.Date)parameterObj);
/* 3989 */     } else if ((parameterObj instanceof Time)) {
/* 3990 */       setTime(parameterIndex, (Time)parameterObj);
/* 3991 */     } else if ((parameterObj instanceof Timestamp)) {
/* 3992 */       setTimestamp(parameterIndex, (Timestamp)parameterObj);
/* 3993 */     } else if ((parameterObj instanceof Boolean)) {
/* 3994 */       setBoolean(parameterIndex, ((Boolean)parameterObj).booleanValue());
/*      */     }
/* 3996 */     else if ((parameterObj instanceof InputStream)) {
/* 3997 */       setBinaryStream(parameterIndex, (InputStream)parameterObj, -1);
/* 3998 */     } else if ((parameterObj instanceof Blob)) {
/* 3999 */       setBlob(parameterIndex, (Blob)parameterObj);
/* 4000 */     } else if ((parameterObj instanceof Clob)) {
/* 4001 */       setClob(parameterIndex, (Clob)parameterObj);
/* 4002 */     } else if ((this.connection.getTreatUtilDateAsTimestamp()) && ((parameterObj instanceof java.util.Date)))
/*      */     {
/* 4004 */       setTimestamp(parameterIndex, new Timestamp(((java.util.Date)parameterObj).getTime()));
/*      */     }
/* 4006 */     else if ((parameterObj instanceof BigInteger)) {
/* 4007 */       setString(parameterIndex, parameterObj.toString());
/*      */     } else {
/* 4009 */       setSerializableObject(parameterIndex, parameterObj);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setObject(int parameterIndex, Object parameterObj, int targetSqlType)
/*      */     throws SQLException
/*      */   {
/* 4030 */     if (!(parameterObj instanceof BigDecimal)) {
/* 4031 */       setObject(parameterIndex, parameterObj, targetSqlType, 0);
/*      */     } else {
/* 4033 */       setObject(parameterIndex, parameterObj, targetSqlType, ((BigDecimal)parameterObj).scale());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setObject(int parameterIndex, Object parameterObj, int targetSqlType, int scale)
/*      */     throws SQLException
/*      */   {
/* 4069 */     if (parameterObj == null) {
/* 4070 */       setNull(parameterIndex, 1111);
/*      */     } else {
/*      */       try {
/* 4073 */         switch (targetSqlType)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         case 16: 
/* 4093 */           if ((parameterObj instanceof Boolean)) {
/* 4094 */             setBoolean(parameterIndex, ((Boolean)parameterObj).booleanValue());
/*      */ 
/*      */           }
/* 4097 */           else if ((parameterObj instanceof String)) {
/* 4098 */             setBoolean(parameterIndex, ("true".equalsIgnoreCase((String)parameterObj)) || (!"0".equalsIgnoreCase((String)parameterObj)));
/*      */ 
/*      */ 
/*      */           }
/* 4102 */           else if ((parameterObj instanceof Number)) {
/* 4103 */             int intValue = ((Number)parameterObj).intValue();
/*      */             
/* 4105 */             setBoolean(parameterIndex, intValue != 0);
/*      */           }
/*      */           else
/*      */           {
/* 4109 */             throw SQLError.createSQLException("No conversion from " + parameterObj.getClass().getName() + " to Types.BOOLEAN possible.", "S1009", getExceptionInterceptor());
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */           break;
/*      */         case -7: 
/*      */         case -6: 
/*      */         case -5: 
/*      */         case 2: 
/*      */         case 3: 
/*      */         case 4: 
/*      */         case 5: 
/*      */         case 6: 
/*      */         case 7: 
/*      */         case 8: 
/* 4125 */           setNumericObject(parameterIndex, parameterObj, targetSqlType, scale);
/*      */           
/* 4127 */           break;
/*      */         
/*      */         case -1: 
/*      */         case 1: 
/*      */         case 12: 
/* 4132 */           if ((parameterObj instanceof BigDecimal)) {
/* 4133 */             setString(parameterIndex, StringUtils.fixDecimalExponent(StringUtils.consistentToString((BigDecimal)parameterObj)));
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/* 4139 */             setString(parameterIndex, parameterObj.toString());
/*      */           }
/*      */           
/* 4142 */           break;
/*      */         
/*      */ 
/*      */         case 2005: 
/* 4146 */           if ((parameterObj instanceof Clob)) {
/* 4147 */             setClob(parameterIndex, (Clob)parameterObj);
/*      */           } else {
/* 4149 */             setString(parameterIndex, parameterObj.toString());
/*      */           }
/*      */           
/* 4152 */           break;
/*      */         
/*      */ 
/*      */         case -4: 
/*      */         case -3: 
/*      */         case -2: 
/*      */         case 2004: 
/* 4159 */           if ((parameterObj instanceof byte[])) {
/* 4160 */             setBytes(parameterIndex, (byte[])parameterObj);
/* 4161 */           } else if ((parameterObj instanceof Blob)) {
/* 4162 */             setBlob(parameterIndex, (Blob)parameterObj);
/*      */           } else {
/* 4164 */             setBytes(parameterIndex, StringUtils.getBytes(parameterObj.toString(), this.charConverter, this.charEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), getExceptionInterceptor()));
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4171 */           break;
/*      */         case 91: 
/*      */         case 93: 
/*      */           java.util.Date parameterAsDate;
/*      */           
/*      */           java.util.Date parameterAsDate;
/*      */           
/* 4178 */           if ((parameterObj instanceof String)) {
/* 4179 */             ParsePosition pp = new ParsePosition(0);
/* 4180 */             DateFormat sdf = new SimpleDateFormat(getDateTimePattern((String)parameterObj, false), Locale.US);
/*      */             
/* 4182 */             parameterAsDate = sdf.parse((String)parameterObj, pp);
/*      */           } else {
/* 4184 */             parameterAsDate = (java.util.Date)parameterObj;
/*      */           }
/*      */           
/* 4187 */           switch (targetSqlType)
/*      */           {
/*      */           case 91: 
/* 4190 */             if ((parameterAsDate instanceof java.sql.Date)) {
/* 4191 */               setDate(parameterIndex, (java.sql.Date)parameterAsDate);
/*      */             }
/*      */             else {
/* 4194 */               setDate(parameterIndex, new java.sql.Date(parameterAsDate.getTime()));
/*      */             }
/*      */             
/*      */ 
/* 4198 */             break;
/*      */           
/*      */ 
/*      */           case 93: 
/* 4202 */             if ((parameterAsDate instanceof Timestamp)) {
/* 4203 */               setTimestamp(parameterIndex, (Timestamp)parameterAsDate);
/*      */             }
/*      */             else {
/* 4206 */               setTimestamp(parameterIndex, new Timestamp(parameterAsDate.getTime()));
/*      */             }
/*      */             
/*      */ 
/*      */             break;
/*      */           }
/*      */           
/*      */           
/* 4214 */           break;
/*      */         
/*      */ 
/*      */         case 92: 
/* 4218 */           if ((parameterObj instanceof String)) {
/* 4219 */             DateFormat sdf = new SimpleDateFormat(getDateTimePattern((String)parameterObj, true), Locale.US);
/*      */             
/* 4221 */             setTime(parameterIndex, new Time(sdf.parse((String)parameterObj).getTime()));
/*      */           }
/* 4223 */           else if ((parameterObj instanceof Timestamp)) {
/* 4224 */             Timestamp xT = (Timestamp)parameterObj;
/* 4225 */             setTime(parameterIndex, new Time(xT.getTime()));
/*      */           } else {
/* 4227 */             setTime(parameterIndex, (Time)parameterObj);
/*      */           }
/*      */           
/* 4230 */           break;
/*      */         
/*      */         case 1111: 
/* 4233 */           setSerializableObject(parameterIndex, parameterObj);
/*      */           
/* 4235 */           break;
/*      */         
/*      */         default: 
/* 4238 */           throw SQLError.createSQLException(Messages.getString("PreparedStatement.16"), "S1000", getExceptionInterceptor());
/*      */         }
/*      */         
/*      */       }
/*      */       catch (Exception ex) {
/* 4243 */         if ((ex instanceof SQLException)) {
/* 4244 */           throw ((SQLException)ex);
/*      */         }
/*      */         
/* 4247 */         SQLException sqlEx = SQLError.createSQLException(Messages.getString("PreparedStatement.17") + parameterObj.getClass().toString() + Messages.getString("PreparedStatement.18") + ex.getClass().getName() + Messages.getString("PreparedStatement.19") + ex.getMessage(), "S1000", getExceptionInterceptor());
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4255 */         sqlEx.initCause(ex);
/*      */         
/* 4257 */         throw sqlEx;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected int setOneBatchedParameterSet(java.sql.PreparedStatement batchedStatement, int batchedParamIndex, Object paramSet)
/*      */     throws SQLException
/*      */   {
/* 4265 */     BatchParams paramArg = (BatchParams)paramSet;
/*      */     
/* 4267 */     boolean[] isNullBatch = paramArg.isNull;
/* 4268 */     boolean[] isStreamBatch = paramArg.isStream;
/*      */     
/* 4270 */     for (int j = 0; j < isNullBatch.length; j++) {
/* 4271 */       if (isNullBatch[j] != 0) {
/* 4272 */         batchedStatement.setNull(batchedParamIndex++, 0);
/*      */       }
/* 4274 */       else if (isStreamBatch[j] != 0) {
/* 4275 */         batchedStatement.setBinaryStream(batchedParamIndex++, paramArg.parameterStreams[j], paramArg.streamLengths[j]);
/*      */       }
/*      */       else
/*      */       {
/* 4279 */         ((PreparedStatement)batchedStatement).setBytesNoEscapeNoQuotes(batchedParamIndex++, paramArg.parameterStrings[j]);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4286 */     return batchedParamIndex;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRef(int i, Ref x)
/*      */     throws SQLException
/*      */   {
/* 4303 */     throw SQLError.notImplemented();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   synchronized void setResultSetConcurrency(int concurrencyFlag)
/*      */   {
/* 4313 */     this.resultSetConcurrency = concurrencyFlag;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   synchronized void setResultSetType(int typeFlag)
/*      */   {
/* 4323 */     this.resultSetType = typeFlag;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void setRetrieveGeneratedKeys(boolean retrieveGeneratedKeys)
/*      */   {
/* 4332 */     this.retrieveGeneratedKeys = retrieveGeneratedKeys;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void setSerializableObject(int parameterIndex, Object parameterObj)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 4352 */       ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
/* 4353 */       ObjectOutputStream objectOut = new ObjectOutputStream(bytesOut);
/* 4354 */       objectOut.writeObject(parameterObj);
/* 4355 */       objectOut.flush();
/* 4356 */       objectOut.close();
/* 4357 */       bytesOut.flush();
/* 4358 */       bytesOut.close();
/*      */       
/* 4360 */       byte[] buf = bytesOut.toByteArray();
/* 4361 */       ByteArrayInputStream bytesIn = new ByteArrayInputStream(buf);
/* 4362 */       setBinaryStream(parameterIndex, bytesIn, buf.length);
/* 4363 */       this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = -2;
/*      */     } catch (Exception ex) {
/* 4365 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("PreparedStatement.54") + ex.getClass().getName(), "S1009", getExceptionInterceptor());
/*      */       
/*      */ 
/* 4368 */       sqlEx.initCause(ex);
/*      */       
/* 4370 */       throw sqlEx;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setShort(int parameterIndex, short x)
/*      */     throws SQLException
/*      */   {
/* 4387 */     setInternal(parameterIndex, String.valueOf(x));
/*      */     
/* 4389 */     this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 5;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setString(int parameterIndex, String x)
/*      */     throws SQLException
/*      */   {
/* 4407 */     if (x == null) {
/* 4408 */       setNull(parameterIndex, 1);
/*      */     } else {
/* 4410 */       checkClosed();
/*      */       
/* 4412 */       int stringLength = x.length();
/*      */       
/* 4414 */       if (this.connection.isNoBackslashEscapesSet())
/*      */       {
/*      */ 
/* 4417 */         boolean needsHexEscape = isEscapeNeededForString(x, stringLength);
/*      */         
/*      */ 
/* 4420 */         if (!needsHexEscape) {
/* 4421 */           byte[] parameterAsBytes = null;
/*      */           
/* 4423 */           StringBuffer quotedString = new StringBuffer(x.length() + 2);
/* 4424 */           quotedString.append('\'');
/* 4425 */           quotedString.append(x);
/* 4426 */           quotedString.append('\'');
/*      */           
/* 4428 */           if (!this.isLoadDataQuery) {
/* 4429 */             parameterAsBytes = StringUtils.getBytes(quotedString.toString(), this.charConverter, this.charEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/* 4435 */             parameterAsBytes = StringUtils.getBytes(quotedString.toString());
/*      */           }
/*      */           
/* 4438 */           setInternal(parameterIndex, parameterAsBytes);
/*      */         } else {
/* 4440 */           byte[] parameterAsBytes = null;
/*      */           
/* 4442 */           if (!this.isLoadDataQuery) {
/* 4443 */             parameterAsBytes = StringUtils.getBytes(x, this.charConverter, this.charEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/* 4449 */             parameterAsBytes = StringUtils.getBytes(x);
/*      */           }
/*      */           
/* 4452 */           setBytes(parameterIndex, parameterAsBytes);
/*      */         }
/*      */         
/* 4455 */         return;
/*      */       }
/*      */       
/* 4458 */       String parameterAsString = x;
/* 4459 */       boolean needsQuoted = true;
/*      */       
/* 4461 */       if ((this.isLoadDataQuery) || (isEscapeNeededForString(x, stringLength))) {
/* 4462 */         needsQuoted = false;
/*      */         
/* 4464 */         StringBuffer buf = new StringBuffer((int)(x.length() * 1.1D));
/*      */         
/* 4466 */         buf.append('\'');
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4475 */         for (int i = 0; i < stringLength; i++) {
/* 4476 */           char c = x.charAt(i);
/*      */           
/* 4478 */           switch (c) {
/*      */           case '\000': 
/* 4480 */             buf.append('\\');
/* 4481 */             buf.append('0');
/*      */             
/* 4483 */             break;
/*      */           
/*      */           case '\n': 
/* 4486 */             buf.append('\\');
/* 4487 */             buf.append('n');
/*      */             
/* 4489 */             break;
/*      */           
/*      */           case '\r': 
/* 4492 */             buf.append('\\');
/* 4493 */             buf.append('r');
/*      */             
/* 4495 */             break;
/*      */           
/*      */           case '\\': 
/* 4498 */             buf.append('\\');
/* 4499 */             buf.append('\\');
/*      */             
/* 4501 */             break;
/*      */           
/*      */           case '\'': 
/* 4504 */             buf.append('\\');
/* 4505 */             buf.append('\'');
/*      */             
/* 4507 */             break;
/*      */           
/*      */           case '"': 
/* 4510 */             if (this.usingAnsiMode) {
/* 4511 */               buf.append('\\');
/*      */             }
/*      */             
/* 4514 */             buf.append('"');
/*      */             
/* 4516 */             break;
/*      */           
/*      */           case '\032': 
/* 4519 */             buf.append('\\');
/* 4520 */             buf.append('Z');
/*      */             
/* 4522 */             break;
/*      */           
/*      */ 
/*      */           case '¥': 
/*      */           case '₩': 
/* 4527 */             if (this.charsetEncoder != null) {
/* 4528 */               CharBuffer cbuf = CharBuffer.allocate(1);
/* 4529 */               ByteBuffer bbuf = ByteBuffer.allocate(1);
/* 4530 */               cbuf.put(c);
/* 4531 */               cbuf.position(0);
/* 4532 */               this.charsetEncoder.encode(cbuf, bbuf, true);
/* 4533 */               if (bbuf.get(0) == 92) {
/* 4534 */                 buf.append('\\');
/*      */               }
/*      */             }
/*      */             break;
/*      */           }
/*      */           
/* 4540 */           buf.append(c);
/*      */         }
/*      */         
/*      */ 
/* 4544 */         buf.append('\'');
/*      */         
/* 4546 */         parameterAsString = buf.toString();
/*      */       }
/*      */       
/* 4549 */       byte[] parameterAsBytes = null;
/*      */       
/* 4551 */       if (!this.isLoadDataQuery) {
/* 4552 */         if (needsQuoted) {
/* 4553 */           parameterAsBytes = StringUtils.getBytesWrapped(parameterAsString, '\'', '\'', this.charConverter, this.charEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 4558 */           parameterAsBytes = StringUtils.getBytes(parameterAsString, this.charConverter, this.charEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 4565 */         parameterAsBytes = StringUtils.getBytes(parameterAsString);
/*      */       }
/*      */       
/* 4568 */       setInternal(parameterIndex, parameterAsBytes);
/*      */       
/* 4570 */       this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 12;
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean isEscapeNeededForString(String x, int stringLength) {
/* 4575 */     boolean needsHexEscape = false;
/*      */     
/* 4577 */     for (int i = 0; i < stringLength; i++) {
/* 4578 */       char c = x.charAt(i);
/*      */       
/* 4580 */       switch (c)
/*      */       {
/*      */       case '\000': 
/* 4583 */         needsHexEscape = true;
/* 4584 */         break;
/*      */       
/*      */       case '\n': 
/* 4587 */         needsHexEscape = true;
/*      */         
/* 4589 */         break;
/*      */       
/*      */       case '\r': 
/* 4592 */         needsHexEscape = true;
/* 4593 */         break;
/*      */       
/*      */       case '\\': 
/* 4596 */         needsHexEscape = true;
/*      */         
/* 4598 */         break;
/*      */       
/*      */       case '\'': 
/* 4601 */         needsHexEscape = true;
/*      */         
/* 4603 */         break;
/*      */       
/*      */       case '"': 
/* 4606 */         needsHexEscape = true;
/*      */         
/* 4608 */         break;
/*      */       
/*      */       case '\032': 
/* 4611 */         needsHexEscape = true;
/*      */       }
/*      */       
/*      */       
/* 4615 */       if (needsHexEscape) {
/*      */         break;
/*      */       }
/*      */     }
/* 4619 */     return needsHexEscape;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTime(int parameterIndex, Time x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 4638 */     setTimeInternal(parameterIndex, x, cal, cal.getTimeZone(), true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTime(int parameterIndex, Time x)
/*      */     throws SQLException
/*      */   {
/* 4655 */     setTimeInternal(parameterIndex, x, null, Util.getDefaultTimeZone(), false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private synchronized void setTimeInternal(int parameterIndex, Time x, Calendar targetCalendar, TimeZone tz, boolean rollForward)
/*      */     throws SQLException
/*      */   {
/* 4676 */     if (x == null) {
/* 4677 */       setNull(parameterIndex, 92);
/*      */     } else {
/* 4679 */       checkClosed();
/*      */       
/* 4681 */       if (!this.useLegacyDatetimeCode) {
/* 4682 */         newSetTimeInternal(parameterIndex, x, targetCalendar);
/*      */       } else {
/* 4684 */         Calendar sessionCalendar = getCalendarInstanceForSessionOrNew();
/*      */         
/* 4686 */         synchronized (sessionCalendar) {
/* 4687 */           x = TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, x, tz, this.connection.getServerTimezoneTZ(), rollForward);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4694 */         setInternal(parameterIndex, "'" + x.toString() + "'");
/*      */       }
/*      */       
/* 4697 */       this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 92;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 4717 */     setTimestampInternal(parameterIndex, x, cal, cal.getTimeZone(), true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTimestamp(int parameterIndex, Timestamp x)
/*      */     throws SQLException
/*      */   {
/* 4734 */     setTimestampInternal(parameterIndex, x, null, Util.getDefaultTimeZone(), false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private synchronized void setTimestampInternal(int parameterIndex, Timestamp x, Calendar targetCalendar, TimeZone tz, boolean rollForward)
/*      */     throws SQLException
/*      */   {
/* 4754 */     if (x == null) {
/* 4755 */       setNull(parameterIndex, 93);
/*      */     } else {
/* 4757 */       checkClosed();
/*      */       
/* 4759 */       if (!this.useLegacyDatetimeCode) {
/* 4760 */         newSetTimestampInternal(parameterIndex, x, targetCalendar);
/*      */       } else {
/* 4762 */         String timestampString = null;
/*      */         
/* 4764 */         Calendar sessionCalendar = this.connection.getUseJDBCCompliantTimezoneShift() ? this.connection.getUtcCalendar() : getCalendarInstanceForSessionOrNew();
/*      */         
/*      */ 
/*      */ 
/* 4768 */         synchronized (sessionCalendar) {
/* 4769 */           x = TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, x, tz, this.connection.getServerTimezoneTZ(), rollForward);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4776 */         if (this.connection.getUseSSPSCompatibleTimezoneShift()) {
/* 4777 */           doSSPSCompatibleTimezoneShift(parameterIndex, x, sessionCalendar);
/*      */         } else {
/* 4779 */           synchronized (this) {
/* 4780 */             if (this.tsdf == null) {
/* 4781 */               this.tsdf = new SimpleDateFormat("''yyyy-MM-dd HH:mm:ss''", Locale.US);
/*      */             }
/*      */             
/* 4784 */             timestampString = this.tsdf.format(x);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4799 */             setInternal(parameterIndex, timestampString);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 4805 */       this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 93;
/*      */     }
/*      */   }
/*      */   
/*      */   private synchronized void newSetTimestampInternal(int parameterIndex, Timestamp x, Calendar targetCalendar) throws SQLException
/*      */   {
/* 4811 */     if (this.tsdf == null) {
/* 4812 */       this.tsdf = new SimpleDateFormat("''yyyy-MM-dd HH:mm:ss", Locale.US);
/*      */     }
/*      */     
/* 4815 */     String timestampString = null;
/*      */     
/* 4817 */     if (targetCalendar != null) {
/* 4818 */       targetCalendar.setTime(x);
/* 4819 */       this.tsdf.setTimeZone(targetCalendar.getTimeZone());
/*      */       
/* 4821 */       timestampString = this.tsdf.format(x);
/*      */     } else {
/* 4823 */       this.tsdf.setTimeZone(this.connection.getServerTimezoneTZ());
/* 4824 */       timestampString = this.tsdf.format(x);
/*      */     }
/*      */     
/* 4827 */     StringBuffer buf = new StringBuffer();
/* 4828 */     buf.append(timestampString);
/* 4829 */     buf.append('.');
/* 4830 */     buf.append(formatNanos(x.getNanos()));
/* 4831 */     buf.append('\'');
/*      */     
/* 4833 */     setInternal(parameterIndex, buf.toString());
/*      */   }
/*      */   
/*      */   private String formatNanos(int nanos) {
/* 4837 */     if ((!this.serverSupportsFracSecs) || (nanos == 0)) {
/* 4838 */       return "0";
/*      */     }
/*      */     
/* 4841 */     boolean usingMicros = true;
/*      */     
/* 4843 */     if (usingMicros) {
/* 4844 */       nanos /= 1000;
/*      */     }
/*      */     
/* 4847 */     int digitCount = usingMicros ? 6 : 9;
/*      */     
/* 4849 */     String nanosString = Integer.toString(nanos);
/* 4850 */     String zeroPadding = usingMicros ? "000000" : "000000000";
/*      */     
/* 4852 */     nanosString = zeroPadding.substring(0, digitCount - nanosString.length()) + nanosString;
/*      */     
/*      */ 
/* 4855 */     int pos = digitCount;
/*      */     
/* 4857 */     while (nanosString.charAt(pos) == '0') {
/* 4858 */       pos--;
/*      */     }
/*      */     
/* 4861 */     nanosString = nanosString.substring(0, pos + 1);
/*      */     
/* 4863 */     return nanosString;
/*      */   }
/*      */   
/*      */   private synchronized void newSetTimeInternal(int parameterIndex, Time x, Calendar targetCalendar) throws SQLException
/*      */   {
/* 4868 */     if (this.tdf == null) {
/* 4869 */       this.tdf = new SimpleDateFormat("''HH:mm:ss''", Locale.US);
/*      */     }
/*      */     
/*      */ 
/* 4873 */     String timeString = null;
/*      */     
/* 4875 */     if (targetCalendar != null) {
/* 4876 */       targetCalendar.setTime(x);
/* 4877 */       this.tdf.setTimeZone(targetCalendar.getTimeZone());
/*      */       
/* 4879 */       timeString = this.tdf.format(x);
/*      */     } else {
/* 4881 */       this.tdf.setTimeZone(this.connection.getServerTimezoneTZ());
/* 4882 */       timeString = this.tdf.format(x);
/*      */     }
/*      */     
/* 4885 */     setInternal(parameterIndex, timeString);
/*      */   }
/*      */   
/*      */   private synchronized void newSetDateInternal(int parameterIndex, java.sql.Date x, Calendar targetCalendar) throws SQLException
/*      */   {
/* 4890 */     if (this.ddf == null) {
/* 4891 */       this.ddf = new SimpleDateFormat("''yyyy-MM-dd''", Locale.US);
/*      */     }
/*      */     
/*      */ 
/* 4895 */     String timeString = null;
/*      */     
/* 4897 */     if (targetCalendar != null) {
/* 4898 */       targetCalendar.setTime(x);
/* 4899 */       this.ddf.setTimeZone(targetCalendar.getTimeZone());
/*      */       
/* 4901 */       timeString = this.ddf.format(x);
/*      */     } else {
/* 4903 */       this.ddf.setTimeZone(this.connection.getServerTimezoneTZ());
/* 4904 */       timeString = this.ddf.format(x);
/*      */     }
/*      */     
/* 4907 */     setInternal(parameterIndex, timeString);
/*      */   }
/*      */   
/*      */   private synchronized void doSSPSCompatibleTimezoneShift(int parameterIndex, Timestamp x, Calendar sessionCalendar) throws SQLException {
/* 4911 */     Calendar sessionCalendar2 = this.connection.getUseJDBCCompliantTimezoneShift() ? this.connection.getUtcCalendar() : getCalendarInstanceForSessionOrNew();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4916 */     synchronized (sessionCalendar2) {
/* 4917 */       java.util.Date oldTime = sessionCalendar2.getTime();
/*      */       try
/*      */       {
/* 4920 */         sessionCalendar2.setTime(x);
/*      */         
/* 4922 */         int year = sessionCalendar2.get(1);
/* 4923 */         int month = sessionCalendar2.get(2) + 1;
/* 4924 */         int date = sessionCalendar2.get(5);
/*      */         
/* 4926 */         int hour = sessionCalendar2.get(11);
/* 4927 */         int minute = sessionCalendar2.get(12);
/* 4928 */         int seconds = sessionCalendar2.get(13);
/*      */         
/* 4930 */         StringBuffer tsBuf = new StringBuffer();
/*      */         
/* 4932 */         tsBuf.append('\'');
/* 4933 */         tsBuf.append(year);
/*      */         
/* 4935 */         tsBuf.append("-");
/*      */         
/* 4937 */         if (month < 10) {
/* 4938 */           tsBuf.append('0');
/*      */         }
/*      */         
/* 4941 */         tsBuf.append(month);
/*      */         
/* 4943 */         tsBuf.append('-');
/*      */         
/* 4945 */         if (date < 10) {
/* 4946 */           tsBuf.append('0');
/*      */         }
/*      */         
/* 4949 */         tsBuf.append(date);
/*      */         
/* 4951 */         tsBuf.append(' ');
/*      */         
/* 4953 */         if (hour < 10) {
/* 4954 */           tsBuf.append('0');
/*      */         }
/*      */         
/* 4957 */         tsBuf.append(hour);
/*      */         
/* 4959 */         tsBuf.append(':');
/*      */         
/* 4961 */         if (minute < 10) {
/* 4962 */           tsBuf.append('0');
/*      */         }
/*      */         
/* 4965 */         tsBuf.append(minute);
/*      */         
/* 4967 */         tsBuf.append(':');
/*      */         
/* 4969 */         if (seconds < 10) {
/* 4970 */           tsBuf.append('0');
/*      */         }
/*      */         
/* 4973 */         tsBuf.append(seconds);
/*      */         
/* 4975 */         tsBuf.append('.');
/* 4976 */         tsBuf.append(formatNanos(x.getNanos()));
/* 4977 */         tsBuf.append('\'');
/*      */         
/* 4979 */         setInternal(parameterIndex, tsBuf.toString());
/*      */       }
/*      */       finally {
/* 4982 */         sessionCalendar.setTime(oldTime);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void setUnicodeStream(int parameterIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 5013 */     if (x == null) {
/* 5014 */       setNull(parameterIndex, 12);
/*      */     } else {
/* 5016 */       setBinaryStream(parameterIndex, x, length);
/*      */       
/* 5018 */       this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 2005;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setURL(int parameterIndex, URL arg)
/*      */     throws SQLException
/*      */   {
/* 5026 */     if (arg != null) {
/* 5027 */       setString(parameterIndex, arg.toString());
/*      */       
/* 5029 */       this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 70;
/*      */     } else {
/* 5031 */       setNull(parameterIndex, 1);
/*      */     }
/*      */   }
/*      */   
/*      */   private final synchronized void streamToBytes(Buffer packet, InputStream in, boolean escape, int streamLength, boolean useLength) throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 5039 */       if (this.streamConvertBuf == null) {
/* 5040 */         this.streamConvertBuf = new byte['က'];
/*      */       }
/*      */       
/* 5043 */       String connectionEncoding = this.connection.getEncoding();
/*      */       
/* 5045 */       boolean hexEscape = false;
/*      */       try
/*      */       {
/* 5048 */         if ((this.connection.isNoBackslashEscapesSet()) || ((this.connection.getUseUnicode()) && (connectionEncoding != null) && (CharsetMapping.isMultibyteCharset(connectionEncoding)) && (!this.connection.parserKnowsUnicode())))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/* 5053 */           hexEscape = true;
/*      */         }
/*      */       } catch (RuntimeException ex) {
/* 5056 */         SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", null);
/* 5057 */         sqlEx.initCause(ex);
/* 5058 */         throw sqlEx;
/*      */       }
/*      */       
/* 5061 */       if (streamLength == -1) {
/* 5062 */         useLength = false;
/*      */       }
/*      */       
/* 5065 */       int bc = -1;
/*      */       
/* 5067 */       if (useLength) {
/* 5068 */         bc = readblock(in, this.streamConvertBuf, streamLength);
/*      */       } else {
/* 5070 */         bc = readblock(in, this.streamConvertBuf);
/*      */       }
/*      */       
/* 5073 */       int lengthLeftToRead = streamLength - bc;
/*      */       
/* 5075 */       if (hexEscape) {
/* 5076 */         packet.writeStringNoNull("x");
/* 5077 */       } else if (this.connection.getIO().versionMeetsMinimum(4, 1, 0)) {
/* 5078 */         packet.writeStringNoNull("_binary");
/*      */       }
/*      */       
/* 5081 */       if (escape) {
/* 5082 */         packet.writeByte((byte)39);
/*      */       }
/*      */       
/* 5085 */       while (bc > 0) {
/* 5086 */         if (hexEscape) {
/* 5087 */           hexEscapeBlock(this.streamConvertBuf, packet, bc);
/* 5088 */         } else if (escape) {
/* 5089 */           escapeblockFast(this.streamConvertBuf, packet, bc);
/*      */         } else {
/* 5091 */           packet.writeBytesNoNull(this.streamConvertBuf, 0, bc);
/*      */         }
/*      */         
/* 5094 */         if (useLength) {
/* 5095 */           bc = readblock(in, this.streamConvertBuf, lengthLeftToRead);
/*      */           
/* 5097 */           if (bc > 0) {
/* 5098 */             lengthLeftToRead -= bc;
/*      */           }
/*      */         } else {
/* 5101 */           bc = readblock(in, this.streamConvertBuf);
/*      */         }
/*      */       }
/*      */       
/* 5105 */       if (escape) {
/* 5106 */         packet.writeByte((byte)39);
/*      */       }
/*      */     } finally {
/* 5109 */       if (this.connection.getAutoClosePStmtStreams()) {
/*      */         try {
/* 5111 */           in.close();
/*      */         }
/*      */         catch (IOException ioEx) {}
/*      */         
/*      */ 
/* 5116 */         in = null;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private final synchronized byte[] streamToBytes(InputStream in, boolean escape, int streamLength, boolean useLength) throws SQLException
/*      */   {
/*      */     try {
/* 5124 */       if (this.streamConvertBuf == null) {
/* 5125 */         this.streamConvertBuf = new byte['က'];
/*      */       }
/* 5127 */       if (streamLength == -1) {
/* 5128 */         useLength = false;
/*      */       }
/*      */       
/* 5131 */       ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
/*      */       
/* 5133 */       int bc = -1;
/*      */       
/* 5135 */       if (useLength) {
/* 5136 */         bc = readblock(in, this.streamConvertBuf, streamLength);
/*      */       } else {
/* 5138 */         bc = readblock(in, this.streamConvertBuf);
/*      */       }
/*      */       
/* 5141 */       int lengthLeftToRead = streamLength - bc;
/*      */       
/* 5143 */       if (escape) {
/* 5144 */         if (this.connection.versionMeetsMinimum(4, 1, 0)) {
/* 5145 */           bytesOut.write(95);
/* 5146 */           bytesOut.write(98);
/* 5147 */           bytesOut.write(105);
/* 5148 */           bytesOut.write(110);
/* 5149 */           bytesOut.write(97);
/* 5150 */           bytesOut.write(114);
/* 5151 */           bytesOut.write(121);
/*      */         }
/*      */         
/* 5154 */         bytesOut.write(39);
/*      */       }
/*      */       
/* 5157 */       while (bc > 0) {
/* 5158 */         if (escape) {
/* 5159 */           escapeblockFast(this.streamConvertBuf, bytesOut, bc);
/*      */         } else {
/* 5161 */           bytesOut.write(this.streamConvertBuf, 0, bc);
/*      */         }
/*      */         
/* 5164 */         if (useLength) {
/* 5165 */           bc = readblock(in, this.streamConvertBuf, lengthLeftToRead);
/*      */           
/* 5167 */           if (bc > 0) {
/* 5168 */             lengthLeftToRead -= bc;
/*      */           }
/*      */         } else {
/* 5171 */           bc = readblock(in, this.streamConvertBuf);
/*      */         }
/*      */       }
/*      */       
/* 5175 */       if (escape) {
/* 5176 */         bytesOut.write(39);
/*      */       }
/*      */       
/* 5179 */       return bytesOut.toByteArray();
/*      */     } finally {
/* 5181 */       if (this.connection.getAutoClosePStmtStreams()) {
/*      */         try {
/* 5183 */           in.close();
/*      */         }
/*      */         catch (IOException ioEx) {}
/*      */         
/*      */ 
/* 5188 */         in = null;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/* 5199 */     StringBuffer buf = new StringBuffer();
/* 5200 */     buf.append(super.toString());
/* 5201 */     buf.append(": ");
/*      */     try
/*      */     {
/* 5204 */       buf.append(asSql());
/*      */     } catch (SQLException sqlEx) {
/* 5206 */       buf.append("EXCEPTION: " + sqlEx.toString());
/*      */     }
/*      */     
/* 5209 */     return buf.toString();
/*      */   }
/*      */   
/*      */   public synchronized boolean isClosed()
/*      */     throws SQLException
/*      */   {
/* 5215 */     return this.isClosed;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int getParameterIndexOffset()
/*      */   {
/* 5226 */     return 0;
/*      */   }
/*      */   
/*      */   public void setAsciiStream(int parameterIndex, InputStream x) throws SQLException {
/* 5230 */     setAsciiStream(parameterIndex, x, -1);
/*      */   }
/*      */   
/*      */   public void setAsciiStream(int parameterIndex, InputStream x, long length) throws SQLException {
/* 5234 */     setAsciiStream(parameterIndex, x, (int)length);
/* 5235 */     this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 2005;
/*      */   }
/*      */   
/*      */   public void setBinaryStream(int parameterIndex, InputStream x) throws SQLException {
/* 5239 */     setBinaryStream(parameterIndex, x, -1);
/*      */   }
/*      */   
/*      */   public void setBinaryStream(int parameterIndex, InputStream x, long length) throws SQLException {
/* 5243 */     setBinaryStream(parameterIndex, x, (int)length);
/*      */   }
/*      */   
/*      */   public void setBlob(int parameterIndex, InputStream inputStream) throws SQLException {
/* 5247 */     setBinaryStream(parameterIndex, inputStream);
/*      */   }
/*      */   
/*      */   public void setCharacterStream(int parameterIndex, Reader reader) throws SQLException {
/* 5251 */     setCharacterStream(parameterIndex, reader, -1);
/*      */   }
/*      */   
/*      */   public void setCharacterStream(int parameterIndex, Reader reader, long length) throws SQLException {
/* 5255 */     setCharacterStream(parameterIndex, reader, (int)length);
/*      */   }
/*      */   
/*      */   public void setClob(int parameterIndex, Reader reader) throws SQLException
/*      */   {
/* 5260 */     setCharacterStream(parameterIndex, reader);
/*      */   }
/*      */   
/*      */   public void setClob(int parameterIndex, Reader reader, long length)
/*      */     throws SQLException
/*      */   {
/* 5266 */     setCharacterStream(parameterIndex, reader, length);
/*      */   }
/*      */   
/*      */   public void setNCharacterStream(int parameterIndex, Reader value) throws SQLException {
/* 5270 */     setNCharacterStream(parameterIndex, value, -1L);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setNString(int parameterIndex, String x)
/*      */     throws SQLException
/*      */   {
/* 5288 */     if ((this.charEncoding.equalsIgnoreCase("UTF-8")) || (this.charEncoding.equalsIgnoreCase("utf8")))
/*      */     {
/* 5290 */       setString(parameterIndex, x);
/* 5291 */       return;
/*      */     }
/*      */     
/*      */ 
/* 5295 */     if (x == null) {
/* 5296 */       setNull(parameterIndex, 1);
/*      */     } else {
/* 5298 */       int stringLength = x.length();
/*      */       
/*      */ 
/*      */ 
/* 5302 */       StringBuffer buf = new StringBuffer((int)(x.length() * 1.1D + 4.0D));
/* 5303 */       buf.append("_utf8");
/* 5304 */       buf.append('\'');
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5313 */       for (int i = 0; i < stringLength; i++) {
/* 5314 */         char c = x.charAt(i);
/*      */         
/* 5316 */         switch (c) {
/*      */         case '\000': 
/* 5318 */           buf.append('\\');
/* 5319 */           buf.append('0');
/*      */           
/* 5321 */           break;
/*      */         
/*      */         case '\n': 
/* 5324 */           buf.append('\\');
/* 5325 */           buf.append('n');
/*      */           
/* 5327 */           break;
/*      */         
/*      */         case '\r': 
/* 5330 */           buf.append('\\');
/* 5331 */           buf.append('r');
/*      */           
/* 5333 */           break;
/*      */         
/*      */         case '\\': 
/* 5336 */           buf.append('\\');
/* 5337 */           buf.append('\\');
/*      */           
/* 5339 */           break;
/*      */         
/*      */         case '\'': 
/* 5342 */           buf.append('\\');
/* 5343 */           buf.append('\'');
/*      */           
/* 5345 */           break;
/*      */         
/*      */         case '"': 
/* 5348 */           if (this.usingAnsiMode) {
/* 5349 */             buf.append('\\');
/*      */           }
/*      */           
/* 5352 */           buf.append('"');
/*      */           
/* 5354 */           break;
/*      */         
/*      */         case '\032': 
/* 5357 */           buf.append('\\');
/* 5358 */           buf.append('Z');
/*      */           
/* 5360 */           break;
/*      */         
/*      */         default: 
/* 5363 */           buf.append(c);
/*      */         }
/*      */         
/*      */       }
/* 5367 */       buf.append('\'');
/*      */       
/* 5369 */       String parameterAsString = buf.toString();
/*      */       
/* 5371 */       byte[] parameterAsBytes = null;
/*      */       
/* 5373 */       if (!this.isLoadDataQuery) {
/* 5374 */         parameterAsBytes = StringUtils.getBytes(parameterAsString, this.connection.getCharsetConverter("UTF-8"), "UTF-8", this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/* 5380 */         parameterAsBytes = StringUtils.getBytes(parameterAsString);
/*      */       }
/*      */       
/* 5383 */       setInternal(parameterIndex, parameterAsBytes);
/*      */       
/* 5385 */       this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = -9;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setNCharacterStream(int parameterIndex, Reader reader, long length)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 5414 */       if (reader == null) {
/* 5415 */         setNull(parameterIndex, -1);
/*      */       }
/*      */       else {
/* 5418 */         char[] c = null;
/* 5419 */         int len = 0;
/*      */         
/* 5421 */         boolean useLength = this.connection.getUseStreamLengthsInPrepStmts();
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 5426 */         if ((useLength) && (length != -1L)) {
/* 5427 */           c = new char[(int)length];
/*      */           
/* 5429 */           int numCharsRead = readFully(reader, c, (int)length);
/*      */           
/*      */ 
/*      */ 
/* 5433 */           setNString(parameterIndex, new String(c, 0, numCharsRead));
/*      */         }
/*      */         else {
/* 5436 */           c = new char['က'];
/*      */           
/* 5438 */           StringBuffer buf = new StringBuffer();
/*      */           
/* 5440 */           while ((len = reader.read(c)) != -1) {
/* 5441 */             buf.append(c, 0, len);
/*      */           }
/*      */           
/* 5444 */           setNString(parameterIndex, buf.toString());
/*      */         }
/*      */         
/* 5447 */         this.parameterTypes[(parameterIndex - 1 + getParameterIndexOffset())] = 2011;
/*      */       }
/*      */     } catch (IOException ioEx) {
/* 5450 */       throw SQLError.createSQLException(ioEx.toString(), "S1000", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */   public void setNClob(int parameterIndex, Reader reader) throws SQLException
/*      */   {
/* 5456 */     setNCharacterStream(parameterIndex, reader);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNClob(int parameterIndex, Reader reader, long length)
/*      */     throws SQLException
/*      */   {
/* 5474 */     if (reader == null) {
/* 5475 */       setNull(parameterIndex, -1);
/*      */     } else {
/* 5477 */       setNCharacterStream(parameterIndex, reader, length);
/*      */     }
/*      */   }
/*      */   
/*      */   public synchronized ParameterBindings getParameterBindings() throws SQLException {
/* 5482 */     return new EmulatedPreparedStatementBindings();
/*      */   }
/*      */   
/*      */   class EmulatedPreparedStatementBindings implements ParameterBindings
/*      */   {
/*      */     private ResultSetImpl bindingsAsRs;
/*      */     private boolean[] parameterIsNull;
/*      */     
/*      */     EmulatedPreparedStatementBindings() throws SQLException {
/* 5491 */       List rows = new ArrayList();
/* 5492 */       this.parameterIsNull = new boolean[PreparedStatement.this.parameterCount];
/* 5493 */       System.arraycopy(PreparedStatement.this.isNull, 0, this.parameterIsNull, 0, PreparedStatement.this.parameterCount);
/*      */       
/*      */ 
/* 5496 */       byte[][] rowData = new byte[PreparedStatement.this.parameterCount][];
/* 5497 */       Field[] typeMetadata = new Field[PreparedStatement.this.parameterCount];
/*      */       
/* 5499 */       for (int i = 0; i < PreparedStatement.this.parameterCount; i++) {
/* 5500 */         if (PreparedStatement.this.batchCommandIndex == -1) {
/* 5501 */           rowData[i] = PreparedStatement.this.getBytesRepresentation(i);
/*      */         } else {
/* 5503 */           rowData[i] = PreparedStatement.this.getBytesRepresentationForBatch(i, PreparedStatement.this.batchCommandIndex);
/*      */         }
/* 5505 */         int charsetIndex = 0;
/*      */         
/* 5507 */         if ((PreparedStatement.this.parameterTypes[i] == -2) || (PreparedStatement.this.parameterTypes[i] == 2004))
/*      */         {
/* 5509 */           charsetIndex = 63;
/*      */         } else {
/*      */           try {
/* 5512 */             String mysqlEncodingName = CharsetMapping.getMysqlEncodingForJavaEncoding(PreparedStatement.this.connection.getEncoding(), PreparedStatement.this.connection);
/*      */             
/*      */ 
/* 5515 */             charsetIndex = CharsetMapping.getCharsetIndexForMysqlEncodingName(mysqlEncodingName);
/*      */           }
/*      */           catch (SQLException ex) {
/* 5518 */             throw ex;
/*      */           } catch (RuntimeException ex) {
/* 5520 */             SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", null);
/* 5521 */             sqlEx.initCause(ex);
/* 5522 */             throw sqlEx;
/*      */           }
/*      */         }
/*      */         
/* 5526 */         Field parameterMetadata = new Field(null, "parameter_" + (i + 1), charsetIndex, PreparedStatement.this.parameterTypes[i], rowData[i].length);
/*      */         
/*      */ 
/* 5529 */         parameterMetadata.setConnection(PreparedStatement.this.connection);
/* 5530 */         typeMetadata[i] = parameterMetadata;
/*      */       }
/*      */       
/* 5533 */       rows.add(new ByteArrayRow(rowData, PreparedStatement.this.getExceptionInterceptor()));
/*      */       
/* 5535 */       this.bindingsAsRs = new ResultSetImpl(PreparedStatement.this.connection.getCatalog(), typeMetadata, new RowDataStatic(rows), PreparedStatement.this.connection, null);
/*      */       
/* 5537 */       this.bindingsAsRs.next();
/*      */     }
/*      */     
/*      */     public Array getArray(int parameterIndex) throws SQLException {
/* 5541 */       return this.bindingsAsRs.getArray(parameterIndex);
/*      */     }
/*      */     
/*      */     public InputStream getAsciiStream(int parameterIndex) throws SQLException
/*      */     {
/* 5546 */       return this.bindingsAsRs.getAsciiStream(parameterIndex);
/*      */     }
/*      */     
/*      */     public BigDecimal getBigDecimal(int parameterIndex) throws SQLException {
/* 5550 */       return this.bindingsAsRs.getBigDecimal(parameterIndex);
/*      */     }
/*      */     
/*      */     public InputStream getBinaryStream(int parameterIndex) throws SQLException
/*      */     {
/* 5555 */       return this.bindingsAsRs.getBinaryStream(parameterIndex);
/*      */     }
/*      */     
/*      */     public Blob getBlob(int parameterIndex) throws SQLException {
/* 5559 */       return this.bindingsAsRs.getBlob(parameterIndex);
/*      */     }
/*      */     
/*      */     public boolean getBoolean(int parameterIndex) throws SQLException {
/* 5563 */       return this.bindingsAsRs.getBoolean(parameterIndex);
/*      */     }
/*      */     
/*      */     public byte getByte(int parameterIndex) throws SQLException {
/* 5567 */       return this.bindingsAsRs.getByte(parameterIndex);
/*      */     }
/*      */     
/*      */     public byte[] getBytes(int parameterIndex) throws SQLException {
/* 5571 */       return this.bindingsAsRs.getBytes(parameterIndex);
/*      */     }
/*      */     
/*      */     public Reader getCharacterStream(int parameterIndex) throws SQLException
/*      */     {
/* 5576 */       return this.bindingsAsRs.getCharacterStream(parameterIndex);
/*      */     }
/*      */     
/*      */     public Clob getClob(int parameterIndex) throws SQLException {
/* 5580 */       return this.bindingsAsRs.getClob(parameterIndex);
/*      */     }
/*      */     
/*      */     public java.sql.Date getDate(int parameterIndex) throws SQLException {
/* 5584 */       return this.bindingsAsRs.getDate(parameterIndex);
/*      */     }
/*      */     
/*      */     public double getDouble(int parameterIndex) throws SQLException {
/* 5588 */       return this.bindingsAsRs.getDouble(parameterIndex);
/*      */     }
/*      */     
/*      */     public float getFloat(int parameterIndex) throws SQLException {
/* 5592 */       return this.bindingsAsRs.getFloat(parameterIndex);
/*      */     }
/*      */     
/*      */     public int getInt(int parameterIndex) throws SQLException {
/* 5596 */       return this.bindingsAsRs.getInt(parameterIndex);
/*      */     }
/*      */     
/*      */     public long getLong(int parameterIndex) throws SQLException {
/* 5600 */       return this.bindingsAsRs.getLong(parameterIndex);
/*      */     }
/*      */     
/*      */     public Reader getNCharacterStream(int parameterIndex) throws SQLException
/*      */     {
/* 5605 */       return this.bindingsAsRs.getCharacterStream(parameterIndex);
/*      */     }
/*      */     
/*      */     public Reader getNClob(int parameterIndex) throws SQLException {
/* 5609 */       return this.bindingsAsRs.getCharacterStream(parameterIndex);
/*      */     }
/*      */     
/*      */     public Object getObject(int parameterIndex) throws SQLException {
/* 5613 */       PreparedStatement.this.checkBounds(parameterIndex, 0);
/*      */       
/* 5615 */       if (this.parameterIsNull[(parameterIndex - 1)] != 0) {
/* 5616 */         return null;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5623 */       switch (PreparedStatement.this.parameterTypes[(parameterIndex - 1)]) {
/*      */       case -6: 
/* 5625 */         return Byte.valueOf(getByte(parameterIndex));
/*      */       case 5: 
/* 5627 */         return Short.valueOf(getShort(parameterIndex));
/*      */       case 4: 
/* 5629 */         return Integer.valueOf(getInt(parameterIndex));
/*      */       case -5: 
/* 5631 */         return Long.valueOf(getLong(parameterIndex));
/*      */       case 6: 
/* 5633 */         return Float.valueOf(getFloat(parameterIndex));
/*      */       case 8: 
/* 5635 */         return Double.valueOf(getDouble(parameterIndex));
/*      */       }
/* 5637 */       return this.bindingsAsRs.getObject(parameterIndex);
/*      */     }
/*      */     
/*      */     public Ref getRef(int parameterIndex) throws SQLException
/*      */     {
/* 5642 */       return this.bindingsAsRs.getRef(parameterIndex);
/*      */     }
/*      */     
/*      */     public short getShort(int parameterIndex) throws SQLException {
/* 5646 */       return this.bindingsAsRs.getShort(parameterIndex);
/*      */     }
/*      */     
/*      */     public String getString(int parameterIndex) throws SQLException {
/* 5650 */       return this.bindingsAsRs.getString(parameterIndex);
/*      */     }
/*      */     
/*      */     public Time getTime(int parameterIndex) throws SQLException {
/* 5654 */       return this.bindingsAsRs.getTime(parameterIndex);
/*      */     }
/*      */     
/*      */     public Timestamp getTimestamp(int parameterIndex) throws SQLException {
/* 5658 */       return this.bindingsAsRs.getTimestamp(parameterIndex);
/*      */     }
/*      */     
/*      */     public URL getURL(int parameterIndex) throws SQLException {
/* 5662 */       return this.bindingsAsRs.getURL(parameterIndex);
/*      */     }
/*      */     
/*      */     public boolean isNull(int parameterIndex) throws SQLException {
/* 5666 */       PreparedStatement.this.checkBounds(parameterIndex, 0);
/*      */       
/* 5668 */       return this.parameterIsNull[(parameterIndex - 1)];
/*      */     }
/*      */   }
/*      */   
/*      */   public synchronized String getPreparedSql() {
/* 5673 */     if (this.rewrittenBatchSize == 0) {
/* 5674 */       return this.originalSql;
/*      */     }
/*      */     try
/*      */     {
/* 5678 */       return this.parseInfo.getSqlForBatch(this.parseInfo);
/*      */     } catch (UnsupportedEncodingException e) {
/* 5680 */       throw new RuntimeException(e);
/*      */     }
/*      */   }
/*      */   
/*      */   public int getUpdateCount() throws SQLException {
/* 5685 */     int count = super.getUpdateCount();
/*      */     
/* 5687 */     if ((containsOnDuplicateKeyUpdateInSQL()) && (this.compensateForOnDuplicateKeyUpdate))
/*      */     {
/* 5689 */       if ((count == 2) || (count == 0)) {
/* 5690 */         count = 1;
/*      */       }
/*      */     }
/*      */     
/* 5694 */     return count;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected static boolean canRewrite(String sql, boolean isOnDuplicateKeyUpdate, int locationOfOnDuplicateKeyUpdate, int statementStartPos)
/*      */   {
/* 5701 */     boolean rewritableOdku = true;
/*      */     
/* 5703 */     if (isOnDuplicateKeyUpdate) {
/* 5704 */       int updateClausePos = StringUtils.indexOfIgnoreCase(locationOfOnDuplicateKeyUpdate, sql, " UPDATE ");
/*      */       
/*      */ 
/* 5707 */       if (updateClausePos != -1) {
/* 5708 */         rewritableOdku = StringUtils.indexOfIgnoreCaseRespectMarker(updateClausePos, sql, "LAST_INSERT_ID", "\"'`", "\"'`", false) == -1;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5715 */     return (StringUtils.startsWithIgnoreCaseAndWs(sql, "INSERT", statementStartPos)) && (StringUtils.indexOfIgnoreCaseRespectMarker(statementStartPos, sql, "SELECT", "\"'`", "\"'`", false) == -1) && (rewritableOdku);
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   protected synchronized int[] executePreparedBatchAsMultiStatement(int batchTimeout)
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 37	com/mysql/jdbc/PreparedStatement:connection	Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 162	com/mysql/jdbc/PreparedStatement:batchedValuesClause	Ljava/lang/String;
/*      */     //   11: ifnonnull +29 -> 40
/*      */     //   14: aload_0
/*      */     //   15: new 94	java/lang/StringBuilder
/*      */     //   18: dup
/*      */     //   19: invokespecial 95	java/lang/StringBuilder:<init>	()V
/*      */     //   22: aload_0
/*      */     //   23: getfield 24	com/mysql/jdbc/PreparedStatement:originalSql	Ljava/lang/String;
/*      */     //   26: invokevirtual 97	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   29: ldc -93
/*      */     //   31: invokevirtual 97	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   34: invokevirtual 99	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   37: putfield 162	com/mysql/jdbc/PreparedStatement:batchedValuesClause	Ljava/lang/String;
/*      */     //   40: aload_0
/*      */     //   41: getfield 37	com/mysql/jdbc/PreparedStatement:connection	Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   44: astore_3
/*      */     //   45: aload_3
/*      */     //   46: invokeinterface 164 1 0
/*      */     //   51: istore 4
/*      */     //   53: aconst_null
/*      */     //   54: astore 5
/*      */     //   56: aload_0
/*      */     //   57: invokevirtual 117	com/mysql/jdbc/PreparedStatement:clearWarnings	()V
/*      */     //   60: aload_0
/*      */     //   61: getfield 64	com/mysql/jdbc/PreparedStatement:batchedArgs	Ljava/util/List;
/*      */     //   64: invokeinterface 148 1 0
/*      */     //   69: istore 6
/*      */     //   71: aload_0
/*      */     //   72: getfield 114	com/mysql/jdbc/PreparedStatement:retrieveGeneratedKeys	Z
/*      */     //   75: ifeq +16 -> 91
/*      */     //   78: aload_0
/*      */     //   79: new 65	java/util/ArrayList
/*      */     //   82: dup
/*      */     //   83: iload 6
/*      */     //   85: invokespecial 165	java/util/ArrayList:<init>	(I)V
/*      */     //   88: putfield 122	com/mysql/jdbc/PreparedStatement:batchedGeneratedKeys	Ljava/util/ArrayList;
/*      */     //   91: aload_0
/*      */     //   92: iload 6
/*      */     //   94: invokevirtual 166	com/mysql/jdbc/PreparedStatement:computeBatchSize	(I)I
/*      */     //   97: istore 7
/*      */     //   99: iload 6
/*      */     //   101: iload 7
/*      */     //   103: if_icmpge +7 -> 110
/*      */     //   106: iload 6
/*      */     //   108: istore 7
/*      */     //   110: aconst_null
/*      */     //   111: astore 8
/*      */     //   113: iconst_1
/*      */     //   114: istore 9
/*      */     //   116: iconst_0
/*      */     //   117: istore 10
/*      */     //   119: iconst_0
/*      */     //   120: istore 11
/*      */     //   122: iconst_0
/*      */     //   123: istore 12
/*      */     //   125: iload 6
/*      */     //   127: newarray <illegal type>
/*      */     //   129: astore 13
/*      */     //   131: aconst_null
/*      */     //   132: astore 14
/*      */     //   134: iload 4
/*      */     //   136: ifne +12 -> 148
/*      */     //   139: aload_3
/*      */     //   140: invokeinterface 167 1 0
/*      */     //   145: invokevirtual 168	com/mysql/jdbc/MysqlIO:enableMultiQueries	()V
/*      */     //   148: aload_0
/*      */     //   149: getfield 114	com/mysql/jdbc/PreparedStatement:retrieveGeneratedKeys	Z
/*      */     //   152: ifeq +21 -> 173
/*      */     //   155: aload_3
/*      */     //   156: aload_0
/*      */     //   157: iload 7
/*      */     //   159: invokespecial 169	com/mysql/jdbc/PreparedStatement:generateMultiStatementForBatch	(I)Ljava/lang/String;
/*      */     //   162: iconst_1
/*      */     //   163: invokeinterface 170 3 0
/*      */     //   168: astore 8
/*      */     //   170: goto +17 -> 187
/*      */     //   173: aload_3
/*      */     //   174: aload_0
/*      */     //   175: iload 7
/*      */     //   177: invokespecial 169	com/mysql/jdbc/PreparedStatement:generateMultiStatementForBatch	(I)Ljava/lang/String;
/*      */     //   180: invokeinterface 171 2 0
/*      */     //   185: astore 8
/*      */     //   187: aload_3
/*      */     //   188: invokeinterface 172 1 0
/*      */     //   193: ifeq +47 -> 240
/*      */     //   196: iload_1
/*      */     //   197: ifeq +43 -> 240
/*      */     //   200: aload_3
/*      */     //   201: iconst_5
/*      */     //   202: iconst_0
/*      */     //   203: iconst_0
/*      */     //   204: invokeinterface 39 4 0
/*      */     //   209: ifeq +31 -> 240
/*      */     //   212: new 173	com/mysql/jdbc/StatementImpl$CancelTask
/*      */     //   215: dup
/*      */     //   216: aload_0
/*      */     //   217: aload 8
/*      */     //   219: checkcast 174	com/mysql/jdbc/StatementImpl
/*      */     //   222: invokespecial 175	com/mysql/jdbc/StatementImpl$CancelTask:<init>	(Lcom/mysql/jdbc/StatementImpl;Lcom/mysql/jdbc/StatementImpl;)V
/*      */     //   225: astore 5
/*      */     //   227: aload_3
/*      */     //   228: invokeinterface 176 1 0
/*      */     //   233: aload 5
/*      */     //   235: iload_1
/*      */     //   236: i2l
/*      */     //   237: invokevirtual 177	java/util/Timer:schedule	(Ljava/util/TimerTask;J)V
/*      */     //   240: iload 6
/*      */     //   242: iload 7
/*      */     //   244: if_icmpge +10 -> 254
/*      */     //   247: iload 6
/*      */     //   249: istore 10
/*      */     //   251: goto +10 -> 261
/*      */     //   254: iload 6
/*      */     //   256: iload 7
/*      */     //   258: idiv
/*      */     //   259: istore 10
/*      */     //   261: iload 10
/*      */     //   263: iload 7
/*      */     //   265: imul
/*      */     //   266: istore 15
/*      */     //   268: iconst_0
/*      */     //   269: istore 16
/*      */     //   271: iload 16
/*      */     //   273: iload 15
/*      */     //   275: if_icmpge +98 -> 373
/*      */     //   278: iload 16
/*      */     //   280: ifeq +63 -> 343
/*      */     //   283: iload 16
/*      */     //   285: iload 7
/*      */     //   287: irem
/*      */     //   288: ifne +55 -> 343
/*      */     //   291: aload 8
/*      */     //   293: invokeinterface 178 1 0
/*      */     //   298: pop
/*      */     //   299: goto +19 -> 318
/*      */     //   302: astore 17
/*      */     //   304: aload_0
/*      */     //   305: iload 11
/*      */     //   307: iload 7
/*      */     //   309: aload 13
/*      */     //   311: aload 17
/*      */     //   313: invokevirtual 179	com/mysql/jdbc/PreparedStatement:handleExceptionForBatch	(II[ILjava/sql/SQLException;)Ljava/sql/SQLException;
/*      */     //   316: astore 14
/*      */     //   318: aload_0
/*      */     //   319: aload 8
/*      */     //   321: checkcast 174	com/mysql/jdbc/StatementImpl
/*      */     //   324: iload 12
/*      */     //   326: aload 13
/*      */     //   328: invokevirtual 180	com/mysql/jdbc/PreparedStatement:processMultiCountsAndKeys	(Lcom/mysql/jdbc/StatementImpl;I[I)I
/*      */     //   331: istore 12
/*      */     //   333: aload 8
/*      */     //   335: invokeinterface 181 1 0
/*      */     //   340: iconst_1
/*      */     //   341: istore 9
/*      */     //   343: aload_0
/*      */     //   344: aload 8
/*      */     //   346: iload 9
/*      */     //   348: aload_0
/*      */     //   349: getfield 64	com/mysql/jdbc/PreparedStatement:batchedArgs	Ljava/util/List;
/*      */     //   352: iload 11
/*      */     //   354: iinc 11 1
/*      */     //   357: invokeinterface 79 2 0
/*      */     //   362: invokevirtual 182	com/mysql/jdbc/PreparedStatement:setOneBatchedParameterSet	(Ljava/sql/PreparedStatement;ILjava/lang/Object;)I
/*      */     //   365: istore 9
/*      */     //   367: iinc 16 1
/*      */     //   370: goto -99 -> 271
/*      */     //   373: aload 8
/*      */     //   375: invokeinterface 178 1 0
/*      */     //   380: pop
/*      */     //   381: goto +21 -> 402
/*      */     //   384: astore 16
/*      */     //   386: aload_0
/*      */     //   387: iload 11
/*      */     //   389: iconst_1
/*      */     //   390: isub
/*      */     //   391: iload 7
/*      */     //   393: aload 13
/*      */     //   395: aload 16
/*      */     //   397: invokevirtual 179	com/mysql/jdbc/PreparedStatement:handleExceptionForBatch	(II[ILjava/sql/SQLException;)Ljava/sql/SQLException;
/*      */     //   400: astore 14
/*      */     //   402: aload_0
/*      */     //   403: aload 8
/*      */     //   405: checkcast 174	com/mysql/jdbc/StatementImpl
/*      */     //   408: iload 12
/*      */     //   410: aload 13
/*      */     //   412: invokevirtual 180	com/mysql/jdbc/PreparedStatement:processMultiCountsAndKeys	(Lcom/mysql/jdbc/StatementImpl;I[I)I
/*      */     //   415: istore 12
/*      */     //   417: aload 8
/*      */     //   419: invokeinterface 181 1 0
/*      */     //   424: iload 6
/*      */     //   426: iload 11
/*      */     //   428: isub
/*      */     //   429: istore 7
/*      */     //   431: jsr +14 -> 445
/*      */     //   434: goto +27 -> 461
/*      */     //   437: astore 18
/*      */     //   439: jsr +6 -> 445
/*      */     //   442: aload 18
/*      */     //   444: athrow
/*      */     //   445: astore 19
/*      */     //   447: aload 8
/*      */     //   449: ifnull +10 -> 459
/*      */     //   452: aload 8
/*      */     //   454: invokeinterface 183 1 0
/*      */     //   459: ret 19
/*      */     //   461: iload 7
/*      */     //   463: ifle +145 -> 608
/*      */     //   466: aload_0
/*      */     //   467: getfield 114	com/mysql/jdbc/PreparedStatement:retrieveGeneratedKeys	Z
/*      */     //   470: ifeq +21 -> 491
/*      */     //   473: aload_3
/*      */     //   474: aload_0
/*      */     //   475: iload 7
/*      */     //   477: invokespecial 169	com/mysql/jdbc/PreparedStatement:generateMultiStatementForBatch	(I)Ljava/lang/String;
/*      */     //   480: iconst_1
/*      */     //   481: invokeinterface 170 3 0
/*      */     //   486: astore 8
/*      */     //   488: goto +17 -> 505
/*      */     //   491: aload_3
/*      */     //   492: aload_0
/*      */     //   493: iload 7
/*      */     //   495: invokespecial 169	com/mysql/jdbc/PreparedStatement:generateMultiStatementForBatch	(I)Ljava/lang/String;
/*      */     //   498: invokeinterface 171 2 0
/*      */     //   503: astore 8
/*      */     //   505: aload 5
/*      */     //   507: ifnull +13 -> 520
/*      */     //   510: aload 5
/*      */     //   512: aload 8
/*      */     //   514: checkcast 174	com/mysql/jdbc/StatementImpl
/*      */     //   517: putfield 184	com/mysql/jdbc/StatementImpl$CancelTask:toCancel	Lcom/mysql/jdbc/StatementImpl;
/*      */     //   520: iconst_1
/*      */     //   521: istore 9
/*      */     //   523: iload 11
/*      */     //   525: iload 6
/*      */     //   527: if_icmpge +30 -> 557
/*      */     //   530: aload_0
/*      */     //   531: aload 8
/*      */     //   533: iload 9
/*      */     //   535: aload_0
/*      */     //   536: getfield 64	com/mysql/jdbc/PreparedStatement:batchedArgs	Ljava/util/List;
/*      */     //   539: iload 11
/*      */     //   541: iinc 11 1
/*      */     //   544: invokeinterface 79 2 0
/*      */     //   549: invokevirtual 182	com/mysql/jdbc/PreparedStatement:setOneBatchedParameterSet	(Ljava/sql/PreparedStatement;ILjava/lang/Object;)I
/*      */     //   552: istore 9
/*      */     //   554: goto -31 -> 523
/*      */     //   557: aload 8
/*      */     //   559: invokeinterface 178 1 0
/*      */     //   564: pop
/*      */     //   565: goto +21 -> 586
/*      */     //   568: astore 15
/*      */     //   570: aload_0
/*      */     //   571: iload 11
/*      */     //   573: iconst_1
/*      */     //   574: isub
/*      */     //   575: iload 7
/*      */     //   577: aload 13
/*      */     //   579: aload 15
/*      */     //   581: invokevirtual 179	com/mysql/jdbc/PreparedStatement:handleExceptionForBatch	(II[ILjava/sql/SQLException;)Ljava/sql/SQLException;
/*      */     //   584: astore 14
/*      */     //   586: aload_0
/*      */     //   587: aload 8
/*      */     //   589: checkcast 174	com/mysql/jdbc/StatementImpl
/*      */     //   592: iload 12
/*      */     //   594: aload 13
/*      */     //   596: invokevirtual 180	com/mysql/jdbc/PreparedStatement:processMultiCountsAndKeys	(Lcom/mysql/jdbc/StatementImpl;I[I)I
/*      */     //   599: istore 12
/*      */     //   601: aload 8
/*      */     //   603: invokeinterface 181 1 0
/*      */     //   608: aload 5
/*      */     //   610: ifnull +36 -> 646
/*      */     //   613: aload 5
/*      */     //   615: getfield 185	com/mysql/jdbc/StatementImpl$CancelTask:caughtWhileCancelling	Ljava/sql/SQLException;
/*      */     //   618: ifnull +9 -> 627
/*      */     //   621: aload 5
/*      */     //   623: getfield 185	com/mysql/jdbc/StatementImpl$CancelTask:caughtWhileCancelling	Ljava/sql/SQLException;
/*      */     //   626: athrow
/*      */     //   627: aload 5
/*      */     //   629: invokevirtual 186	com/mysql/jdbc/StatementImpl$CancelTask:cancel	()Z
/*      */     //   632: pop
/*      */     //   633: aload_3
/*      */     //   634: invokeinterface 176 1 0
/*      */     //   639: invokevirtual 187	java/util/Timer:purge	()I
/*      */     //   642: pop
/*      */     //   643: aconst_null
/*      */     //   644: astore 5
/*      */     //   646: aload 14
/*      */     //   648: ifnull +40 -> 688
/*      */     //   651: new 188	java/sql/BatchUpdateException
/*      */     //   654: dup
/*      */     //   655: aload 14
/*      */     //   657: invokevirtual 189	java/sql/SQLException:getMessage	()Ljava/lang/String;
/*      */     //   660: aload 14
/*      */     //   662: invokevirtual 190	java/sql/SQLException:getSQLState	()Ljava/lang/String;
/*      */     //   665: aload 14
/*      */     //   667: invokevirtual 191	java/sql/SQLException:getErrorCode	()I
/*      */     //   670: aload 13
/*      */     //   672: invokespecial 192	java/sql/BatchUpdateException:<init>	(Ljava/lang/String;Ljava/lang/String;I[I)V
/*      */     //   675: astore 15
/*      */     //   677: aload 15
/*      */     //   679: aload 14
/*      */     //   681: invokevirtual 193	java/sql/SQLException:initCause	(Ljava/lang/Throwable;)Ljava/lang/Throwable;
/*      */     //   684: pop
/*      */     //   685: aload 15
/*      */     //   687: athrow
/*      */     //   688: aload 13
/*      */     //   690: astore 15
/*      */     //   692: jsr +19 -> 711
/*      */     //   695: jsr +40 -> 735
/*      */     //   698: aload_2
/*      */     //   699: monitorexit
/*      */     //   700: aload 15
/*      */     //   702: areturn
/*      */     //   703: astore 20
/*      */     //   705: jsr +6 -> 711
/*      */     //   708: aload 20
/*      */     //   710: athrow
/*      */     //   711: astore 21
/*      */     //   713: aload 8
/*      */     //   715: ifnull +10 -> 725
/*      */     //   718: aload 8
/*      */     //   720: invokeinterface 183 1 0
/*      */     //   725: ret 21
/*      */     //   727: astore 22
/*      */     //   729: jsr +6 -> 735
/*      */     //   732: aload 22
/*      */     //   734: athrow
/*      */     //   735: astore 23
/*      */     //   737: aload 5
/*      */     //   739: ifnull +19 -> 758
/*      */     //   742: aload 5
/*      */     //   744: invokevirtual 186	com/mysql/jdbc/StatementImpl$CancelTask:cancel	()Z
/*      */     //   747: pop
/*      */     //   748: aload_3
/*      */     //   749: invokeinterface 176 1 0
/*      */     //   754: invokevirtual 187	java/util/Timer:purge	()I
/*      */     //   757: pop
/*      */     //   758: aload_0
/*      */     //   759: invokevirtual 150	com/mysql/jdbc/PreparedStatement:resetCancelledState	()V
/*      */     //   762: iload 4
/*      */     //   764: ifne +12 -> 776
/*      */     //   767: aload_3
/*      */     //   768: invokeinterface 167 1 0
/*      */     //   773: invokevirtual 194	com/mysql/jdbc/MysqlIO:disableMultiQueries	()V
/*      */     //   776: aload_0
/*      */     //   777: invokevirtual 159	com/mysql/jdbc/PreparedStatement:clearBatch	()V
/*      */     //   780: ret 23
/*      */     //   782: astore 24
/*      */     //   784: aload_2
/*      */     //   785: monitorexit
/*      */     //   786: aload 24
/*      */     //   788: athrow
/*      */     // Line number table:
/*      */     //   Java source line #1486	-> byte code offset #0
/*      */     //   Java source line #1488	-> byte code offset #7
/*      */     //   Java source line #1489	-> byte code offset #14
/*      */     //   Java source line #1492	-> byte code offset #40
/*      */     //   Java source line #1494	-> byte code offset #45
/*      */     //   Java source line #1495	-> byte code offset #53
/*      */     //   Java source line #1498	-> byte code offset #56
/*      */     //   Java source line #1500	-> byte code offset #60
/*      */     //   Java source line #1502	-> byte code offset #71
/*      */     //   Java source line #1503	-> byte code offset #78
/*      */     //   Java source line #1506	-> byte code offset #91
/*      */     //   Java source line #1508	-> byte code offset #99
/*      */     //   Java source line #1509	-> byte code offset #106
/*      */     //   Java source line #1512	-> byte code offset #110
/*      */     //   Java source line #1514	-> byte code offset #113
/*      */     //   Java source line #1515	-> byte code offset #116
/*      */     //   Java source line #1516	-> byte code offset #119
/*      */     //   Java source line #1517	-> byte code offset #122
/*      */     //   Java source line #1518	-> byte code offset #125
/*      */     //   Java source line #1519	-> byte code offset #131
/*      */     //   Java source line #1522	-> byte code offset #134
/*      */     //   Java source line #1523	-> byte code offset #139
/*      */     //   Java source line #1526	-> byte code offset #148
/*      */     //   Java source line #1527	-> byte code offset #155
/*      */     //   Java source line #1531	-> byte code offset #173
/*      */     //   Java source line #1535	-> byte code offset #187
/*      */     //   Java source line #1538	-> byte code offset #212
/*      */     //   Java source line #1539	-> byte code offset #227
/*      */     //   Java source line #1543	-> byte code offset #240
/*      */     //   Java source line #1544	-> byte code offset #247
/*      */     //   Java source line #1546	-> byte code offset #254
/*      */     //   Java source line #1549	-> byte code offset #261
/*      */     //   Java source line #1551	-> byte code offset #268
/*      */     //   Java source line #1552	-> byte code offset #278
/*      */     //   Java source line #1554	-> byte code offset #291
/*      */     //   Java source line #1558	-> byte code offset #299
/*      */     //   Java source line #1555	-> byte code offset #302
/*      */     //   Java source line #1556	-> byte code offset #304
/*      */     //   Java source line #1560	-> byte code offset #318
/*      */     //   Java source line #1564	-> byte code offset #333
/*      */     //   Java source line #1565	-> byte code offset #340
/*      */     //   Java source line #1568	-> byte code offset #343
/*      */     //   Java source line #1551	-> byte code offset #367
/*      */     //   Java source line #1574	-> byte code offset #373
/*      */     //   Java source line #1578	-> byte code offset #381
/*      */     //   Java source line #1575	-> byte code offset #384
/*      */     //   Java source line #1576	-> byte code offset #386
/*      */     //   Java source line #1580	-> byte code offset #402
/*      */     //   Java source line #1584	-> byte code offset #417
/*      */     //   Java source line #1586	-> byte code offset #424
/*      */     //   Java source line #1587	-> byte code offset #431
/*      */     //   Java source line #1591	-> byte code offset #434
/*      */     //   Java source line #1588	-> byte code offset #437
/*      */     //   Java source line #1589	-> byte code offset #452
/*      */     //   Java source line #1594	-> byte code offset #461
/*      */     //   Java source line #1596	-> byte code offset #466
/*      */     //   Java source line #1597	-> byte code offset #473
/*      */     //   Java source line #1601	-> byte code offset #491
/*      */     //   Java source line #1605	-> byte code offset #505
/*      */     //   Java source line #1606	-> byte code offset #510
/*      */     //   Java source line #1609	-> byte code offset #520
/*      */     //   Java source line #1611	-> byte code offset #523
/*      */     //   Java source line #1612	-> byte code offset #530
/*      */     //   Java source line #1618	-> byte code offset #557
/*      */     //   Java source line #1622	-> byte code offset #565
/*      */     //   Java source line #1619	-> byte code offset #568
/*      */     //   Java source line #1620	-> byte code offset #570
/*      */     //   Java source line #1624	-> byte code offset #586
/*      */     //   Java source line #1628	-> byte code offset #601
/*      */     //   Java source line #1631	-> byte code offset #608
/*      */     //   Java source line #1632	-> byte code offset #613
/*      */     //   Java source line #1633	-> byte code offset #621
/*      */     //   Java source line #1636	-> byte code offset #627
/*      */     //   Java source line #1638	-> byte code offset #633
/*      */     //   Java source line #1640	-> byte code offset #643
/*      */     //   Java source line #1643	-> byte code offset #646
/*      */     //   Java source line #1644	-> byte code offset #651
/*      */     //   Java source line #1647	-> byte code offset #677
/*      */     //   Java source line #1648	-> byte code offset #685
/*      */     //   Java source line #1651	-> byte code offset #688
/*      */     //   Java source line #1653	-> byte code offset #703
/*      */     //   Java source line #1654	-> byte code offset #718
/*      */     //   Java source line #1658	-> byte code offset #727
/*      */     //   Java source line #1659	-> byte code offset #742
/*      */     //   Java source line #1660	-> byte code offset #748
/*      */     //   Java source line #1663	-> byte code offset #758
/*      */     //   Java source line #1665	-> byte code offset #762
/*      */     //   Java source line #1666	-> byte code offset #767
/*      */     //   Java source line #1669	-> byte code offset #776
/*      */     //   Java source line #1671	-> byte code offset #782
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	789	0	this	PreparedStatement
/*      */     //   0	789	1	batchTimeout	int
/*      */     //   5	780	2	Ljava/lang/Object;	Object
/*      */     //   44	724	3	locallyScopedConn	MySQLConnection
/*      */     //   51	712	4	multiQueriesEnabled	boolean
/*      */     //   54	689	5	timeoutTask	StatementImpl.CancelTask
/*      */     //   69	457	6	numBatchedArgs	int
/*      */     //   97	479	7	numValuesPerBatch	int
/*      */     //   111	608	8	batchedStatement	java.sql.PreparedStatement
/*      */     //   114	439	9	batchedParamIndex	int
/*      */     //   117	145	10	numberToExecuteAsMultiValue	int
/*      */     //   120	452	11	batchCounter	int
/*      */     //   123	477	12	updateCountCounter	int
/*      */     //   129	560	13	updateCounts	int[]
/*      */     //   132	548	14	sqlEx	SQLException
/*      */     //   266	8	15	numberArgsToExecute	int
/*      */     //   568	12	15	ex	SQLException
/*      */     //   675	26	15	batchUpdateException	SQLException
/*      */     //   269	99	16	i	int
/*      */     //   384	12	16	ex	SQLException
/*      */     //   302	10	17	ex	SQLException
/*      */     //   437	6	18	localObject1	Object
/*      */     //   445	1	19	localObject2	Object
/*      */     //   703	6	20	localObject3	Object
/*      */     //   711	1	21	localObject4	Object
/*      */     //   727	6	22	localObject5	Object
/*      */     //   735	1	23	localObject6	Object
/*      */     //   782	5	24	localObject7	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   291	299	302	java/sql/SQLException
/*      */     //   373	381	384	java/sql/SQLException
/*      */     //   134	434	437	finally
/*      */     //   437	442	437	finally
/*      */     //   557	565	568	java/sql/SQLException
/*      */     //   461	695	703	finally
/*      */     //   703	708	703	finally
/*      */     //   56	698	727	finally
/*      */     //   703	732	727	finally
/*      */     //   7	700	782	finally
/*      */     //   703	786	782	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   protected synchronized int[] executeBatchedInserts(int batchTimeout)
/*      */     throws SQLException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual 198	com/mysql/jdbc/PreparedStatement:getValuesClause	()Ljava/lang/String;
/*      */     //   4: astore_2
/*      */     //   5: aload_0
/*      */     //   6: getfield 37	com/mysql/jdbc/PreparedStatement:connection	Lcom/mysql/jdbc/MySQLConnection;
/*      */     //   9: astore_3
/*      */     //   10: aload_2
/*      */     //   11: ifnonnull +9 -> 20
/*      */     //   14: aload_0
/*      */     //   15: iload_1
/*      */     //   16: invokevirtual 156	com/mysql/jdbc/PreparedStatement:executeBatchSerially	(I)[I
/*      */     //   19: areturn
/*      */     //   20: aload_0
/*      */     //   21: getfield 64	com/mysql/jdbc/PreparedStatement:batchedArgs	Ljava/util/List;
/*      */     //   24: invokeinterface 148 1 0
/*      */     //   29: istore 4
/*      */     //   31: aload_0
/*      */     //   32: getfield 114	com/mysql/jdbc/PreparedStatement:retrieveGeneratedKeys	Z
/*      */     //   35: ifeq +16 -> 51
/*      */     //   38: aload_0
/*      */     //   39: new 65	java/util/ArrayList
/*      */     //   42: dup
/*      */     //   43: iload 4
/*      */     //   45: invokespecial 165	java/util/ArrayList:<init>	(I)V
/*      */     //   48: putfield 122	com/mysql/jdbc/PreparedStatement:batchedGeneratedKeys	Ljava/util/ArrayList;
/*      */     //   51: aload_0
/*      */     //   52: iload 4
/*      */     //   54: invokevirtual 166	com/mysql/jdbc/PreparedStatement:computeBatchSize	(I)I
/*      */     //   57: istore 5
/*      */     //   59: iload 4
/*      */     //   61: iload 5
/*      */     //   63: if_icmpge +7 -> 70
/*      */     //   66: iload 4
/*      */     //   68: istore 5
/*      */     //   70: aconst_null
/*      */     //   71: astore 6
/*      */     //   73: iconst_1
/*      */     //   74: istore 7
/*      */     //   76: iconst_0
/*      */     //   77: istore 8
/*      */     //   79: iconst_0
/*      */     //   80: istore 9
/*      */     //   82: iconst_0
/*      */     //   83: istore 10
/*      */     //   85: aconst_null
/*      */     //   86: astore 11
/*      */     //   88: aconst_null
/*      */     //   89: astore 12
/*      */     //   91: iload 4
/*      */     //   93: newarray <illegal type>
/*      */     //   95: astore 13
/*      */     //   97: iconst_0
/*      */     //   98: istore 14
/*      */     //   100: iload 14
/*      */     //   102: aload_0
/*      */     //   103: getfield 64	com/mysql/jdbc/PreparedStatement:batchedArgs	Ljava/util/List;
/*      */     //   106: invokeinterface 148 1 0
/*      */     //   111: if_icmpge +15 -> 126
/*      */     //   114: aload 13
/*      */     //   116: iload 14
/*      */     //   118: iconst_1
/*      */     //   119: iastore
/*      */     //   120: iinc 14 1
/*      */     //   123: goto -23 -> 100
/*      */     //   126: aload_0
/*      */     //   127: aload_3
/*      */     //   128: iload 5
/*      */     //   130: invokevirtual 199	com/mysql/jdbc/PreparedStatement:prepareBatchedInsertSQL	(Lcom/mysql/jdbc/MySQLConnection;I)Lcom/mysql/jdbc/PreparedStatement;
/*      */     //   133: astore 6
/*      */     //   135: aload_3
/*      */     //   136: invokeinterface 172 1 0
/*      */     //   141: ifeq +47 -> 188
/*      */     //   144: iload_1
/*      */     //   145: ifeq +43 -> 188
/*      */     //   148: aload_3
/*      */     //   149: iconst_5
/*      */     //   150: iconst_0
/*      */     //   151: iconst_0
/*      */     //   152: invokeinterface 39 4 0
/*      */     //   157: ifeq +31 -> 188
/*      */     //   160: new 173	com/mysql/jdbc/StatementImpl$CancelTask
/*      */     //   163: dup
/*      */     //   164: aload_0
/*      */     //   165: aload 6
/*      */     //   167: checkcast 174	com/mysql/jdbc/StatementImpl
/*      */     //   170: invokespecial 175	com/mysql/jdbc/StatementImpl$CancelTask:<init>	(Lcom/mysql/jdbc/StatementImpl;Lcom/mysql/jdbc/StatementImpl;)V
/*      */     //   173: astore 11
/*      */     //   175: aload_3
/*      */     //   176: invokeinterface 176 1 0
/*      */     //   181: aload 11
/*      */     //   183: iload_1
/*      */     //   184: i2l
/*      */     //   185: invokevirtual 177	java/util/Timer:schedule	(Ljava/util/TimerTask;J)V
/*      */     //   188: iload 4
/*      */     //   190: iload 5
/*      */     //   192: if_icmpge +10 -> 202
/*      */     //   195: iload 4
/*      */     //   197: istore 9
/*      */     //   199: goto +10 -> 209
/*      */     //   202: iload 4
/*      */     //   204: iload 5
/*      */     //   206: idiv
/*      */     //   207: istore 9
/*      */     //   209: iload 9
/*      */     //   211: iload 5
/*      */     //   213: imul
/*      */     //   214: istore 14
/*      */     //   216: iconst_0
/*      */     //   217: istore 15
/*      */     //   219: iload 15
/*      */     //   221: iload 14
/*      */     //   223: if_icmpge +95 -> 318
/*      */     //   226: iload 15
/*      */     //   228: ifeq +60 -> 288
/*      */     //   231: iload 15
/*      */     //   233: iload 5
/*      */     //   235: irem
/*      */     //   236: ifne +52 -> 288
/*      */     //   239: iload 8
/*      */     //   241: aload 6
/*      */     //   243: invokeinterface 200 1 0
/*      */     //   248: iadd
/*      */     //   249: istore 8
/*      */     //   251: goto +21 -> 272
/*      */     //   254: astore 16
/*      */     //   256: aload_0
/*      */     //   257: iload 10
/*      */     //   259: iconst_1
/*      */     //   260: isub
/*      */     //   261: iload 5
/*      */     //   263: aload 13
/*      */     //   265: aload 16
/*      */     //   267: invokevirtual 179	com/mysql/jdbc/PreparedStatement:handleExceptionForBatch	(II[ILjava/sql/SQLException;)Ljava/sql/SQLException;
/*      */     //   270: astore 12
/*      */     //   272: aload_0
/*      */     //   273: aload 6
/*      */     //   275: invokevirtual 201	com/mysql/jdbc/PreparedStatement:getBatchedGeneratedKeys	(Ljava/sql/Statement;)V
/*      */     //   278: aload 6
/*      */     //   280: invokeinterface 181 1 0
/*      */     //   285: iconst_1
/*      */     //   286: istore 7
/*      */     //   288: aload_0
/*      */     //   289: aload 6
/*      */     //   291: iload 7
/*      */     //   293: aload_0
/*      */     //   294: getfield 64	com/mysql/jdbc/PreparedStatement:batchedArgs	Ljava/util/List;
/*      */     //   297: iload 10
/*      */     //   299: iinc 10 1
/*      */     //   302: invokeinterface 79 2 0
/*      */     //   307: invokevirtual 182	com/mysql/jdbc/PreparedStatement:setOneBatchedParameterSet	(Ljava/sql/PreparedStatement;ILjava/lang/Object;)I
/*      */     //   310: istore 7
/*      */     //   312: iinc 15 1
/*      */     //   315: goto -96 -> 219
/*      */     //   318: iload 8
/*      */     //   320: aload 6
/*      */     //   322: invokeinterface 200 1 0
/*      */     //   327: iadd
/*      */     //   328: istore 8
/*      */     //   330: goto +21 -> 351
/*      */     //   333: astore 15
/*      */     //   335: aload_0
/*      */     //   336: iload 10
/*      */     //   338: iconst_1
/*      */     //   339: isub
/*      */     //   340: iload 5
/*      */     //   342: aload 13
/*      */     //   344: aload 15
/*      */     //   346: invokevirtual 179	com/mysql/jdbc/PreparedStatement:handleExceptionForBatch	(II[ILjava/sql/SQLException;)Ljava/sql/SQLException;
/*      */     //   349: astore 12
/*      */     //   351: aload_0
/*      */     //   352: aload 6
/*      */     //   354: invokevirtual 201	com/mysql/jdbc/PreparedStatement:getBatchedGeneratedKeys	(Ljava/sql/Statement;)V
/*      */     //   357: iload 4
/*      */     //   359: iload 10
/*      */     //   361: isub
/*      */     //   362: istore 5
/*      */     //   364: jsr +14 -> 378
/*      */     //   367: goto +27 -> 394
/*      */     //   370: astore 17
/*      */     //   372: jsr +6 -> 378
/*      */     //   375: aload 17
/*      */     //   377: athrow
/*      */     //   378: astore 18
/*      */     //   380: aload 6
/*      */     //   382: ifnull +10 -> 392
/*      */     //   385: aload 6
/*      */     //   387: invokeinterface 183 1 0
/*      */     //   392: ret 18
/*      */     //   394: iload 5
/*      */     //   396: ifle +103 -> 499
/*      */     //   399: aload_0
/*      */     //   400: aload_3
/*      */     //   401: iload 5
/*      */     //   403: invokevirtual 199	com/mysql/jdbc/PreparedStatement:prepareBatchedInsertSQL	(Lcom/mysql/jdbc/MySQLConnection;I)Lcom/mysql/jdbc/PreparedStatement;
/*      */     //   406: astore 6
/*      */     //   408: aload 11
/*      */     //   410: ifnull +13 -> 423
/*      */     //   413: aload 11
/*      */     //   415: aload 6
/*      */     //   417: checkcast 174	com/mysql/jdbc/StatementImpl
/*      */     //   420: putfield 184	com/mysql/jdbc/StatementImpl$CancelTask:toCancel	Lcom/mysql/jdbc/StatementImpl;
/*      */     //   423: iconst_1
/*      */     //   424: istore 7
/*      */     //   426: iload 10
/*      */     //   428: iload 4
/*      */     //   430: if_icmpge +30 -> 460
/*      */     //   433: aload_0
/*      */     //   434: aload 6
/*      */     //   436: iload 7
/*      */     //   438: aload_0
/*      */     //   439: getfield 64	com/mysql/jdbc/PreparedStatement:batchedArgs	Ljava/util/List;
/*      */     //   442: iload 10
/*      */     //   444: iinc 10 1
/*      */     //   447: invokeinterface 79 2 0
/*      */     //   452: invokevirtual 182	com/mysql/jdbc/PreparedStatement:setOneBatchedParameterSet	(Ljava/sql/PreparedStatement;ILjava/lang/Object;)I
/*      */     //   455: istore 7
/*      */     //   457: goto -31 -> 426
/*      */     //   460: iload 8
/*      */     //   462: aload 6
/*      */     //   464: invokeinterface 200 1 0
/*      */     //   469: iadd
/*      */     //   470: istore 8
/*      */     //   472: goto +21 -> 493
/*      */     //   475: astore 14
/*      */     //   477: aload_0
/*      */     //   478: iload 10
/*      */     //   480: iconst_1
/*      */     //   481: isub
/*      */     //   482: iload 5
/*      */     //   484: aload 13
/*      */     //   486: aload 14
/*      */     //   488: invokevirtual 179	com/mysql/jdbc/PreparedStatement:handleExceptionForBatch	(II[ILjava/sql/SQLException;)Ljava/sql/SQLException;
/*      */     //   491: astore 12
/*      */     //   493: aload_0
/*      */     //   494: aload 6
/*      */     //   496: invokevirtual 201	com/mysql/jdbc/PreparedStatement:getBatchedGeneratedKeys	(Ljava/sql/Statement;)V
/*      */     //   499: aload 12
/*      */     //   501: ifnull +40 -> 541
/*      */     //   504: new 188	java/sql/BatchUpdateException
/*      */     //   507: dup
/*      */     //   508: aload 12
/*      */     //   510: invokevirtual 189	java/sql/SQLException:getMessage	()Ljava/lang/String;
/*      */     //   513: aload 12
/*      */     //   515: invokevirtual 190	java/sql/SQLException:getSQLState	()Ljava/lang/String;
/*      */     //   518: aload 12
/*      */     //   520: invokevirtual 191	java/sql/SQLException:getErrorCode	()I
/*      */     //   523: aload 13
/*      */     //   525: invokespecial 192	java/sql/BatchUpdateException:<init>	(Ljava/lang/String;Ljava/lang/String;I[I)V
/*      */     //   528: astore 14
/*      */     //   530: aload 14
/*      */     //   532: aload 12
/*      */     //   534: invokevirtual 193	java/sql/SQLException:initCause	(Ljava/lang/Throwable;)Ljava/lang/Throwable;
/*      */     //   537: pop
/*      */     //   538: aload 14
/*      */     //   540: athrow
/*      */     //   541: aload 13
/*      */     //   543: astore 14
/*      */     //   545: jsr +17 -> 562
/*      */     //   548: jsr +38 -> 586
/*      */     //   551: aload 14
/*      */     //   553: areturn
/*      */     //   554: astore 19
/*      */     //   556: jsr +6 -> 562
/*      */     //   559: aload 19
/*      */     //   561: athrow
/*      */     //   562: astore 20
/*      */     //   564: aload 6
/*      */     //   566: ifnull +10 -> 576
/*      */     //   569: aload 6
/*      */     //   571: invokeinterface 183 1 0
/*      */     //   576: ret 20
/*      */     //   578: astore 21
/*      */     //   580: jsr +6 -> 586
/*      */     //   583: aload 21
/*      */     //   585: athrow
/*      */     //   586: astore 22
/*      */     //   588: aload 11
/*      */     //   590: ifnull +19 -> 609
/*      */     //   593: aload 11
/*      */     //   595: invokevirtual 186	com/mysql/jdbc/StatementImpl$CancelTask:cancel	()Z
/*      */     //   598: pop
/*      */     //   599: aload_3
/*      */     //   600: invokeinterface 176 1 0
/*      */     //   605: invokevirtual 187	java/util/Timer:purge	()I
/*      */     //   608: pop
/*      */     //   609: aload_0
/*      */     //   610: invokevirtual 150	com/mysql/jdbc/PreparedStatement:resetCancelledState	()V
/*      */     //   613: ret 22
/*      */     // Line number table:
/*      */     //   Java source line #1698	-> byte code offset #0
/*      */     //   Java source line #1700	-> byte code offset #5
/*      */     //   Java source line #1702	-> byte code offset #10
/*      */     //   Java source line #1703	-> byte code offset #14
/*      */     //   Java source line #1706	-> byte code offset #20
/*      */     //   Java source line #1708	-> byte code offset #31
/*      */     //   Java source line #1709	-> byte code offset #38
/*      */     //   Java source line #1712	-> byte code offset #51
/*      */     //   Java source line #1714	-> byte code offset #59
/*      */     //   Java source line #1715	-> byte code offset #66
/*      */     //   Java source line #1718	-> byte code offset #70
/*      */     //   Java source line #1720	-> byte code offset #73
/*      */     //   Java source line #1721	-> byte code offset #76
/*      */     //   Java source line #1722	-> byte code offset #79
/*      */     //   Java source line #1723	-> byte code offset #82
/*      */     //   Java source line #1724	-> byte code offset #85
/*      */     //   Java source line #1725	-> byte code offset #88
/*      */     //   Java source line #1727	-> byte code offset #91
/*      */     //   Java source line #1729	-> byte code offset #97
/*      */     //   Java source line #1730	-> byte code offset #114
/*      */     //   Java source line #1729	-> byte code offset #120
/*      */     //   Java source line #1735	-> byte code offset #126
/*      */     //   Java source line #1738	-> byte code offset #135
/*      */     //   Java source line #1741	-> byte code offset #160
/*      */     //   Java source line #1743	-> byte code offset #175
/*      */     //   Java source line #1747	-> byte code offset #188
/*      */     //   Java source line #1748	-> byte code offset #195
/*      */     //   Java source line #1750	-> byte code offset #202
/*      */     //   Java source line #1754	-> byte code offset #209
/*      */     //   Java source line #1757	-> byte code offset #216
/*      */     //   Java source line #1758	-> byte code offset #226
/*      */     //   Java source line #1760	-> byte code offset #239
/*      */     //   Java source line #1765	-> byte code offset #251
/*      */     //   Java source line #1762	-> byte code offset #254
/*      */     //   Java source line #1763	-> byte code offset #256
/*      */     //   Java source line #1767	-> byte code offset #272
/*      */     //   Java source line #1768	-> byte code offset #278
/*      */     //   Java source line #1769	-> byte code offset #285
/*      */     //   Java source line #1773	-> byte code offset #288
/*      */     //   Java source line #1757	-> byte code offset #312
/*      */     //   Java source line #1779	-> byte code offset #318
/*      */     //   Java source line #1783	-> byte code offset #330
/*      */     //   Java source line #1780	-> byte code offset #333
/*      */     //   Java source line #1781	-> byte code offset #335
/*      */     //   Java source line #1785	-> byte code offset #351
/*      */     //   Java source line #1787	-> byte code offset #357
/*      */     //   Java source line #1788	-> byte code offset #364
/*      */     //   Java source line #1792	-> byte code offset #367
/*      */     //   Java source line #1789	-> byte code offset #370
/*      */     //   Java source line #1790	-> byte code offset #385
/*      */     //   Java source line #1795	-> byte code offset #394
/*      */     //   Java source line #1796	-> byte code offset #399
/*      */     //   Java source line #1800	-> byte code offset #408
/*      */     //   Java source line #1801	-> byte code offset #413
/*      */     //   Java source line #1804	-> byte code offset #423
/*      */     //   Java source line #1806	-> byte code offset #426
/*      */     //   Java source line #1807	-> byte code offset #433
/*      */     //   Java source line #1813	-> byte code offset #460
/*      */     //   Java source line #1817	-> byte code offset #472
/*      */     //   Java source line #1814	-> byte code offset #475
/*      */     //   Java source line #1815	-> byte code offset #477
/*      */     //   Java source line #1819	-> byte code offset #493
/*      */     //   Java source line #1822	-> byte code offset #499
/*      */     //   Java source line #1823	-> byte code offset #504
/*      */     //   Java source line #1826	-> byte code offset #530
/*      */     //   Java source line #1827	-> byte code offset #538
/*      */     //   Java source line #1830	-> byte code offset #541
/*      */     //   Java source line #1832	-> byte code offset #554
/*      */     //   Java source line #1833	-> byte code offset #569
/*      */     //   Java source line #1837	-> byte code offset #578
/*      */     //   Java source line #1838	-> byte code offset #593
/*      */     //   Java source line #1839	-> byte code offset #599
/*      */     //   Java source line #1842	-> byte code offset #609
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	615	0	this	PreparedStatement
/*      */     //   0	615	1	batchTimeout	int
/*      */     //   4	7	2	valuesClause	String
/*      */     //   9	591	3	locallyScopedConn	MySQLConnection
/*      */     //   29	400	4	numBatchedArgs	int
/*      */     //   57	426	5	numValuesPerBatch	int
/*      */     //   71	499	6	batchedStatement	java.sql.PreparedStatement
/*      */     //   74	382	7	batchedParamIndex	int
/*      */     //   77	394	8	updateCountRunningTotal	int
/*      */     //   80	130	9	numberToExecuteAsMultiValue	int
/*      */     //   83	396	10	batchCounter	int
/*      */     //   86	508	11	timeoutTask	StatementImpl.CancelTask
/*      */     //   89	444	12	sqlEx	SQLException
/*      */     //   95	447	13	updateCounts	int[]
/*      */     //   98	23	14	i	int
/*      */     //   214	8	14	numberArgsToExecute	int
/*      */     //   475	12	14	ex	SQLException
/*      */     //   528	24	14	batchUpdateException	SQLException
/*      */     //   217	96	15	i	int
/*      */     //   333	12	15	ex	SQLException
/*      */     //   254	12	16	ex	SQLException
/*      */     //   370	6	17	localObject1	Object
/*      */     //   378	1	18	localObject2	Object
/*      */     //   554	6	19	localObject3	Object
/*      */     //   562	1	20	localObject4	Object
/*      */     //   578	6	21	localObject5	Object
/*      */     //   586	1	22	localObject6	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   239	251	254	java/sql/SQLException
/*      */     //   318	330	333	java/sql/SQLException
/*      */     //   126	367	370	finally
/*      */     //   370	375	370	finally
/*      */     //   460	472	475	java/sql/SQLException
/*      */     //   394	548	554	finally
/*      */     //   554	559	554	finally
/*      */     //   126	551	578	finally
/*      */     //   554	583	578	finally
/*      */   }
/*      */ }


/* Location:              C:\Users\Static\Desktop\G10_Prototype_Server.jar!\mysql-connector-java-5.1.19-bin.jar!\com\mysql\jdbc\PreparedStatement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */