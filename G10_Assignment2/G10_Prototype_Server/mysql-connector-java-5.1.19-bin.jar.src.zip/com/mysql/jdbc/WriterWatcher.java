package com.mysql.jdbc;

abstract interface WriterWatcher
{
  public abstract void writerClosed(WatchableWriter paramWatchableWriter);
}


/* Location:              C:\Users\Static\Desktop\G10_Prototype_Server.jar!\mysql-connector-java-5.1.19-bin.jar!\com\mysql\jdbc\WriterWatcher.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */