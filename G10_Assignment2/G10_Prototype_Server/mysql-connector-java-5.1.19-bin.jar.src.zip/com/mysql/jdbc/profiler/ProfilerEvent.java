/*     */ package com.mysql.jdbc.profiler;
/*     */ 
/*     */ import com.mysql.jdbc.StringUtils;
/*     */ import com.mysql.jdbc.Util;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProfilerEvent
/*     */ {
/*     */   public static final byte TYPE_WARN = 0;
/*     */   public static final byte TYPE_OBJECT_CREATION = 1;
/*     */   public static final byte TYPE_PREPARE = 2;
/*     */   public static final byte TYPE_QUERY = 3;
/*     */   public static final byte TYPE_EXECUTE = 4;
/*     */   public static final byte TYPE_FETCH = 5;
/*     */   public static final byte TYPE_SLOW_QUERY = 6;
/*     */   protected byte eventType;
/*     */   protected long connectionId;
/*     */   protected int statementId;
/*     */   protected int resultSetId;
/*     */   protected long eventCreationTime;
/*     */   protected long eventDuration;
/*     */   protected String durationUnits;
/*     */   protected int hostNameIndex;
/*     */   protected String hostName;
/*     */   protected int catalogIndex;
/*     */   protected String catalog;
/*     */   protected int eventCreationPointIndex;
/*     */   protected Throwable eventCreationPoint;
/*     */   protected String eventCreationPointDesc;
/*     */   protected String message;
/*     */   
/*     */   public ProfilerEvent(byte eventType, String hostName, String catalog, long connectionId, int statementId, int resultSetId, long eventCreationTime, long eventDuration, String durationUnits, String eventCreationPointDesc, Throwable eventCreationPoint, String message)
/*     */   {
/* 182 */     this.eventType = eventType;
/* 183 */     this.connectionId = connectionId;
/* 184 */     this.statementId = statementId;
/* 185 */     this.resultSetId = resultSetId;
/* 186 */     this.eventCreationTime = eventCreationTime;
/* 187 */     this.eventDuration = eventDuration;
/* 188 */     this.durationUnits = durationUnits;
/* 189 */     this.eventCreationPoint = eventCreationPoint;
/* 190 */     this.eventCreationPointDesc = eventCreationPointDesc;
/* 191 */     this.message = message;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getEventCreationPointAsString()
/*     */   {
/* 200 */     if (this.eventCreationPointDesc == null) {
/* 201 */       this.eventCreationPointDesc = Util.stackTraceToString(this.eventCreationPoint);
/*     */     }
/*     */     
/*     */ 
/* 205 */     return this.eventCreationPointDesc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 214 */     StringBuffer buf = new StringBuffer(32);
/*     */     
/* 216 */     switch (this.eventType) {
/*     */     case 4: 
/* 218 */       buf.append("EXECUTE");
/* 219 */       break;
/*     */     
/*     */     case 5: 
/* 222 */       buf.append("FETCH");
/* 223 */       break;
/*     */     
/*     */     case 1: 
/* 226 */       buf.append("CONSTRUCT");
/* 227 */       break;
/*     */     
/*     */     case 2: 
/* 230 */       buf.append("PREPARE");
/* 231 */       break;
/*     */     
/*     */     case 3: 
/* 234 */       buf.append("QUERY");
/* 235 */       break;
/*     */     
/*     */     case 0: 
/* 238 */       buf.append("WARN");
/* 239 */       break;
/*     */     case 6: 
/* 241 */       buf.append("SLOW QUERY");
/* 242 */       break;
/*     */     default: 
/* 244 */       buf.append("UNKNOWN");
/*     */     }
/*     */     
/* 247 */     buf.append(" created: ");
/* 248 */     buf.append(new Date(this.eventCreationTime));
/* 249 */     buf.append(" duration: ");
/* 250 */     buf.append(this.eventDuration);
/* 251 */     buf.append(" connection: ");
/* 252 */     buf.append(this.connectionId);
/* 253 */     buf.append(" statement: ");
/* 254 */     buf.append(this.statementId);
/* 255 */     buf.append(" resultset: ");
/* 256 */     buf.append(this.resultSetId);
/*     */     
/* 258 */     if (this.message != null) {
/* 259 */       buf.append(" message: ");
/* 260 */       buf.append(this.message);
/*     */     }
/*     */     
/*     */ 
/* 264 */     if (this.eventCreationPointDesc != null) {
/* 265 */       buf.append("\n\nEvent Created at:\n");
/* 266 */       buf.append(this.eventCreationPointDesc);
/*     */     }
/*     */     
/* 269 */     return buf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ProfilerEvent unpack(byte[] buf)
/*     */     throws Exception
/*     */   {
/* 282 */     int pos = 0;
/*     */     
/* 284 */     byte eventType = buf[(pos++)];
/* 285 */     long connectionId = readInt(buf, pos);
/* 286 */     pos += 8;
/* 287 */     int statementId = readInt(buf, pos);
/* 288 */     pos += 4;
/* 289 */     int resultSetId = readInt(buf, pos);
/* 290 */     pos += 4;
/* 291 */     long eventCreationTime = readLong(buf, pos);
/* 292 */     pos += 8;
/* 293 */     long eventDuration = readLong(buf, pos);
/* 294 */     pos += 4;
/*     */     
/* 296 */     byte[] eventDurationUnits = readBytes(buf, pos);
/* 297 */     pos += 4;
/*     */     
/* 299 */     if (eventDurationUnits != null) {
/* 300 */       pos += eventDurationUnits.length;
/*     */     }
/*     */     
/* 303 */     readInt(buf, pos);
/* 304 */     pos += 4;
/* 305 */     byte[] eventCreationAsBytes = readBytes(buf, pos);
/* 306 */     pos += 4;
/*     */     
/* 308 */     if (eventCreationAsBytes != null) {
/* 309 */       pos += eventCreationAsBytes.length;
/*     */     }
/*     */     
/* 312 */     byte[] message = readBytes(buf, pos);
/* 313 */     pos += 4;
/*     */     
/* 315 */     if (message != null) {
/* 316 */       pos += message.length;
/*     */     }
/*     */     
/* 319 */     return new ProfilerEvent(eventType, "", "", connectionId, statementId, resultSetId, eventCreationTime, eventDuration, StringUtils.toString(eventDurationUnits, "ISO8859_1"), StringUtils.toString(eventCreationAsBytes, "ISO8859_1"), null, StringUtils.toString(message, "ISO8859_1"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] pack()
/*     */     throws Exception
/*     */   {
/* 335 */     int len = 29;
/*     */     
/* 337 */     byte[] eventCreationAsBytes = null;
/*     */     
/* 339 */     getEventCreationPointAsString();
/*     */     
/* 341 */     if (this.eventCreationPointDesc != null) {
/* 342 */       eventCreationAsBytes = StringUtils.getBytes(this.eventCreationPointDesc, "ISO8859_1");
/*     */       
/* 344 */       len += 4 + eventCreationAsBytes.length;
/*     */     } else {
/* 346 */       len += 4;
/*     */     }
/*     */     
/* 349 */     byte[] messageAsBytes = null;
/*     */     
/* 351 */     if (messageAsBytes != null) {
/* 352 */       messageAsBytes = StringUtils.getBytes(this.message, "ISO8859_1");
/* 353 */       len += 4 + messageAsBytes.length;
/*     */     } else {
/* 355 */       len += 4;
/*     */     }
/*     */     
/* 358 */     byte[] durationUnitsAsBytes = null;
/*     */     
/* 360 */     if (this.durationUnits != null) {
/* 361 */       durationUnitsAsBytes = StringUtils.getBytes(this.durationUnits, "ISO8859_1");
/* 362 */       len += 4 + durationUnitsAsBytes.length;
/*     */     } else {
/* 364 */       len += 4;
/* 365 */       durationUnitsAsBytes = StringUtils.getBytes("", "ISO8859_1");
/*     */     }
/*     */     
/* 368 */     byte[] buf = new byte[len];
/*     */     
/* 370 */     int pos = 0;
/*     */     
/* 372 */     buf[(pos++)] = this.eventType;
/* 373 */     pos = writeLong(this.connectionId, buf, pos);
/* 374 */     pos = writeInt(this.statementId, buf, pos);
/* 375 */     pos = writeInt(this.resultSetId, buf, pos);
/* 376 */     pos = writeLong(this.eventCreationTime, buf, pos);
/* 377 */     pos = writeLong(this.eventDuration, buf, pos);
/* 378 */     pos = writeBytes(durationUnitsAsBytes, buf, pos);
/* 379 */     pos = writeInt(this.eventCreationPointIndex, buf, pos);
/*     */     
/* 381 */     if (eventCreationAsBytes != null) {
/* 382 */       pos = writeBytes(eventCreationAsBytes, buf, pos);
/*     */     } else {
/* 384 */       pos = writeInt(0, buf, pos);
/*     */     }
/*     */     
/* 387 */     if (messageAsBytes != null) {
/* 388 */       pos = writeBytes(messageAsBytes, buf, pos);
/*     */     } else {
/* 390 */       pos = writeInt(0, buf, pos);
/*     */     }
/*     */     
/* 393 */     return buf;
/*     */   }
/*     */   
/*     */   private static int writeInt(int i, byte[] buf, int pos)
/*     */   {
/* 398 */     buf[(pos++)] = ((byte)(i & 0xFF));
/* 399 */     buf[(pos++)] = ((byte)(i >>> 8));
/* 400 */     buf[(pos++)] = ((byte)(i >>> 16));
/* 401 */     buf[(pos++)] = ((byte)(i >>> 24));
/*     */     
/* 403 */     return pos;
/*     */   }
/*     */   
/*     */   private static int writeLong(long l, byte[] buf, int pos) {
/* 407 */     buf[(pos++)] = ((byte)(int)(l & 0xFF));
/* 408 */     buf[(pos++)] = ((byte)(int)(l >>> 8));
/* 409 */     buf[(pos++)] = ((byte)(int)(l >>> 16));
/* 410 */     buf[(pos++)] = ((byte)(int)(l >>> 24));
/* 411 */     buf[(pos++)] = ((byte)(int)(l >>> 32));
/* 412 */     buf[(pos++)] = ((byte)(int)(l >>> 40));
/* 413 */     buf[(pos++)] = ((byte)(int)(l >>> 48));
/* 414 */     buf[(pos++)] = ((byte)(int)(l >>> 56));
/*     */     
/* 416 */     return pos;
/*     */   }
/*     */   
/*     */   private static int writeBytes(byte[] msg, byte[] buf, int pos) {
/* 420 */     pos = writeInt(msg.length, buf, pos);
/*     */     
/* 422 */     System.arraycopy(msg, 0, buf, pos, msg.length);
/*     */     
/* 424 */     return pos + msg.length;
/*     */   }
/*     */   
/*     */   private static int readInt(byte[] buf, int pos) {
/* 428 */     return buf[(pos++)] & 0xFF | (buf[(pos++)] & 0xFF) << 8 | (buf[(pos++)] & 0xFF) << 16 | (buf[(pos++)] & 0xFF) << 24;
/*     */   }
/*     */   
/*     */ 
/*     */   private static long readLong(byte[] buf, int pos)
/*     */   {
/* 434 */     return buf[(pos++)] & 0xFF | (buf[(pos++)] & 0xFF) << 8 | (buf[(pos++)] & 0xFF) << 16 | (buf[(pos++)] & 0xFF) << 24 | (buf[(pos++)] & 0xFF) << 32 | (buf[(pos++)] & 0xFF) << 40 | (buf[(pos++)] & 0xFF) << 48 | (buf[(pos++)] & 0xFF) << 56;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static byte[] readBytes(byte[] buf, int pos)
/*     */   {
/* 444 */     int length = readInt(buf, pos);
/*     */     
/* 446 */     pos += 4;
/*     */     
/* 448 */     byte[] msg = new byte[length];
/* 449 */     System.arraycopy(buf, pos, msg, 0, length);
/*     */     
/* 451 */     return msg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCatalog()
/*     */   {
/* 460 */     return this.catalog;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getConnectionId()
/*     */   {
/* 469 */     return this.connectionId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Throwable getEventCreationPoint()
/*     */   {
/* 479 */     return this.eventCreationPoint;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getEventCreationTime()
/*     */   {
/* 489 */     return this.eventCreationTime;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getEventDuration()
/*     */   {
/* 498 */     return this.eventDuration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getDurationUnits()
/*     */   {
/* 505 */     return this.durationUnits;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte getEventType()
/*     */   {
/* 514 */     return this.eventType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getResultSetId()
/*     */   {
/* 523 */     return this.resultSetId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getStatementId()
/*     */   {
/* 532 */     return this.statementId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage()
/*     */   {
/* 541 */     return this.message;
/*     */   }
/*     */ }


/* Location:              C:\Users\Static\Desktop\G10_Prototype_Server.jar!\mysql-connector-java-5.1.19-bin.jar!\com\mysql\jdbc\profiler\ProfilerEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */